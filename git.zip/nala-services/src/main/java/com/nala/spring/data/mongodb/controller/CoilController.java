package com.nala.spring.data.mongodb.controller;

public class CoilController {

}
