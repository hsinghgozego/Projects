package com.nala.spring.data.mongodb.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Burner {

}
