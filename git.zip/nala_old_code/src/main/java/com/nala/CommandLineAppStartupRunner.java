package com.nala;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nala.service.NalaCoreService;

@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {
	
	@Autowired
	NalaCoreService nalaCoreService;

	@Override
	public void run(String... args) throws Exception {
		nalaCoreService.startNalCoreProcess();
	}

}
