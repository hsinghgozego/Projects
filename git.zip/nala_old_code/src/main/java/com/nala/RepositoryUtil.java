package com.nala;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import com.nala.repository.BurnerRegistersRepository;

@Component
@ComponentScan(basePackages = "com.nala")
public class RepositoryUtil {
	
	@Autowired
	private BurnerRegistersRepository burnerRegistersRepository;

}
