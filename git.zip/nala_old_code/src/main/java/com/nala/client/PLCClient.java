package com.nala.client;

import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.nala.service.tasks.PLCProcess;

import de.re.easymodbus.exceptions.ModbusException;
import de.re.easymodbus.modbusclient.ModbusClient;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PLCClient {

	private static final Logger log = LoggerFactory.getLogger(PLCClient.class);
	private static final String IP_ADDR = "192.168.2.245";
	private static final Integer PORT = 502;

	private static final ModbusClient modbusClient = new ModbusClient(IP_ADDR, PORT);

	public static ModbusClient getModbusClientInstance() {
		return modbusClient;
	}

	private static final Integer COIL_STRAT_ADDRESS = 5000;
	private static final Integer NO_OF_COILS_TO_READ = 1990;

	public boolean invokeWriteToRegisterAPI(Integer burnerAddress, Integer actionId, String recipeName) {
		boolean invokeAPISuccess = false;
		try {
			modbusClient.Connect();
			modbusClient.WriteSingleRegister(burnerAddress, actionId);
			log.info("Writing to Address:" + modbusClient.ReadInputRegisters(burnerAddress, 1));
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			log.info("*************** UnknownHostException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (SocketException e) {
			log.info("*************** SocketException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (ModbusException e) {
			log.info("*************** ModbusException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (IOException e) {
			log.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (Exception e) {
			log.info("*************** ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} finally {
			if (modbusClient != null) {
				try {
					modbusClient.Disconnect();
				} catch (IOException e) {
					log.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}

	public void invokePrintReadHoldingRegistersAPI(String recipeName, Integer actionId, Integer registerAddress,
			int registerCount) {
		int[] registerValues = new int[registerCount];
		try {
			modbusClient.Connect();
			registerValues = modbusClient.ReadHoldingRegisters(registerAddress, registerCount);
			for (int i = 0; i < registerValues.length; i++) {
				log.info("Recipe - " + recipeName + " with Action - " + actionId + "Read Address: "
						+ (registerAddress + i) + " - " + registerValues[i]);
			}
		} catch (UnknownHostException e) {
			log.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			log.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			log.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			log.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} finally {
			if (modbusClient != null) {
				try {
					modbusClient.Disconnect();
				} catch (IOException e) {
					log.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}
	}

	public boolean[] invokeReadCoilsAPI() {
		boolean[] status = null;
		try {
			modbusClient.Connect();
			status = modbusClient.ReadCoils(COIL_STRAT_ADDRESS, NO_OF_COILS_TO_READ);
		} catch (UnknownHostException e) {
			log.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			log.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			log.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			log.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} finally {
			if (modbusClient != null) {
				try {
					modbusClient.Disconnect();
				} catch (IOException e) {
					log.info("*************** IOException ERROR IN EXECUTING: ");
					e.printStackTrace();
				}
			}
		}

		return status;
	}

	public boolean invokeWriteMultipleRegistersAPI(Integer burnerAddress, Integer actionId, String recipeName) {
		boolean invokeAPISuccess = false;
		try {
			modbusClient.Connect();
			int[] a = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			modbusClient.WriteMultipleRegisters(burnerAddress, a);
			log.info("Writing to Address:" + modbusClient.ReadInputRegisters(burnerAddress, 1));
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			log.info("*************** UnknownHostException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (SocketException e) {
			log.info("*************** SocketException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (ModbusException e) {
			log.info("*************** ModbusException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (IOException e) {
			log.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (Exception e) {
			log.info("*************** ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} finally {
			if (modbusClient != null) {
				try {
					modbusClient.Disconnect();
				} catch (IOException e) {
					log.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}
	
	public boolean getActionDoneAddress(int startAddress, int quantity) {

		boolean status = false;
		try {
			modbusClient.Connect();
			modbusClient.WriteSingleCoil(startAddress, true);
			status = modbusClient.ReadCoils(startAddress, quantity)[0];
		} catch (UnknownHostException e) {
			System.out.println("*************** ERROR IN EXECUTING getActionDoneAddress()");
			e.printStackTrace();
		} catch (SocketException e) {
			System.out.println("*************** ERROR IN EXECUTING getActionDoneAddress()");
			e.printStackTrace();
		} catch (ModbusException e) {
			System.out.println("*************** ERROR IN EXECUTING getActionDoneAddress()");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("*************** ERROR IN EXECUTING getActionDoneAddress()");
			e.printStackTrace();
		} finally {
			if (modbusClient != null) {
				try {
					modbusClient.Disconnect();
				} catch (IOException e) {
					System.out.println("*************** IOException ERROR IN READING COILS");
					e.printStackTrace();
				}
			}
		}
		return status;
	}
	
	public boolean writeAllRegistersWithZero(List<Integer> addressList) {
		boolean flag = false;
		try {
			modbusClient.Connect();
			for (Integer address : addressList) {
				modbusClient.WriteSingleRegister(address, 0);
			}
			modbusClient.Disconnect();
			flag = true;
		} catch (UnknownHostException e) {
			System.out.println("*************** ERROR IN EXECUTING writeAllRegistersWithZero ");
			e.printStackTrace();
		} catch (SocketException e) {
			System.out.println("*************** ERROR IN EXECUTING writeAllRegistersWithZero ");
			e.printStackTrace();
		} catch (ModbusException e) {
			System.out.println("*************** ERROR IN EXECUTING writeAllRegistersWithZero ");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("*************** ERROR IN EXECUTING writeAllRegistersWithZero ");
			e.printStackTrace();
		} finally {
			if (modbusClient != null) {
				try {
					modbusClient.Disconnect();
				} catch (IOException e) {
					System.out.println("*************** IOException ERROR IN READING COILS");
					e.printStackTrace();
				}
			}
		}
		return flag;
	}

}
