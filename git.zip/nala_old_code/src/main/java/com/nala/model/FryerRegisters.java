package com.nala.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Data
@Getter
@Setter
@ToString
@Document
public class FryerRegisters {

	@Id
	private ObjectId id;

	Integer fryerRegisterId;

	Integer actionId;

	String actionName;

	String typeOfAction;

	Integer fryer1Pool1;

	Integer fryer1Pool2;

	Integer fryer1Pool3;

	Integer fryer1Pool4;

	Integer fryer2Pool1;

	Integer fryer2Pool2;

	Integer fryer2Pool3;

	Integer fryer2Pool4;

	String description;

	String javaPreOperations;

	String javaPostOperations;

	String plcOperations;

	Integer operationType;

}
