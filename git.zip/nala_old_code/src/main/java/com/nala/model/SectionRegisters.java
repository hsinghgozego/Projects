package com.nala.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Data
@Getter
@Setter
@ToString
@Document
public class SectionRegisters {

	@Id
	private ObjectId id;

	Integer sectionRegisterId;

	Integer actionId;

	String actionName;

	String typeOfAction;

	Integer section1;

	Integer section2;

	Integer section3;

	Integer section4;

	Integer section5;

	Integer section6;

	Integer section7;

	Integer section8;

	Integer section9;

	Integer section10;

	Integer section11;

	Integer section12;

	Integer section13;

	Integer section14;

	Integer section15;

	Integer section16;

	Integer section17;

	Integer section18;

	Integer section19;

	Integer section20;

	String description;

	String javaPreOperations;

	String javaPostOperations;

	String plcOperations;

	Integer operationType;

}
