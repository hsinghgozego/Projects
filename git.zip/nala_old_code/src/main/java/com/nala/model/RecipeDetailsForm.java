package com.nala.model;

import java.util.List;

public class RecipeDetailsForm {
	
	private List<RecipeDetail> recipeDetails;

	public List<RecipeDetail> getRecipeDetails() {
		return recipeDetails;
	}

	public void setRecipeDetails(List<RecipeDetail> recipeDetails) {
		this.recipeDetails = recipeDetails;
	}

}
