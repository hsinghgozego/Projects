package com.nala.model.actions;

public class VegCollection {
	
	private int vegColwrite;
	
	private int binNumberWrite;
	
	private int weight;
	
	private int vegColRead;
	
	private int binNumberRead;
	
	private int achievedWeight;
	
	private int operationRunTime;
	
	private int weighingOperationRunTime;
	
	private int cutOffInPct;
	
	private int normalOperationInPct;
	
	private int normalOperationSpeed;
	
	private int inchingOperationSpeed;
	
	private int gapBtwNormalAndInch;
	
	private int gapBtwInching;
	
	private int inchingTime;

	public int getVegColwrite() {
		return vegColwrite;
	}

	public void setVegColwrite(int vegColwrite) {
		this.vegColwrite = vegColwrite;
	}

	public int getBinNumberWrite() {
		return binNumberWrite;
	}

	public void setBinNumberWrite(int binNumberWrite) {
		this.binNumberWrite = binNumberWrite;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getVegColRead() {
		return vegColRead;
	}

	public void setVegColRead(int vegColRead) {
		this.vegColRead = vegColRead;
	}

	public int getBinNumberRead() {
		return binNumberRead;
	}

	public void setBinNumberRead(int binNumberRead) {
		this.binNumberRead = binNumberRead;
	}

	public int getAchievedWeight() {
		return achievedWeight;
	}

	public void setAchievedWeight(int achievedWeight) {
		this.achievedWeight = achievedWeight;
	}

	public int getOperationRunTime() {
		return operationRunTime;
	}

	public void setOperationRunTime(int operationRunTime) {
		this.operationRunTime = operationRunTime;
	}

	public int getWeighingOperationRunTime() {
		return weighingOperationRunTime;
	}

	public void setWeighingOperationRunTime(int weighingOperationRunTime) {
		this.weighingOperationRunTime = weighingOperationRunTime;
	}

	public int getCutOffInPct() {
		return cutOffInPct;
	}

	public void setCutOffInPct(int cutOffInPct) {
		this.cutOffInPct = cutOffInPct;
	}

	public int getNormalOperationInPct() {
		return normalOperationInPct;
	}

	public void setNormalOperationInPct(int normalOperationInPct) {
		this.normalOperationInPct = normalOperationInPct;
	}

	public int getNormalOperationSpeed() {
		return normalOperationSpeed;
	}

	public void setNormalOperationSpeed(int normalOperationSpeed) {
		this.normalOperationSpeed = normalOperationSpeed;
	}

	public int getInchingOperationSpeed() {
		return inchingOperationSpeed;
	}

	public void setInchingOperationSpeed(int inchingOperationSpeed) {
		this.inchingOperationSpeed = inchingOperationSpeed;
	}

	public int getGapBtwNormalAndInch() {
		return gapBtwNormalAndInch;
	}

	public void setGapBtwNormalAndInch(int gapBtwNormalAndInch) {
		this.gapBtwNormalAndInch = gapBtwNormalAndInch;
	}

	public int getGapBtwInching() {
		return gapBtwInching;
	}

	public void setGapBtwInching(int gapBtwInching) {
		this.gapBtwInching = gapBtwInching;
	}

	public int getInchingTime() {
		return inchingTime;
	}

	public void setInchingTime(int inchingTime) {
		this.inchingTime = inchingTime;
	}

	@Override
	public String toString() {
		return "VegCollection [vegColwrite=" + vegColwrite + ", binNumberWrite=" + binNumberWrite + ", weight=" + weight
				+ ", vegColRead=" + vegColRead + ", binNumberRead=" + binNumberRead + ", achievedWeight="
				+ achievedWeight + ", operationRunTime=" + operationRunTime + ", weighingOperationRunTime="
				+ weighingOperationRunTime + ", cutOffInPct=" + cutOffInPct + ", normalOperationInPct="
				+ normalOperationInPct + ", normalOperationSpeed=" + normalOperationSpeed + ", inchingOperationSpeed="
				+ inchingOperationSpeed + ", gapBtwNormalAndInch=" + gapBtwNormalAndInch + ", gapBtwInching="
				+ gapBtwInching + ", inchingTime=" + inchingTime + "]";
	}


}
