package com.nala.model.actions;

public class SpatulaPick {
	
	private int pickWrite;
	
	private int typeWrite;
	
	private int pickRead;
	
	private int typeRead;
	
	private int operationRunTime;

	public int getPickWrite() {
		return pickWrite;
	}

	public void setPickWrite(int pickWrite) {
		this.pickWrite = pickWrite;
	}

	public int getTypeWrite() {
		return typeWrite;
	}

	public void setTypeWrite(int typeWrite) {
		this.typeWrite = typeWrite;
	}

	public int getPickRead() {
		return pickRead;
	}

	public void setPickRead(int pickRead) {
		this.pickRead = pickRead;
	}

	public int getTypeRead() {
		return typeRead;
	}

	public void setTypeRead(int typeRead) {
		this.typeRead = typeRead;
	}

	public int getOperationRunTime() {
		return operationRunTime;
	}

	public void setOperationRunTime(int operationRunTime) {
		this.operationRunTime = operationRunTime;
	}

	@Override
	public String toString() {
		return "SpatulaPick [pickWrite=" + pickWrite + ", typeWrite=" + typeWrite + ", pickRead=" + pickRead
				+ ", typeRead=" + typeRead + ", operationRunTime=" + operationRunTime + "]";
	}

}
