package com.nala.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Data
@Getter
@Setter
@ToString
@Document
public class BurnerRegisters {

	@Id
	private ObjectId id;

	Integer burnerRegisterId;

	Integer actionId;

	String actionName;

	String typeOfAction;

	Integer burner1;

	Integer burner2;

	Integer burner3;

	Integer burner4;

	Integer burner5;

	Integer burner6;

	Integer burner7;

	Integer burner8;

	String description;

	String javaPreOperations;

	String javaPostOperations;

	String plcOperations;
	
	Integer operationType;

	public Integer getBurner1() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getOperationType() {
		// TODO Auto-generated method stub
		return null;
	}

}
