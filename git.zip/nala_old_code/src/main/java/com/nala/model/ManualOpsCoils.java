package com.nala.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Data
@Getter
@Setter
@ToString
@Document
public class ManualOpsCoils {

	@Id
	private ObjectId id;

	Integer manualOpsCoilId;
	
	String clasType1;
	
	String clasType2;
	
	String clasType3;
	
	String type;
	
	String buttonType;

	String javaPreOperations;

	Integer registerNo;
	
	Integer operationType;

}
