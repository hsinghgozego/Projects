package com.nala.action.enums;

public interface Labeled {
	
    String label();

}
