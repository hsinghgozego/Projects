package com.nala.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.nala.action.enums.Status;

abstract class AbstractAction implements Action {
	
	private Status status;
	
	private int timeout;
		
	private long elapsedTimeAction;
	
    public synchronized void setStatus(Status status) {
    	System.out.println("UtensilPick setStatus()");
    	this.status = status;
    }
	
	public synchronized Status getStatus() {
		System.out.println("UtensilPick getStatus()");
		return this.status;
	}
		
	public void setTimeout(int timeout) {
		this.timeout = timeout;
		this.elapsedTimeAction = System.currentTimeMillis() + (timeout*1000);
	}
	
	public boolean isTimeOut() {
	   if(System.currentTimeMillis() >= this.elapsedTimeAction) {
          return true;
	   } else {
	     return false;
	   }
	}
	
}
