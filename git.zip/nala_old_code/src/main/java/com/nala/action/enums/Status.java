package com.nala.action.enums;

public enum Status {
	Unprocessed,
	Executing,
	Jobdone,
	Complete
}

