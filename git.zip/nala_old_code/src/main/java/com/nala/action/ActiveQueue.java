package com.nala.action;

import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nala.action.enums.Status;
import com.nala.controller.BurnerController;
import com.nala.model.BurnerRegisters;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ActiveQueue {
	
	private CopyOnWriteArrayList<Action<BurnerRegisters>> actionsList = new CopyOnWriteArrayList<Action<BurnerRegisters>>();
	
	private static final Logger log = LoggerFactory.getLogger(ActiveQueue.class);
	
	public CopyOnWriteArrayList<Action<BurnerRegisters>> getActionsList(){
		log.info("ActiveQueue getActionsList()");
		Action<BurnerRegisters> action = new UtensilPick<BurnerRegisters>();
		action.setStatus(Status.Jobdone);
		actionsList.add(action);
		return actionsList;
	}
}
