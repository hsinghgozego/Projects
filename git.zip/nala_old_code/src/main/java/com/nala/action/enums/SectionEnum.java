package com.nala.action.enums;

public enum SectionEnum {
	
	SECTION1("section1", 1),
	SECTION2("section2", 2),
	SECTION3("section3", 3),
	SECTION4("section4", 4),
	SECTION5("section5", 5),
	SECTION6("section6", 6),
	SECTION7("section7", 7),
	SECTION8("section8", 8),
	SECTION9("section9", 9),
	SECTION10("section10", 10),
	SECTION11("section11", 11),
	SECTION12("section12", 12),
	SECTION13("section13", 13),
	SECTION14("section14", 14),
	SECTION15("section15", 15),
	SECTION16("section16", 16),
	SECTION17("section17", 17),
	SECTION18("section18", 18),
	SECTION19("section19", 19),
	SECTION20("section20", 20);

	private final String sectionName;

	private final int sectionNo;
	
	private SectionEnum(String sectionName, int sectionNo) {
		this.sectionName = sectionName;
		this.sectionNo = sectionNo;
	}

	public String getSectionName() {
		return sectionName;
	}

	public int getSectionNo() {
		return sectionNo;
	}

}
