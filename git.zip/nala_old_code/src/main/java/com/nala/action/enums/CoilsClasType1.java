package com.nala.action.enums;

public enum CoilsClasType1 {
	
	ALARMS,
	BURNER,
	FRYER,
	HEALTHY_CHECKS,
	LIQUID,
	ROBOT,
	SECTION,
	STATUS,
	SYSTEM;

}
