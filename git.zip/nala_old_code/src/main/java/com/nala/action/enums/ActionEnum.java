package com.nala.action.enums;

import java.util.HashMap;
import java.util.Map;

public enum ActionEnum implements Labeled {
	
	IGNITION("IGNITION", 1, 10, 2, 2),
	DELAY("DELAY", 2, 10, 2, 2),
	UTENSIL_PICK("UTENSIL_PICK", 3, 10, 4, 6),
	SPATULA_PICK("SPATULA_PICK", 4, 10, 4, 6),
	STIRR("STIRR", 5, 10, 5, 5),
	TOSS("TOSS", 6, 10, 4, 4),
	LIQUID_DISP("LIQUID_DISP", 7, 50, 22, 23),
	SERVE("SERVE", 8, 10, 3, 4),
	FRYER_IGNITION("FRYER_IGNITION", 21, 10, 2, 2),
	FRYER_TEMP_SET("FRYER_TEMP_SET", 22, 10, 2, 3),
	FRYER_BASKET_PICK("FRYER_BASKET_PICK", 23, 10, 3, 5),
	FRYER_SPATULA_PICK("FRYER_SPATULA_PICK", 24, 10, 3, 5),
	FRYER_BASKET_DIP_LIFT("FRYER_BASKET_DIP_LIFT", 25, 10, 3, 4),
	FRYER_FRYING("FRYER_FRYING", 26, 10, 3, 3),
	FRYER_STIRR("FRYER_STIRR", 27, 10, 3, 3),
	FRYER_TOSS("FRYER_TOSS", 28, 10, 3, 3),
	FRYER_LIQUID_DISP("FRYER_LIQUID_DISP", 29, 10, 4, 5),
	FRYER_SERVE("FRYER_SERVE", 30, 10, 3, 4),
	SEC_COLL("SEC_COLL", 41, 40, 13, 9),
	SEC_PICKUP("SEC_PICKUP", 42, 20, 6, 9),
	FLAME("FLAME", 51, 2, 1, 1),
	FRYER_FLAME("FRYER_FLAME", 52, 2, 1, 1);

    /** final variables to store the values, which can't be changed */
    public final String label;
    public final int actionId;
    public final int noOfRegisters;
    public final int noOfWriteRegisters;
    public final int noOfReadRegisters;
    
    /** 
     * Maps cache labels and their associated ActionEnum instances.
     * Note that this only works if the values are all unique!
     */
    private static final Map<String, ActionEnum> BY_LABEL = new HashMap<>();
    private static final Map<Integer, ActionEnum> BY_ACTION_ID = new HashMap<>();
    private static final Map<Integer, ActionEnum> BY_NO_OF_REGISTERS = new HashMap<>();
    private static final Map<Integer, ActionEnum> BY_NO_OF_WRITE_REGISTERS = new HashMap<>();
    private static final Map<Integer, ActionEnum> BY_NO_OF_READ_REGISTERS = new HashMap<>();

    /** populate the caches */
    static {
        for (ActionEnum e : values()) {
            BY_LABEL.put(e.label, e);
            BY_ACTION_ID.put(e.actionId, e);
            BY_NO_OF_REGISTERS.put(e.noOfRegisters, e);
            BY_NO_OF_WRITE_REGISTERS.put(e.noOfWriteRegisters, e);
            BY_NO_OF_READ_REGISTERS.put(e.noOfReadRegisters, e);
        }
    }

    private ActionEnum(String label, int actionId, int noOfRegisters, int noOfWriteRegisters, int noOfReadRegisters) {
        this.label = label;
        this.actionId = actionId;
        this.noOfRegisters = noOfRegisters;
        this.noOfWriteRegisters = noOfWriteRegisters;
        this.noOfReadRegisters = noOfReadRegisters;
    }
    
    /**
     * Implement the Labeled interface.
     * @return the label value
     */
    @Override
    public String label() {
        return label;
    }
    
    /**
     * Look up ActionEnum instances by the label field. This implementation finds the label in the BY_LABEL cache.
     * @param label The label to look up
     * @return The ActionEnum instance with the label, or null if not found.
     */
    public static ActionEnum valueOfLabel(String label) {
        return BY_LABEL.get(label);
    }
    
    /**
     * Look up ActionEnum instances by the actionId field. This implementation finds the actionId address in the cache.
     * @param actionId the address to look up
     * @return The ActionEnum instance with the actionId, or null if not found.
     */
    public static ActionEnum valueOfActionId(int actionId) {
        return BY_ACTION_ID.get(actionId);
    }
    
    /**
     * Look up ActionEnum instances by the noOfRegisters field. This implementation finds the noOfRegisters address in the cache.
     * @param noOfRegisters the address to look up
     * @return The ActionEnum instance with the noOfRegisters, or null if not found.
     */
    public static ActionEnum valueOfNoOfRegisters(int noOfRegisters) {
        return BY_NO_OF_REGISTERS.get(noOfRegisters);
    }
    
    /**
     * Look up ActionEnum instances by the noOfWriteRegisters field. This implementation finds the noOfWriteRegisters address in the cache.
     * @param noOfWriteRegisters the address to look up
     * @return The ActionEnum instance with the noOfWriteRegisters, or null if not found.
     */
    public static ActionEnum valueOfNoOfWriteRegisters(int noOfWriteRegisters) {
        return BY_NO_OF_WRITE_REGISTERS.get(noOfWriteRegisters);
    }
    
    /**
     * Look up ActionEnum instances by the noOfReadRegisters field. This implementation finds the noOfReadRegisters address in the cache.
     * @param noOfReadRegisters the address to look up
     * @return The ActionEnum instance with the noOfReadRegisters, or null if not found.
     */
    public static ActionEnum valueOfNoOfReadRegisters(int noOfReadRegisters) {
        return BY_NO_OF_READ_REGISTERS.get(noOfReadRegisters);
    }
    
    /**
     * Override the toString() method to return the label instead of the declared name.
     * @return 
     */
    @Override
    public String toString() {
        return this.label;
    }

}

