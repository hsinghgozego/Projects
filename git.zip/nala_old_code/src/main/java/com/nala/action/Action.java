package com.nala.action;

import java.util.List;

import com.nala.action.enums.Status;
import com.nala.model.Coils;

public interface Action<E> {
	
	void setStatus(Status status);
	
	Status getStatus();

	List<E> getWriteRegisters();
	
	List<E> getReadRegisters();
	
	Coils getHealthyStatusCoil();
	
	Coils getExecutingStatusCoil();
	
	Coils getDoneStatusCoil();
	
	E getFlameSetRegister();
	
	E getFlameReadRegister();
			
	void setTimeout(int timeout);
	
	public boolean isTimeOut();
	
}
