package com.nala.action;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Component;

import com.nala.RepositoryUtil;
import com.nala.action.enums.ActionEnum;
import com.nala.action.enums.OperationTypeEnum;
import com.nala.config.MongoConfig;
import com.nala.config.NalaApplicationContext;
import com.nala.model.BurnerRegisters;
import com.nala.model.Coils;
import com.nala.repository.BurnerRegistersRepository;
import com.nala.repository.CoilsRepository;

public class UtensilPick<E> extends AbstractAction {
	
	private BurnerRegistersRepository burnerRegistersRepository;
	
	private CoilsRepository coilsRepository;
	
	private List<BurnerRegisters> utensilPickRegistersList = null;
	private List<BurnerRegisters> utensilPickWriteRegistersList = null;
	private List<BurnerRegisters> utensilPickReadRegistersList = null;
	private Coils healthyStatusCoil = null;
	private Coils executingStatusCoil = null;
	private Coils doneStatusCoil = null;
	
	@SuppressWarnings("unchecked")
	public List<E> getWriteRegisters() {
		System.out.println("UtensilPick getWriteRegisters()");
		return (List<E>) utensilPickWriteRegistersList;
	}
	
	@SuppressWarnings("unchecked")
	public List<E> getReadRegisters() {
		System.out.println("UtensilPick getReadRegisters()");
		return (List<E>) utensilPickReadRegistersList;
	}	
	
	private void populateUtensilPickRegister() {
		burnerRegistersRepository = (BurnerRegistersRepository) NalaApplicationContext.getBean("burnerRegistersRepository");
		coilsRepository = (CoilsRepository) NalaApplicationContext.getBean("coilsRepository");
		utensilPickRegistersList = burnerRegistersRepository.findByActionId(ActionEnum.UTENSIL_PICK.actionId);
		if(utensilPickRegistersList!=null && !utensilPickRegistersList.isEmpty()) {
			utensilPickWriteRegistersList = new ArrayList<>();
			utensilPickReadRegistersList = new ArrayList<>();
			utensilPickRegistersList.forEach(burnerRegisters -> {
				if (burnerRegisters.getOperationType().equals(OperationTypeEnum.WRITE.getValue())) {
					utensilPickWriteRegistersList.add(burnerRegisters);
				} else if (burnerRegisters.getOperationType().equals(OperationTypeEnum.READ.getValue())) {
					utensilPickReadRegistersList.add(burnerRegisters);
				} else {
					System.out.println("Eroor in UtensilPickRegisters, please check the DB");
				}	
			});
		}
	}

	@Override
	public Coils getHealthyStatusCoil() {
		Coils coils = coilsRepository.findByCoilId(300);
		return coils;
	}

	@Override
	public Coils getExecutingStatusCoil() {
		Coils coils = coilsRepository.findByCoilId(308);
		return coils;
	}

	@Override
	public Coils getDoneStatusCoil() {
		Coils coils = coilsRepository.findByCoilId(316);
		return coils;
	}

	@Override
	public Object getFlameSetRegister() {
		BurnerRegisters burnerRegisters = burnerRegistersRepository.findByBurnerRegisterId(87);
		return burnerRegisters;
	}

	@Override
	public Object getFlameReadRegister() {
		BurnerRegisters burnerRegisters = burnerRegistersRepository.findByBurnerRegisterId(88);
		return burnerRegisters;
	}
}
