package com.nala.action.enums;

public enum BurnerEnum {
	
	BURNER1("burner1", 1),
	BURNER2("burner2", 2),
	BURNER3("burner3", 3),
	BURNER4("burner4", 4),
	BURNER5("burner5", 5),
	BURNER6("burner6", 6),
	BURNER7("burner7", 7),
	BURNER8("burner8", 8);

	private final String burnerName;

	private final int burnerNo;

    private BurnerEnum(String burnerName, int burnerNo) {
        this.burnerName = burnerName;
        this.burnerNo = burnerNo;
    }
	
	public String getBurnerName(){
		return burnerName;
	}

	public int getBurnerNo() {
		return burnerNo;
	}

}