package com.nala.action.enums;

public enum FryerEnum {
	
	FRYER1_POOL1("fryer1Pool1", 1),
	FRYER1_POOL2("fryer1Pool2", 2),
	FRYER1_POOL3("fryer1Pool3", 3),
	FRYER1_POOL4("fryer1Pool4", 4),
	FRYER2_POOL1("fryer2Pool1", 5),
	FRYER2_POOL2("fryer2Pool2", 6),
	FRYER2_POOL3("fryer2Pool3", 7),
	FRYER2_POOL4("fryer2Pool4", 8);

	private final String poolName;

	private final int poolNo;
	
	private FryerEnum(String poolName, int poolNo) {
        this.poolName = poolName;
        this.poolNo = poolNo;
    }

	public String getPoolName() {
		return poolName;
	}

	public int getPoolNo() {
		return poolNo;
	}

}
