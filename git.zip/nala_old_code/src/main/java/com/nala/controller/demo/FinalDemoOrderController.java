package com.nala.controller.demo;

import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nala.enums.ActionEnum;
import com.nala.enums.BowlPickEnum;
import com.nala.enums.BurnerEnum;
import com.nala.enums.CoilEnum;
import com.nala.enums.DemoRecipeDetailsStatusEnum;
import com.nala.enums.OrderPreparingStatusEnum;
import com.nala.enums.RegisterEnum;
import com.nala.enums.SectionEnum;
import com.nala.model.DispenseSetting;
import com.nala.model.RegisterAddress;
import com.nala.model.demo.ActionProcessingRules;
import com.nala.model.demo.DemoActions;
import com.nala.model.demo.DemoBins;
import com.nala.model.demo.DemoBurners;
import com.nala.model.demo.DemoIngredients;
import com.nala.model.demo.DemoOrderProcessing;
import com.nala.model.demo.DemoOrders;
import com.nala.model.demo.DemoRecipeDetails;
import com.nala.model.demo.DemoRecipes;
import com.nala.model.helper.FryerAction;
import com.nala.model.helper.FryerPickup;
import com.nala.model.helper.FryerServe;
import com.nala.model.helper.LiquidBin;
import com.nala.repository.RegisterAddressRepository;
import com.nala.repository.demo.ActionProcessingRulesRepository;
import com.nala.repository.demo.CoilAddressRepository;
import com.nala.repository.demo.DemoActionsRepository;
import com.nala.repository.demo.DemoBinsRepository;
import com.nala.repository.demo.DemoBurnersRepository;
import com.nala.repository.demo.DemoIngredientsRepository;
import com.nala.repository.demo.DemoOrderProcessingRespository;
import com.nala.repository.demo.DemoOrdersRepository;
import com.nala.repository.demo.DemoRacksRepository;
import com.nala.repository.demo.DemoRecipeDetailsRepository;
import com.nala.repository.demo.DemoRecipesRepository;

import de.re.easymodbus.exceptions.ModbusException;
import de.re.easymodbus.modbusclient.ModbusClient;

public class FinalDemoOrderController {

	private static final Logger logger = LoggerFactory.getLogger(FinalDemoOrderController.class);

	private static final String IP_ADDR = "192.168.2.245";
	private static final Integer PORT = 502;
	private static final Integer COIL_STRAT_ADDRESS = 5000;
	private static final Integer NO_OF_COILS_TO_READ = 1990;

	@Autowired
	ActionProcessingRulesRepository actionProcessingRulesRepository;

	@Autowired
	CoilAddressRepository coilAddressRepository;

	@Autowired
	DemoActionsRepository demoActionsRepository;

	@Autowired
	DemoBinsRepository demoBinsRepository;

	@Autowired
	DemoBurnersRepository demoBurnersRepository;

	@Autowired
	DemoIngredientsRepository demoIngredientsRepository;

	@Autowired
	DemoOrdersRepository demoOrdersRepository;

	@Autowired
	DemoOrderProcessingRespository demoOrderProcessingRespository;

	@Autowired
	DemoRacksRepository demoRacksRepository;

	@Autowired
	DemoRecipesRepository demoRecipesRepository;

	@Autowired
	DemoRecipeDetailsRepository demoRecipeDetailsRepository;

	@Autowired
	RegisterAddressRepository registerAddressRepository;

	ModbusClient mc = null;

	// Updated after Each Serve Action Completion
	private static boolean isBurner1Free = false;
	private static boolean isBurner2Free = false;
	private static boolean isBurner3Free = false;
	private static boolean isBurner4Free = false;

	// Updated after Utensil Pick Done
	private static boolean isBurner1UtensilPickDone = false;
	private static boolean isBurner2UtensilPickDone = false;
	private static boolean isBurner3UtensilPickDone = false;
	private static boolean isBurner4UtensilPickDone = false;

	// Update after Spatula Pick Done
	private static boolean isBurner1SpatulaPickDone = false;
	private static boolean isBurner2SpatulaPickDone = false;
	private static boolean isBurner3SpatulaPickDone = false;
	private static boolean isBurner4SpatulaPickDone = false;

	// Updated at Each Action
	private static Integer burner1CurrentGroupId = 0;
	private static Integer burner2CurrentGroupId = 0;
	private static Integer burner3CurrentGroupId = 0;
	private static Integer burner4CurrentGroupId = 0;

	// Updated at Robot Actions
	private static Integer station1ActiveBurner = 0;
	private static Integer station2ActiveBurner = 0;

	// Updated at start by using coil status
	private static boolean isHoldingStation1Available = false;
	private static boolean isHoldingStation2Available = false;

	// Updated at Each Robot Action
	private static boolean isRobot1Free = false;
	private static boolean isRobot2Free = false;

	// Updated at Start
	private static boolean isRack1Available = false;
	private static boolean isRack2Available = false;

	// Updated after Pickup Actions
	private static boolean isRack1VegSectionFree = false;
	private static boolean isRack1SpiceSectionFree = false;
	private static boolean isRack1MeatSectionFree = false;
	private static boolean isRack2VegSectionFree = false;
	private static boolean isRack2SpiceSectionFree = false;
	private static boolean isRack2MeatSectionFree = false;

	// Updated at start by using coils and also Update at Collections and Pickups
	private static boolean isRack1VegBowlAvailable = false;
	private static boolean isRack1SpiceBowlAvailable = false;
	private static boolean isRack1MeatBowlAvailable = false;
	private static boolean isRack2VegBowlAvailable = false;
	private static boolean isRack2SpiceBowlAvailable = false;
	private static boolean isRack2MeatBowlAvailable = false;

	// Updated after Collections Done
	private static boolean isRack1VegCollectionDone = false;
	private static boolean isRack1MeatCollectionDone = false;
	private static boolean isRack1SpiceCollectionDone = false;
	private static boolean isRack2VegCollectionDone = false;
	private static boolean isRack2MeatCollectionDone = false;
	private static boolean isRack2SpiceCollectionDone = false;

	// Updated at Collections and Empty After Pickups
	private static Integer rack1VegColForBurnerNo = 0;
	private static Integer rack1SpiceColForBurnerNo = 0;
	private static Integer rack1MeatColForBurnerNo = 0;
	private static Integer rack2VegColForBurnerNo = 0;
	private static Integer rack2SpiceColForBurnerNo = 0;
	private static Integer rack2MeatColForBurnerNo = 0;

	// Updated during Pool Actions
	private static Integer station1ActivePool = 0;
	private static Integer station2ActivePool = 0;

	// Updated at start by using coils
	private static boolean isFryer1Available = false;
	private static boolean isFryer2Available = false;

	// Updated at start and at each Fryer Actions
	private static boolean isFryer1VegPoolFree = false;
	private static boolean isFryer1MeatPoolFree = false;
	private static boolean isFryer2VegPoolFree = false;
	private static boolean isFryer2MeatPoolFree = false;

	// Updated at start and Also at Collections and Pickups
	private static boolean isHoldingStation1VegBowlsAvailable = false;
	private static boolean isHoldingStation1SpiceBowlsAvailable = false;
	private static boolean isHoldingStation1MeatBowlsAvailable = false;
	private static boolean isHoldingStation2VegBowlsAvailable = false;
	private static boolean isHoldingStation2SpiceBowlsAvailable = false;
	private static boolean isHoldingStation2MeatBowlsAvailable = false;

	// Updated at Strat
	private static boolean isServingStationPosition1Free = false;
	private static boolean isServingStationPosition2Free = false;

	// Updated at Start and Liquid Dispenser and Stir, Toss, Serve
	private static boolean isStation1DedicatedLiquidDispenserFree = false;
	private static boolean isStation1CommonLiquidDispenserFree = false;
	private static boolean isStation2DedicatedLiquidDispenserFree = false;
	private static boolean isStation2CommonLiquidDispenserFree = false;

	// Updated at Liquid Dispenseing
	private static Integer station1DedicatedLiquidDispenserOnBurner = 0;
	private static Integer station1CommonLiquidDispenserOnBurner = 0;
	private static Integer station2DedicatedLiquidDispenserOnBurner = 0;
	private static Integer station2CommonLiquidDispenserOnBurner = 0;

	@RequestMapping(value = "/finalStratCooking", method = RequestMethod.GET)
	public ModelAndView finalStratCooking() {
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			// Burners List
			List<DemoBurners> _burnersList = demoBurnersRepository.findAll();
			for (DemoBurners _db : _burnersList) {
				if (_db.getBurnerNo().equals(1)) {
					isBurner1Free = _db.getIsFree();
				} else if (_db.getBurnerNo().equals(2)) {
					isBurner2Free = _db.getIsFree();
				} else if (_db.getBurnerNo().equals(3)) {
					isBurner3Free = _db.getIsFree();
				} else if (_db.getBurnerNo().equals(4)) {
					isBurner4Free = _db.getIsFree();
				}
			}
			// Get Orders List from DB
			List<DemoOrders> ordersList = demoOrdersRepository
					.getByStatus(OrderPreparingStatusEnum.CREATED.getStatusDescription());
			// Get Actions List from DB
			List<DemoActions> actionsList = demoActionsRepository.findAll();
			// Get Register Address List from DB
			List<RegisterAddress> registerAddresses = registerAddressRepository.findAll();
			Map<String, RegisterAddress> registerAddressMap = new HashMap<>();
			Map<Integer, List<RegisterAddress>> actionRegisterAddressListMap = new HashMap<>();
			Map<Integer, List<RegisterAddress>> actionRegisterAddressWriteMap = new HashMap<>();
			Map<Integer, List<RegisterAddress>> actionRegisterAddressReadMap = new HashMap<>();

			registerAddresses.forEach(registerAddress -> {
				List<RegisterAddress> _list = null;
				List<RegisterAddress> _wlist = null;
				List<RegisterAddress> _rlist = null;
				registerAddressMap.put(registerAddress.getTypeOfAction(), registerAddress);
				if (actionRegisterAddressListMap.get(registerAddress.getActionId()) != null) {
					_list = actionRegisterAddressListMap.get(registerAddress.getActionId());
				} else {
					_list = new ArrayList<>();
				}
				_list.add(registerAddress);
				actionRegisterAddressListMap.put(registerAddress.getActionId(), _list);

				if (registerAddress.getOperationType() == 1) {
					if (actionRegisterAddressWriteMap.get(registerAddress.getActionId()) != null) {
						_wlist = actionRegisterAddressWriteMap.get(registerAddress.getActionId());
					} else {
						_wlist = new ArrayList<>();
					}
					_wlist.add(registerAddress);
					actionRegisterAddressWriteMap.put(registerAddress.getActionId(), _wlist);
				} else if (registerAddress.getOperationType() == 2) {
					if (actionRegisterAddressReadMap.get(registerAddress.getActionId()) != null) {
						_rlist = actionRegisterAddressReadMap.get(registerAddress.getActionId());
					} else {
						_rlist = new ArrayList<>();
					}
					_rlist.add(registerAddress);
					actionRegisterAddressReadMap.put(registerAddress.getActionId(), _rlist);
				}

			});

			Map<Integer, DemoActions> actionMap = new HashMap<>();
			Map<Integer, Integer> burnerFlameAddressMap = getBurnerWiseFlameAddressMap();
			actionsList.forEach(action -> actionMap.put(action.getActionId(), action));

			if (ordersList != null && !ordersList.isEmpty()) {

				for (DemoOrders demoOrders : ordersList) {

					int recipeId = demoOrders.getRecipeId();

					DemoRecipes demoRecipes = demoRecipesRepository.getByRecipeIdQtyAndStatus(recipeId,
							demoOrders.getQty(), true);

					if (demoRecipes != null) {

						List<DemoBurners> burnersList = getAvailableBurners();

						if (burnersList != null && !burnersList.isEmpty()) {
							for (DemoBurners db : burnersList) {
								if (getIngredientAvailability(db.getBurnerNo(), recipeId)
										&& getUtensilAvailability(db.getStationId(), recipeId)
										&& getSpatulaAvailability(db.getStationId(), recipeId)
										&& getBowlAvailability(db.getStationId(), recipeId)
										&& getHelathChecks(db.getBurnerNo(), recipeId)) {

									int burnerNo = db.getBurnerNo();
									List<DemoRecipeDetails> demoRecipeDetailsList = demoRecipeDetailsRepository
											.findByRecipeId(recipeId);

									if (demoRecipeDetailsList != null && !demoRecipeDetailsList.isEmpty()) {

										if (burnerNo == 1) {
											isBurner1Free = false;
										} else if (burnerNo == 2) {
											isBurner2Free = false;
										} else if (burnerNo == 3) {
											isBurner3Free = false;
										} else if (burnerNo == 4) {
											isBurner4Free = false;
										}

										List<DemoOrderProcessing> demoOrderProcessingList = new ArrayList<>();
										for (DemoRecipeDetails demoRecipeDetails : demoRecipeDetailsList) {
											DemoOrderProcessing dop = new DemoOrderProcessing();
											dop.setOrderId(demoOrders.getOrderId());
											dop.setRecipeId(recipeId);
											dop.setRecipeName(demoRecipes.getRecipeName());
											dop.setStationId(db.getStationId());
											dop.setBurnerNo(burnerNo);
											dop.setRobotId(db.getRobotId());
											dop.setRecipeDetailsId(demoRecipeDetails.getRecipeDetailsId());
											int actionId = demoRecipeDetails.getActionId();
											dop.setActionId(actionId);
											if (actionId == ActionEnum.VEG_COLLECTION.actionId
													|| actionId == ActionEnum.SPICE_COLLECTION.actionId
													|| actionId == ActionEnum.MEAT_COLLECTION.actionId
													|| actionId == ActionEnum.VEG_PICKUP.actionId
													|| actionId == ActionEnum.SPICE_PICKUP.actionId
													|| actionId == ActionEnum.MEAT_PICKUP.actionId
													|| actionId == ActionEnum.FRYER_PICKUP.actionId
													|| actionId == ActionEnum.LIQUID_DISPENSING.actionId) {

												if (actionId == ActionEnum.VEG_PICKUP.actionId
														|| actionId == ActionEnum.MEAT_PICKUP.actionId
														|| actionId == ActionEnum.SPICE_PICKUP.actionId) {
													dop.setBcWbc((Integer) demoRecipeDetails.getSourceOrType());
												}
												if (actionId == ActionEnum.VEG_COLLECTION.actionId
														|| actionId == ActionEnum.VEG_PICKUP.actionId) {
													dop.setSectionId(SectionEnum.VEG.getLoc());
												} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId
														|| actionId == ActionEnum.MEAT_PICKUP.actionId) {
													dop.setSectionId(SectionEnum.MEAT.getLoc());
												} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId
														|| actionId == ActionEnum.SPICE_PICKUP.actionId) {
													dop.setSectionId(SectionEnum.SPICE.getLoc());
												} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
													dop.setFryerId(db.getFryerId());
													ObjectMapper mapper = new ObjectMapper();
													FryerPickup fp = mapper.convertValue(
															demoRecipeDetails.getSourceOrType(),
															new TypeReference<FryerPickup>() {
															});
													dop.setSectionId(fp.getPickLocation());
													dop.setPoolId(fp.getDropLocation());
													dop.setBcWbc(fp.getBcWbc());
												} else {
													dop.setSectionId(SectionEnum.NOTHING.getLoc());
												}
												dop.setRackId(db.getRackId());
											} else if (actionId == ActionEnum.FRYER_ACTION.actionId
													|| actionId == ActionEnum.FRYER_SERVE.actionId) {
												dop.setFryerId(db.getFryerId());
												ObjectMapper mapper = new ObjectMapper();
												if (actionId == ActionEnum.FRYER_ACTION.actionId) {
													FryerAction fa = mapper.convertValue(
															demoRecipeDetails.getSourceOrType(),
															new TypeReference<FryerAction>() {
															});
													dop.setPoolId(fa.getPoolLocation());
													dop.setSectionId(0);
												} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
													FryerServe fs = mapper.convertValue(
															demoRecipeDetails.getSourceOrType(),
															new TypeReference<FryerServe>() {
															});
													dop.setPoolId(fs.getPoolLoc());
													dop.setSectionId(0);
												}
											} else {
												dop.setSectionId(0);
											}
											dop.setSourceOrType(demoRecipeDetails.getSourceOrType());
											dop.setQty(demoRecipeDetails.getQty());
											dop.setTime(demoRecipeDetails.getTime());
											dop.setFlame(demoRecipeDetails.getFlame());
											dop.setGroupId(demoRecipeDetails.getGroupId());
											if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.UTENSIL_PICK_WRITE.label())));
											} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.SPATULA_PICK_WRITE.label())));
											} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.VEG_COLLECTION_WRITE.label())));
												dop.setMotorAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label())));
											} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.MEAT_COLLECTION_WRITE.label())));
												dop.setMotorAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label())));
											} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.SPICE_COLLECTION_WRITE.label())));
												dop.setMotorAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label())));
											} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
												dop.setAddressId(getAddress(burnerNo,
														registerAddressMap.get(RegisterEnum.VEG_PICKUP_WRITE.label())));
											} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.MEAT_PICKUP_WRITE.label())));
											} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.SPICE_PICKUP_WRITE.label())));
											} else if (actionId == ActionEnum.IGNITION.actionId) {
												dop.setAddressId(getAddress(burnerNo,
														registerAddressMap.get(RegisterEnum.IGNITION_WRITE.label())));
											} else if (actionId == ActionEnum.STIRR.actionId) {
												dop.setAddressId(getAddress(burnerNo,
														registerAddressMap.get(RegisterEnum.STIRR_WRITE.label())));
											} else if (actionId == ActionEnum.TOSS.actionId) {
												dop.setAddressId(getAddress(burnerNo,
														registerAddressMap.get(RegisterEnum.TOSS_WRITE.label())));
											} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.LIQUID_DISPENSING_WRITE.label())));
											} else if (actionId == ActionEnum.DELAY.actionId) {
												dop.setAddressId(getAddress(burnerNo,
														registerAddressMap.get(RegisterEnum.DELAY_WRITE.label())));
											} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.FRYER_PICKUP_WRITE.label())));
											} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.FRYER_ACTION_WRITE.label())));
											} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
												dop.setAddressId(getAddress(burnerNo, registerAddressMap
														.get(RegisterEnum.FRYER_SERVE_WRITE.label())));
											} else if (actionId == ActionEnum.SERVE.actionId) {
												dop.setAddressId(getAddress(burnerNo,
														registerAddressMap.get(RegisterEnum.SERVE_WRITE.label())));
											}
											dop.setFlameAddressId(burnerFlameAddressMap.get(burnerNo));
											dop.setStatus(DemoRecipeDetailsStatusEnum.CREATED.getStatusValue());
											demoOrderProcessingList.add(dop);
										}
										demoOrderProcessingRespository.insert(demoOrderProcessingList);
										demoOrders.setStatus(OrderPreparingStatusEnum.EXECUTING.getStatusDescription());
									} else {
										logger.error("Demo Recipe Details List is Empty or Null for Recipe Id : "
												+ demoOrders.getRecipeId());
									}

									break;
								} else {
									logger.error(
											"One of the Status Check failed for Ingredients, Utensils, Spatulas, Bowls, HelathChecks");
								}
							} // End of Burners For Loop
						} else {
							logger.error("Burner are Not avialable for the Recipe Id : " + demoOrders.getRecipeId()
									+ ", at this Moment : " + new Date());
						}

					} else {
						logger.error("Recipe Not Found with the Given Recipe Id : " + demoOrders.getRecipeId()
								+ ", for Order : " + demoOrders.getOrderId());
					}
				} // End of DemoOrders For Loop

			} else {
				logger.info("No New Orders found at this Moment : " + new Date());
			}

			List<DemoOrderProcessing> createdList = demoOrderProcessingRespository
					.getByStatus(DemoRecipeDetailsStatusEnum.CREATED.getStatusValue());
			createdList.sort(
					(DemoOrderProcessing d1, DemoOrderProcessing d2) -> d1.getGroupId().compareTo(d2.getGroupId()));

			List<DemoOrderProcessing> waitingList = demoOrderProcessingRespository
					.getByStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
			waitingList.sort(
					(DemoOrderProcessing d1, DemoOrderProcessing d2) -> d1.getGroupId().compareTo(d2.getGroupId()));

			List<DemoOrderProcessing> executingList = demoOrderProcessingRespository
					.getByStatus(DemoRecipeDetailsStatusEnum.DONE.getStatusValue());

			List<DemoOrderProcessing> toDoList = new ArrayList<>();

			// Adding Steps from Waiting List to Executing List by checking the conditions
			for (DemoOrderProcessing cdp : createdList) {
				if (waitingList != null && !waitingList.isEmpty()) {
					for (DemoOrderProcessing edp : waitingList) {
						DemoActions _demoActions = actionMap.get(edp.getActionId());
						ActionProcessingRules actionProcessingRules = actionProcessingRulesRepository
								.getByActionIdBurnerNoRackOrLiquidAndSectionId(edp.getActionId(), edp.getBurnerNo(),
										edp.getRackId(), edp.getSectionId());

						if (_demoActions != null && actionProcessingRules != null) {

							if (executingList != null && !executingList.isEmpty()) {

								boolean noConflict = true;

								for (DemoOrderProcessing dpObj : executingList) {
									ActionProcessingRules apr = actionProcessingRulesRepository
											.getByActionIdBurnerNoRackOrLiquidAndSectionId(dpObj.getActionId(),
													edp.getBurnerNo(), edp.getRackId(), edp.getSectionId());
									// To Do Action Processing Rules Comparison

								}

								if (noConflict) {

									boolean depFlag = true;

									if (_demoActions.getActionId() == ActionEnum.UTENSIL_PICK.actionId) {

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Checking Holding Station Dependency
										if (!getUtensilAvailabilityByType(edp.getStationId(),
												Integer.parseInt(edp.getSourceOrType().toString()))) {
											depFlag = false;
										}

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Updating Robot Free Status
												updateRobotFreeStatus(edp.getStationId());

												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.UTENSIL_PICK_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.UTENSIL_TYPE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																(Integer) edp.getSourceOrType(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: UTENSIL_PICK - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("UTENSIL_PICK flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in UTENSIL_PICK Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.SPATULA_PICK.actionId) {

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Checking Holding Station Dependency
										if (!getSpatulaAvailabilityByType(edp.getStationId(),
												Integer.parseInt(edp.getSourceOrType().toString()))) {
											depFlag = false;
										}

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Updating Robot Free Status
												updateRobotFreeStatus(edp.getStationId());

												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.SPATULA_PICK_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.SPATULA_TYPE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																(Integer) edp.getSourceOrType(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: SPATULA_PICK - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("SPATULA_PICK flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in SPATULA_PICK Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.VEG_COLLECTION.actionId) {

										// Check Rack Dependency
										depFlag = checkCollectionRackDependency(SectionEnum.VEG.getLoc(),
												edp.getRackId(), edp.getBurnerNo(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												DispenseSetting ds = null;
												DemoBins db = null;
												List<DispenseSetting> dss = null;
												List<DemoBins> dbList = null;

												DemoIngredients ingredient = demoIngredientsRepository
														.findByIngredientId((Integer) edp.getSourceOrType());
												if (ingredient != null) {
													if (ingredient.getDispenseSettings() != null
															&& !ingredient.getDispenseSettings().isEmpty()) {
														dss = ingredient.getDispenseSettings();
														for (DispenseSetting _ds : dss) {
															if ((edp.getQty() >= _ds.getMin())
																	&& (edp.getQty() <= _ds.getMax())) {
																ds = _ds;
																break;
															}
														}

														if (ds != null) {
															dbList = demoBinsRepository.findByIngredientIdRackId(
																	ingredient.getIngredientId(), edp.getRackId());
															if (dbList != null && !dbList.isEmpty()) {
																db = dbList.get(0);

																for (RegisterAddress obj : writeList) {
																	if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_COLLECTION_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				edp.getActionId(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_COLLECTION_BIN_NUMBER_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				db.getBinNo(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_COLLECTION_WEIGHT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				edp.getQty(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getCutOffPct(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getNormalOpsInPct(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_NORMAL_SPEED_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getNormalOpsSpeed(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_INCHING_SPEED_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getInchingSpeed(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getGapBtwNormalAndInch(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getGapBtwInch(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.VEG_MOTOR_INCHING_TIME_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getInchingTime(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else {
																		logger.error(
																				"******** ERROR: VEG_COLLECTION - Type Of Action : "
																						+ obj.getTypeOfAction()
																						+ "  ********");
																	}
																}

																boolean flameWrite = invokeWriteToRegisterAPI(
																		edp.getFlameAddressId(), edp.getFlame(),
																		edp.getRecipeName());
																logger.info(
																		"VEG_COLLECTION flameWrite : " + flameWrite);
															} else {
																logger.error(
																		"VEG_COLLECTION Bins not found for Ingredient: "
																				+ ingredient.getName());
															}
														} else {
															logger.error(
																	"VEG_COLLECTION Dispense Settings not found for the Given Qty: "
																			+ edp.getQty() + " for Ingredient: "
																			+ ingredient.getName());
														}
													} else {
														logger.error(
																"VEG_COLLECTION Dispense Settings not found for the Ingredient: "
																		+ ingredient.getName());
													}
												} else {
													logger.error("VEG_COLLECTION Ingredient not found with the Id: "
															+ (Integer) edp.getSourceOrType());
												}

											} else {
												logger.error("No WRITE REGISTERS found in VEG_COLLECTION Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.MEAT_COLLECTION.actionId) {

										// Check Rack Dependency
										depFlag = checkCollectionRackDependency(SectionEnum.MEAT.getLoc(),
												edp.getRackId(), edp.getBurnerNo(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												DispenseSetting ds = null;
												DemoBins db = null;
												List<DispenseSetting> dss = null;
												List<DemoBins> dbList = null;

												DemoIngredients ingredient = demoIngredientsRepository
														.findByIngredientId((Integer) edp.getSourceOrType());
												if (ingredient != null) {
													if (ingredient.getDispenseSettings() != null
															&& !ingredient.getDispenseSettings().isEmpty()) {
														dss = ingredient.getDispenseSettings();
														for (DispenseSetting _ds : dss) {
															if ((edp.getQty() >= _ds.getMin())
																	&& (edp.getQty() <= _ds.getMax())) {
																ds = _ds;
																break;
															}
														}

														if (ds != null) {
															dbList = demoBinsRepository.findByIngredientIdRackId(
																	ingredient.getIngredientId(), edp.getRackId());
															if (dbList != null && !dbList.isEmpty()) {
																db = dbList.get(0);

																for (RegisterAddress obj : writeList) {
																	if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_COLLECTION_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				edp.getActionId(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_COLLECTION_BIN_NUMBER_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				db.getBinNo(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_COLLECTION_WEIGHT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				edp.getQty(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getCutOffPct(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getNormalOpsInPct(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_NORMAL_SPEED_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getNormalOpsSpeed(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_INCHING_SPEED_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getInchingSpeed(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getGapBtwNormalAndInch(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getGapBtwInch(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.MEAT_MOTOR_INCHING_TIME_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getInchingTime(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else {
																		logger.error(
																				"******** ERROR: MEAT_COLLECTION - Type Of Action : "
																						+ obj.getTypeOfAction()
																						+ "  ********");
																	}
																}

																boolean flameWrite = invokeWriteToRegisterAPI(
																		edp.getFlameAddressId(), edp.getFlame(),
																		edp.getRecipeName());
																logger.info(
																		"MEAT_COLLECTION flameWrite : " + flameWrite);
															} else {
																logger.error(
																		"MEAT_COLLECTION Bins not found for Ingredient: "
																				+ ingredient.getName());
															}
														} else {
															logger.error(
																	"MEAT_COLLECTION Dispense Settings not found for the Given Qty: "
																			+ edp.getQty() + " for Ingredient: "
																			+ ingredient.getName());
														}
													} else {
														logger.error(
																"MEAT_COLLECTION Dispense Settings not found for the Ingredient: "
																		+ ingredient.getName());
													}
												} else {
													logger.error("MEAT_COLLECTION Ingredient not found with the Id: "
															+ (Integer) edp.getSourceOrType());
												}

											} else {
												logger.error("No WRITE REGISTERS found in MEAT_COLLECTION Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.SPICE_COLLECTION.actionId) {

										// Check Rack Dependency
										depFlag = checkCollectionRackDependency(SectionEnum.SPICE.getLoc(),
												edp.getRackId(), edp.getBurnerNo(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												DispenseSetting ds = null;
												DemoBins db = null;
												List<DispenseSetting> dss = null;
												List<DemoBins> dbList = null;

												DemoIngredients ingredient = demoIngredientsRepository
														.findByIngredientId((Integer) edp.getSourceOrType());
												if (ingredient != null) {
													if (ingredient.getDispenseSettings() != null
															&& !ingredient.getDispenseSettings().isEmpty()) {
														dss = ingredient.getDispenseSettings();
														for (DispenseSetting _ds : dss) {
															if ((edp.getQty() >= _ds.getMin())
																	&& (edp.getQty() <= _ds.getMax())) {
																ds = _ds;
																break;
															}
														}

														if (ds != null) {
															dbList = demoBinsRepository.findByIngredientIdRackId(
																	ingredient.getIngredientId(), edp.getRackId());
															if (dbList != null && !dbList.isEmpty()) {
																db = dbList.get(0);

																for (RegisterAddress obj : writeList) {
																	if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_COLLECTION_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				edp.getActionId(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_COLLECTION_BIN_NUMBER_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				db.getBinNo(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_COLLECTION_WEIGHT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				edp.getQty(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getCutOffPct(), edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getNormalOpsInPct(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_NORMAL_SPEED_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getNormalOpsSpeed(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_INCHING_SPEED_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getInchingSpeed(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getGapBtwNormalAndInch(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getGapBtwInch(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else if (obj.getTypeOfAction().equals(
																			RegisterEnum.SPICE_MOTOR_INCHING_TIME_WRITE.label)) {
																		boolean result = invokeWriteToRegisterAPI(
																				getAddress(edp.getBurnerNo(), obj),
																				ds.getInchingTime(),
																				edp.getRecipeName());
																		logger.info(
																				obj.getTypeOfAction() + " : " + result);
																	} else {
																		logger.error(
																				"******** ERROR: SPICE_COLLECTION - Type Of Action : "
																						+ obj.getTypeOfAction()
																						+ "  ********");
																	}
																}

																boolean flameWrite = invokeWriteToRegisterAPI(
																		edp.getFlameAddressId(), edp.getFlame(),
																		edp.getRecipeName());
																logger.info(
																		"SPICE_COLLECTION flameWrite : " + flameWrite);
															} else {
																logger.error(
																		"SPICE_COLLECTION Bins not found for Ingredient: "
																				+ ingredient.getName());
															}
														} else {
															logger.error(
																	"SPICE_COLLECTION Dispense Settings not found for the Given Qty: "
																			+ edp.getQty() + " for Ingredient: "
																			+ ingredient.getName());
														}
													} else {
														logger.error(
																"SPICE_COLLECTION Dispense Settings not found for the Ingredient: "
																		+ ingredient.getName());
													}
												} else {
													logger.error("SPICE_COLLECTION Ingredient not found with the Id: "
															+ (Integer) edp.getSourceOrType());
												}

											} else {
												logger.error("No WRITE REGISTERS found in SPICE_COLLECTION Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.VEG_PICKUP.actionId) {

										// Check Pickup Rack Dependency
										depFlag = checkPickupRackDependency(SectionEnum.VEG.getLoc(), edp.getRackId(),
												edp.getBurnerNo(), depFlag, false);
										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Checking Liquid Dependency
										depFlag = checkCrossLiquidDependecyPickupAndServe(edp.getBurnerNo(), depFlag);
										// Checking Holding Station Dependency for Bowl Change
										int wcBwc = Integer.parseInt(edp.getSourceOrType().toString());
										depFlag = checkHoldingStationDependecyForBowl(SectionEnum.VEG.getLoc(),
												edp.getStationId(), wcBwc, depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Updating Robot Free Status
												updateRobotFreeStatus(edp.getStationId());

												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.VEG_PICKUP_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.VEG_PICKUP_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), wcBwc,
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: VEG_PICKUP- Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("VEG_PICKUP flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in VEG_PICKUP Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.MEAT_PICKUP.actionId) {

										// Check Pickup Rack Dependency
										depFlag = checkPickupRackDependency(SectionEnum.MEAT.getLoc(), edp.getRackId(),
												edp.getBurnerNo(), depFlag, false);
										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Checking Liquid Dependency
										depFlag = checkCrossLiquidDependecyPickupAndServe(edp.getBurnerNo(), depFlag);
										// Checking Holding Station Dependency for Bowl Change
										int wcBwc = Integer.parseInt(edp.getSourceOrType().toString());
										depFlag = checkHoldingStationDependecyForBowl(SectionEnum.VEG.getLoc(),
												edp.getStationId(), wcBwc, depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Updating Robot Free Status
												updateRobotFreeStatus(edp.getStationId());

												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.MEAT_PICKUP_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.MEAT_PICKUP_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), wcBwc,
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: MEAT_PICKUP- Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("MEAT_PICKUP flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in MEAT_PICKUP Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.SPICE_PICKUP.actionId) {

										// Check Pickup Rack Dependency
										depFlag = checkPickupRackDependency(SectionEnum.SPICE.getLoc(), edp.getRackId(),
												edp.getBurnerNo(), depFlag, false);
										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Checking Liquid Dependency
										depFlag = checkCrossLiquidDependecyPickupAndServe(edp.getBurnerNo(), depFlag);
										// Checking Holding Station Dependency for Bowl Change
										int wcBwc = Integer.parseInt(edp.getSourceOrType().toString());
										depFlag = checkHoldingStationDependecyForBowl(SectionEnum.VEG.getLoc(),
												edp.getStationId(), wcBwc, depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Updating Robot Free Status
												updateRobotFreeStatus(edp.getStationId());

												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.SPICE_PICKUP_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.SPICE_PICKUP_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), wcBwc,
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: SPICE_PICKUP - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("SPICE_PICKUP flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in SPICE_PICKUP Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.IGNITION.actionId) {

										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.IGNITION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.IGNITION_DELAY_TIME_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getTime(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.FLAME_LEVEL_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																edp.getFlameAddressId(), edp.getFlame(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: IGNITION - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}
											} else {
												logger.error("No WRITE REGISTERS found in IGNITION Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.STIRR.actionId) {

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Check Liquid Dependency
										depFlag = checkCrossLiquidDependecyDuringStirrAndToss(edp.getBurnerNo(),
												depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);
										// Check Spatula Dependency
										depFlag = checkSpatulaDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.STIRR_TYPE_NUMBER_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																(Integer) edp.getSourceOrType(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.STIRR_TIME_IN_MILLI_SEC_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getTime(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: STIRR - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("STIRR flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in STIRR Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.TOSS.actionId) {

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Check Liquid Dependency
										depFlag = checkCrossLiquidDependecyDuringStirrAndToss(edp.getBurnerNo(),
												depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.TOSS_TYPE_NUMBER_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																(Integer) edp.getSourceOrType(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.TOSS_TIME_IN_MILLI_SEC_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getTime(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.info("******** ERROR: TOSS - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("TOSS flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in TOSS Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.LIQUID_DISPENSING.actionId) {

										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Check Liquid Dependency
										depFlag = checkLiquidDependecy(edp.getBurnerNo(), depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												ObjectMapper mapper = new ObjectMapper();
												List<LiquidBin> lb = mapper.convertValue(edp.getSourceOrType(),
														new TypeReference<List<LiquidBin>>() {
														});

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.LIQUID_DISPENSING_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE.label)) {
														if (lb.size() > 0) {
															List<DemoBins> dbList = demoBinsRepository
																	.findByIngredientId(lb.get(0).getIngId());
															if (!dbList.isEmpty()) {
																DemoBins db = null;
																if (dbList.get(0) != null && (edp.getBurnerNo() == 1
																		|| edp.getBurnerNo() == 2)) {
																	db = dbList.get(0);
																} else if (dbList.get(1) != null
																		&& (edp.getBurnerNo() == 3
																				|| edp.getBurnerNo() == 4)) {
																	db = dbList.get(1);
																}
																if (db != null && db.getBinNo() != null) {
																	boolean result = invokeWriteToRegisterAPI(
																			getAddress(edp.getBurnerNo(), obj),
																			db.getBinNo(), edp.getRecipeName());
																	logger.info(obj.getTypeOfAction() + " : " + result);
																} else {
																	logger.error("Invalid Mapping for address: "
																			+ edp.getAddressId()
																			+ ", No Bin found with the Liquid 1 Mapping : "
																			+ lb.get(0).getIngId());
																}
															} else {
																logger.error("address: " + edp.getAddressId()
																		+ ", No Bin 1 found with the Liquid Mapping : "
																		+ lb.get(0).getIngId());
															}
														} else {
															logger.info("address: " + edp.getAddressId()
																	+ ", Need to Dispense atleast 1 Liquid from Bin");
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_1_WRITE.label)) {
														if (lb.size() > 0) {
															boolean result = invokeWriteToRegisterAPI(
																	getAddress(edp.getBurnerNo(), obj),
																	lb.get(0).getMs() / 100, edp.getRecipeName());
															logger.info(obj.getTypeOfAction() + " : " + result);
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_WRITE.label)) {
														if (lb.size() >= 2) {
															List<DemoBins> dbList = demoBinsRepository
																	.findByIngredientId(lb.get(1).getIngId());
															if (!dbList.isEmpty()) {
																DemoBins db = null;
																if (dbList.get(0) != null && (edp.getBurnerNo() == 1
																		|| edp.getBurnerNo() == 2)) {
																	db = dbList.get(0);
																} else if (dbList.get(1) != null
																		&& (edp.getBurnerNo() == 3
																				|| edp.getBurnerNo() == 4)) {
																	db = dbList.get(1);
																}
																if (db != null && db.getBinNo() != null) {
																	boolean result = invokeWriteToRegisterAPI(
																			getAddress(edp.getBurnerNo(), obj),
																			db.getBinNo(), edp.getRecipeName());
																	logger.info(obj.getTypeOfAction() + " : " + result);
																} else {
																	logger.error("Invalid Mapping for address: "
																			+ edp.getAddressId()
																			+ ", No Bin found with the Liquid 2 Mapping : "
																			+ lb.get(1).getIngId());
																}
															} else {
																logger.error("address: " + edp.getAddressId()
																		+ ", No Bin found with the Liquid 2 Mapping : "
																		+ lb.get(1).getIngId());
															}
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_2_WRITE.label)) {
														if (lb.size() >= 2) {
															boolean result = invokeWriteToRegisterAPI(
																	getAddress(edp.getBurnerNo(), obj),
																	lb.get(1).getMs() / 100, edp.getRecipeName());
															logger.info(obj.getTypeOfAction() + " : " + result);
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_WRITE.label)) {
														if (lb.size() >= 3) {
															List<DemoBins> dbList = demoBinsRepository
																	.findByIngredientId(lb.get(2).getIngId());
															if (!dbList.isEmpty()) {
																DemoBins db = null;
																if (dbList.get(0) != null && (edp.getBurnerNo() == 1
																		|| edp.getBurnerNo() == 2)) {
																	db = dbList.get(0);
																} else if (dbList.get(1) != null
																		&& (edp.getBurnerNo() == 3
																				|| edp.getBurnerNo() == 4)) {
																	db = dbList.get(1);
																}
																if (db != null && db.getBinNo() != null) {
																	boolean result = invokeWriteToRegisterAPI(
																			getAddress(edp.getBurnerNo(), obj),
																			db.getBinNo(), edp.getRecipeName());
																	logger.info(obj.getTypeOfAction() + " : " + result);
																} else {
																	logger.error("Invalid Mapping for address: "
																			+ edp.getAddressId()
																			+ ", No Bin found with the Liquid 3 Mapping : "
																			+ lb.get(2).getIngId());
																}
															} else {
																logger.error("address: " + edp.getAddressId()
																		+ ", No Bin found with the Liquid 3 Mapping : "
																		+ lb.get(2).getIngId());
															}
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_3_WRITE.label)) {
														if (lb.size() >= 3) {
															boolean result = invokeWriteToRegisterAPI(
																	getAddress(edp.getBurnerNo(), obj),
																	lb.get(2).getMs() / 100, edp.getRecipeName());
															logger.info(obj.getTypeOfAction() + " : " + result);
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_WRITE.label)) {
														if (lb.size() >= 4) {
															List<DemoBins> dbList = demoBinsRepository
																	.findByIngredientId(lb.get(2).getIngId());
															if (!dbList.isEmpty()) {
																DemoBins db = null;
																if (dbList.get(0) != null && (edp.getBurnerNo() == 1
																		|| edp.getBurnerNo() == 2)) {
																	db = dbList.get(0);
																} else if (dbList.get(1) != null
																		&& (edp.getBurnerNo() == 3
																				|| edp.getBurnerNo() == 4)) {
																	db = dbList.get(1);
																}
																if (db != null && db.getBinNo() != null) {
																	boolean result = invokeWriteToRegisterAPI(
																			getAddress(edp.getBurnerNo(), obj),
																			db.getBinNo(), edp.getRecipeName());
																	logger.info(obj.getTypeOfAction() + " : " + result);
																} else {
																	logger.error("Invalid Mapping for address: "
																			+ edp.getAddressId()
																			+ ", No Bin found with the Liquid 4 Mapping : "
																			+ lb.get(3).getIngId());
																}
															} else {
																logger.error("address: " + edp.getAddressId()
																		+ ", No Bin found with the Liquid 4 Mapping : "
																		+ lb.get(3).getIngId());
															}
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_4_WRITE.label)) {
														if (lb.size() >= 4) {
															boolean result = invokeWriteToRegisterAPI(
																	getAddress(edp.getBurnerNo(), obj),
																	lb.get(3).getMs() / 100, edp.getRecipeName());
															logger.info(obj.getTypeOfAction() + " : " + result);
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_WRITE.label)) {
														if (lb.size() >= 5) {
															List<DemoBins> dbList = demoBinsRepository
																	.findByIngredientId(lb.get(4).getIngId());
															if (!dbList.isEmpty()) {
																DemoBins db = null;
																if (dbList.get(0) != null && (edp.getBurnerNo() == 1
																		|| edp.getBurnerNo() == 2)) {
																	db = dbList.get(0);
																} else if (dbList.get(1) != null
																		&& (edp.getBurnerNo() == 3
																				|| edp.getBurnerNo() == 4)) {
																	db = dbList.get(1);
																}
																if (db != null && db.getBinNo() != null) {
																	boolean result = invokeWriteToRegisterAPI(
																			getAddress(edp.getBurnerNo(), obj),
																			db.getBinNo(), edp.getRecipeName());
																	logger.info(obj.getTypeOfAction() + " : " + result);
																} else {
																	logger.error("Invalid Mapping for address: "
																			+ edp.getAddressId()
																			+ ", No Bin found with the Liquid 5 Mapping : "
																			+ lb.get(4).getIngId());
																}
															} else {
																logger.info("address: " + edp.getAddressId()
																		+ ", No Bin found with the Liquid 5 Mapping : "
																		+ lb.get(4).getIngId());
															}
														}
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_5_WRITE.label)) {
														if (lb.size() >= 5) {
															boolean result = invokeWriteToRegisterAPI(
																	getAddress(edp.getBurnerNo(), obj),
																	lb.get(4).getMs() / 100, edp.getRecipeName());
															logger.info(obj.getTypeOfAction() + " : " + result);
														}
													} else {
														logger.error(
																"******** ERROR: LIQUID_DISPENSING - Type Of Action : "
																		+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("LIQUID_DISPENSING flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in LIQUID_DISPENSING Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.DELAY.actionId) {

										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.DELAY_TIME_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getTime(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: DELAY - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("DELAY flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in DELAY Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.FRYER_PICKUP.actionId) {

										ObjectMapper mapper = new ObjectMapper();
										FryerPickup fp = mapper.convertValue(edp.getSourceOrType(),
												new TypeReference<FryerPickup>() {
												});

										// Check Pickup Rack Dependency
										depFlag = checkPickupRackDependency(fp.getPickLocation(), edp.getRackId(),
												edp.getFryerId(), depFlag, true);
										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Holding Station Dependency for Bowl Change
										depFlag = checkHoldingStationDependecyForBowl(fp.getPickLocation(),
												edp.getStationId(), fp.getBcWbc(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.FRYER_PICKUP_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.FRYER_PICKUP_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																fp.getPickLocation(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.FRYER_PICKUP_DROP_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																fp.getDropLocation(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), fp.getBcWbc(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: FRYER_PICKUP - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("FRYER_PICKUP flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in FRYER_PICKUP Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.FRYER_ACTION.actionId) {

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												ObjectMapper mapper = new ObjectMapper();
												FryerAction fa = mapper.convertValue(edp.getSourceOrType(),
														new TypeReference<FryerAction>() {
														});

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.FRYER_ACTION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.FRYER_ACTION_POOL_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																fa.getPoolLocation(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.FRYER_ACTION_LIFT_DIP_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), fa.getLiftDip(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.error("******** ERROR: FRYER_ACTION - Type Of Action : "
																+ obj.getTypeOfAction() + "  ********");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("FRYER_ACTION flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in FRYER_ACTION Action");
											}
										}
									} else if (_demoActions.getActionId() == ActionEnum.FRYER_SERVE.actionId) {

										ObjectMapper mapper = new ObjectMapper();
										FryerServe fs = mapper.convertValue(edp.getSourceOrType(),
												new TypeReference<FryerServe>() {
												});

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										if (fs.getTransOrServe() == 1) {
											depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);
										} else {
											// Check Utensil Dependency
											depFlag = checkServingStationDependecy(edp.getBurnerNo(), depFlag);
										}

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction()
															.equals(RegisterEnum.FRYER_SERVE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.FRYER_SERVE_POOL_LOCATION_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), fs.getPoolLoc(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction().equals(
															RegisterEnum.FRYER_SERVE_TRANSFER_OR_SERVE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																fs.getTransOrServe(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.info(
																"******************* ERROR: FRYER_SERVE *******************");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("FRYER_SERVE flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in FRYER_SERVE Action");
											}
										}

									} else if (_demoActions.getActionId() == ActionEnum.SERVE.actionId) {

										// Checking Robot Dependency
										depFlag = checkRobotDependecy(edp.getStationId(), depFlag);
										// Checking Burner Dependency
										depFlag = checkBurnerDependecy(edp.getBurnerNo(), depFlag);
										// Check Serving Station Dependency
										depFlag = checkServingStationDependecy(edp.getStationId(), depFlag);
										// Check Liquid Dependency
										depFlag = checkCrossLiquidDependecyPickupAndServe(edp.getBurnerNo(), depFlag);
										// Check Utensil Dependency
										depFlag = checkUtensilDependecy(edp.getBurnerNo(), depFlag);

										if (depFlag) {
											// WRITE REGISTERS
											List<RegisterAddress> writeList = actionRegisterAddressWriteMap
													.get(edp.getActionId());
											if (writeList != null && !writeList.isEmpty()) {
												// Writing Data to Registers
												edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
												edp = demoOrderProcessingRespository.save(edp);

												updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());

												for (RegisterAddress obj : writeList) {
													if (obj.getTypeOfAction().equals(RegisterEnum.SERVE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
																edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else if (obj.getTypeOfAction()
															.equals(RegisterEnum.SERVE_TYPE_WRITE.label)) {
														boolean result = invokeWriteToRegisterAPI(
																getAddress(edp.getBurnerNo(), obj),
																(Integer) edp.getSourceOrType(), edp.getRecipeName());
														logger.info(obj.getTypeOfAction() + " : " + result);
													} else {
														logger.info(
																"******************* ERROR: SERVE *******************");
													}
												}

												boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
														edp.getFlame(), edp.getRecipeName());
												logger.info("SERVE flameWrite : " + flameWrite);
											} else {
												logger.error("No WRITE REGISTERS found in SERVE Action");
											}
										}
									} // End of Actions

									if (depFlag) {
										edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
									}

								}

							} // End of If Condition Executing List
						} else {
							if (_demoActions == null) {
								logger.error("Action not found with the given Action Id : " + edp.getActionId());
							}
							if (actionProcessingRules == null) {
								logger.error("Processing Rules not found with the given Action Id : "
										+ edp.getActionId() + ", Burner No : " + edp.getBurnerNo() + ", Rack Id : "
										+ edp.getRackId() + ", Section Id : " + edp.getSectionId());
							}
						}

					}
				} else {
					cdp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
					demoOrderProcessingRespository.save(cdp);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.error("*************** IOException ERROR IN EXECUTING: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}

		ModelAndView model = new ModelAndView();
		model.addObject("urlPage", "orderCooking");
		model.setViewName("/admin/orderCooking");
		return model;
	}

	public void updateRobotFreeStatus(Integer stationId) {
		if (stationId == 1) {
			isRobot1Free = false;
		}
		if (stationId == 2) {
			isRobot2Free = false;
		}
	}

	public boolean checkCollectionRackDependency(Integer sectionId, Integer rackId, Integer burnerNo, boolean _tFlag) {
		if (sectionId == SectionEnum.VEG.getLoc()) {
			if ((rackId == 1 && !isRack1VegSectionFree) || (rackId == 2 && !isRack2VegSectionFree)) {
				_tFlag = false;
			} else if (rackId == 1 && isRack1VegSectionFree && !isRack1VegBowlAvailable) {
				_tFlag = false;
			} else if (rackId == 1 && isRack1VegSectionFree && isRack1VegBowlAvailable
					&& (rack1VegColForBurnerNo != 0 && rack1VegColForBurnerNo != burnerNo)) {
				_tFlag = false;
			} else if (rackId == 2 && isRack2VegSectionFree && !isRack2VegBowlAvailable) {
				_tFlag = false;
			} else if (rackId == 2 && isRack2VegSectionFree && isRack2VegBowlAvailable
					&& (rack2VegColForBurnerNo != 0 && rack2VegColForBurnerNo != burnerNo)) {
				_tFlag = false;
			}
		} else if (sectionId == SectionEnum.MEAT.getLoc()) {
			if ((rackId == 1 && !isRack1MeatSectionFree) || (rackId == 2 && !isRack2MeatSectionFree)) {
				_tFlag = false;
			} else if (rackId == 1 && isRack1MeatSectionFree && !isRack1MeatBowlAvailable) {
				_tFlag = false;
			} else if (rackId == 1 && isRack1MeatSectionFree && isRack1MeatBowlAvailable
					&& (rack1MeatColForBurnerNo != 0 && rack1MeatColForBurnerNo != burnerNo)) {
				_tFlag = false;
			} else if (rackId == 2 && isRack2MeatSectionFree && !isRack2MeatBowlAvailable) {
				_tFlag = false;
			} else if (rackId == 2 && isRack2MeatSectionFree && isRack2MeatBowlAvailable
					&& (rack2MeatColForBurnerNo != 0 && rack2MeatColForBurnerNo != burnerNo)) {
				_tFlag = false;
			}
		} else if (sectionId == SectionEnum.SPICE.getLoc()) {
			if ((rackId == 1 && !isRack1SpiceSectionFree) || (rackId == 2 && !isRack2SpiceSectionFree)) {
				_tFlag = false;
			} else if (rackId == 1 && isRack1SpiceSectionFree && !isRack1SpiceBowlAvailable) {
				_tFlag = false;
			} else if (rackId == 1 && isRack1SpiceSectionFree && isRack1SpiceBowlAvailable
					&& (rack1SpiceColForBurnerNo != 0 && rack1SpiceColForBurnerNo != burnerNo)) {
				_tFlag = false;
			} else if (rackId == 2 && isRack2SpiceSectionFree && !isRack2SpiceBowlAvailable) {
				_tFlag = false;
			} else if (rackId == 2 && isRack2SpiceSectionFree && isRack2SpiceBowlAvailable
					&& (rack2SpiceColForBurnerNo != 0 && rack2SpiceColForBurnerNo != burnerNo)) {
				_tFlag = false;
			}
		}
		return _tFlag;
	}

	public boolean checkPickupRackDependency(Integer sectionId, Integer rackId, Integer burnerNo, boolean _tFlag,
			boolean forFryer) {
		if (sectionId == SectionEnum.VEG.getLoc()) {
			if ((rackId == 1 && isRack1VegSectionFree) || (rackId == 2 && isRack2VegSectionFree)) {
				_tFlag = false;
			}
			if ((rackId == 1 && !isRack1VegBowlAvailable) || (rackId == 2 && !isRack2VegBowlAvailable)) {
				_tFlag = false;
			}
			if ((rackId == 1 && !isRack1VegCollectionDone) || (rackId == 2 && !isRack2VegCollectionDone)) {
				_tFlag = false;
			}
			if (!forFryer) {
				if (burnerNo != rack1VegColForBurnerNo && burnerNo != rack2VegColForBurnerNo) {
					_tFlag = false;
				}
			} else {
				if (burnerNo == 1 && (!isFryer1Available || !isFryer1VegPoolFree)) {
					_tFlag = false;
				} else if (burnerNo == 2 && (!isFryer2Available || !isFryer2VegPoolFree)) {
					_tFlag = false;
				}
			}
		} else if (sectionId == SectionEnum.MEAT.getLoc()) {
			if ((rackId == 1 && isRack1MeatSectionFree) || (rackId == 2 && isRack2MeatSectionFree)) {
				_tFlag = false;
			}
			if ((rackId == 1 && !isRack1MeatBowlAvailable) || (rackId == 2 && !isRack2MeatBowlAvailable)) {
				_tFlag = false;
			}
			if ((rackId == 1 && !isRack1MeatCollectionDone) || (rackId == 2 && !isRack2MeatCollectionDone)) {
				_tFlag = false;
			}
			if (!forFryer) {
				if (burnerNo != rack1MeatColForBurnerNo && burnerNo != rack2MeatColForBurnerNo) {
					_tFlag = false;
				}
			} else {
				if (burnerNo == 1 && (!isFryer1Available || !isFryer1MeatPoolFree)) {
					_tFlag = false;
				} else if (burnerNo == 2 && (!isFryer2Available || !isFryer2MeatPoolFree)) {
					_tFlag = false;
				}
			}
		} else if (sectionId == SectionEnum.SPICE.getLoc()) {
			if ((rackId == 1 && isRack1SpiceSectionFree) || (rackId == 2 && isRack2SpiceSectionFree)) {
				_tFlag = false;
			}
			if ((rackId == 1 && !isRack1SpiceBowlAvailable) || (rackId == 2 && !isRack2SpiceBowlAvailable)) {
				_tFlag = false;
			}
			if ((rackId == 1 && !isRack1SpiceCollectionDone) || (rackId == 2 && !isRack2SpiceCollectionDone)) {
				_tFlag = false;
			}
			if (!forFryer) {
				if (burnerNo != rack1SpiceColForBurnerNo && burnerNo != rack2SpiceColForBurnerNo) {
					_tFlag = false;
				}
			}
		}
		return _tFlag;
	}

	public boolean checkRobotDependecy(Integer stationId, boolean _tFlag) {
		if (stationId == 1 && !isRobot1Free) {
			_tFlag = false;
		}
		if (stationId == 2 && !isRobot2Free) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkBurnerDependecy(Integer burnerNo, boolean _tFlag) {
		if (burnerNo < 1 || burnerNo > 4) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkUtensilDependecy(Integer burnerNo, boolean _tFlag) {
		if ((burnerNo == 1 && !isBurner1UtensilPickDone) || (burnerNo == 2 && !isBurner2UtensilPickDone)
				|| (burnerNo == 3 && !isBurner3UtensilPickDone) || (burnerNo == 4 && !isBurner4UtensilPickDone)) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkSpatulaDependecy(Integer burnerNo, boolean _tFlag) {
		if ((burnerNo == 1 && !isBurner1SpatulaPickDone) || (burnerNo == 2 && !isBurner2SpatulaPickDone)
				|| (burnerNo == 3 && !isBurner3SpatulaPickDone) || (burnerNo == 4 && !isBurner4SpatulaPickDone)) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkHoldingStationDependecyForBowl(Integer sectionId, Integer stationId, Integer wcBwc,
			boolean _tFlag) {
		if (sectionId == SectionEnum.VEG.getLoc() && wcBwc == BowlPickEnum.WBC.getChangeType()
				&& (stationId == 1 ? !isHoldingStation1VegBowlsAvailable : !isHoldingStation2VegBowlsAvailable)) {
			_tFlag = false;
		} else if (sectionId == SectionEnum.MEAT.getLoc() && wcBwc == BowlPickEnum.WBC.getChangeType()
				&& (stationId == 1 ? !isHoldingStation1MeatBowlsAvailable : !isHoldingStation2MeatBowlsAvailable)) {
			_tFlag = false;
		} else if (sectionId == SectionEnum.SPICE.getLoc() && wcBwc == BowlPickEnum.WBC.getChangeType()
				&& (stationId == 1 ? !isHoldingStation1SpiceBowlsAvailable : !isHoldingStation2SpiceBowlsAvailable)) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkServingStationDependecy(Integer stationId, boolean _tFlag) {
		if (stationId == 1 && !isServingStationPosition1Free) {
			_tFlag = false;
		}
		if (stationId == 2 && !isServingStationPosition2Free) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkLiquidDependecy(Integer burnerNo, boolean _tFlag) {
		if ((burnerNo == 1 || burnerNo == 2)
				&& (!isStation1DedicatedLiquidDispenserFree || !isStation1CommonLiquidDispenserFree)) {
			_tFlag = false;
		}
		if ((burnerNo == 3 || burnerNo == 4)
				&& (!isStation2DedicatedLiquidDispenserFree || !isStation2CommonLiquidDispenserFree)) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkCrossLiquidDependecyPickupAndServe(Integer burnerNo, boolean _tFlag) {
		if (burnerNo == 1 && ((!isStation1DedicatedLiquidDispenserFree && station1DedicatedLiquidDispenserOnBurner == 1)
				|| (!isStation1CommonLiquidDispenserFree && station1CommonLiquidDispenserOnBurner == 1))) {
			_tFlag = false;
		}
		if (burnerNo == 2 && ((!isStation1DedicatedLiquidDispenserFree && station1DedicatedLiquidDispenserOnBurner == 2)
				|| (!isStation1CommonLiquidDispenserFree && station1CommonLiquidDispenserOnBurner == 2))) {
			_tFlag = false;
		}
		if (burnerNo == 3 && ((!isStation2DedicatedLiquidDispenserFree && station2DedicatedLiquidDispenserOnBurner == 3)
				|| (!isStation2CommonLiquidDispenserFree && station2CommonLiquidDispenserOnBurner == 3))) {
			_tFlag = false;
		}
		if (burnerNo == 4 && ((!isStation2DedicatedLiquidDispenserFree && station2DedicatedLiquidDispenserOnBurner == 4)
				|| (!isStation2CommonLiquidDispenserFree && station2CommonLiquidDispenserOnBurner == 4))) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public boolean checkCrossLiquidDependecyDuringStirrAndToss(Integer burnerNo, boolean _tFlag) {
		if (burnerNo == 1 && ((!isStation1DedicatedLiquidDispenserFree && station1DedicatedLiquidDispenserOnBurner == 1)
				|| station1CommonLiquidDispenserOnBurner != 2)) {
			_tFlag = false;
		}
		if (burnerNo == 2 && ((!isStation1DedicatedLiquidDispenserFree && station1DedicatedLiquidDispenserOnBurner == 2)
				|| station1CommonLiquidDispenserOnBurner != 1)) {
			_tFlag = false;
		}
		if (burnerNo == 3 && ((!isStation2DedicatedLiquidDispenserFree && station2DedicatedLiquidDispenserOnBurner == 3)
				|| station2CommonLiquidDispenserOnBurner != 4)) {
			_tFlag = false;
		}
		if (burnerNo == 4 && ((!isStation2DedicatedLiquidDispenserFree && station2DedicatedLiquidDispenserOnBurner == 4)
				|| station2CommonLiquidDispenserOnBurner != 3)) {
			_tFlag = false;
		}
		return _tFlag;
	}

	public void updateCurrentBurnerGroupId(Integer currentBurnerId, Integer groupId) {
		if (currentBurnerId == BurnerEnum.BURNER1.getBurnerNo()) {
			burner1CurrentGroupId = groupId;
		} else if (currentBurnerId == BurnerEnum.BURNER2.getBurnerNo()) {
			burner2CurrentGroupId = groupId;
		} else if (currentBurnerId == BurnerEnum.BURNER3.getBurnerNo()) {
			burner3CurrentGroupId = groupId;
		} else if (currentBurnerId == BurnerEnum.BURNER4.getBurnerNo()) {
			burner4CurrentGroupId = groupId;
		}
	}

	public List<DemoBurners> getAvailableBurners() {
		return demoBurnersRepository.getActiveFreeBurners(true, true);
	}

	public boolean getIngredientAvailability(int burnerNo, int recipeId) {
		return true;
	}

	public boolean getUtensilAvailability(int stationId, int recipeId) {
		return true;
	}

	public boolean getUtensilAvailabilityByType(int holdingStationId, int utensilType) {
		return true;
	}

	public boolean getSpatulaAvailability(int stationId, int recipeId) {
		return true;
	}

	public boolean getSpatulaAvailabilityByType(int holdingStationId, int spatulaType) {
		return true;
	}

	public boolean getBowlAvailability(int stationId, int recipeId) {
		return true;
	}

	public boolean getBowlAvailabilityByType(int stationId, int bowlType) {
		return true;
	}

	public boolean getHelathChecks(int burnerNo, int recipeId) {
		return true;
	}

	public boolean getServingStationPositionFree(int servingStationId, int positionId) {
		return true;
	}

	public boolean invokeWriteToRegisterAPI(int address, int value, String recipeName) {
		boolean invokeAPISuccess = false;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			mc.WriteSingleRegister(address, value);
			logger.info("Writing to Address:" + mc.ReadInputRegisters(address, 1));
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			logger.info("*************** UnknownHostException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}

	public void invokePrintReadHoldingRegistersAPI(String recipeName, Integer actionId, Integer registerAddress,
			int registerCount) {
		int[] registerValues = new int[registerCount];
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			registerValues = mc.ReadHoldingRegisters(registerAddress, registerCount);
			for (int i = 0; i < registerValues.length; i++) {
				logger.info("Recipe - " + recipeName + " with Action - " + actionId + "Read Address: "
						+ (registerAddress + i) + " - " + registerValues[i]);
			}
		} catch (UnknownHostException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}
	}

	public boolean[] invokeReadCoilsAPI(String recipeName) {
		boolean[] status = null;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			status = mc.ReadCoils(COIL_STRAT_ADDRESS, NO_OF_COILS_TO_READ);
		} catch (UnknownHostException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}

		return status;
	}

	private Integer getAddress(Integer burnerNo, RegisterAddress obj) {
		int address = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			address = obj.getBurner1Register();
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			address = obj.getBurner2Register();
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			address = obj.getBurner3Register();
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			address = obj.getBurner4Register();
		}
		return address;
	}

	private Integer getCoilAddress(Integer burnerNo, Integer actionId) {
		int coilAddress = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_1_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_1_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_1_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_1_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_1_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_2_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_2_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_2_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_2_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_2_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_3_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_3_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_3_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_3_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_3_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_4_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_4_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_4_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_4_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_4_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_SERVE_DONE.coilAddress;
			}
		}
		return coilAddress;
	}

	private Integer getNoOfRegisters(Integer actionId) {
		int noOfRegisters = 0;
		if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
			noOfRegisters = ActionEnum.UTENSIL_PICK.noOfRegisters;
		} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
			noOfRegisters = ActionEnum.SPATULA_PICK.noOfRegisters;
		} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
			noOfRegisters = ActionEnum.VEG_COLLECTION.noOfRegisters;
		} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
			noOfRegisters = ActionEnum.SPICE_COLLECTION.noOfRegisters;
		} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
			noOfRegisters = ActionEnum.MEAT_COLLECTION.noOfRegisters;
		} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
			noOfRegisters = ActionEnum.VEG_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
			noOfRegisters = ActionEnum.SPICE_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
			noOfRegisters = ActionEnum.MEAT_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.IGNITION.actionId) {
			noOfRegisters = ActionEnum.IGNITION.noOfRegisters;
		} else if (actionId == ActionEnum.STIRR.actionId) {
			noOfRegisters = ActionEnum.STIRR.noOfRegisters;
		} else if (actionId == ActionEnum.TOSS.actionId) {
			noOfRegisters = ActionEnum.TOSS.noOfRegisters;
		} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
			noOfRegisters = ActionEnum.LIQUID_DISPENSING.noOfRegisters;
		} else if (actionId == ActionEnum.DELAY.actionId) {
			noOfRegisters = ActionEnum.DELAY.noOfRegisters;
		} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
			noOfRegisters = ActionEnum.FRYER_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
			noOfRegisters = ActionEnum.FRYER_ACTION.noOfRegisters;
		} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
			noOfRegisters = ActionEnum.FRYER_SERVE.noOfRegisters;
		} else if (actionId == ActionEnum.SERVE.actionId) {
			noOfRegisters = ActionEnum.SERVE.noOfRegisters;
		}
		return noOfRegisters;
	}

	private Map<Integer, Integer> getBurnerWiseFlameAddressMap() {
		RegisterAddress registerAddress = registerAddressRepository
				.findByActionIdTypeOfAction(ActionEnum.IGNITION.actionId, RegisterEnum.FLAME_LEVEL_WRITE.label);
		if (registerAddress != null) {
			Map<Integer, Integer> burnerFlameAddressMap = new HashMap<>();
			burnerFlameAddressMap.put(1, registerAddress.getBurner1Register());
			burnerFlameAddressMap.put(2, registerAddress.getBurner1Register());
			burnerFlameAddressMap.put(3, registerAddress.getBurner1Register());
			burnerFlameAddressMap.put(4, registerAddress.getBurner1Register());
			return burnerFlameAddressMap;
		} else {
			return null;
		}
	}

}
