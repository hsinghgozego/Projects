package com.nala.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.ServingStation;
import com.nala.model.User;
import com.nala.repository.ServingStationRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class ServingStationController {

	private static final Logger logger = LoggerFactory.getLogger(ServingStationController.class);
	//list-servingStations
	///admin/list-servingStations
	
	@Autowired
	ServingStationRepository servingStationRepository;
	
	@RequestMapping("/list-servingStations")
	public ModelAndView listBurners(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "servingStationSearchName", required = false) String servingStationSearchName,
			@RequestParam(value = "servingStationSearchType", required = false) String servingStationSearchType,
			@RequestParam(value = "servingStationSearchStatus", required = false) String servingStationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax){
		
		Iterable<ServingStation> servingStationsList = servingStationRepository.findAll();
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new ServingStation());
		model.addObject("servingStationsList", servingStationsList);
		model.setViewName("/admin/servingStations_list");
		return model;
				
	}
	
	
	
	
	
}
