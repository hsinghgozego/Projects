package com.nala.controller.demo;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nala.enums.ActionEnum;
import com.nala.enums.BurnerEnum;
import com.nala.enums.CoilEnum;
import com.nala.enums.OperationTypeEnum;
import com.nala.enums.RegisterEnum;
import com.nala.model.DispenseSetting;
import com.nala.model.RegisterAddress;
import com.nala.model.RegisterAddressForm;
import com.nala.model.demo.DemoBins;
import com.nala.model.demo.DemoBurners;
import com.nala.model.demo.DemoIngredients;
import com.nala.model.demo.DemoRecipeDetails;
import com.nala.model.demo.DemoRecipes;
import com.nala.model.helper.FryerAction;
import com.nala.model.helper.FryerPickup;
import com.nala.model.helper.FryerServe;
import com.nala.model.helper.LiquidBin;
import com.nala.repository.demo.ActionProcessingRulesRepository;
import com.nala.repository.IngredientRepository;
import com.nala.repository.RegisterAddressRepository;
import com.nala.repository.demo.CoilAddressRepository;
import com.nala.repository.demo.DemoBinsRepository;
import com.nala.repository.demo.DemoBurnersRepository;
import com.nala.repository.demo.DemoIngredientsRepository;
import com.nala.repository.demo.DemoRacksRepository;
import com.nala.repository.demo.DemoRecipeDetailsRepository;
import com.nala.repository.demo.DemoRecipesRepository;

import de.re.easymodbus.modbusclient.ModbusClient;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RecipeDemoController {

	private static final Logger logger = LoggerFactory.getLogger(RecipeDemoController.class);

	private static final String IP_ADDR = "192.168.2.245";
	private static final Integer PORT = 502;
	private static final Integer COIL_STRAT_ADDRESS = 5000;
	private static final Integer NO_OF_COILS_TO_READ = 1990;

	@Autowired
	ActionProcessingRulesRepository actionProcessingRulesRepository;

	@Autowired
	CoilAddressRepository coilAddressRepository;

	@Autowired
	DemoBinsRepository demoBinsRepository;

	@Autowired
	DemoBurnersRepository demoBurnersRepository;

	@Autowired
	DemoRacksRepository demoRacksRepository;

	@Autowired
	DemoIngredientsRepository demoIngredientsRepository;

	@Autowired
	DemoRecipesRepository demoRecipesRepository;

	@Autowired
	IngredientRepository ingredientRepository;

	@Autowired
	RegisterAddressRepository registerAddressRepository;

	@Autowired
	DemoRecipeDetailsRepository demoRecipeDetailsRepository;

	@RequestMapping("/recipeCooking")
	public ModelAndView openRegisterInfo() {
		ModelAndView model = new ModelAndView();
		List<DemoRecipes> demoRecipesList = demoRecipesRepository.getRecipesByActiveStatus(true);
		List<DemoBurners> demoBurnersList = demoBurnersRepository.getByBurnerStatus(true);
		model.addObject("urlPage", "recipeCooking");
		model.addObject("demoRecipesList", demoRecipesList);
		model.addObject("demoBurnersList", demoBurnersList);
		model.addObject("command", new RegisterAddressForm());
		model.setViewName("/admin/recipeCooking");
		return model;
	}

	@RequestMapping(value = "/cooking/{recipeId}/{burnerId}", method = RequestMethod.GET)
	public ModelAndView writeRegsiters(@PathVariable("recipeId") Integer recipeId,
			@PathVariable("burnerId") Integer burnerNo) {

		ModbusClient mc = null;

		try {

			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			for (int b = 3001; b < 6000;) {
				int[] a = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
				mc.WriteMultipleRegisters(b, a);
				b += 30;
			}
			mc.Disconnect();

			int rackId = 0;
			if (burnerNo == 1 || burnerNo == 2) {
				rackId = 1;
			} else if (burnerNo == 3 || burnerNo == 4) {
				rackId = 2;
			}

			List<DemoRecipeDetails> testRecipeList = demoRecipeDetailsRepository.findByRecipeId(recipeId);

			TreeMap<Integer, List<DemoRecipeDetails>> groupActionsMap = new TreeMap<>();
			testRecipeList.forEach(tr -> {
				List<DemoRecipeDetails> tempList = null;
				if (groupActionsMap.get(tr.getGroupId()) != null) {
					tempList = groupActionsMap.get(tr.getGroupId());
				} else {
					tempList = new ArrayList<DemoRecipeDetails>();
				}
				tempList.add(tr);
				groupActionsMap.put(tr.getGroupId(), tempList);
			});

			// FLAME_LEVEL_WRITE
			int flameAddress = 0;
			RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
					ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
			if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
				flameAddress = flameObj.getBurner1Register();
			} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
				flameAddress = flameObj.getBurner2Register();
			} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
				flameAddress = flameObj.getBurner3Register();
			} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
				flameAddress = flameObj.getBurner4Register();
			} else {
				logger.info("******************* ERROR: FLAME_LEVEL_WRITE *******************");
			}

			for (Integer groupId : groupActionsMap.keySet()) {

				boolean flag = true;

				Map<Integer, Integer> actionToCoilMap = new HashMap<>();
				Map<Integer, Integer> actionToAddressMap = new HashMap<>();

				List<DemoRecipeDetails> trList = groupActionsMap.get(groupId);

				try {
					mc = new ModbusClient(IP_ADDR, PORT);
					mc.Connect();
					for (DemoRecipeDetails tr : trList) {

						// UTENSIL_PICK Action
						if (tr.getActionId() == ActionEnum.UTENSIL_PICK.actionId) {
							logger.info("******************* IN UTENSIL_PICK *******************");

							int actionAddress = 0;
							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.UTENSIL_PICK.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}
									if (obj.getTypeOfAction().equals(RegisterEnum.UTENSIL_PICK_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.UTENSIL_PICK.actionId);
										logger.info("address: " + mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(RegisterEnum.UTENSIL_TYPE_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: UTENSIL_PICK *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.UTENSIL_PICK.actionId,
										getCoilAddress(burnerNo, ActionEnum.UTENSIL_PICK.actionId));
								actionToAddressMap.put(ActionEnum.UTENSIL_PICK.actionId, actionAddress);
							} else {
								logger.error("No WRITE REGISTERS found in UTENSIL_PICK Action");
							}

						}
						// SPATULA_PICK Action
						else if (tr.getActionId() == ActionEnum.SPATULA_PICK.actionId) {
							logger.info("******************* IN SPATULA_PICK *******************");

							int actionAddress = 0;
							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.SPATULA_PICK.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}
									if (obj.getTypeOfAction().equals(RegisterEnum.SPATULA_PICK_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.SPATULA_PICK.actionId);
										logger.info("address: " + mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(RegisterEnum.SPATULA_TYPE_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: SPATULA_PICK *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.SPATULA_PICK.actionId,
										getCoilAddress(burnerNo, ActionEnum.SPATULA_PICK.actionId));
								actionToAddressMap.put(ActionEnum.SPATULA_PICK.actionId, actionAddress);
							} else {
								logger.error("No WRITE REGISTERS found in SPATULA_PICK Action");
							}

						}
						// VEG_COLLECTION Action
						else if (tr.getActionId() == ActionEnum.VEG_COLLECTION.actionId) {
							logger.info("******************* IN VEG_COLLECTION *******************");

							int actionAddress = 0;
							DispenseSetting ds = null;
							DemoBins db = null;

							DemoIngredients ingredient = demoIngredientsRepository
									.findByIngredientId((Integer) tr.getSourceOrType());
							List<DispenseSetting> dss = ingredient.getDispenseSettings();
							for (DispenseSetting _ds : dss) {
								if ((tr.getQty() >= _ds.getMin()) && (tr.getQty() <= _ds.getMax())) {
									ds = _ds;
									break;
								}
							}

							List<DemoBins> dbList = demoBinsRepository
									.findByIngredientIdRackId(ingredient.getIngredientId(), rackId);
							if (!dbList.isEmpty()) {
								db = dbList.get(0);
								// WRITE REGISTERS
								List<RegisterAddress> writeList = registerAddressRepository
										.findByActionNameAndOperationType(ActionEnum.VEG_COLLECTION.label,
												OperationTypeEnum.WRITE.getValue());
								if (writeList != null && !writeList.isEmpty()) {
									for (RegisterAddress obj : writeList) {
										int address = getAddress(burnerNo, obj);
										if (address != 0 && actionAddress == 0) {
											actionAddress = address;
										}

										if (obj.getTypeOfAction().equals(RegisterEnum.VEG_COLLECTION_WRITE.label)) {
											logger.info("VEG_COLLECTION_WRITE address:" + address + ", actionId:"
													+ ActionEnum.VEG_COLLECTION.actionId);
											mc.WriteSingleRegister(address, ActionEnum.VEG_COLLECTION.actionId);
											logger.info("address: " + address + ", actionId:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_COLLECTION_BIN_NUMBER_WRITE.label)) {
											logger.info("VEG_COLLECTION_BIN_NUMBER_WRITE address:" + address
													+ ", actionId:" + db.getBinNo());
											mc.WriteSingleRegister(address, db.getBinNo());
											logger.info("address: " + address + ", Bin:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_COLLECTION_WEIGHT_WRITE.label)) {
											logger.info("VEG_COLLECTION_WEIGHT_WRITE address:" + address
													+ ", COLLECTION_WEIGHT_WRITE:" + tr.getQty());
											mc.WriteSingleRegister(address, tr.getQty());
											logger.info("address: " + address + ", Qty: "
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
											if (ds != null) {
												logger.info("VEG_MOTOR_CUTOFF_IN_PCT address:" + address
														+ ", CUTOFF_IN_PCT:" + ds.getCutOffPct());
												mc.WriteSingleRegister(address, ds.getCutOffPct());
												logger.info("address: " + address + ", CutOffPct: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 95);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
											if (ds != null) {
												logger.info("VEG_MOTOR_NORMAL_IN_PCT address:" + address
														+ ", NORMAL_IN_PCT:" + ds.getNormalOpsInPct());
												mc.WriteSingleRegister(address, ds.getNormalOpsInPct());
												logger.info("address: " + address + ", NormalOpsInPct: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 10);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_MOTOR_NORMAL_SPEED_WRITE.label)) {
											if (ds != null) {
												logger.info("VEG_MOTOR_NORMAL_SPEED_WRITE address:" + address
														+ ", NORMAL_SPEED_WRITE:" + ds.getNormalOpsSpeed());
												mc.WriteSingleRegister(address, ds.getNormalOpsSpeed());
												logger.info("address: " + address + ", NormalOpsSpeed: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 20);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_MOTOR_INCHING_SPEED_WRITE.label)) {
											if (ds != null) {
												logger.info("VEG_MOTOR_INCHING_SPEED_WRITE address:" + address
														+ ", INCHING_SPEED_WRITE:" + ds.getInchingSpeed());
												mc.WriteSingleRegister(address, ds.getInchingSpeed());
												logger.info("address: " + address + ", InchingSpeed: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 20);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction().equals(
												RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
											if (ds != null) {
												logger.info(
														"VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_OPERATION address:"
																+ address + ", GAP_BETWEEN_NORMAL_AND_INCH_OPERATION:"
																+ ds.getGapBtwNormalAndInch());
												mc.WriteSingleRegister(address, ds.getGapBtwNormalAndInch());
												logger.info("address: " + address + ", GapBtwNormalAndInch: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 15);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
											if (ds != null) {
												logger.info("VEG_MOTOR_TIME_GAP_BETWEEN_INCHING address:" + address
														+ ", GAP_BETWEEN_INCHING:" + ds.getGapBtwInch());
												mc.WriteSingleRegister(address, ds.getGapBtwInch());
												logger.info("address: " + address + ", GapBtwInch: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 7);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.VEG_MOTOR_INCHING_TIME_WRITE.label)) {
											if (ds != null) {
												logger.info("VEG_MOTOR_INCHING_TIME address:" + address
														+ ", INCHING_TIME:" + ds.getInchingTime());
												mc.WriteSingleRegister(address, ds.getInchingTime());
												logger.info("address: " + address + ", InchingTime: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 2);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else {
											logger.info(
													"******************* ERROR: VEG_COLLECTION *******************");
										}
									}

									mc.WriteSingleRegister(flameAddress, tr.getFlame());
									logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

									actionToCoilMap.put(ActionEnum.VEG_COLLECTION.actionId,
											getCoilAddress(burnerNo, ActionEnum.VEG_COLLECTION.actionId));
									actionToAddressMap.put(ActionEnum.VEG_COLLECTION.actionId, actionAddress);

								} else {
									logger.error("No WRITE REGISTERS found in VEG_COLLECTION Action");
								}

							} else {
								logger.error("No VEG Bins found with the Given Ingredient Id : "
										+ ingredient.getIngredientId());
							}

						}
						// SPICE_COLLECTION Action
						else if (tr.getActionId() == ActionEnum.SPICE_COLLECTION.actionId) {
							logger.info("******************* IN SPICE_COLLECTION *******************");

							int actionAddress = 0;
							DispenseSetting ds = null;
							DemoBins db = null;

							DemoIngredients ingredient = demoIngredientsRepository
									.findByIngredientId((Integer) tr.getSourceOrType());
							List<DispenseSetting> dss = ingredient.getDispenseSettings();
							for (DispenseSetting _ds : dss) {
								if ((tr.getQty() >= _ds.getMin()) && (tr.getQty() <= _ds.getMax())) {
									ds = _ds;
									break;
								}
							}

							List<DemoBins> dbList = demoBinsRepository
									.findByIngredientIdRackId(ingredient.getIngredientId(), rackId);
							if (!dbList.isEmpty()) {
								db = dbList.get(0);

								// WRITE REGISTERS
								List<RegisterAddress> writeList = registerAddressRepository
										.findByActionNameAndOperationType(ActionEnum.SPICE_COLLECTION.label,
												OperationTypeEnum.WRITE.getValue());
								if (writeList != null && !writeList.isEmpty()) {
									for (RegisterAddress obj : writeList) {
										int address = getAddress(burnerNo, obj);
										if (address != 0 && actionAddress == 0) {
											actionAddress = address;
										}

										if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_COLLECTION_WRITE.label)) {
											logger.info("SPICE_COLLECTION_WRITE address:" + address + ", actionId:"
													+ ActionEnum.SPICE_COLLECTION.actionId);
											mc.WriteSingleRegister(address, ActionEnum.SPICE_COLLECTION.actionId);
											logger.info("address: " + address + ", actionId:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_COLLECTION_BIN_NUMBER_WRITE.label)) {
											logger.info("SPICE_COLLECTION_BIN_NUMBER_WRITE address:" + address
													+ ", BIN_NUMBER:" + db.getBinNo());
											mc.WriteSingleRegister(address, db.getBinNo());
											logger.info("address: " + address + ", Bin:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_COLLECTION_WEIGHT_WRITE.label)) {
											logger.info("SPICE_COLLECTION_WEIGHT_WRITE address:" + address
													+ ", COLLECTION_WEIGHT_WRITE:" + tr.getQty());
											mc.WriteSingleRegister(address, tr.getQty());
											logger.info("address: " + address + ", Qty:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
											if (ds != null) {
												logger.info("SPICE_MOTOR_CUTOFF_IN_PCT address:" + address
														+ ", CUTOFF_IN_PCT:" + ds.getCutOffPct());
												mc.WriteSingleRegister(address, ds.getCutOffPct());
												logger.info("address: " + address + ", CutOffPct: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 95);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
											if (ds != null) {
												logger.info("SPICE_MOTOR_NORMAL_IN_PCT address:" + address
														+ ", NORMAL_IN_PCT:" + ds.getNormalOpsInPct());
												mc.WriteSingleRegister(address, ds.getNormalOpsInPct());
												logger.info("address: " + address + ", NormalOpsInPct: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 10);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_MOTOR_NORMAL_SPEED_WRITE.label)) {
											if (ds != null) {
												logger.info("SPICE_MOTOR_NORMAL_SPEED_WRITE address:" + address
														+ ", NORMAL_SPEED_WRITE:" + ds.getNormalOpsSpeed());
												mc.WriteSingleRegister(address, ds.getNormalOpsSpeed());
												logger.info("address: " + address + ", NormalOpsSpeed: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 20);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_MOTOR_INCHING_SPEED_WRITE.label)) {
											if (ds != null) {
												logger.info("SPICE_MOTOR_INCHING_SPEED_WRITE address:" + address
														+ ", INCHING_SPEED_WRITE:" + ds.getInchingSpeed());
												mc.WriteSingleRegister(address, ds.getInchingSpeed());
												logger.info("address: " + address + ", InchingSpeed: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 20);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction().equals(
												RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
											if (ds != null) {
												logger.info(
														"SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_OPERATION address:"
																+ address + ", GAP_BETWEEN_NORMAL_AND_INCH_OPERATION:"
																+ ds.getGapBtwNormalAndInch());
												mc.WriteSingleRegister(address, ds.getGapBtwNormalAndInch());
												logger.info("address: " + address + ", GapBtwNormalAndInch: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 15);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
											if (ds != null) {
												logger.info("SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING address:" + address
														+ ", GAP_BETWEEN_INCHING:" + ds.getGapBtwInch());
												mc.WriteSingleRegister(address, ds.getGapBtwInch());
												logger.info("address: " + address + ", GapBtwInch: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 7);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.SPICE_MOTOR_INCHING_TIME_WRITE.label)) {
											if (ds != null) {
												logger.info("SPICE_MOTOR_INCHING_TIME address:" + address
														+ ", INCHING_TIME:" + ds.getInchingTime());
												mc.WriteSingleRegister(address, ds.getInchingTime());
												logger.info("address: " + address + ", InchingTime: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 2);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else {
											logger.info(
													"******************* ERROR: SPICE_COLLECTION *******************");
										}
									}

									mc.WriteSingleRegister(flameAddress, tr.getFlame());
									logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

									actionToCoilMap.put(ActionEnum.SPICE_COLLECTION.actionId,
											getCoilAddress(burnerNo, ActionEnum.SPICE_COLLECTION.actionId));
									actionToAddressMap.put(ActionEnum.SPICE_COLLECTION.actionId, actionAddress);

								} else {
									logger.error("No WRITE REGISTERS found in SPICE_COLLECTION Action");
								}

							} else {
								logger.error("No SPICE Bins found with the Given Ingredient Id : "
										+ ingredient.getIngredientId());
							}

						}
						// MEAT_COLLECTION Action
						else if (tr.getActionId() == ActionEnum.MEAT_COLLECTION.actionId) {
							logger.info("******************* IN MEAT_COLLECTION *******************");

							int actionAddress = 0;
							DispenseSetting ds = null;
							DemoBins db = null;

							DemoIngredients ingredient = demoIngredientsRepository
									.findByIngredientId((Integer) tr.getSourceOrType());
							List<DispenseSetting> dss = ingredient.getDispenseSettings();
							for (DispenseSetting _ds : dss) {
								if ((tr.getQty() >= _ds.getMin()) && (tr.getQty() <= _ds.getMax())) {
									ds = _ds;
									break;
								}
							}

							List<DemoBins> dbList = demoBinsRepository
									.findByIngredientIdRackId(ingredient.getIngredientId(), rackId);
							if (!dbList.isEmpty()) {
								db = dbList.get(0);

								// WRITE REGISTERS
								List<RegisterAddress> writeList = registerAddressRepository
										.findByActionNameAndOperationType(ActionEnum.MEAT_COLLECTION.label,
												OperationTypeEnum.WRITE.getValue());
								if (writeList != null && !writeList.isEmpty()) {
									for (RegisterAddress obj : writeList) {
										int address = getAddress(burnerNo, obj);
										if (address != 0 && actionAddress == 0) {
											actionAddress = address;
										}

										if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_COLLECTION_WRITE.label)) {
											logger.info("MEAT_COLLECTION_WRITE address:" + address + ", actionId:"
													+ ActionEnum.MEAT_COLLECTION.actionId);
											mc.WriteSingleRegister(address, ActionEnum.MEAT_COLLECTION.actionId);
											logger.info("address: " + address + ", actionId:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_COLLECTION_BIN_NUMBER_WRITE.label)) {
											logger.info("MEAT_COLLECTION_BIN_NUMBER_WRITE address:" + address
													+ ", BIN_NUMBER:" + db.getBinNo());
											mc.WriteSingleRegister(address, db.getBinNo());
											logger.info("address: " + address + ", Bin:"
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_COLLECTION_WEIGHT_WRITE.label)) {
											mc.WriteSingleRegister(address, tr.getQty());
											logger.info("address: " + address + ", Qty: "
													+ mc.ReadHoldingRegisters(address, 1)[0]);
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
											if (ds != null) {
												logger.info("MEAT_MOTOR_CUTOFF_IN_PCT address:" + address
														+ ", CUTOFF_IN_PCT:" + ds.getCutOffPct());
												mc.WriteSingleRegister(address, ds.getCutOffPct());
												logger.info("address: " + address + ", CutOffPct: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 95);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
											if (ds != null) {
												logger.info("MEAT_MOTOR_NORMAL_IN_PCT address:" + address
														+ ", NORMAL_IN_PCT:" + ds.getNormalOpsInPct());
												mc.WriteSingleRegister(address, ds.getNormalOpsInPct());
												logger.info("address: " + address + ", NormalOpsInPct: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 10);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_MOTOR_NORMAL_SPEED_WRITE.label)) {
											if (ds != null) {
												logger.info("MEAT_MOTOR_NORMAL_SPEED_WRITE address:" + address
														+ ", NORMAL_SPEED_WRITE:" + ds.getNormalOpsSpeed());
												mc.WriteSingleRegister(address, ds.getNormalOpsSpeed());
												logger.info("address: " + address + ", NormalOpsSpeed: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 20);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_MOTOR_INCHING_SPEED_WRITE.label)) {
											if (ds != null) {
												logger.info("MEAT_MOTOR_INCHING_SPEED_WRITE address:" + address
														+ ", INCHING_SPEED_WRITE:" + ds.getInchingSpeed());
												mc.WriteSingleRegister(address, ds.getInchingSpeed());
												logger.info("address: " + address + ", InchingSpeed: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 20);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction().equals(
												RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
											if (ds != null) {
												logger.info(
														"MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_OPERATION address:"
																+ address + ", GAP_BETWEEN_NORMAL_AND_INCH_OPERATION:"
																+ ds.getGapBtwNormalAndInch());
												mc.WriteSingleRegister(address, ds.getGapBtwNormalAndInch());
												logger.info("address: " + address + ", GapBtwNormalAndInch: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 15);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
											if (ds != null) {
												logger.info("MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING address:" + address
														+ ", GAP_BETWEEN_INCHING:" + ds.getGapBtwInch());
												mc.WriteSingleRegister(address, ds.getGapBtwInch());
												logger.info("address: " + address + ", GapBtwInch: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 7);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else if (obj.getTypeOfAction()
												.equals(RegisterEnum.MEAT_MOTOR_INCHING_TIME_WRITE.label)) {
											if (ds != null) {
												logger.info("MEAT_MOTOR_INCHING_TIME address:" + address
														+ ", INCHING_TIME:" + ds.getInchingTime());
												mc.WriteSingleRegister(address, ds.getInchingTime());
												logger.info("address: " + address + ", InchingTime: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											} else {
												mc.WriteSingleRegister(address, 2);
												logger.info("Default added value in address: "
														+ mc.ReadHoldingRegisters(address, 1)[0]);
											}
										} else {
											logger.info(
													"******************* ERROR: MEAT_COLLECTION *******************");
										}
									}

									mc.WriteSingleRegister(flameAddress, tr.getFlame());
									logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

									actionToCoilMap.put(ActionEnum.MEAT_COLLECTION.actionId,
											getCoilAddress(burnerNo, ActionEnum.MEAT_COLLECTION.actionId));
									actionToAddressMap.put(ActionEnum.MEAT_COLLECTION.actionId, actionAddress);

								} else {
									logger.error("No WRITE REGISTERS found in MEAT_COLLECTION Action");
								}

							} else {
								logger.error("No MEAT Bins found with the Given Ingredient Id : "
										+ ingredient.getIngredientId());
							}

						}
						// VEG_PICKUP Action
						else if (tr.getActionId() == ActionEnum.VEG_PICKUP.actionId) {
							logger.info("******************* IN VEG_PICKUP *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.VEG_PICKUP.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.VEG_PICKUP_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.VEG_PICKUP.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.VEG_PICKUP_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: VEG_PICKUP *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.VEG_PICKUP.actionId,
										getCoilAddress(burnerNo, ActionEnum.VEG_PICKUP.actionId));
								actionToAddressMap.put(ActionEnum.VEG_PICKUP.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in VEG_PICKUP Action");
							}

						}
						// SPICE_PICKUP Action
						else if (tr.getActionId() == ActionEnum.SPICE_PICKUP.actionId) {
							logger.info("******************* IN SPICE_PICKUP *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.SPICE_PICKUP.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_PICKUP_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.SPICE_PICKUP.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.SPICE_PICKUP_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + address + ", PICKUP_LOCATION:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: SPICE_PICKUP *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.SPICE_PICKUP.actionId,
										getCoilAddress(burnerNo, ActionEnum.SPICE_PICKUP.actionId));
								actionToAddressMap.put(ActionEnum.SPICE_PICKUP.actionId, actionAddress);
							} else {
								logger.error("No WRITE REGISTERS found in SPICE_PICKUP Action");
							}

						}
						// MEAT_PICKUP Action
						else if (tr.getActionId() == ActionEnum.MEAT_PICKUP.actionId) {
							logger.info("******************* IN MEAT_PICKUP *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.MEAT_PICKUP.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_PICKUP_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.MEAT_PICKUP.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.MEAT_PICKUP_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + address + ", PICKUP_LOCATION:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: MEAT_PICKUP *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.MEAT_PICKUP.actionId,
										getCoilAddress(burnerNo, ActionEnum.MEAT_PICKUP.actionId));
								actionToAddressMap.put(ActionEnum.MEAT_PICKUP.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in MEAT_PICKUP Action");
							}

						} // IGNITION Action
						else if (tr.getActionId() == ActionEnum.IGNITION.actionId) {
							logger.info("******************* IN IGNITION *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.IGNITION.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.IGNITION_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.IGNITION.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(RegisterEnum.IGNITION_DELAY_TIME_WRITE.label)) {
										mc.WriteSingleRegister(address, tr.getTime());
										logger.info("address: " + address + ", DELAY_TIME:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: IGNITION *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.IGNITION.actionId,
										getCoilAddress(burnerNo, ActionEnum.IGNITION.actionId));
								actionToAddressMap.put(ActionEnum.IGNITION.actionId, actionAddress);
							} else {
								logger.error("No WRITE REGISTERS found in IGNITION Action");
							}

						}
						// STIRR Action
						else if (tr.getActionId() == ActionEnum.STIRR.actionId) {
							logger.info("******************* IN STIRR *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.STIRR.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.STIRR.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.STIRR_TYPE_NUMBER_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + address + ", STIR_TYPE_NUMBER:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.STIRR_TIME_IN_MILLI_SEC_WRITE.label)) {
										mc.WriteSingleRegister(address, tr.getTime());
										logger.info("address: " + address + ", TIME:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: STIRR *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.STIRR.actionId,
										getCoilAddress(burnerNo, ActionEnum.STIRR.actionId));
								actionToAddressMap.put(ActionEnum.STIRR.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in STIRR Action");
							}
						}
						// TOSS Action
						else if (tr.getActionId() == ActionEnum.TOSS.actionId) {
							logger.info("******************* IN TOSS *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.TOSS.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.TOSS.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.TOSS_TYPE_NUMBER_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + address + ", TOSS_TYPE_NUMBER:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.TOSS_TIME_IN_MILLI_SEC_WRITE.label)) {
										mc.WriteSingleRegister(address, tr.getTime());
										logger.info("address: " + address + ", TIME:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: TOSS *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.TOSS.actionId,
										getCoilAddress(burnerNo, ActionEnum.TOSS.actionId));
								actionToAddressMap.put(ActionEnum.TOSS.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in STIRR");
							}

						}
						// LIQUID_DISPENSING Action
						else if (tr.getActionId() == ActionEnum.LIQUID_DISPENSING.actionId) {
							logger.info("******************* IN LIQUID_DISPENSING *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.LIQUID_DISPENSING.label,
											OperationTypeEnum.WRITE.getValue());
							ObjectMapper mapper = new ObjectMapper();
							List<LiquidBin> lb = mapper.convertValue(tr.getSourceOrType(),
									new TypeReference<List<LiquidBin>>() {
									});
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.LIQUID_DISPENSING.actionId);
										logger.info("address: " + address + ", actionId: "
												+ ActionEnum.LIQUID_DISPENSING.actionId);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE.label)) {
										if (lb.size() > 0) {
											List<DemoBins> dbList = demoBinsRepository
													.findByIngredientId(lb.get(0).getIngId());
											if (!dbList.isEmpty()) {
												DemoBins db = null;
												if (burnerNo == 1 || burnerNo == 2) {
													db = dbList.get(0);
												} else {
													db = dbList.get(1);
												}
												mc.WriteSingleRegister(address, db.getBinNo());
												logger.info("address: " + address + ", Bin 1: " + db.getBinNo());
											} else {
												logger.info("address: " + address
														+ ", No Bin 1 found with the Liquid Mapping : "
														+ lb.get(0).getIngId());
											}
										} else {
											logger.info("address: " + address
													+ ", Need to Dispense atleast 1 Liquid from Bin");
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_1_WRITE.label)) {
										if (lb.size() > 0) {
											mc.WriteSingleRegister(address, lb.get(0).getMs() / 100);
											logger.info("address: " + address + ", Bin 1 NoOfMilliSec: "
													+ lb.get(0).getMs());
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_WRITE.label)) {
										if (lb.size() >= 2) {
											List<DemoBins> dbList = demoBinsRepository
													.findByIngredientId(lb.get(1).getIngId());
											if (!dbList.isEmpty()) {
												DemoBins db = null;
												if (burnerNo == 1 || burnerNo == 2) {
													db = dbList.get(0);
												} else {
													db = dbList.get(1);
												}
												mc.WriteSingleRegister(address, db.getBinNo());
												logger.info("address: " + address + ", Bin 2: " + db.getBinNo());
											} else {
												logger.info("address: " + address
														+ ", No Bin found with the Liquid 2 Mapping : "
														+ lb.get(1).getIngId());
											}
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_2_WRITE.label)) {
										if (lb.size() >= 2) {
											mc.WriteSingleRegister(address, lb.get(1).getMs() / 100);
											logger.info("address: " + address + ", Bin 2 NoOfMilliSec: "
													+ lb.get(1).getMs());
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_WRITE.label)) {
										if (lb.size() >= 3) {
											List<DemoBins> dbList = demoBinsRepository
													.findByIngredientId(lb.get(2).getIngId());
											if (!dbList.isEmpty()) {
												DemoBins db = null;
												if (burnerNo == 1 || burnerNo == 2) {
													db = dbList.get(0);
												} else {
													db = dbList.get(1);
												}
												mc.WriteSingleRegister(address, db.getBinNo());
												logger.info("address: " + address + ", Bin 3: " + db.getBinNo());
											} else {
												logger.info("address: " + address
														+ ", No Bin found with the Liquid 3 Mapping : "
														+ lb.get(2).getIngId());
											}
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_3_WRITE.label)) {
										if (lb.size() >= 3) {
											mc.WriteSingleRegister(address, lb.get(2).getMs() / 100);
											logger.info("address: " + address + ", Bin 3 NoOfMilliSec: "
													+ lb.get(2).getMs());
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_WRITE.label)) {
										if (lb.size() >= 4) {
											List<DemoBins> dbList = demoBinsRepository
													.findByIngredientId(lb.get(3).getIngId());
											if (!dbList.isEmpty()) {
												DemoBins db = null;
												if (burnerNo == 1 || burnerNo == 2) {
													db = dbList.get(0);
												} else {
													db = dbList.get(1);
												}
												mc.WriteSingleRegister(address, db.getBinNo());
												logger.info("address: " + address + ", Bin 4: " + db.getBinNo());
											} else {
												logger.info("address: " + address
														+ ", No Bin found with the Liquid 4 Mapping : "
														+ lb.get(3).getIngId());
											}
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_4_WRITE.label)) {
										if (lb.size() >= 4) {
											mc.WriteSingleRegister(address, lb.get(3).getMs() / 100);
											logger.info("address: " + address + ", Bin 4 NoOfMilliSec: "
													+ lb.get(3).getMs());
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_WRITE.label)) {
										if (lb.size() >= 5) {
											List<DemoBins> dbList = demoBinsRepository
													.findByIngredientId(lb.get(4).getIngId());
											if (!dbList.isEmpty()) {
												DemoBins db = null;
												if (burnerNo == 1 || burnerNo == 2) {
													db = dbList.get(0);
												} else {
													db = dbList.get(1);
												}
												mc.WriteSingleRegister(address, db.getBinNo());
												logger.info("address: " + address + ", Bin 5: " + db.getBinNo());
											} else {
												logger.info("address: " + address
														+ ", No Bin found with the Liquid 5 Mapping : "
														+ lb.get(4).getIngId());
											}
										}
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_5_WRITE.label)) {
										if (lb.size() >= 5) {
											mc.WriteSingleRegister(address, lb.get(4).getMs() / 100);
											logger.info("address: " + address + ", Bin 5 NoOfMilliSec: "
													+ lb.get(4).getMs());
										}
									} else {
										logger.info("******************* ERROR: LIQUID_DISPENSING *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.LIQUID_DISPENSING.actionId,
										getCoilAddress(burnerNo, ActionEnum.LIQUID_DISPENSING.actionId));
								actionToAddressMap.put(ActionEnum.LIQUID_DISPENSING.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in LIQUID_DISPENSING Action");
							}

						} // DELAY Action
						else if (tr.getActionId() == ActionEnum.DELAY.actionId) {
							logger.info("******************* IN DELAY *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.DELAY.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.DELAY.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_TIME_WRITE.label)) {
										mc.WriteSingleRegister(address, tr.getTime());
										logger.info("address: " + address + ", TIME:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: DELAY *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.DELAY.actionId,
										getCoilAddress(burnerNo, ActionEnum.DELAY.actionId));
								actionToAddressMap.put(ActionEnum.DELAY.actionId, actionAddress);
							} else {
								logger.error("No WRITE REGISTERS found in DELAY");
							}
						}
						// FRYER_PICKUP Action
						else if (tr.getActionId() == ActionEnum.FRYER_PICKUP.actionId) {
							logger.info("******************* IN FRYER_PICKUP *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.FRYER_PICKUP.label,
											OperationTypeEnum.WRITE.getValue());
							ObjectMapper mapper = new ObjectMapper();
							FryerPickup fp = mapper.convertValue(tr.getSourceOrType(),
									new TypeReference<FryerPickup>() {
									});
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.FRYER_PICKUP.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, fp.getPickLocation());
										logger.info("address: " + address + ", FRYER_PICKUP_LOCATION_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.FRYER_PICKUP_DROP_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, fp.getDropLocation());
										logger.info("address: " + address + ", FRYER_PICKUP_DROP_LOCATION_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(
											RegisterEnum.FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE.label)) {
										mc.WriteSingleRegister(address, fp.getBcWbc());
										logger.info("address: " + address
												+ ", FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: FRYER_PICKUP *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.FRYER_PICKUP.actionId,
										getCoilAddress(burnerNo, ActionEnum.FRYER_PICKUP.actionId));
								actionToAddressMap.put(ActionEnum.FRYER_PICKUP.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in FRYER_PICKUP Action");
							}

						} // FRYER_ACTION Action
						else if (tr.getActionId() == ActionEnum.FRYER_ACTION.actionId) {
							logger.info("******************* IN FRYER_ACTION *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.FRYER_ACTION.label,
											OperationTypeEnum.WRITE.getValue());
							ObjectMapper mapper = new ObjectMapper();
							FryerAction fa = mapper.convertValue(tr.getSourceOrType(),
									new TypeReference<FryerAction>() {
									});
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_ACTION_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.FRYER_ACTION.actionId);
										logger.info("address: " + address + ", actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.FRYER_ACTION_POOL_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, fa.getPoolLocation());
										logger.info("address: " + address + ", FRYER_ACTION_POOL_LOCATION_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.FRYER_ACTION_LIFT_DIP_WRITE.label)) {
										mc.WriteSingleRegister(address, fa.getLiftDip());
										logger.info("address: " + address + ", FRYER_ACTION_LIFT_DIP_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: FRYER_ACTION *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.FRYER_ACTION.actionId,
										getCoilAddress(burnerNo, ActionEnum.FRYER_ACTION.actionId));
								actionToAddressMap.put(ActionEnum.FRYER_ACTION.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in FRYER_ACTION");
							}

						} // FRYER_SERVE Action
						else if (tr.getActionId() == ActionEnum.FRYER_SERVE.actionId) {
							logger.info("******************* IN FRYER_SERVE *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.FRYER_SERVE.label,
											OperationTypeEnum.WRITE.getValue());
							ObjectMapper mapper = new ObjectMapper();
							FryerServe fs = mapper.convertValue(tr.getSourceOrType(), new TypeReference<FryerServe>() {
							});
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_SERVE_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.FRYER_SERVE.actionId);
										logger.info("address: " + address + ", FRYER_SERVE actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.FRYER_ACTION_POOL_LOCATION_WRITE.label)) {
										mc.WriteSingleRegister(address, fs.getPoolLoc());
										logger.info("address: " + address + ", FRYER_ACTION_POOL_LOCATION_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction()
											.equals(RegisterEnum.FRYER_SERVE_TRANSFER_OR_SERVE_WRITE.label)) {
										mc.WriteSingleRegister(address, fs.getTransOrServe());
										logger.info("address: " + address + ", FRYER_SERVE_TRANSFER_OR_SERVE_WRITE:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: FRYER_SERVE *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.FRYER_SERVE.actionId,
										getCoilAddress(burnerNo, ActionEnum.FRYER_SERVE.actionId));
								actionToAddressMap.put(ActionEnum.FRYER_SERVE.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in FRYER_SERVE Action");
							}

						} // SERVE Action
						else if (tr.getActionId() == ActionEnum.SERVE.actionId) {
							logger.info("******************* IN SERVE *******************");

							int actionAddress = 0;

							// WRITE REGISTERS
							List<RegisterAddress> writeList = registerAddressRepository
									.findByActionNameAndOperationType(ActionEnum.SERVE.label,
											OperationTypeEnum.WRITE.getValue());
							if (writeList != null && !writeList.isEmpty()) {
								for (RegisterAddress obj : writeList) {
									int address = getAddress(burnerNo, obj);
									if (address != 0 && actionAddress == 0) {
										actionAddress = address;
									}

									if (obj.getTypeOfAction().equals(RegisterEnum.SERVE_WRITE.label)) {
										mc.WriteSingleRegister(address, ActionEnum.SERVE.actionId);
										logger.info("address: " + address + ", SERVE_WRITE actionId:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else if (obj.getTypeOfAction().equals(RegisterEnum.SERVE_TYPE_WRITE.label)) {
										mc.WriteSingleRegister(address, (Integer) tr.getSourceOrType());
										logger.info("address: " + address + ", SERVE_TYPE_WRITE Type:"
												+ mc.ReadHoldingRegisters(address, 1)[0]);
									} else {
										logger.info("******************* ERROR: SERVE *******************");
									}
								}

								mc.WriteSingleRegister(flameAddress, tr.getFlame());
								logger.info("Flame address: " + mc.ReadHoldingRegisters(flameAddress, 1)[0]);

								actionToCoilMap.put(ActionEnum.SERVE.actionId,
										getCoilAddress(burnerNo, ActionEnum.SERVE.actionId));
								actionToAddressMap.put(ActionEnum.SERVE.actionId, actionAddress);

							} else {
								logger.error("No WRITE REGISTERS found in SERVE");
							}

						}

					}
				} catch (SocketException se) {
					mc.Disconnect();
					mc = new ModbusClient(IP_ADDR, PORT);
					mc.Connect();
				} catch (Exception e) {
					logger.info("*************** ERROR IN EXECUTING: " + groupId);
					e.printStackTrace();
				}

				// Coil Status Reading
				int count = 0;
				while (flag) {
					Thread.sleep(1000);
					++count;
					logger.info("Iteration Count: " + count);
					try {
						boolean[] coilsArray = mc.ReadCoils(COIL_STRAT_ADDRESS, NO_OF_COILS_TO_READ);
						Iterator<Map.Entry<Integer, Integer>> iterator = actionToCoilMap.entrySet().iterator();
						if (actionToCoilMap.size() > 0) {
							while (iterator.hasNext()) {
								int[] readWriteAddress = new int[10];
								Entry<Integer, Integer> entry = iterator.next();
								int tmpAddress = (int) entry.getValue();
								boolean tmpVale = coilsArray[tmpAddress % 5000];
								if (tmpVale) {
									readWriteAddress = mc.ReadHoldingRegisters(actionToAddressMap.get(entry.getKey()),
											getNoOfRegisters(entry.getKey()));
									for (int i = 0; i < readWriteAddress.length; i++) {
										logger.info("Read Address: " + (actionToAddressMap.get(entry.getKey()) + i)
												+ " - " + readWriteAddress[i]);
										logger.info("Flame Info: " + mc.ReadHoldingRegisters((flameAddress + 1), 1)[0]);
									}
									int[] a = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
									mc.WriteMultipleRegisters(actionToAddressMap.get(entry.getKey()), a);
									iterator.remove();
								}
							}
						} else {
							flag = false;
							break;
						}
					} catch (SocketException se) {
						mc.Disconnect();
						mc = new ModbusClient(IP_ADDR, PORT);
						mc.Connect();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		ModelAndView model = new ModelAndView();
		model.addObject("urlPage", "recipeCooking");
		model.setViewName("/admin/recipeCooking");
		return model;
	}

	private Integer getAddress(Integer burnerNo, RegisterAddress obj) {
		int address = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			address = obj.getBurner1Register();
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			address = obj.getBurner2Register();
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			address = obj.getBurner3Register();
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			address = obj.getBurner4Register();
		}
		return address;
	}

	private Integer getCoilAddress(Integer burnerNo, Integer actionId) {
		int coilAddress = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_1_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_1_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_1_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_1_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_1_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_2_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_2_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_2_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_2_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_2_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_3_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_3_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_3_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_3_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_3_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_4_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_4_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_4_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_4_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_4_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_SERVE_DONE.coilAddress;
			}
		}
		return coilAddress;
	}

	private Integer getNoOfRegisters(Integer actionId) {
		int noOfRegisters = 0;
		if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
			noOfRegisters = ActionEnum.UTENSIL_PICK.noOfRegisters;
		} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
			noOfRegisters = ActionEnum.SPATULA_PICK.noOfRegisters;
		} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
			noOfRegisters = ActionEnum.VEG_COLLECTION.noOfRegisters;
		} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
			noOfRegisters = ActionEnum.SPICE_COLLECTION.noOfRegisters;
		} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
			noOfRegisters = ActionEnum.MEAT_COLLECTION.noOfRegisters;
		} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
			noOfRegisters = ActionEnum.VEG_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
			noOfRegisters = ActionEnum.SPICE_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
			noOfRegisters = ActionEnum.MEAT_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.IGNITION.actionId) {
			noOfRegisters = ActionEnum.IGNITION.noOfRegisters;
		} else if (actionId == ActionEnum.STIRR.actionId) {
			noOfRegisters = ActionEnum.STIRR.noOfRegisters;
		} else if (actionId == ActionEnum.TOSS.actionId) {
			noOfRegisters = ActionEnum.TOSS.noOfRegisters;
		} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
			noOfRegisters = ActionEnum.LIQUID_DISPENSING.noOfRegisters;
		} else if (actionId == ActionEnum.DELAY.actionId) {
			noOfRegisters = ActionEnum.DELAY.noOfRegisters;
		} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
			noOfRegisters = ActionEnum.FRYER_PICKUP.noOfRegisters;
		} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
			noOfRegisters = ActionEnum.FRYER_ACTION.noOfRegisters;
		} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
			noOfRegisters = ActionEnum.FRYER_SERVE.noOfRegisters;
		} else if (actionId == ActionEnum.SERVE.actionId) {
			noOfRegisters = ActionEnum.SERVE.noOfRegisters;
		}
		return noOfRegisters;
	}

}
