package com.nala.controller.demo;

import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.enums.ActionEnum;
import com.nala.enums.BurnerEnum;
import com.nala.enums.CoilEnum;
import com.nala.enums.OperationTypeEnum;
import com.nala.enums.RegisterEnum;
import com.nala.model.DispenseSetting;
import com.nala.model.RegisterAddress;
import com.nala.model.RegisterAddressForm;
import com.nala.model.demo.DemoBins;
import com.nala.model.demo.DemoIngredients;
import com.nala.repository.BinRepository;
import com.nala.repository.demo.CoilAddressRepository;
import com.nala.repository.IngredientRepository;
import com.nala.repository.RegisterAddressRepository;
import com.nala.repository.demo.DemoBinsRepository;
import com.nala.repository.demo.DemoIngredientsRepository;

import de.re.easymodbus.exceptions.ModbusException;
import de.re.easymodbus.modbusclient.ModbusClient;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class StepExecuterController {

	private static final Logger logger = LoggerFactory.getLogger(StepExecuterController.class);

	private static final String IP_ADDR = "192.168.2.245";
	private static final Integer PORT = 502;

	ModbusClient mc = null;

	@Autowired
	BinRepository binRepository;

	@Autowired
	CoilAddressRepository coilAddressRepository;

	@Autowired
	IngredientRepository ingredientRepository;

	@Autowired
	DemoIngredientsRepository demoIngredientsRepository;

	@Autowired
	DemoBinsRepository demoBinsRepository;

	@Autowired
	RegisterAddressRepository registerAddressRepository;

	@RequestMapping("/openStepExecuter")
	public ModelAndView openRegisterInfo() {
		ModelAndView model = new ModelAndView();
		model.addObject("urlPage", "openStepExecuter");
		model.addObject("command", new RegisterAddressForm());
		model.setViewName("/admin/register_check2");
		return model;
	}

	@RequestMapping(value = "/writeAndReadSteps", method = RequestMethod.POST)
	public ModelAndView writeRegsiters(@ModelAttribute("registerAddressForm") RegisterAddressForm form,
			BindingResult result) {
		HashMap<Integer, Integer> writeDetails = new HashMap<>();
		HashMap<Integer, Integer> readDetails = new HashMap<>();
		try {
			logger.info("writeRegsiters: " + form.toString());
			ModbusClient modbusClient = new ModbusClient(IP_ADDR, PORT);
			modbusClient.Connect();
			
			Map<Integer, Integer> flameAddressMap = getBurnerWiseFlameAddressMap();

			boolean flag = true;
			int burnerNo = 0;
			int rackId = 0;
			if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
				burnerNo = 1;
			} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
				burnerNo = 2;
			} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
				burnerNo = 3;
			} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
				burnerNo = 4;
			}
			if (burnerNo == 1 || burnerNo == 2) {
				rackId = 1;
			} else if (burnerNo == 3 || burnerNo == 4) {
				rackId = 2;
			}

			int[] readFlameAddress = new int[1];
			boolean[] isActionDone = new boolean[1];
			int[] a = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

			int actionAddress = 0;
			int flameAddress = 0;
			int motorAddress = 0;


			// FLAME_SET_POINT
			if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
				flameAddress = flameAddressMap.get(BurnerEnum.BURNER1.getBurnerNo());
			} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
				flameAddress = flameAddressMap.get(BurnerEnum.BURNER2.getBurnerNo());
			} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
				flameAddress = flameAddressMap.get(BurnerEnum.BURNER3.getBurnerNo());
			} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
				flameAddress = flameAddressMap.get(BurnerEnum.BURNER4.getBurnerNo());
			} else {
				System.out.println("******************* ERROR: FLAME_SET_POINT *******************");
			}
			
			// UTENSIL_PICK Action
			if (form.getActionName().equals(ActionEnum.UTENSIL_PICK.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.UTENSIL_PICK.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.UTENSIL_PICK.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}
						if (obj.getTypeOfAction().equals(RegisterEnum.UTENSIL_PICK_WRITE.label)) {
							invokeWriteToRegisterAPI(ActionEnum.UTENSIL_PICK.actionId, address, ActionEnum.UTENSIL_PICK.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.UTENSIL_TYPE_WRITE.label)) {
							invokeWriteToRegisterAPI(ActionEnum.UTENSIL_PICK.actionId, address, form.getBin());
						} else {
							System.out.println("******************* ERROR: UTENSIL_PICK *******************");
						}
					}

					invokeWriteToRegisterAPI(ActionEnum.UTENSIL_PICK.actionId, flameAddress, form.getFlame());

					writeReadAddress = invokePrintReadHoldingRegistersAPI(ActionEnum.UTENSIL_PICK.actionId,
							actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = invokeReadCoilsAPI(ActionEnum.UTENSIL_PICK.actionId, CoilEnum.BURNER_1_UTENSIL_PICK_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_UTENSIL_PICK_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_UTENSIL_PICK_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_UTENSIL_PICK_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: UTENSIL_PICK Coil Address *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// SPATULA_PICK Action
			else if (form.getActionName().equals(ActionEnum.SPATULA_PICK.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.SPATULA_PICK.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.SPATULA_PICK.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}
						if (obj.getTypeOfAction().equals(RegisterEnum.SPATULA_PICK_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.SPATULA_PICK.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SPATULA_TYPE_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else {
							System.out.println("******************* ERROR: SPATULA_PICK *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_SPATULA_PICK_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_SPATULA_PICK_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_SPATULA_PICK_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_SPATULA_PICK_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: SPATULA_PICK Coil Address *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// VEG_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.VEG_COLLECTION.label)) {

				int[] writeReadAddress = new int[10];
				int[] writeReadMotorAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int[] readWriteMotorAddress = new int[10];
				int noOfRegisters = ActionEnum.VEG_COLLECTION.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.VEG_COLLECTION.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
							motorAddress = address+280;
						}

						DispenseSetting ds = null;
						DemoBins db = demoBinsRepository.findBySectionBinNoAndRackId("VEG", form.getBin(), rackId);
						DemoIngredients di = demoIngredientsRepository.findByIngredientId(db.getIngredientId());
						List<DispenseSetting> dss = di.getDispenseSettings();
						for (DispenseSetting _ds : dss) {
							if ((form.getQty() >= _ds.getMin()) && (form.getQty() <= _ds.getMax())) {
								ds = _ds;
								break;
							}
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.VEG_COLLECTION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.VEG_COLLECTION.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.VEG_COLLECTION_BIN_NUMBER_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.VEG_COLLECTION_WEIGHT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getQty());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getCutOffPct());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.VEG_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getNormalOpsInPct());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.VEG_MOTOR_NORMAL_SPEED_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getNormalOpsSpeed());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.VEG_MOTOR_INCHING_SPEED_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getInchingSpeed());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getGapBtwNormalAndInch());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getGapBtwInch());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.VEG_MOTOR_INCHING_TIME_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getInchingTime());
						} else {
							System.out.println("******************* ERROR: VEG_COLLECTION *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
					writeReadMotorAddress = modbusClient.ReadHoldingRegisters(motorAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}
					for (int i = 0; i < writeReadMotorAddress.length; i++) {
						writeDetails.put(motorAddress + i, writeReadMotorAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_VEG_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_VEG_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_VEG_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_VEG_COLLECTION_DONE.coilAddress, 1);
					} else {
						System.out
								.println("******************* ERROR: VEG_COLLECTION Coil Address *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				readWriteMotorAddress = modbusClient.ReadHoldingRegisters(motorAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}
				for (int i = 0; i < readWriteMotorAddress.length; i++) {
					readDetails.put(motorAddress + i, readWriteMotorAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);
				modbusClient.WriteMultipleRegisters(motorAddress, a);

			}
			// SPICE_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.SPICE_COLLECTION.label)) {

				int[] writeReadAddress = new int[10];
				int[] writeReadMotorAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int[] readWriteMotorAddress = new int[10];
				int noOfRegisters = ActionEnum.SPICE_COLLECTION.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.SPICE_COLLECTION.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
							motorAddress = address+280;
						}

						DispenseSetting ds = null;
						DemoBins db = demoBinsRepository.findBySectionBinNoAndRackId("SPICE", form.getBin(), rackId);
						DemoIngredients di = demoIngredientsRepository.findByIngredientId(db.getIngredientId());
						List<DispenseSetting> dss = di.getDispenseSettings();
						for (DispenseSetting _ds : dss) {
							if ((form.getQty() >= _ds.getMin()) && (form.getQty() <= _ds.getMax())) {
								ds = _ds;
								break;
							}
						}
						if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_COLLECTION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.SPICE_COLLECTION.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_COLLECTION_BIN_NUMBER_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_COLLECTION_WEIGHT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getQty());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getCutOffPct());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.SPICE_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getNormalOpsInPct());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.SPICE_MOTOR_NORMAL_SPEED_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getNormalOpsSpeed());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.SPICE_MOTOR_INCHING_SPEED_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getInchingSpeed());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getGapBtwNormalAndInch());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getGapBtwInch());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_MOTOR_INCHING_TIME_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getInchingTime());
						} else {
							System.out.println("******************* ERROR: SPICE_COLLECTION *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
					writeReadMotorAddress = modbusClient.ReadHoldingRegisters(motorAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}
					for (int i = 0; i < writeReadMotorAddress.length; i++) {
						writeDetails.put(motorAddress + i, writeReadMotorAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_SPICE_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_SPICE_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_SPICE_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_SPICE_COLLECTION_DONE.coilAddress, 1);
					} else {
						System.out.println(
								"******************* ERROR: SPICE_COLLECTION Coil Address *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				readWriteMotorAddress = modbusClient.ReadHoldingRegisters(motorAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}
				for (int i = 0; i < readWriteMotorAddress.length; i++) {
					readDetails.put(motorAddress + i, readWriteMotorAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);
				modbusClient.WriteMultipleRegisters(motorAddress, a);

			}
			// MEAT_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.MEAT_COLLECTION.label)) {

				int[] writeReadAddress = new int[10];
				int[] writeReadMotorAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int[] readWriteMotorAddress = new int[10];
				int noOfRegisters = ActionEnum.MEAT_COLLECTION.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.MEAT_COLLECTION.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
							motorAddress = address+280;
						}

						DispenseSetting ds = null;
						DemoBins db = demoBinsRepository.findBySectionBinNoAndRackId("MEAT", form.getBin(), rackId);
						DemoIngredients di = demoIngredientsRepository.findByIngredientId(db.getIngredientId());
						List<DispenseSetting> dss = di.getDispenseSettings();
						for (DispenseSetting _ds : dss) {
							if ((form.getQty() >= _ds.getMin()) && (form.getQty() <= _ds.getMax())) {
								ds = _ds;
								break;
							}
						}
						if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_COLLECTION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.MEAT_COLLECTION.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_COLLECTION_BIN_NUMBER_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_COLLECTION_WEIGHT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getQty());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getCutOffPct());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.MEAT_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getNormalOpsInPct());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.MEAT_MOTOR_NORMAL_SPEED_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getNormalOpsSpeed());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.MEAT_MOTOR_INCHING_SPEED_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getInchingSpeed());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getGapBtwNormalAndInch());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getGapBtwInch());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_MOTOR_INCHING_TIME_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ds.getInchingTime());
						} else {
							System.out.println("******************* ERROR: MEAT_COLLECTION *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
					writeReadMotorAddress = modbusClient.ReadHoldingRegisters(motorAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}
					for (int i = 0; i < writeReadMotorAddress.length; i++) {
						writeDetails.put(motorAddress + i, writeReadMotorAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_MEAT_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_MEAT_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_MEAT_COLLECTION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_MEAT_COLLECTION_DONE.coilAddress, 1);
					} else {
						System.out
								.println("******************* ERROR: MEAT_COLLECTION Coil Address *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				readWriteMotorAddress = modbusClient.ReadHoldingRegisters(motorAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}
				for (int i = 0; i < readWriteMotorAddress.length; i++) {
					readDetails.put(motorAddress + i, readWriteMotorAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);
				modbusClient.WriteMultipleRegisters(motorAddress, a);

			}
			// VEG_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.VEG_PICKUP.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.VEG_PICKUP.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.VEG_PICKUP.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.VEG_PICKUP_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.VEG_PICKUP.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.VEG_PICKUP_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else {
							System.out.println("******************* ERROR: VEG_PICKUP *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_VEG_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_VEG_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_VEG_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_VEG_PICKUP_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: VEG_PICKUP Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// SPICE_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.SPICE_PICKUP.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.SPICE_PICKUP.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.SPICE_PICKUP.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_PICKUP_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.SPICE_PICKUP.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_PICKUP_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else {
							System.out.println("******************* ERROR: SPICE_PICKUP *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_SPICE_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_SPICE_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_SPICE_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_SPICE_PICKUP_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: SPICE_PICKUP Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// MEAT_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.MEAT_PICKUP.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.MEAT_PICKUP.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.MEAT_PICKUP.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_PICKUP_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.MEAT_PICKUP.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_PICKUP_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else {
							System.out.println("******************* ERROR: MEAT_PICKUP *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_MEAT_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_MEAT_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_MEAT_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_MEAT_PICKUP_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: MEAT_PICKUP Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// IGNITION Action
			else if (form.getActionName().equals(ActionEnum.IGNITION.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.IGNITION.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.IGNITION.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.IGNITION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.IGNITION.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.IGNITION_DELAY_TIME_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getTime());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.FLAME_LEVEL_WRITE.label)) {
							modbusClient.WriteSingleRegister(flameAddress, form.getFlame());
						} else {
							System.out.println("******************* ERROR: IGNITION *******************");
						}
					}
					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_IGNITION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_IGNITION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_IGNITION_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_IGNITION_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: IGNITION Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// STIRR Action
			else if (form.getActionName().equals(ActionEnum.STIRR.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.STIRR.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository
						.findByActionNameAndOperationType(ActionEnum.STIRR.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.STIRR.actionId);
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.STIRR_TYPE_NUMBER_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_TIME_IN_MILLI_SEC_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getTime());
						} else {
							System.out.println("******************* ERROR: STIRR *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_STIRR_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_STIRR_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_STIRR_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_STIRR_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: STIRR Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// TOSS Action
			else if (form.getActionName().equals(ActionEnum.TOSS.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.TOSS.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository
						.findByActionNameAndOperationType(ActionEnum.TOSS.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.TOSS.actionId);
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.TOSS_TYPE_NUMBER_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_TIME_IN_MILLI_SEC_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getTime());
						} else {
							System.out.println("******************* ERROR: TOSS *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_TOSS_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_TOSS_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_TOSS_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_TOSS_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: TOSS Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// LIQUID_DISPENSING Action
			else if (form.getActionName().equals(ActionEnum.LIQUID_DISPENSING.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.LIQUID_DISPENSING.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.LIQUID_DISPENSING.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.LIQUID_DISPENSING.actionId);
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_1_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getTime());
						} /*
							 * else if (obj.getTypeOfAction()
							 * .equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_WRITE.label)) {
							 * modbusClient.WriteSingleRegister(address, 3); } else if
							 * (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_2_WRITE.
							 * label)) { modbusClient.WriteSingleRegister(address, 25); } else if
							 * (obj.getTypeOfAction()
							 * .equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_WRITE.label)) {
							 * modbusClient.WriteSingleRegister(address, 4); } else if
							 * (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_3_WRITE.
							 * label)) { modbusClient.WriteSingleRegister(address, 15); } else if
							 * (obj.getTypeOfAction()
							 * .equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_WRITE.label)) {
							 * modbusClient.WriteSingleRegister(address, 5); } else if
							 * (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_4_WRITE.
							 * label)) { modbusClient.WriteSingleRegister(address, 35); } else if
							 * (obj.getTypeOfAction()
							 * .equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_WRITE.label)) {
							 * modbusClient.WriteSingleRegister(address, 6); } else if
							 * (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_5_WRITE.
							 * label)) { modbusClient.WriteSingleRegister(address, 25); }
							 */ else {
							System.out.println("******************* ERROR: LIQUID_DISPENSING *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_LIQUID_DISPENSING_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_LIQUID_DISPENSING_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_LIQUID_DISPENSING_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_LIQUID_DISPENSING_DONE.coilAddress, 1);
					} else {
						System.out.println(
								"******************* ERROR: LIQUID_DISPENSING Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}

			// DELAY Action
			else if (form.getActionName().equals(ActionEnum.DELAY.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.DELAY.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository
						.findByActionNameAndOperationType(ActionEnum.DELAY.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.DELAY.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_TIME_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getTime());
						} else {
							System.out.println("******************* ERROR: DELAY *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_DELAY_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_DELAY_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_DELAY_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_DELAY_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: DELAY Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// FRYER_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.FRYER_PICKUP.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.FRYER_PICKUP.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.FRYER_PICKUP.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.FRYER_PICKUP.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_DROP_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getQty());
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getTime());
						} else {
							System.out.println("******************* ERROR: FRYER_PICKUP *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_FRYER_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_FRYER_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_FRYER_PICKUP_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_FRYER_PICKUP_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: FRYER_PICKUP Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// FRYER_ACTION Action
			else if (form.getActionName().equals(ActionEnum.FRYER_ACTION.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.FRYER_ACTION.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.FRYER_ACTION.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_ACTION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.FRYER_ACTION.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_ACTION_POOL_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_ACTION_LIFT_DIP_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getQty());
						} else {
							System.out.println("******************* ERROR: FRYER_ACTION *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_FRYER_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_FRYER_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_FRYER_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_FRYER_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: FRYER_ACTION Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// FRYER_SERVE Action
			else if (form.getActionName().equals(ActionEnum.FRYER_SERVE.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.FRYER_SERVE.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository.findByActionNameAndOperationType(
						ActionEnum.FRYER_SERVE.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_SERVE_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.FRYER_SERVE.actionId);
						} else if (obj.getTypeOfAction()
								.equals(RegisterEnum.FRYER_SERVE_POOL_LOCATION_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_SERVE_TRANSFER_OR_SERVE_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getQty());
						} else {
							System.out.println("******************* ERROR: FRYER_SERVE *******************");
						}
					}

					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_FRYER_SERVE_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_FRYER_SERVE_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_FRYER_SERVE_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_FRYER_SERVE_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: FRYER_SERVE Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			// SERVE Action
			else if (form.getActionName().equals(ActionEnum.SERVE.label)) {

				int[] writeReadAddress = new int[10];
				int[] readWriteAddress = new int[10];
				int noOfRegisters = ActionEnum.SERVE.noOfRegisters;

				// WRITE REGISTERS
				List<RegisterAddress> writeList = registerAddressRepository
						.findByActionNameAndOperationType(ActionEnum.SERVE.label, OperationTypeEnum.WRITE.getValue());
				if (writeList != null && !writeList.isEmpty()) {
					for (RegisterAddress obj : writeList) {
						int address = 0;
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							address = obj.getBurner1Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							address = obj.getBurner2Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							address = obj.getBurner3Register();
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							address = obj.getBurner4Register();
						}
						if (address != 0 && actionAddress == 0) {
							actionAddress = address;
						}

						if (obj.getTypeOfAction().equals(RegisterEnum.SERVE_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, ActionEnum.SERVE.actionId);
						} else if (obj.getTypeOfAction().equals(RegisterEnum.SERVE_TYPE_WRITE.label)) {
							modbusClient.WriteSingleRegister(address, form.getBin());
						} else {
							System.out.println("******************* ERROR: SERVE *******************");
						}
					}
					
					// FLAME_LEVEL_WRITE
					RegisterAddress flameObj = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
							ActionEnum.IGNITION.label, RegisterEnum.FLAME_LEVEL_WRITE.label);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						flameAddress = flameObj.getBurner1Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						flameAddress = flameObj.getBurner2Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						flameAddress = flameObj.getBurner3Register();
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						flameAddress = flameObj.getBurner4Register();
					} else {
						System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
					}
					modbusClient.WriteSingleRegister(flameAddress, form.getFlame());

					writeReadAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);

					for (int i = 0; i < writeReadAddress.length; i++) {
						writeDetails.put(actionAddress + i, writeReadAddress[i]);
					}

					readFlameAddress = modbusClient.ReadHoldingRegisters(flameAddress, 1);
					writeDetails.put(flameAddress, readFlameAddress[0]);

					for (Integer adr : writeDetails.keySet()) {
						System.out.println("Address: " + adr + " - " + writeDetails.get(adr));
					}

				}

				// Coil Status Reading
				while (flag) {
					Thread.sleep(500);
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_1_SERVE_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_2_SERVE_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_3_SERVE_DONE.coilAddress, 1);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						isActionDone = modbusClient.ReadCoils(CoilEnum.BURNER_4_SERVE_DONE.coilAddress, 1);
					} else {
						System.out.println("******************* ERROR: SERVE Coil Adddress *******************");
					}
					if (isActionDone[0]) {
						flag = false;
					}
				}

				// READ REGISTERS
				readWriteAddress = modbusClient.ReadHoldingRegisters(actionAddress, noOfRegisters);
				for (int i = 0; i < readWriteAddress.length; i++) {
					readDetails.put(actionAddress + i, readWriteAddress[i]);
				}

				readFlameAddress = modbusClient.ReadHoldingRegisters((flameAddress + 1), 1);
				readDetails.put((flameAddress + 1), readFlameAddress[0]);

				// Inserting Zero's into Registers after Read
				modbusClient.WriteMultipleRegisters(actionAddress, a);
				System.out.println("actionAddress: " + actionAddress);

			}
			modbusClient.Disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		ModelAndView model = new ModelAndView();
		model.addObject("writeDetails", writeDetails);
		model.addObject("readDetails", readDetails);
		model.addObject("command", new RegisterAddressForm());
		model.setViewName("/admin/register_check2");
		return model;
	}

	public boolean invokeWriteToRegisterAPI(Integer actionId, int address, int value) {
		boolean invokeAPISuccess = false;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			mc.WriteSingleRegister(address, value);
			logger.info("Writing to Address:" + address + ", Value:" + mc.ReadHoldingRegisters(address, 1)[0]);
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			logger.info("*************** UnknownHostException IN EXECUTING invokeWriteToRegisterAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException IN EXECUTING invokeWriteToRegisterAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException IN EXECUTING invokeWriteToRegisterAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException IN EXECUTING invokeWriteToRegisterAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING invokeWriteToRegisterAPI ActionId: " + actionId
					+ ",  Address: " + address);
			e.printStackTrace();
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING invokeWriteToRegisterAPI");
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}

	public boolean invokeWriteToMultipeRegisterAPI(Integer actionId, Integer address, int registerCount) {
		boolean invokeAPISuccess = false;
		try {
			int[] registerValues = new int[registerCount];
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			int[] a = new int[registerCount];
			mc.WriteMultipleRegisters(address, a);
			registerValues = mc.ReadHoldingRegisters(address, registerCount);
			for (int i = 0; i < registerValues.length; i++) {
				logger.info("Action - " + actionId + "Read Address: " + (address + i) + " - " + registerValues[i]);
			}
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			logger.info("*************** UnknownHostException IN EXECUTING invokeWriteToMultipeRegisterAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException IN EXECUTING invokeWriteToMultipeRegisterAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException IN EXECUTING invokeWriteToMultipeRegisterAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException IN EXECUTING invokeWriteToMultipeRegisterAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING invokeWriteToMultipeRegisterAPI ActionId: " + actionId
					+ ",  Address: " + address);
			e.printStackTrace();
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING invokeWriteToMultipeRegisterAPI");
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}

	public int[] invokePrintReadHoldingRegistersAPI(Integer actionId, Integer address, int registerCount) {
		int[] registerValues = new int[registerCount];
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			registerValues = mc.ReadHoldingRegisters(address, registerCount);
			for (int i = 0; i < registerValues.length; i++) {
				logger.info("Action - " + actionId + "Read Address: " + (address + i) + " - " + registerValues[i]);
			}
		} catch (UnknownHostException e) {
			logger.info(
					"*************** UnknownHostException IN EXECUTING invokePrintReadHoldingRegistersAPI ActionId: "
							+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException IN EXECUTING invokePrintReadHoldingRegistersAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException IN EXECUTING invokePrintReadHoldingRegistersAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException IN EXECUTING invokePrintReadHoldingRegistersAPI ActionId: "
					+ actionId + ", Address: " + address);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ActionId: " + actionId
					+ ",  Address: " + address);
			e.printStackTrace();
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI");
					e.printStackTrace();
				}
			}
		}
		return registerValues;
	}

	public boolean[] invokeReadCoilsAPI(Integer actionId, Integer address, int noOfCoils) {
		boolean[] status = null;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			status = mc.ReadCoils(address, noOfCoils);
		} catch (UnknownHostException e) {
			logger.info("*************** UnknownHostException IN EXECUTING InvokeReadCoilAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException IN EXECUTING InvokeReadCoilAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException IN EXECUTING InvokeReadCoilAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException IN EXECUTING InvokeReadCoilAPI ActionId: " + actionId
					+ ", Address: " + address);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING ActionId: " + actionId + ",  Address: " + address);
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING invokeReadCoilsAPI");
					e.printStackTrace();
				}
			}
		}

		return status;
	}
	
	private Map<Integer, Integer> getBurnerWiseFlameAddressMap() {
		RegisterAddress registerAddress = registerAddressRepository
				.findByActionIdTypeOfAction(ActionEnum.IGNITION.actionId, RegisterEnum.FLAME_LEVEL_WRITE.label);
		if (registerAddress != null) {
			Map<Integer, Integer> burnerFlameAddressMap = new HashMap<>();
			burnerFlameAddressMap.put(1, registerAddress.getBurner1Register());
			burnerFlameAddressMap.put(2, registerAddress.getBurner2Register());
			burnerFlameAddressMap.put(3, registerAddress.getBurner3Register());
			burnerFlameAddressMap.put(4, registerAddress.getBurner4Register());
			return burnerFlameAddressMap;
		} else {
			return null;
		}
	}
	


	private Integer getCoilAddress(Integer burnerNo, Integer actionId) {
		int coilAddress = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_1_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_1_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_1_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_1_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_1_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_2_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_2_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_2_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_2_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_2_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_3_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_3_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_3_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_3_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_3_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_4_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_4_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_4_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_4_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_4_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_SERVE_DONE.coilAddress;
			}
		}
		return coilAddress;
	}


}
