package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.Coils;

@Repository
public interface CoilsRepository extends MongoRepository<Coils, String> {

	@Query("{'operationType' : {$eq : ?0}}")
	List<Coils> findByOperationType(Integer operationType);

	@Query("{'classification' : {$eq : ?0}}")
	List<Coils> findByClassification(String classification);

	@Query("{'buttonType' : {$eq : ?0}}")
	List<Coils> findByButtonType(String buttonType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'buttonType' : {$eq : ?1}}]}")
	List<Coils> findByClassificationAndButtonType(String classification, String buttonType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}]}")
	List<Coils> findBySubClassification(String classification, String subClassification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}, {'buttonType' : {$eq : ?2}}]}")
	List<Coils> findBySubClassificationAndButtonType(String classification, String subClassification,
			String buttonType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'buttonType' : {$eq : ?1}}, {'operationType' : {$eq : ?2}}]}")
	List<Coils> findByClassificationButtonTypeAndOperationType(String classification, String buttonType,
			Integer operationType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}, {'buttonType' : {$eq : ?2}}, {'operationType' : {$eq : ?3}}]}")
	List<Coils> findBySubClassificationButtonTypeAndOperationType(String classification, String subClassification,
			String buttonType, Integer operationType);

	@Query("{'type' : {$eq : ?0}}")
	Coils findUniqueByType(String type);

	@Query("{'coilId' : {$eq : ?0}}")
	Coils findByCoilId(Integer coilId);

}
