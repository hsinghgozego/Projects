package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.BurnerRegisters;

@Repository
public interface BurnerRegistersRepository extends MongoRepository<BurnerRegisters, String> {

	@Query("{'actionId' : {$eq : ?0}}")
	List<BurnerRegisters> findByActionId(Integer actionId);

	@Query("{'actionName' : {$eq : ?0}}")
	List<BurnerRegisters> findByActionName(String actionName);

	@Query("{'$and' : [{ 'actionId' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	List<BurnerRegisters> findByActionIdAndOperationType(Integer actionId, Integer operationType);

	@Query("{'$and' : [{ 'actionName' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	List<BurnerRegisters> findByActionNameAndOperationType(String actionName, Integer operationType);

	@Query("{'typeOfAction' : {$eq : ?0}}")
	BurnerRegisters findByTypeOfAction(String typeOfAction);

	@Query("{'burnerRegisterId' : {$eq : ?0}}")
	BurnerRegisters findByBurnerRegisterId(Integer burnerRegisterId);

}
