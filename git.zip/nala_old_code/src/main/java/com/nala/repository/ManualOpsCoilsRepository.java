package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.ManualOpsCoils;

@Repository
public interface ManualOpsCoilsRepository extends MongoRepository<ManualOpsCoils, String> {

	@Query("{'operationType' : {$eq : ?0}}")
	List<ManualOpsCoils> findByOperationType(Integer operationType);

	@Query("{'classification' : {$eq : ?0}}")
	List<ManualOpsCoils> findByClassification(String classification);

	@Query("{'buttonType' : {$eq : ?0}}")
	List<ManualOpsCoils> findByButtonType(String buttonType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'buttonType' : {$eq : ?1}}]}")
	List<ManualOpsCoils> findByClassificationAndButtonType(String classification, String buttonType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}]}")
	List<ManualOpsCoils> findBySubClassification(String classification, String subClassification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}, {'buttonType' : {$eq : ?2}}]}")
	List<ManualOpsCoils> findBySubClassificationAndButtonType(String classification, String subClassification,
			String buttonType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'buttonType' : {$eq : ?1}}, {'operationType' : {$eq : ?2}}]}")
	List<ManualOpsCoils> findByClassificationButtonTypeAndOperationType(String classification, String buttonType,
			Integer operationType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}, {'buttonType' : {$eq : ?2}}, {'operationType' : {$eq : ?3}}]}")
	List<ManualOpsCoils> findBySubClassificationButtonTypeAndOperationType(String classification, String subClassification,
			String buttonType, Integer operationType);

	@Query("{'type' : {$eq : ?0}}")
	ManualOpsCoils findUniqueByType(String type);

	@Query("{'manualOpsCoilId' : {$eq : ?0}}")
	ManualOpsCoils findByManualOpsCoilId(Integer manualOpsCoilId);

}
