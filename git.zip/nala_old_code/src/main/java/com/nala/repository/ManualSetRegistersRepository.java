package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.ManualSetRegisters;

@Repository
public interface ManualSetRegistersRepository extends MongoRepository<ManualSetRegisters, String> {

	@Query("{'operationType' : {$eq : ?0}}")
	List<ManualSetRegisters> findByOperationType(Integer operationType);

	@Query("{'classification' : {$eq : ?0}}")
	List<ManualSetRegisters> findByClassification(String classification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}]}")
	List<ManualSetRegisters> findBySubClassification(String classification, String subClassification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'operationType' : {$eq : ?1}}]}")
	List<ManualSetRegisters> findByClassificationAndOperationType(String classification, String operationType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}, {'operationType' : {$eq : ?2}}]}")
	List<ManualSetRegisters> findBySubClassificationAndOperationType(String classification, String subClassification,
			Integer operationType);

	@Query("{'type' : {$eq : ?0}}")
	ManualSetRegisters findUniqueByType(String type);

	@Query("{'manualSetRegisterId' : {$eq : ?0}}")
	ManualSetRegisters findByManualSetRegisterId(Integer manualSetRegisterId);

}
