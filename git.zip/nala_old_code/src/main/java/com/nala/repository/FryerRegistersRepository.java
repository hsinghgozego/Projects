package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.FryerRegisters;

@Repository
public interface FryerRegistersRepository extends MongoRepository<FryerRegisters, String> {

	@Query("{'actionId' : {$eq : ?0}}")
	List<FryerRegisters> findByActionId(Integer actionId);

	@Query("{'actionName' : {$eq : ?0}}")
	List<FryerRegisters> findByActionName(String actionName);

	@Query("{'$and' : [{ 'actionId' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	List<FryerRegisters> findByActionIdAndOperationType(Integer actionId, Integer operationType);

	@Query("{'$and' : [{ 'actionName' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	List<FryerRegisters> findByActionNameAndOperationType(String actionName, Integer operationType);

	@Query("{'typeOfAction' : {$eq : ?0}}")
	FryerRegisters findByTypeOfAction(String typeOfAction);

	@Query("{'fryerRegisterId' : {$eq : ?0}}")
	FryerRegisters findByFryerRegisterId(Integer fryerRegisterId);

}
