package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.AlarmRegisters;

@Repository
public interface AlarmRegistersRepository extends MongoRepository<AlarmRegisters, String> {

	@Query("{'operationType' : {$eq : ?0}}")
	List<AlarmRegisters> findByOperationType(Integer operationType);

	@Query("{'classification' : {$eq : ?0}}")
	List<AlarmRegisters> findByClassification(String classification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}]}")
	List<AlarmRegisters> findBySubClassification(String classification, String subClassification);

	@Query("{'type' : {$eq : ?0}}")
	AlarmRegisters findUniqueByType(String type);

	@Query("{'alarmRegisterId' : {$eq : ?0}}")
	AlarmRegisters findByAlarmRegisterId(Integer alarmRegisterId);

}
