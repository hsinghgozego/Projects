package com.nala.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nala.model.ServingStation;

public interface ServingStationRepository extends MongoRepository< ServingStation, String>{

	
	
	
}
