package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.MonitoringRegisters;

@Repository
public interface MonitoringRegistersRepository extends MongoRepository<MonitoringRegisters, String> {

	@Query("{'operationType' : {$eq : ?0}}")
	List<MonitoringRegisters> findByOperationType(Integer operationType);

	@Query("{'classification' : {$eq : ?0}}")
	List<MonitoringRegisters> findByClassification(String classification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}]}")
	List<MonitoringRegisters> findBySubClassification(String classification, String subClassification);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'operationType' : {$eq : ?1}}]}")
	List<MonitoringRegisters> findByClassificationAndOperationType(String classification, String operationType);

	@Query("{'$and' : [{'classification' : {$eq : ?0}}, {'subClassification' : {$eq : ?1}}, {'operationType' : {$eq : ?2}}]}")
	List<MonitoringRegisters> findBySubClassificationAndOperationType(String classification, String subClassification,
			Integer operationType);

	@Query("{'type' : {$eq : ?0}}")
	MonitoringRegisters findUniqueByType(String type);

	@Query("{'monitoringRegisterId' : {$eq : ?0}}")
	MonitoringRegisters findByMonitoringRegisterId(Integer monitoringRegisterId);

}
