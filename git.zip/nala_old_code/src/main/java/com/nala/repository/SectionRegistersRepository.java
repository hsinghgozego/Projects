package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.nala.model.SectionRegisters;

@Repository
public interface SectionRegistersRepository extends MongoRepository<SectionRegisters, String> {

	@Query("{'actionId' : {$eq : ?0}}")
	List<SectionRegisters> findByActionId(Integer actionId);

	@Query("{'actionName' : {$eq : ?0}}")
	List<SectionRegisters> findByActionName(String actionName);

	@Query("{'$and' : [{ 'actionId' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	List<SectionRegisters> findByActionIdAndOperationType(Integer actionId, Integer operationType);

	@Query("{'$and' : [{ 'actionName' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	List<SectionRegisters> findByActionNameAndOperationType(String actionName, Integer operationType);

	@Query("{'typeOfAction' : {$eq : ?0}}")
	SectionRegisters findByTypeOfAction(String typeOfAction);

	@Query("{'sectionRegisterId' : {$eq : ?0}}")
	SectionRegisters findBySectionRegisterId(Integer sectionRegisterId);

}
