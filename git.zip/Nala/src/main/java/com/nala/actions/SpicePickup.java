package com.nala.actions;

public class SpicePickup {

	private Integer spice_pickup_write;

	private Integer spice_pickup_location_write;

	private Integer spice_pickup_read;

	private Integer spice_pickup_location_read;

	private Integer spice_pickup_run_time_read;

	public Integer getSpice_pickup_write() {
		return spice_pickup_write;
	}

	public void setSpice_pickup_write(Integer spice_pickup_write) {
		this.spice_pickup_write = spice_pickup_write;
	}

	public Integer getSpice_pickup_location_write() {
		return spice_pickup_location_write;
	}

	public void setSpice_pickup_location_write(Integer spice_pickup_location_write) {
		this.spice_pickup_location_write = spice_pickup_location_write;
	}

	public Integer getSpice_pickup_read() {
		return spice_pickup_read;
	}

	public void setSpice_pickup_read(Integer spice_pickup_read) {
		this.spice_pickup_read = spice_pickup_read;
	}

	public Integer getSpice_pickup_location_read() {
		return spice_pickup_location_read;
	}

	public void setSpice_pickup_location_read(Integer spice_pickup_location_read) {
		this.spice_pickup_location_read = spice_pickup_location_read;
	}

	public Integer getSpice_pickup_run_time_read() {
		return spice_pickup_run_time_read;
	}

	public void setSpice_pickup_run_time_read(Integer spice_pickup_run_time_read) {
		this.spice_pickup_run_time_read = spice_pickup_run_time_read;
	}

	@Override
	public String toString() {
		return "SpicePickup [spice_pickup_write=" + spice_pickup_write + ", spice_pickup_location_write="
				+ spice_pickup_location_write + ", spice_pickup_read=" + spice_pickup_read
				+ ", spice_pickup_location_read=" + spice_pickup_location_read + ", spice_pickup_run_time_read="
				+ spice_pickup_run_time_read + "]";
	}

}
