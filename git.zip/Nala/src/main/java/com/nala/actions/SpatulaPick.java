package com.nala.actions;

public class SpatulaPick {
	
	private Integer spatula_pick_write;
	
	private Integer spatula_type_write;
	
	private Integer spatula_pick_read;
	
	private Integer spatula_type_read;
	
	private Integer spatula_pick_run_time_read;

	public Integer getSpatula_pick_write() {
		return spatula_pick_write;
	}

	public void setSpatula_pick_write(Integer spatula_pick_write) {
		this.spatula_pick_write = spatula_pick_write;
	}

	public Integer getSpatula_type_write() {
		return spatula_type_write;
	}

	public void setSpatula_type_write(Integer spatula_type_write) {
		this.spatula_type_write = spatula_type_write;
	}

	public Integer getSpatula_pick_read() {
		return spatula_pick_read;
	}

	public void setSpatula_pick_read(Integer spatula_pick_read) {
		this.spatula_pick_read = spatula_pick_read;
	}

	public Integer getSpatula_type_read() {
		return spatula_type_read;
	}

	public void setSpatula_type_read(Integer spatula_type_read) {
		this.spatula_type_read = spatula_type_read;
	}

	public Integer getSpatula_pick_run_time_read() {
		return spatula_pick_run_time_read;
	}

	public void setSpatula_pick_run_time_read(Integer spatula_pick_run_time_read) {
		this.spatula_pick_run_time_read = spatula_pick_run_time_read;
	}

	@Override
	public String toString() {
		return "SpatulaPick [spatula_pick_write=" + spatula_pick_write + ", spatula_type_write=" + spatula_type_write
				+ ", spatula_pick_read=" + spatula_pick_read + ", spatula_type_read=" + spatula_type_read
				+ ", spatula_pick_run_time_read=" + spatula_pick_run_time_read + "]";
	}

	

}
