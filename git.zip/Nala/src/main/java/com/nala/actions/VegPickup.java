package com.nala.actions;

public class VegPickup {

	private Integer veg_pickup_write;

	private Integer veg_pickup_location_write;

	private Integer veg_pickup_read;

	private Integer veg_pickup_location_read;

	private Integer veg_pickup_run_time_read;

	public Integer getVeg_pickup_write() {
		return veg_pickup_write;
	}

	public void setVeg_pickup_write(Integer veg_pickup_write) {
		this.veg_pickup_write = veg_pickup_write;
	}

	public Integer getVeg_pickup_location_write() {
		return veg_pickup_location_write;
	}

	public void setVeg_pickup_location_write(Integer veg_pickup_location_write) {
		this.veg_pickup_location_write = veg_pickup_location_write;
	}

	public Integer getVeg_pickup_read() {
		return veg_pickup_read;
	}

	public void setVeg_pickup_read(Integer veg_pickup_read) {
		this.veg_pickup_read = veg_pickup_read;
	}

	public Integer getVeg_pickup_location_read() {
		return veg_pickup_location_read;
	}

	public void setVeg_pickup_location_read(Integer veg_pickup_location_read) {
		this.veg_pickup_location_read = veg_pickup_location_read;
	}

	public Integer getVeg_pickup_run_time_read() {
		return veg_pickup_run_time_read;
	}

	public void setVeg_pickup_run_time_read(Integer veg_pickup_run_time_read) {
		this.veg_pickup_run_time_read = veg_pickup_run_time_read;
	}

	@Override
	public String toString() {
		return "VegPickup [veg_pickup_write=" + veg_pickup_write + ", veg_pickup_location_write="
				+ veg_pickup_location_write + ", veg_pickup_read=" + veg_pickup_read + ", veg_pickup_location_read="
				+ veg_pickup_location_read + ", veg_pickup_run_time_read=" + veg_pickup_run_time_read + "]";
	}

}
