package com.nala.actions;

public class Serve {

	private Integer serve_write;

	private Integer serve_type_write;

	private Integer serve_read;

	private Integer serve_type_read;

	private Integer serve_run_time_read;

	public Integer getServe_write() {
		return serve_write;
	}

	public void setServe_write(Integer serve_write) {
		this.serve_write = serve_write;
	}

	public Integer getServe_type_write() {
		return serve_type_write;
	}

	public void setServe_type_write(Integer serve_type_write) {
		this.serve_type_write = serve_type_write;
	}

	public Integer getServe_read() {
		return serve_read;
	}

	public void setServe_read(Integer serve_read) {
		this.serve_read = serve_read;
	}

	public Integer getServe_type_read() {
		return serve_type_read;
	}

	public void setServe_type_read(Integer serve_type_read) {
		this.serve_type_read = serve_type_read;
	}

	public Integer getServe_run_time_read() {
		return serve_run_time_read;
	}

	public void setServe_run_time_read(Integer serve_run_time_read) {
		this.serve_run_time_read = serve_run_time_read;
	}

	@Override
	public String toString() {
		return "Serve [serve_write=" + serve_write + ", serve_type_write=" + serve_type_write + ", serve_read="
				+ serve_read + ", serve_type_read=" + serve_type_read + ", serve_run_time_read=" + serve_run_time_read
				+ "]";
	}

}
