package com.nala.actions;

public class FryerPickupDB {

	private Integer fryer_pickup_write;
	
	private Integer fryer_pickup_location_write;
	
	private Integer fryer_pickup_drop_location_write;
	
	private Integer fryer_pickup_bowl_change_or_without_bowl_change_write;
	
	private Integer fryer_pickup_read;
	
	private Integer fryer_pickup_location_read;
	
	private Integer fryer_pickup_drop_location_read;
	
	private Integer fryer_pickup_bowl_change_or_without_bowl_change_read;
	
	private Integer fryer_pickup_run_time_read;

	public Integer getFryer_pickup_write() {
		return fryer_pickup_write;
	}

	public void setFryer_pickup_write(Integer fryer_pickup_write) {
		this.fryer_pickup_write = fryer_pickup_write;
	}

	public Integer getFryer_pickup_location_write() {
		return fryer_pickup_location_write;
	}

	public void setFryer_pickup_location_write(Integer fryer_pickup_location_write) {
		this.fryer_pickup_location_write = fryer_pickup_location_write;
	}

	public Integer getFryer_pickup_drop_location_write() {
		return fryer_pickup_drop_location_write;
	}

	public void setFryer_pickup_drop_location_write(Integer fryer_pickup_drop_location_write) {
		this.fryer_pickup_drop_location_write = fryer_pickup_drop_location_write;
	}

	public Integer getFryer_pickup_bowl_change_or_without_bowl_change_write() {
		return fryer_pickup_bowl_change_or_without_bowl_change_write;
	}

	public void setFryer_pickup_bowl_change_or_without_bowl_change_write(
			Integer fryer_pickup_bowl_change_or_without_bowl_change_write) {
		this.fryer_pickup_bowl_change_or_without_bowl_change_write = fryer_pickup_bowl_change_or_without_bowl_change_write;
	}

	public Integer getFryer_pickup_read() {
		return fryer_pickup_read;
	}

	public void setFryer_pickup_read(Integer fryer_pickup_read) {
		this.fryer_pickup_read = fryer_pickup_read;
	}

	public Integer getFryer_pickup_location_read() {
		return fryer_pickup_location_read;
	}

	public void setFryer_pickup_location_read(Integer fryer_pickup_location_read) {
		this.fryer_pickup_location_read = fryer_pickup_location_read;
	}

	public Integer getFryer_pickup_drop_location_read() {
		return fryer_pickup_drop_location_read;
	}

	public void setFryer_pickup_drop_location_read(Integer fryer_pickup_drop_location_read) {
		this.fryer_pickup_drop_location_read = fryer_pickup_drop_location_read;
	}

	public Integer getFryer_pickup_bowl_change_or_without_bowl_change_read() {
		return fryer_pickup_bowl_change_or_without_bowl_change_read;
	}

	public void setFryer_pickup_bowl_change_or_without_bowl_change_read(
			Integer fryer_pickup_bowl_change_or_without_bowl_change_read) {
		this.fryer_pickup_bowl_change_or_without_bowl_change_read = fryer_pickup_bowl_change_or_without_bowl_change_read;
	}

	public Integer getFryer_pickup_run_time_read() {
		return fryer_pickup_run_time_read;
	}

	public void setFryer_pickup_run_time_read(Integer fryer_pickup_run_time_read) {
		this.fryer_pickup_run_time_read = fryer_pickup_run_time_read;
	}

	@Override
	public String toString() {
		return "FryerPickupDB [fryer_pickup_write=" + fryer_pickup_write + ", fryer_pickup_location_write="
				+ fryer_pickup_location_write + ", fryer_pickup_drop_location_write=" + fryer_pickup_drop_location_write
				+ ", fryer_pickup_bowl_change_or_without_bowl_change_write="
				+ fryer_pickup_bowl_change_or_without_bowl_change_write + ", fryer_pickup_read=" + fryer_pickup_read
				+ ", fryer_pickup_location_read=" + fryer_pickup_location_read + ", fryer_pickup_drop_location_read="
				+ fryer_pickup_drop_location_read + ", fryer_pickup_bowl_change_or_without_bowl_change_read="
				+ fryer_pickup_bowl_change_or_without_bowl_change_read + ", fryer_pickup_run_time_read="
				+ fryer_pickup_run_time_read + "]";
	}

}
