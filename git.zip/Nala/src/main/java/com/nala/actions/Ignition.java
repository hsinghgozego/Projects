package com.nala.actions;

public class Ignition {
	
	private Integer ignition_write;
	
	private Integer ignition_delay_time_write;
	
	private Integer ignition_read;
	
	private Integer ignition_run_time_read;
	
	private Integer flame_level_write;
	
	private Integer flame_level_read;

	public Integer getIgnition_write() {
		return ignition_write;
	}

	public void setIgnition_write(Integer ignition_write) {
		this.ignition_write = ignition_write;
	}

	public Integer getIgnition_delay_time_write() {
		return ignition_delay_time_write;
	}

	public void setIgnition_delay_time_write(Integer ignition_delay_time_write) {
		this.ignition_delay_time_write = ignition_delay_time_write;
	}

	public Integer getIgnition_read() {
		return ignition_read;
	}

	public void setIgnition_read(Integer ignition_read) {
		this.ignition_read = ignition_read;
	}

	public Integer getIgnition_run_time_read() {
		return ignition_run_time_read;
	}

	public void setIgnition_run_time_read(Integer ignition_run_time_read) {
		this.ignition_run_time_read = ignition_run_time_read;
	}

	public Integer getFlame_level_write() {
		return flame_level_write;
	}

	public void setFlame_level_write(Integer flame_level_write) {
		this.flame_level_write = flame_level_write;
	}

	public Integer getFlame_level_read() {
		return flame_level_read;
	}

	public void setFlame_level_read(Integer flame_level_read) {
		this.flame_level_read = flame_level_read;
	}

	@Override
	public String toString() {
		return "Ignition [ignition_write=" + ignition_write + ", ignition_delay_time_write=" + ignition_delay_time_write
				+ ", ignition_read=" + ignition_read + ", ignition_run_time_read=" + ignition_run_time_read
				+ ", flame_level_write=" + flame_level_write + ", flame_level_read=" + flame_level_read + "]";
	}

	
}
