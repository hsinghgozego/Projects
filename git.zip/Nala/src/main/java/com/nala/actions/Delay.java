package com.nala.actions;

public class Delay {

	private Integer delay_write;

	private Integer delay_time_write;

	private Integer delay_read;

	private Integer delay_run_time_read;

	public Integer getDelay_write() {
		return delay_write;
	}

	public void setDelay_write(Integer delay_write) {
		this.delay_write = delay_write;
	}

	public Integer getDelay_time_write() {
		return delay_time_write;
	}

	public void setDelay_time_write(Integer delay_time_write) {
		this.delay_time_write = delay_time_write;
	}

	public Integer getDelay_read() {
		return delay_read;
	}

	public void setDelay_read(Integer delay_read) {
		this.delay_read = delay_read;
	}

	public Integer getDelay_run_time_read() {
		return delay_run_time_read;
	}

	public void setDelay_run_time_read(Integer delay_run_time_read) {
		this.delay_run_time_read = delay_run_time_read;
	}

	@Override
	public String toString() {
		return "Delay [delay_write=" + delay_write + ", delay_time_write=" + delay_time_write + ", delay_read="
				+ delay_read + ", delay_run_time_read=" + delay_run_time_read + "]";
	}

}
