package com.nala.actions;

public class SpiceCollection {

	private Integer spice_collection_write;

	private Integer spice_collection_bin_number_write;

	private Integer spice_collection_weight_write;

	private Integer spice_collection_read;

	private Integer spice_collection_bin_number_read;

	private Integer spice_collection_achieved_weight_read;

	private Integer spice_collection_run_time_read;

	private Integer spice_collection_weighing_run_time_read;

	private Integer spice_motor_cutoff_in_pct_write;

	private Integer spice_motor_normal_in_pct_write;

	private Integer spice_motor_normal_speed_write;

	private Integer spice_motor_inching_speed_write;

	private Integer spice_motor_time_gap_between_normal_and_inch_write;

	private Integer spice_motor_time_gap_between_inching_write;

	private Integer spice_motor_inching_time_write;

	public Integer getSpice_collection_write() {
		return spice_collection_write;
	}

	public void setSpice_collection_write(Integer spice_collection_write) {
		this.spice_collection_write = spice_collection_write;
	}

	public Integer getSpice_collection_bin_number_write() {
		return spice_collection_bin_number_write;
	}

	public void setSpice_collection_bin_number_write(Integer spice_collection_bin_number_write) {
		this.spice_collection_bin_number_write = spice_collection_bin_number_write;
	}

	public Integer getSpice_collection_weight_write() {
		return spice_collection_weight_write;
	}

	public void setSpice_collection_weight_write(Integer spice_collection_weight_write) {
		this.spice_collection_weight_write = spice_collection_weight_write;
	}

	public Integer getSpice_collection_read() {
		return spice_collection_read;
	}

	public void setSpice_collection_read(Integer spice_collection_read) {
		this.spice_collection_read = spice_collection_read;
	}

	public Integer getSpice_collection_bin_number_read() {
		return spice_collection_bin_number_read;
	}

	public void setSpice_collection_bin_number_read(Integer spice_collection_bin_number_read) {
		this.spice_collection_bin_number_read = spice_collection_bin_number_read;
	}

	public Integer getSpice_collection_achieved_weight_read() {
		return spice_collection_achieved_weight_read;
	}

	public void setSpice_collection_achieved_weight_read(Integer spice_collection_achieved_weight_read) {
		this.spice_collection_achieved_weight_read = spice_collection_achieved_weight_read;
	}

	public Integer getSpice_collection_run_time_read() {
		return spice_collection_run_time_read;
	}

	public void setSpice_collection_run_time_read(Integer spice_collection_run_time_read) {
		this.spice_collection_run_time_read = spice_collection_run_time_read;
	}

	public Integer getSpice_collection_weighing_run_time_read() {
		return spice_collection_weighing_run_time_read;
	}

	public void setSpice_collection_weighing_run_time_read(Integer spice_collection_weighing_run_time_read) {
		this.spice_collection_weighing_run_time_read = spice_collection_weighing_run_time_read;
	}

	public Integer getSpice_motor_cutoff_in_pct_write() {
		return spice_motor_cutoff_in_pct_write;
	}

	public void setSpice_motor_cutoff_in_pct_write(Integer spice_motor_cutoff_in_pct_write) {
		this.spice_motor_cutoff_in_pct_write = spice_motor_cutoff_in_pct_write;
	}

	public Integer getSpice_motor_normal_in_pct_write() {
		return spice_motor_normal_in_pct_write;
	}

	public void setSpice_motor_normal_in_pct_write(Integer spice_motor_normal_in_pct_write) {
		this.spice_motor_normal_in_pct_write = spice_motor_normal_in_pct_write;
	}

	public Integer getSpice_motor_normal_speed_write() {
		return spice_motor_normal_speed_write;
	}

	public void setSpice_motor_normal_speed_write(Integer spice_motor_normal_speed_write) {
		this.spice_motor_normal_speed_write = spice_motor_normal_speed_write;
	}

	public Integer getSpice_motor_inching_speed_write() {
		return spice_motor_inching_speed_write;
	}

	public void setSpice_motor_inching_speed_write(Integer spice_motor_inching_speed_write) {
		this.spice_motor_inching_speed_write = spice_motor_inching_speed_write;
	}

	public Integer getSpice_motor_time_gap_between_normal_and_inch_write() {
		return spice_motor_time_gap_between_normal_and_inch_write;
	}

	public void setSpice_motor_time_gap_between_normal_and_inch_write(
			Integer spice_motor_time_gap_between_normal_and_inch_write) {
		this.spice_motor_time_gap_between_normal_and_inch_write = spice_motor_time_gap_between_normal_and_inch_write;
	}

	public Integer getSpice_motor_time_gap_between_inching_write() {
		return spice_motor_time_gap_between_inching_write;
	}

	public void setSpice_motor_time_gap_between_inching_write(Integer spice_motor_time_gap_between_inching_write) {
		this.spice_motor_time_gap_between_inching_write = spice_motor_time_gap_between_inching_write;
	}

	public Integer getSpice_motor_inching_time_write() {
		return spice_motor_inching_time_write;
	}

	public void setSpice_motor_inching_time_write(Integer spice_motor_inching_time_write) {
		this.spice_motor_inching_time_write = spice_motor_inching_time_write;
	}

	@Override
	public String toString() {
		return "SpiceCollection [spice_collection_write=" + spice_collection_write
				+ ", spice_collection_bin_number_write=" + spice_collection_bin_number_write
				+ ", spice_collection_weight_write=" + spice_collection_weight_write + ", spice_collection_read="
				+ spice_collection_read + ", spice_collection_bin_number_read=" + spice_collection_bin_number_read
				+ ", spice_collection_achieved_weight_read=" + spice_collection_achieved_weight_read
				+ ", spice_collection_run_time_read=" + spice_collection_run_time_read
				+ ", spice_collection_weighing_run_time_read=" + spice_collection_weighing_run_time_read
				+ ", spice_motor_cutoff_in_pct_write=" + spice_motor_cutoff_in_pct_write
				+ ", spice_motor_normal_in_pct_write=" + spice_motor_normal_in_pct_write
				+ ", spice_motor_normal_speed_write=" + spice_motor_normal_speed_write
				+ ", spice_motor_inching_speed_write=" + spice_motor_inching_speed_write
				+ ", spice_motor_time_gap_between_normal_and_inch_write="
				+ spice_motor_time_gap_between_normal_and_inch_write + ", spice_motor_time_gap_between_inching_write="
				+ spice_motor_time_gap_between_inching_write + ", spice_motor_inching_time_write="
				+ spice_motor_inching_time_write + "]";
	}

}
