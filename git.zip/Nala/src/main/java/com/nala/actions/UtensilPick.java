package com.nala.actions;

public class UtensilPick {
	
	private Integer utensil_pick_write;
	
	private Integer utensil_type_write;
	
	private Integer utensil_pick_read;
	
	private Integer utensil_type_read;
	
	private Integer utensil_pick_run_time_read;

	public Integer getUtensil_pick_write() {
		return utensil_pick_write;
	}

	public void setUtensil_pick_write(Integer utensil_pick_write) {
		this.utensil_pick_write = utensil_pick_write;
	}

	public Integer getUtensil_type_write() {
		return utensil_type_write;
	}

	public void setUtensil_type_write(Integer utensil_type_write) {
		this.utensil_type_write = utensil_type_write;
	}

	public Integer getUtensil_pick_read() {
		return utensil_pick_read;
	}

	public void setUtensil_pick_read(Integer utensil_pick_read) {
		this.utensil_pick_read = utensil_pick_read;
	}

	public Integer getUtensil_type_read() {
		return utensil_type_read;
	}

	public void setUtensil_type_read(Integer utensil_type_read) {
		this.utensil_type_read = utensil_type_read;
	}

	public Integer getUtensil_pick_run_time_read() {
		return utensil_pick_run_time_read;
	}

	public void setUtensil_pick_run_time_read(Integer utensil_pick_run_time_read) {
		this.utensil_pick_run_time_read = utensil_pick_run_time_read;
	}

	@Override
	public String toString() {
		return "UtensilPick [utensil_pick_write=" + utensil_pick_write + ", utensil_type_write=" + utensil_type_write
				+ ", utensil_pick_read=" + utensil_pick_read + ", utensil_type_read=" + utensil_type_read
				+ ", utensil_pick_run_time_read=" + utensil_pick_run_time_read + "]";
	}


}
