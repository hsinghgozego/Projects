package com.nala.actions;

public class LiquidDispensing {

	private Integer liquid_dispensing_write;

	private Integer liquid_dispensing_liq_bin_number_1_write;

	private Integer liquid_dispensing_delay_time_1_write;

	private Integer liquid_dispensing_liq_bin_number_2_write;

	private Integer liquid_dispensing_delay_time_2_write;

	private Integer liquid_dispensing_liq_bin_number_3_write;

	private Integer liquid_dispensing_delay_time_3_write;

	private Integer liquid_dispensing_liq_bin_number_4_write;

	private Integer liquid_dispensing_delay_time_4_write;

	private Integer liquid_dispensing_liq_bin_number_5_write;

	private Integer liquid_dispensing_delay_time_5_write;

	private Integer liquid_dispensing_liq_bin_number_1_run_time_read;

	private Integer liquid_dispensing_liq_bin_number_2_run_time_read;

	private Integer liquid_dispensing_liq_bin_number_3_run_time_read;

	private Integer liquid_dispensing_liq_bin_number_4_run_time_read;

	private Integer liquid_dispensing_liq_bin_number_5_run_time_read;

	private Integer liquid_dispensing_read;

	private Integer liquid_dispensing_run_time_read;

	public Integer getLiquid_dispensing_write() {
		return liquid_dispensing_write;
	}

	public void setLiquid_dispensing_write(Integer liquid_dispensing_write) {
		this.liquid_dispensing_write = liquid_dispensing_write;
	}

	public Integer getLiquid_dispensing_liq_bin_number_1_write() {
		return liquid_dispensing_liq_bin_number_1_write;
	}

	public void setLiquid_dispensing_liq_bin_number_1_write(Integer liquid_dispensing_liq_bin_number_1_write) {
		this.liquid_dispensing_liq_bin_number_1_write = liquid_dispensing_liq_bin_number_1_write;
	}

	public Integer getLiquid_dispensing_delay_time_1_write() {
		return liquid_dispensing_delay_time_1_write;
	}

	public void setLiquid_dispensing_delay_time_1_write(Integer liquid_dispensing_delay_time_1_write) {
		this.liquid_dispensing_delay_time_1_write = liquid_dispensing_delay_time_1_write;
	}

	public Integer getLiquid_dispensing_liq_bin_number_2_write() {
		return liquid_dispensing_liq_bin_number_2_write;
	}

	public void setLiquid_dispensing_liq_bin_number_2_write(Integer liquid_dispensing_liq_bin_number_2_write) {
		this.liquid_dispensing_liq_bin_number_2_write = liquid_dispensing_liq_bin_number_2_write;
	}

	public Integer getLiquid_dispensing_delay_time_2_write() {
		return liquid_dispensing_delay_time_2_write;
	}

	public void setLiquid_dispensing_delay_time_2_write(Integer liquid_dispensing_delay_time_2_write) {
		this.liquid_dispensing_delay_time_2_write = liquid_dispensing_delay_time_2_write;
	}

	public Integer getLiquid_dispensing_liq_bin_number_3_write() {
		return liquid_dispensing_liq_bin_number_3_write;
	}

	public void setLiquid_dispensing_liq_bin_number_3_write(Integer liquid_dispensing_liq_bin_number_3_write) {
		this.liquid_dispensing_liq_bin_number_3_write = liquid_dispensing_liq_bin_number_3_write;
	}

	public Integer getLiquid_dispensing_delay_time_3_write() {
		return liquid_dispensing_delay_time_3_write;
	}

	public void setLiquid_dispensing_delay_time_3_write(Integer liquid_dispensing_delay_time_3_write) {
		this.liquid_dispensing_delay_time_3_write = liquid_dispensing_delay_time_3_write;
	}

	public Integer getLiquid_dispensing_liq_bin_number_4_write() {
		return liquid_dispensing_liq_bin_number_4_write;
	}

	public void setLiquid_dispensing_liq_bin_number_4_write(Integer liquid_dispensing_liq_bin_number_4_write) {
		this.liquid_dispensing_liq_bin_number_4_write = liquid_dispensing_liq_bin_number_4_write;
	}

	public Integer getLiquid_dispensing_delay_time_4_write() {
		return liquid_dispensing_delay_time_4_write;
	}

	public void setLiquid_dispensing_delay_time_4_write(Integer liquid_dispensing_delay_time_4_write) {
		this.liquid_dispensing_delay_time_4_write = liquid_dispensing_delay_time_4_write;
	}

	public Integer getLiquid_dispensing_liq_bin_number_5_write() {
		return liquid_dispensing_liq_bin_number_5_write;
	}

	public void setLiquid_dispensing_liq_bin_number_5_write(Integer liquid_dispensing_liq_bin_number_5_write) {
		this.liquid_dispensing_liq_bin_number_5_write = liquid_dispensing_liq_bin_number_5_write;
	}

	public Integer getLiquid_dispensing_delay_time_5_write() {
		return liquid_dispensing_delay_time_5_write;
	}

	public void setLiquid_dispensing_delay_time_5_write(Integer liquid_dispensing_delay_time_5_write) {
		this.liquid_dispensing_delay_time_5_write = liquid_dispensing_delay_time_5_write;
	}

	public Integer getLiquid_dispensing_liq_bin_number_1_run_time_read() {
		return liquid_dispensing_liq_bin_number_1_run_time_read;
	}

	public void setLiquid_dispensing_liq_bin_number_1_run_time_read(
			Integer liquid_dispensing_liq_bin_number_1_run_time_read) {
		this.liquid_dispensing_liq_bin_number_1_run_time_read = liquid_dispensing_liq_bin_number_1_run_time_read;
	}

	public Integer getLiquid_dispensing_liq_bin_number_2_run_time_read() {
		return liquid_dispensing_liq_bin_number_2_run_time_read;
	}

	public void setLiquid_dispensing_liq_bin_number_2_run_time_read(
			Integer liquid_dispensing_liq_bin_number_2_run_time_read) {
		this.liquid_dispensing_liq_bin_number_2_run_time_read = liquid_dispensing_liq_bin_number_2_run_time_read;
	}

	public Integer getLiquid_dispensing_liq_bin_number_3_run_time_read() {
		return liquid_dispensing_liq_bin_number_3_run_time_read;
	}

	public void setLiquid_dispensing_liq_bin_number_3_run_time_read(
			Integer liquid_dispensing_liq_bin_number_3_run_time_read) {
		this.liquid_dispensing_liq_bin_number_3_run_time_read = liquid_dispensing_liq_bin_number_3_run_time_read;
	}

	public Integer getLiquid_dispensing_liq_bin_number_4_run_time_read() {
		return liquid_dispensing_liq_bin_number_4_run_time_read;
	}

	public void setLiquid_dispensing_liq_bin_number_4_run_time_read(
			Integer liquid_dispensing_liq_bin_number_4_run_time_read) {
		this.liquid_dispensing_liq_bin_number_4_run_time_read = liquid_dispensing_liq_bin_number_4_run_time_read;
	}

	public Integer getLiquid_dispensing_liq_bin_number_5_run_time_read() {
		return liquid_dispensing_liq_bin_number_5_run_time_read;
	}

	public void setLiquid_dispensing_liq_bin_number_5_run_time_read(
			Integer liquid_dispensing_liq_bin_number_5_run_time_read) {
		this.liquid_dispensing_liq_bin_number_5_run_time_read = liquid_dispensing_liq_bin_number_5_run_time_read;
	}

	public Integer getLiquid_dispensing_read() {
		return liquid_dispensing_read;
	}

	public void setLiquid_dispensing_read(Integer liquid_dispensing_read) {
		this.liquid_dispensing_read = liquid_dispensing_read;
	}

	public Integer getLiquid_dispensing_run_time_read() {
		return liquid_dispensing_run_time_read;
	}

	public void setLiquid_dispensing_run_time_read(Integer liquid_dispensing_run_time_read) {
		this.liquid_dispensing_run_time_read = liquid_dispensing_run_time_read;
	}

	@Override
	public String toString() {
		return "LiquidDispensing [liquid_dispensing_write=" + liquid_dispensing_write
				+ ", liquid_dispensing_liq_bin_number_1_write=" + liquid_dispensing_liq_bin_number_1_write
				+ ", liquid_dispensing_delay_time_1_write=" + liquid_dispensing_delay_time_1_write
				+ ", liquid_dispensing_liq_bin_number_2_write=" + liquid_dispensing_liq_bin_number_2_write
				+ ", liquid_dispensing_delay_time_2_write=" + liquid_dispensing_delay_time_2_write
				+ ", liquid_dispensing_liq_bin_number_3_write=" + liquid_dispensing_liq_bin_number_3_write
				+ ", liquid_dispensing_delay_time_3_write=" + liquid_dispensing_delay_time_3_write
				+ ", liquid_dispensing_liq_bin_number_4_write=" + liquid_dispensing_liq_bin_number_4_write
				+ ", liquid_dispensing_delay_time_4_write=" + liquid_dispensing_delay_time_4_write
				+ ", liquid_dispensing_liq_bin_number_5_write=" + liquid_dispensing_liq_bin_number_5_write
				+ ", liquid_dispensing_delay_time_5_write=" + liquid_dispensing_delay_time_5_write
				+ ", liquid_dispensing_liq_bin_number_1_run_time_read="
				+ liquid_dispensing_liq_bin_number_1_run_time_read
				+ ", liquid_dispensing_liq_bin_number_2_run_time_read="
				+ liquid_dispensing_liq_bin_number_2_run_time_read
				+ ", liquid_dispensing_liq_bin_number_3_run_time_read="
				+ liquid_dispensing_liq_bin_number_3_run_time_read
				+ ", liquid_dispensing_liq_bin_number_4_run_time_read="
				+ liquid_dispensing_liq_bin_number_4_run_time_read
				+ ", liquid_dispensing_liq_bin_number_5_run_time_read="
				+ liquid_dispensing_liq_bin_number_5_run_time_read + ", liquid_dispensing_read="
				+ liquid_dispensing_read + ", liquid_dispensing_run_time_read=" + liquid_dispensing_run_time_read + "]";
	}

}
