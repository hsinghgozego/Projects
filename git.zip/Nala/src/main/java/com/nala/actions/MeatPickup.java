package com.nala.actions;

public class MeatPickup {

	private Integer meat_pickup_write;

	private Integer meat_pickup_location_write;

	private Integer meat_pickup_read;

	private Integer meat_pickup_location_read;

	private Integer meat_pickup_run_time_read;

	public Integer getMeat_pickup_write() {
		return meat_pickup_write;
	}

	public void setMeat_pickup_write(Integer meat_pickup_write) {
		this.meat_pickup_write = meat_pickup_write;
	}

	public Integer getMeat_pickup_location_write() {
		return meat_pickup_location_write;
	}

	public void setMeat_pickup_location_write(Integer meat_pickup_location_write) {
		this.meat_pickup_location_write = meat_pickup_location_write;
	}

	public Integer getMeat_pickup_read() {
		return meat_pickup_read;
	}

	public void setMeat_pickup_read(Integer meat_pickup_read) {
		this.meat_pickup_read = meat_pickup_read;
	}

	public Integer getMeat_pickup_location_read() {
		return meat_pickup_location_read;
	}

	public void setMeat_pickup_location_read(Integer meat_pickup_location_read) {
		this.meat_pickup_location_read = meat_pickup_location_read;
	}

	public Integer getMeat_pickup_run_time_read() {
		return meat_pickup_run_time_read;
	}

	public void setMeat_pickup_run_time_read(Integer meat_pickup_run_time_read) {
		this.meat_pickup_run_time_read = meat_pickup_run_time_read;
	}

	@Override
	public String toString() {
		return "MeatPickup [meat_pickup_write=" + meat_pickup_write + ", meat_pickup_location_write="
				+ meat_pickup_location_write + ", meat_pickup_read=" + meat_pickup_read + ", meat_pickup_location_read="
				+ meat_pickup_location_read + ", meat_pickup_run_time_read=" + meat_pickup_run_time_read + "]";
	}

}
