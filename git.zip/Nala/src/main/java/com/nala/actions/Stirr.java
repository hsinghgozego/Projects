package com.nala.actions;

public class Stirr {

	private Integer stirr_write;

	private Integer stirr_stir_type_number_write;

	private Integer stirr_time_in_milli_sec_write;

	private Integer stirr_read;

	private Integer stirr_stir_type_number_read;

	private Integer stirr_run_time_read;

	public Integer getStirr_write() {
		return stirr_write;
	}

	public void setStirr_write(Integer stirr_write) {
		this.stirr_write = stirr_write;
	}

	public Integer getStirr_stir_type_number_write() {
		return stirr_stir_type_number_write;
	}

	public void setStirr_stir_type_number_write(Integer stirr_stir_type_number_write) {
		this.stirr_stir_type_number_write = stirr_stir_type_number_write;
	}

	public Integer getStirr_time_in_milli_sec_write() {
		return stirr_time_in_milli_sec_write;
	}

	public void setStirr_time_in_milli_sec_write(Integer stirr_time_in_milli_sec_write) {
		this.stirr_time_in_milli_sec_write = stirr_time_in_milli_sec_write;
	}

	public Integer getStirr_read() {
		return stirr_read;
	}

	public void setStirr_read(Integer stirr_read) {
		this.stirr_read = stirr_read;
	}

	public Integer getStirr_stir_type_number_read() {
		return stirr_stir_type_number_read;
	}

	public void setStirr_stir_type_number_read(Integer stirr_stir_type_number_read) {
		this.stirr_stir_type_number_read = stirr_stir_type_number_read;
	}

	public Integer getStirr_run_time_read() {
		return stirr_run_time_read;
	}

	public void setStirr_run_time_read(Integer stirr_run_time_read) {
		this.stirr_run_time_read = stirr_run_time_read;
	}

	@Override
	public String toString() {
		return "Stirr [stirr_write=" + stirr_write + ", stirr_stir_type_number_write=" + stirr_stir_type_number_write
				+ ", stirr_time_in_milli_sec_write=" + stirr_time_in_milli_sec_write + ", stirr_read=" + stirr_read
				+ ", stirr_stir_type_number_read=" + stirr_stir_type_number_read + ", stirr_run_time_read="
				+ stirr_run_time_read + "]";
	}

}
