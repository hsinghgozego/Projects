package com.nala.actions;

public class FryerServeDB {

	private Integer fryer_serve_write;

	private Integer fryer_serve_pool_location_write;

	private Integer fryer_serve_transfer_or_serve_write;

	private Integer fryer_serve_read;

	private Integer fryer_serve_pool_location_read;

	private Integer fryer_serve_transfer_or_serve_read;

	private Integer fryer_serve_run_time_read;

	public Integer getFryer_serve_write() {
		return fryer_serve_write;
	}

	public void setFryer_serve_write(Integer fryer_serve_write) {
		this.fryer_serve_write = fryer_serve_write;
	}

	public Integer getFryer_serve_pool_location_write() {
		return fryer_serve_pool_location_write;
	}

	public void setFryer_serve_pool_location_write(Integer fryer_serve_pool_location_write) {
		this.fryer_serve_pool_location_write = fryer_serve_pool_location_write;
	}

	public Integer getFryer_serve_transfer_or_serve_write() {
		return fryer_serve_transfer_or_serve_write;
	}

	public void setFryer_serve_transfer_or_serve_write(Integer fryer_serve_transfer_or_serve_write) {
		this.fryer_serve_transfer_or_serve_write = fryer_serve_transfer_or_serve_write;
	}

	public Integer getFryer_serve_read() {
		return fryer_serve_read;
	}

	public void setFryer_serve_read(Integer fryer_serve_read) {
		this.fryer_serve_read = fryer_serve_read;
	}

	public Integer getFryer_serve_pool_location_read() {
		return fryer_serve_pool_location_read;
	}

	public void setFryer_serve_pool_location_read(Integer fryer_serve_pool_location_read) {
		this.fryer_serve_pool_location_read = fryer_serve_pool_location_read;
	}

	public Integer getFryer_serve_transfer_or_serve_read() {
		return fryer_serve_transfer_or_serve_read;
	}

	public void setFryer_serve_transfer_or_serve_read(Integer fryer_serve_transfer_or_serve_read) {
		this.fryer_serve_transfer_or_serve_read = fryer_serve_transfer_or_serve_read;
	}

	public Integer getFryer_serve_run_time_read() {
		return fryer_serve_run_time_read;
	}

	public void setFryer_serve_run_time_read(Integer fryer_serve_run_time_read) {
		this.fryer_serve_run_time_read = fryer_serve_run_time_read;
	}

	@Override
	public String toString() {
		return "FryerServeDB [fryer_serve_write=" + fryer_serve_write + ", fryer_serve_pool_location_write="
				+ fryer_serve_pool_location_write + ", fryer_serve_transfer_or_serve_write="
				+ fryer_serve_transfer_or_serve_write + ", fryer_serve_read=" + fryer_serve_read
				+ ", fryer_serve_pool_location_read=" + fryer_serve_pool_location_read
				+ ", fryer_serve_transfer_or_serve_read=" + fryer_serve_transfer_or_serve_read
				+ ", fryer_serve_run_time_read=" + fryer_serve_run_time_read + "]";
	}

}
