package com.nala.actions;

public class FryerActionDB {

	private Integer fryer_action_write;

	private Integer fryer_action_pool_location_write;

	private Integer fryer_action_lift_dip_write;

	private Integer fryer_action_read;

	private Integer fryer_action_pool_location_read;

	private Integer fryer_action_lift_dip_read;

	private Integer fryer_action_run_time_read;

	public Integer getFryer_action_write() {
		return fryer_action_write;
	}

	public void setFryer_action_write(Integer fryer_action_write) {
		this.fryer_action_write = fryer_action_write;
	}

	public Integer getFryer_action_pool_location_write() {
		return fryer_action_pool_location_write;
	}

	public void setFryer_action_pool_location_write(Integer fryer_action_pool_location_write) {
		this.fryer_action_pool_location_write = fryer_action_pool_location_write;
	}

	public Integer getFryer_action_lift_dip_write() {
		return fryer_action_lift_dip_write;
	}

	public void setFryer_action_lift_dip_write(Integer fryer_action_lift_dip_write) {
		this.fryer_action_lift_dip_write = fryer_action_lift_dip_write;
	}

	public Integer getFryer_action_read() {
		return fryer_action_read;
	}

	public void setFryer_action_read(Integer fryer_action_read) {
		this.fryer_action_read = fryer_action_read;
	}

	public Integer getFryer_action_pool_location_read() {
		return fryer_action_pool_location_read;
	}

	public void setFryer_action_pool_location_read(Integer fryer_action_pool_location_read) {
		this.fryer_action_pool_location_read = fryer_action_pool_location_read;
	}

	public Integer getFryer_action_lift_dip_read() {
		return fryer_action_lift_dip_read;
	}

	public void setFryer_action_lift_dip_read(Integer fryer_action_lift_dip_read) {
		this.fryer_action_lift_dip_read = fryer_action_lift_dip_read;
	}

	public Integer getFryer_action_run_time_read() {
		return fryer_action_run_time_read;
	}

	public void setFryer_action_run_time_read(Integer fryer_action_run_time_read) {
		this.fryer_action_run_time_read = fryer_action_run_time_read;
	}

	@Override
	public String toString() {
		return "FryerActionDB [fryer_action_write=" + fryer_action_write + ", fryer_action_pool_location_write="
				+ fryer_action_pool_location_write + ", fryer_action_lift_dip_write=" + fryer_action_lift_dip_write
				+ ", fryer_action_read=" + fryer_action_read + ", fryer_action_pool_location_read="
				+ fryer_action_pool_location_read + ", fryer_action_lift_dip_read=" + fryer_action_lift_dip_read
				+ ", fryer_action_run_time_read=" + fryer_action_run_time_read + "]";
	}

}
