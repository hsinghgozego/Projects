package com.nala.actions;

public class Toss {

	private Integer toss_write;

	private Integer toss_toss_type_number_write;

	private Integer toss_time_in_milli_sec_write;

	private Integer toss_read;

	private Integer toss_toss_type_number_read;

	private Integer toss_run_time_read;

	public Integer getToss_write() {
		return toss_write;
	}

	public void setToss_write(Integer toss_write) {
		this.toss_write = toss_write;
	}

	public Integer getToss_toss_type_number_write() {
		return toss_toss_type_number_write;
	}

	public void setToss_toss_type_number_write(Integer toss_toss_type_number_write) {
		this.toss_toss_type_number_write = toss_toss_type_number_write;
	}

	public Integer getToss_time_in_milli_sec_write() {
		return toss_time_in_milli_sec_write;
	}

	public void setToss_time_in_milli_sec_write(Integer toss_time_in_milli_sec_write) {
		this.toss_time_in_milli_sec_write = toss_time_in_milli_sec_write;
	}

	public Integer getToss_read() {
		return toss_read;
	}

	public void setToss_read(Integer toss_read) {
		this.toss_read = toss_read;
	}

	public Integer getToss_toss_type_number_read() {
		return toss_toss_type_number_read;
	}

	public void setToss_toss_type_number_read(Integer toss_toss_type_number_read) {
		this.toss_toss_type_number_read = toss_toss_type_number_read;
	}

	public Integer getToss_run_time_read() {
		return toss_run_time_read;
	}

	public void setToss_run_time_read(Integer toss_run_time_read) {
		this.toss_run_time_read = toss_run_time_read;
	}

	@Override
	public String toString() {
		return "Toss [toss_write=" + toss_write + ", toss_toss_type_number_write=" + toss_toss_type_number_write
				+ ", toss_time_in_milli_sec_write=" + toss_time_in_milli_sec_write + ", toss_read=" + toss_read
				+ ", toss_toss_type_number_read=" + toss_toss_type_number_read + ", toss_run_time_read="
				+ toss_run_time_read + "]";
	}

}
