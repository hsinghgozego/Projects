package com.nala.actions;

public class MeatCollection {

	private Integer meat_collection_write;

	private Integer meat_collection_bin_number_write;

	private Integer meat_collection_weight_write;

	private Integer meat_collection_read;

	private Integer meat_collection_bin_number_read;

	private Integer meat_collection_achieved_weight_read;

	private Integer meat_collection_run_time_read;

	private Integer meat_collection_weighing_run_time_read;

	private Integer meat_motor_cutoff_in_pct_write;

	private Integer meat_motor_normal_in_pct_write;

	private Integer meat_motor_normal_speed_write;

	private Integer meat_motor_inching_speed_write;

	private Integer meat_motor_time_gap_between_normal_and_inch_write;

	private Integer meat_motor_time_gap_between_inching_write;

	private Integer meat_motor_inching_time_write;

	public Integer getMeat_collection_write() {
		return meat_collection_write;
	}

	public void setMeat_collection_write(Integer meat_collection_write) {
		this.meat_collection_write = meat_collection_write;
	}

	public Integer getMeat_collection_bin_number_write() {
		return meat_collection_bin_number_write;
	}

	public void setMeat_collection_bin_number_write(Integer meat_collection_bin_number_write) {
		this.meat_collection_bin_number_write = meat_collection_bin_number_write;
	}

	public Integer getMeat_collection_weight_write() {
		return meat_collection_weight_write;
	}

	public void setMeat_collection_weight_write(Integer meat_collection_weight_write) {
		this.meat_collection_weight_write = meat_collection_weight_write;
	}

	public Integer getMeat_collection_read() {
		return meat_collection_read;
	}

	public void setMeat_collection_read(Integer meat_collection_read) {
		this.meat_collection_read = meat_collection_read;
	}

	public Integer getMeat_collection_bin_number_read() {
		return meat_collection_bin_number_read;
	}

	public void setMeat_collection_bin_number_read(Integer meat_collection_bin_number_read) {
		this.meat_collection_bin_number_read = meat_collection_bin_number_read;
	}

	public Integer getMeat_collection_achieved_weight_read() {
		return meat_collection_achieved_weight_read;
	}

	public void setMeat_collection_achieved_weight_read(Integer meat_collection_achieved_weight_read) {
		this.meat_collection_achieved_weight_read = meat_collection_achieved_weight_read;
	}

	public Integer getMeat_collection_run_time_read() {
		return meat_collection_run_time_read;
	}

	public void setMeat_collection_run_time_read(Integer meat_collection_run_time_read) {
		this.meat_collection_run_time_read = meat_collection_run_time_read;
	}

	public Integer getMeat_collection_weighing_run_time_read() {
		return meat_collection_weighing_run_time_read;
	}

	public void setMeat_collection_weighing_run_time_read(Integer meat_collection_weighing_run_time_read) {
		this.meat_collection_weighing_run_time_read = meat_collection_weighing_run_time_read;
	}

	public Integer getMeat_motor_cutoff_in_pct_write() {
		return meat_motor_cutoff_in_pct_write;
	}

	public void setMeat_motor_cutoff_in_pct_write(Integer meat_motor_cutoff_in_pct_write) {
		this.meat_motor_cutoff_in_pct_write = meat_motor_cutoff_in_pct_write;
	}

	public Integer getMeat_motor_normal_in_pct_write() {
		return meat_motor_normal_in_pct_write;
	}

	public void setMeat_motor_normal_in_pct_write(Integer meat_motor_normal_in_pct_write) {
		this.meat_motor_normal_in_pct_write = meat_motor_normal_in_pct_write;
	}

	public Integer getMeat_motor_normal_speed_write() {
		return meat_motor_normal_speed_write;
	}

	public void setMeat_motor_normal_speed_write(Integer meat_motor_normal_speed_write) {
		this.meat_motor_normal_speed_write = meat_motor_normal_speed_write;
	}

	public Integer getMeat_motor_inching_speed_write() {
		return meat_motor_inching_speed_write;
	}

	public void setMeat_motor_inching_speed_write(Integer meat_motor_inching_speed_write) {
		this.meat_motor_inching_speed_write = meat_motor_inching_speed_write;
	}

	public Integer getMeat_motor_time_gap_between_normal_and_inch_write() {
		return meat_motor_time_gap_between_normal_and_inch_write;
	}

	public void setMeat_motor_time_gap_between_normal_and_inch_write(
			Integer meat_motor_time_gap_between_normal_and_inch_write) {
		this.meat_motor_time_gap_between_normal_and_inch_write = meat_motor_time_gap_between_normal_and_inch_write;
	}

	public Integer getMeat_motor_time_gap_between_inching_write() {
		return meat_motor_time_gap_between_inching_write;
	}

	public void setMeat_motor_time_gap_between_inching_write(Integer meat_motor_time_gap_between_inching_write) {
		this.meat_motor_time_gap_between_inching_write = meat_motor_time_gap_between_inching_write;
	}

	public Integer getMeat_motor_inching_time_write() {
		return meat_motor_inching_time_write;
	}

	public void setMeat_motor_inching_time_write(Integer meat_motor_inching_time_write) {
		this.meat_motor_inching_time_write = meat_motor_inching_time_write;
	}

	@Override
	public String toString() {
		return "MeatCollection [meat_collection_write=" + meat_collection_write + ", meat_collection_bin_number_write="
				+ meat_collection_bin_number_write + ", meat_collection_weight_write=" + meat_collection_weight_write
				+ ", meat_collection_read=" + meat_collection_read + ", meat_collection_bin_number_read="
				+ meat_collection_bin_number_read + ", meat_collection_achieved_weight_read="
				+ meat_collection_achieved_weight_read + ", meat_collection_run_time_read="
				+ meat_collection_run_time_read + ", meat_collection_weighing_run_time_read="
				+ meat_collection_weighing_run_time_read + ", meat_motor_cutoff_in_pct_write="
				+ meat_motor_cutoff_in_pct_write + ", meat_motor_normal_in_pct_write=" + meat_motor_normal_in_pct_write
				+ ", meat_motor_normal_speed_write=" + meat_motor_normal_speed_write
				+ ", meat_motor_inching_speed_write=" + meat_motor_inching_speed_write
				+ ", meat_motor_time_gap_between_normal_and_inch_write="
				+ meat_motor_time_gap_between_normal_and_inch_write + ", meat_motor_time_gap_between_inching_write="
				+ meat_motor_time_gap_between_inching_write + ", meat_motor_inching_time_write="
				+ meat_motor_inching_time_write + "]";
	}

}
