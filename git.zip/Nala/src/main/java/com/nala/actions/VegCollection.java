package com.nala.actions;

public class VegCollection {
	
	private Integer veg_collection_write;
	
	private Integer veg_collection_bin_number_write;
	
	private Integer veg_collection_weight_write;
	
	private Integer veg_collection_read;
	
	private Integer veg_collection_bin_number_read;
	
	private Integer veg_collection_achieved_weight_read;
	
	private Integer veg_collection_run_time_read;
	
	private Integer veg_collection_weighing_run_time_read;
	
	private Integer veg_motor_cutoff_in_pct_write;
	
	private Integer veg_motor_normal_in_pct_write;
	
	private Integer veg_motor_normal_speed_write;
	
	private Integer veg_motor_inching_speed_write;
	
	private Integer veg_motor_time_gap_between_normal_and_inch_write;
	
	private Integer veg_motor_time_gap_between_inching_write;
	
	private Integer veg_motor_inching_time_write;

	public Integer getVeg_collection_write() {
		return veg_collection_write;
	}

	public void setVeg_collection_write(Integer veg_collection_write) {
		this.veg_collection_write = veg_collection_write;
	}

	public Integer getVeg_collection_bin_number_write() {
		return veg_collection_bin_number_write;
	}

	public void setVeg_collection_bin_number_write(Integer veg_collection_bin_number_write) {
		this.veg_collection_bin_number_write = veg_collection_bin_number_write;
	}

	public Integer getVeg_collection_weight_write() {
		return veg_collection_weight_write;
	}

	public void setVeg_collection_weight_write(Integer veg_collection_weight_write) {
		this.veg_collection_weight_write = veg_collection_weight_write;
	}

	public Integer getVeg_collection_read() {
		return veg_collection_read;
	}

	public void setVeg_collection_read(Integer veg_collection_read) {
		this.veg_collection_read = veg_collection_read;
	}

	public Integer getVeg_collection_bin_number_read() {
		return veg_collection_bin_number_read;
	}

	public void setVeg_collection_bin_number_read(Integer veg_collection_bin_number_read) {
		this.veg_collection_bin_number_read = veg_collection_bin_number_read;
	}

	public Integer getVeg_collection_achieved_weight_read() {
		return veg_collection_achieved_weight_read;
	}

	public void setVeg_collection_achieved_weight_read(Integer veg_collection_achieved_weight_read) {
		this.veg_collection_achieved_weight_read = veg_collection_achieved_weight_read;
	}

	public Integer getVeg_collection_run_time_read() {
		return veg_collection_run_time_read;
	}

	public void setVeg_collection_run_time_read(Integer veg_collection_run_time_read) {
		this.veg_collection_run_time_read = veg_collection_run_time_read;
	}

	public Integer getVeg_collection_weighing_run_time_read() {
		return veg_collection_weighing_run_time_read;
	}

	public void setVeg_collection_weighing_run_time_read(Integer veg_collection_weighing_run_time_read) {
		this.veg_collection_weighing_run_time_read = veg_collection_weighing_run_time_read;
	}

	public Integer getVeg_motor_cutoff_in_pct_write() {
		return veg_motor_cutoff_in_pct_write;
	}

	public void setVeg_motor_cutoff_in_pct_write(Integer veg_motor_cutoff_in_pct_write) {
		this.veg_motor_cutoff_in_pct_write = veg_motor_cutoff_in_pct_write;
	}

	public Integer getVeg_motor_normal_in_pct_write() {
		return veg_motor_normal_in_pct_write;
	}

	public void setVeg_motor_normal_in_pct_write(Integer veg_motor_normal_in_pct_write) {
		this.veg_motor_normal_in_pct_write = veg_motor_normal_in_pct_write;
	}

	public Integer getVeg_motor_normal_speed_write() {
		return veg_motor_normal_speed_write;
	}

	public void setVeg_motor_normal_speed_write(Integer veg_motor_normal_speed_write) {
		this.veg_motor_normal_speed_write = veg_motor_normal_speed_write;
	}

	public Integer getVeg_motor_inching_speed_write() {
		return veg_motor_inching_speed_write;
	}

	public void setVeg_motor_inching_speed_write(Integer veg_motor_inching_speed_write) {
		this.veg_motor_inching_speed_write = veg_motor_inching_speed_write;
	}

	public Integer getVeg_motor_time_gap_between_normal_and_inch_write() {
		return veg_motor_time_gap_between_normal_and_inch_write;
	}

	public void setVeg_motor_time_gap_between_normal_and_inch_write(
			Integer veg_motor_time_gap_between_normal_and_inch_write) {
		this.veg_motor_time_gap_between_normal_and_inch_write = veg_motor_time_gap_between_normal_and_inch_write;
	}

	public Integer getVeg_motor_time_gap_between_inching_write() {
		return veg_motor_time_gap_between_inching_write;
	}

	public void setVeg_motor_time_gap_between_inching_write(Integer veg_motor_time_gap_between_inching_write) {
		this.veg_motor_time_gap_between_inching_write = veg_motor_time_gap_between_inching_write;
	}

	public Integer getVeg_motor_inching_time_write() {
		return veg_motor_inching_time_write;
	}

	public void setVeg_motor_inching_time_write(Integer veg_motor_inching_time_write) {
		this.veg_motor_inching_time_write = veg_motor_inching_time_write;
	}

	@Override
	public String toString() {
		return "VegCollection [veg_collection_write=" + veg_collection_write + ", veg_collection_bin_number_write="
				+ veg_collection_bin_number_write + ", veg_collection_weight_write=" + veg_collection_weight_write
				+ ", veg_collection_read=" + veg_collection_read + ", veg_collection_bin_number_read="
				+ veg_collection_bin_number_read + ", veg_collection_achieved_weight_read="
				+ veg_collection_achieved_weight_read + ", veg_collection_run_time_read=" + veg_collection_run_time_read
				+ ", veg_collection_weighing_run_time_read=" + veg_collection_weighing_run_time_read
				+ ", veg_motor_cutoff_in_pct_write=" + veg_motor_cutoff_in_pct_write
				+ ", veg_motor_normal_in_pct_write=" + veg_motor_normal_in_pct_write + ", veg_motor_normal_speed_write="
				+ veg_motor_normal_speed_write + ", veg_motor_inching_speed_write=" + veg_motor_inching_speed_write
				+ ", veg_motor_time_gap_between_normal_and_inch_write="
				+ veg_motor_time_gap_between_normal_and_inch_write + ", veg_motor_time_gap_between_inching_write="
				+ veg_motor_time_gap_between_inching_write + ", veg_motor_inching_time_write="
				+ veg_motor_inching_time_write + "]";
	}


}
