package com.nala.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.Ingredient;

public interface IngredientRepository extends MongoRepository<Ingredient, String> {
	
	 List<Ingredient> findByName(String name);
	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<Ingredient> findIngredientsByRegexpNameAndDescription(String name, String description);
	 
	 @Query("{ 'name' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Ingredient> findIngredientsByRegexpName(String regexp);
	 
	 @Query("{ 'description' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Ingredient> findIngredientsByRegexpDescription(String regexp);

	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'ingredientClassificationType' : { '$regex' : ?1 , $options: 'i'}}, { 'ingredientTypeOfUsage' : { '$regex' : ?2 , $options: 'i'}}, { 'status' : { '$regex' : ?3 , $options: 'i'}}]}")
	Page<Ingredient> search(String ingredientSearchName, String ingredientSearchClassification,	String ingredientSearchTypeOfUsage, String ingredientSearchStatus, Pageable paging);

	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}} ]}")
	Page<Ingredient> search(String ingredientSearchName, Pageable paging);

	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}} , { 'ingredientClassificationType' : { '$regex' : ?1 , $options: 'i'}} ]}")
	Page<Ingredient> search(String ingredientSearchName, String ingredientSearchClassification, Pageable paging);

	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}} , { 'ingredientClassificationType' : { '$regex' : ?1 , $options: 'i'}} , { 'ingredientTypeOfUsage' : { '$regex' : ?2 , $options: 'i'}} ]}")
	Page<Ingredient> search(String ingredientSearchName, String ingredientSearchClassification,
			String ingredientSearchTypeOfUsage, Pageable paging);

	 

}
