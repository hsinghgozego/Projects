package com.nala.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.DispenseSettings;

public interface DispenseSettingsRepository extends MongoRepository<DispenseSettings, String>  {

	
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}} ]}")
	Page<DispenseSettings> search(String dispenseSettingsStart, Pageable paging);

	
	
	
	
}
