package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoOrderSteps;

public interface DemoOrderStepsRepository extends MongoRepository<DemoOrderSteps, String> {

	@Query("{'orderId' : {$eq : ?0}}")
	List<DemoOrderSteps> getByOrderId(Integer orderId);

}
