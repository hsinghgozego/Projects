package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.Flame;

public interface FlameLevelRepository extends MongoRepository<Flame, String>{
	
	 List<Flame> findByPercentage(String percentage);
	 
	 @Query("{'$or' : [{ 'percentage' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<Flame> findFlameLevelByQuery(int percentage, String description);
	 
	 @Query("{'$and' : [{ 'percentage' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<Flame> findFlameLevelByRegexpPercentageAndDescription(int percentage, String description);
	 
	 @Query("{ 'percentage' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Flame> findFlameLevelByRegexpPercentage(String regexp);
	 
	 @Query("{ 'description' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Flame> findFlameLevelByRegexpDescription(String regexp);
}
