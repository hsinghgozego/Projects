package com.nala.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.RecipeDetail;


public interface RecipeDetailRepository  extends MongoRepository<RecipeDetail, String>{

	 @Query("{ 'recipe.id' : ?0 }")
	 List<RecipeDetail> findByRecipeId(String id);
	 
	 @Query("{ 'recipe.id' : ?0 }")
	 List<RecipeDetail> findByRecipeObjectId(ObjectId id);
	
	
	 @Query("{ 'recipe.name' : { $regex: ?0 } }")
	 List<RecipeDetail> findRecipeDetailRegexpRecipeName(String regexp);
	
	 @Query("{'$or' : [{ 'stepNo' : { '$regex' : ?0 , $options: 'i'}}, { 'recipe.name' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<RecipeDetail> findRecipeDetailByQuery(int stepNo, String recipeName);

	 @Query("{'$and' : [{ 'stepNo' : { '$regex' : ?0 , $options: 'i'}}, { 'recipe.name' : { '$regex' : ?1 , $options: 'i'}}]}")
	 RecipeDetail findByStepNoAndRecipeName(int stepNo, String recipeName);
	 
	 @Query("{ 'recipe.name' : ?0 }")
	 List<RecipeDetail> findRecipeDetailsByRecipeName(String name);
	 
	 @Query("{'stepNo' : ?0 , 'recipe.id' : ?1}")
	 RecipeDetail findByStepNoAndRecipeId(int stepNo,String id);
	 
}
