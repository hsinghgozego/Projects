package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.CoilAddress;

public interface CoilAddressRepository extends MongoRepository<CoilAddress, String> {
	
	 @Query("{'$and' : [{ 'coilType' : { '$regex' : ?0 , $options: 'i'}}, { 'burner' : { '$regex' : ?1 , $options: 'i'}}, { 'coilName' : { '$regex' : ?2 , $options: 'i'}}]}")
	 List<CoilAddress> findByActionNameAndTypeOfAction(String coilType, String burner, String coilName);

	 @Query("{'coilType' : {$eq : ?0}}")
	 List<CoilAddress> findByCoilType(String coilType);

	 @Query("{'coilTypeId' : {$eq : ?0}}")
	 List<CoilAddress> findByCoilTypeId(Integer coilTypeId);
	 
	 @Query("{'coilName' : {$eq : ?0}}")
	 CoilAddress findByCoilName(String coilName);
	 
}
