package com.nala.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.Fryer;

public interface FryerRepository extends MongoRepository<Fryer, String> {

	@Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'status' : { '$regex' : ?1 , $options: 'i'}}]}")
	Page<Fryer> search(String name, String status, Pageable pageable);
	
	 List<Fryer> findByName(String name);
	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<Fryer> findFryersByRegexpNameAndDescription(String name, String description);
	 
	 @Query("{ 'name' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Fryer> findFryersByRegexpName(String regexp);
	 
	 @Query("{ 'description' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Fryer> findFryersByRegexpDescription(String regexp);
	 
}
