package com.nala.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.Bowl;

public interface BowlRepository extends MongoRepository<Bowl, String> {
	
	 List<Bowl> findByName(String name);
	
	 @Query("{ 'name' : { $regex: ?0 } }")
	 List<Bowl> findBowlRegexpName(String regexp);
	
	 @Query("{'$or' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<Bowl> findBowlyQuery(String name, String description);
	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<Bowl> findBowlByRegexpNameAndDescription(String name, String description);
	 
	 @Query("{ 'name' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Bowl> findBowlByRegexpName(String regexp);
	 
	 @Query("{ 'description' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<Bowl> findBowlByRegexpDescription(String regexp);
	 
	 @Query("{ 'bowlType.name' : ?0 }")
	 List<Bowl> findBowlsByBowlTypeName(String name);	

	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'bowlType.name' : { '$regex' : ?1 , $options: 'i'}}, { 'status' : { '$regex' : ?2 , $options: 'i'}}]}")
	 Page<Bowl> search(String bowlSearchName, String bowlSearchTypeName, String bowlSearchStatus, Pageable pageable);

}
