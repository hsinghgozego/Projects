package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoRacks;

public interface DemoRacksRepository extends MongoRepository<DemoRacks, String> {

	@Query("{'rackId' : {$eq : ?0}}")
	DemoRacks findByRackId(Integer rackId);

	@Query("{ 'rackName' : {$eq : ?0} }")
	DemoRacks findByRackName(String rackName);

	@Query("{ 'type' : {$eq : ?0} }")
	List<DemoRacks> findByType(String type);

}
