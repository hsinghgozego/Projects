package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoBurners;

public interface DemoBurnersRepository extends MongoRepository<DemoBurners, String> {

	@Query("{'burnerNo' : {$eq : ?0}}")
	DemoBurners getByBurnerNo(Integer burnerNo);

	@Query("{'name' : {$eq : ?0}}")
	DemoBurners getByBurnerName(String name);

	@Query("{'stationId' : {$eq : ?0}}")
	List<DemoBurners> findByStationId(Integer stationId);

	@Query("{'robotId' : {$eq : ?0}}")
	List<DemoBurners> findByRobotId(Integer robotId);

	@Query("{'isFree' : {$eq : ?0}}")
	List<DemoBurners> getFreeBurners(Boolean isFree);

	@Query("{'$and' : [{ 'isActive' : {$eq : ?0}}, { 'isFree' : {$eq : ?1}}]}")
	List<DemoBurners> getActiveFreeBurners(Boolean isActive, Boolean isFree);

	@Query("{'isActive' : {$eq : ?0}}")
	List<DemoBurners> getByBurnerStatus(Boolean isActive);

}
