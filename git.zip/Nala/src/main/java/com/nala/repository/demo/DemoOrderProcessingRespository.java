package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoOrderProcessing;

public interface DemoOrderProcessingRespository extends MongoRepository<DemoOrderProcessing, String> {

	@Query("{'orderId' : {$eq : ?0}}")
	List<DemoOrderProcessing> findByOrderId(Integer orderId);

	@Query("{'recipeId' : {$eq : ?0}}")
	List<DemoOrderProcessing> findByRecipeId(Integer recipeId);

	@Query("{'burnerId' : {$eq : ?0}}")
	List<DemoOrderProcessing> findByBurnerId(Integer burnerId);

	@Query("{'status' : {$eq : ?0}}")
	List<DemoOrderProcessing> getByStatus(Integer status);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'status' : {$eq : ?1}}]}")
	List<DemoOrderProcessing> findByOrderIdAndStatus(Integer orderId, Integer status);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeId' : {$eq : ?1}}]}")
	List<DemoOrderProcessing> findByOrderIdRecipeId(Integer orderId, Integer recipeId);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeId' : {$eq : ?1}}, { 'status' : {$eq : ?2}}]}")
	List<DemoOrderProcessing> findByOrderIdRecipeIdAndStatus(Integer orderId, Integer recipeId, Integer status);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeName' : {$eq : ?1}}]}")
	List<DemoOrderProcessing> findByOrderIdAndRecipeName(Integer orderId, String recipeName);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeName' : {$eq : ?1}}, { 'status' : {$eq : ?2}}]}")
	List<DemoOrderProcessing> findByOrderIdRecipeNameAndStatus(Integer orderId, String recipeName, Integer status);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeId' : {$eq : ?1}}, { 'burnerId' : {$eq : ?2}}, { 'status' : {$eq : ?3}}]}")
	List<DemoOrderProcessing> findByOrderIdRecipeIdBurnerIdAndStatus(Integer orderId, Integer recipeId, Integer burnerId, Integer status);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeId' : {$eq : ?1}}, { 'burnerId' : {$eq : ?2}}, { 'groupId' : {$eq : ?3}}, { 'status' : {$eq : ?4}}]}")
	List<DemoOrderProcessing> findByOrderIdRecipeIdBurnerIdGroupIdAndStatus(Integer orderId, Integer recipeId, Integer burnerId, Integer groupId, Integer status);

	@Query("{'$and' : [{ 'orderId' : {$eq : ?0}}, { 'recipeId' : {$eq : ?1}}, { 'burnerId' : {$eq : ?2}}, { 'recipeDetailsId' : {$eq : ?3}}, { 'status' : {$eq : ?4}}]}")
	List<DemoOrderProcessing> findByOrderIdRecipeIdBurnerIdRecipeDetailsIdAndStatus(Integer orderId, Integer recipeId, Integer burnerId, Integer recipeDetailsId, Integer status);
	
	

}
