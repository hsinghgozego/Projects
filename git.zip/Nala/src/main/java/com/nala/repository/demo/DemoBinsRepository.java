package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoBins;

public interface DemoBinsRepository extends MongoRepository<DemoBins, String> {

	@Query("{'binUniqueId' : {$eq : ?0}}")
	DemoBins findByBinUniqueId(Integer binUniqueId);

	@Query("{'binNo' : {$eq : ?0}}")
	DemoBins findByBinNo(Integer binNo);

	@Query("{'$and' : [{ 'section' : {$eq : ?0}}, { 'binNo' : {$eq : ?1}}]}")
	DemoBins findBySectionAndBinNo(String section, Integer binNo);

	@Query("{'$and' : [{ 'sectionName' : {$eq : ?0}}, { 'binNo' : {$eq : ?1}}]}, { 'rackId' : {$eq : ?2}}]}")
	DemoBins findBySectionBinNoAndRackId(String section, Integer binNo, Integer rackId);

	@Query("{ 'ingredientId' : {$eq : ?0} }")
	List<DemoBins> findByIngredientId(Integer ingredientId);

	@Query("{'$and' : [{ 'ingredientId' : {$eq : ?0}}, { 'rackId' : {$eq : ?1}}]}")
	List<DemoBins> findByIngredientIdRackId(Integer ingredientId, Integer rackId);

	@Query("{ 'ingredientName' : {$eq : ?0} }")
	List<DemoBins> findByIngredientName(String ingredientName);

	@Query("{ 'section' : {$eq : ?0} }")
	List<DemoBins> findBySection(String section);

	@Query("{ 'rack' : {$eq : ?0} }")
	List<DemoBins> findByRack(Integer rack);

	@Query("{ 'classificationType' : {$eq : ?0} }")
	List<DemoBins> findByClassificationType(String classificationType);

}
