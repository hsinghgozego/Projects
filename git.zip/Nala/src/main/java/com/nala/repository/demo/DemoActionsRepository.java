package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoActions;

public interface DemoActionsRepository extends MongoRepository<DemoActions, String> {

	@Query("{'actionId' : {$eq : ?0}}")
	DemoActions findByActionId(int actionId);

	@Query("{'actionName' : {$eq : ?0}}")
	DemoActions findByActionName(String name);

	@Query("{'isRackDependent' : {$eq : ?0}}")
	List<DemoActions> findByRackDependency(boolean isRackDependent);

	@Query("{'isRoboDependent' : {$eq : ?0}}")
	List<DemoActions> findByRoboDependency(boolean isRoboDependent);

	@Query("{'isBurnerDependent' : {$eq : ?0}}")
	List<DemoActions> findByBurnerDependency(boolean isBurnerDependent);

	@Query("{'isHoldingStationDependent' : {$eq : ?0}}")
	List<DemoActions> findByHoldingStationDependency(boolean isHoldingStationDependent);

	@Query("{'isServingStationDependent' : {$eq : ?0}}")
	List<DemoActions> findByServingStationDependency(boolean isServingStationDependent);

	@Query("{'isFryerDependent' : {$eq : ?0}}")
	List<DemoActions> findByFryerDependency(boolean isFryerDependent);

	@Query("{'isLiquidDependent' : {$eq : ?0}}")
	List<DemoActions> findByLiquidDependency(boolean isLiquidDependent);

	@Query("{'isSectionDependent' : {$eq : ?0}}")
	List<DemoActions> findBySectionDependency(boolean isSectionDependent);

	@Query("{'isUtensilDependent' : {$eq : ?0}}")
	List<DemoActions> findByUtensilDependency(boolean isUtensilDependent);

	@Query("{'isSpatulaDependent' : {$eq : ?0}}")
	List<DemoActions> findBySpatulaDependency(boolean isSpatulaDependent);

	@Query("{'isStirDependent' : {$eq : ?0}}")
	List<DemoActions> findByStirDependency(boolean isStirDependent);

	@Query("{'isTossDependent' : {$eq : ?0}}")
	List<DemoActions> findByTossDependency(boolean isTossDependent);

	@Query("{'isBowlDependent' : {$eq : ?0}}")
	List<DemoActions> findByBowlDependency(boolean isBowlDependent);

	@Query("{'isActive' : {$eq : ?0}}")
	List<DemoActions> findByStatus(boolean isActive);

}
