package com.nala.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.StirType;

public interface StirTypeRepository extends MongoRepository<StirType, String>{
	
	 List<StirType> findByName(String name);
	 
	 @Query("{'$or' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<StirType> findStirTypeByQuery(String name, String description);
	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<StirType> findStirTypeByRegexpNameAndDescription(String name, String description);
	 
	 @Query("{ 'name' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<StirType> findStirTypeByRegexpName(String regexp);
	 
	 @Query("{ 'description' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<StirType> findStirTypeByRegexpDescription(String regexp);

	@Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'stirTypeId' : { '$regex' : ?1 , $options: 'i'}}]}")
	Page<StirType> search(String stirTypeSearchName, String stirTypeSearchTypeId, Pageable paging);
	 
}
