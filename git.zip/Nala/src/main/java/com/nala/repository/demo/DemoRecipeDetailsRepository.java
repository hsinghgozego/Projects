package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoRecipeDetails;

public interface DemoRecipeDetailsRepository extends MongoRepository<DemoRecipeDetails, String> {

	 @Query("{'recipeId' : {$eq : ?0}}")
	 List<DemoRecipeDetails> findByRecipeId(Integer recipeId);
	 
	 @Query("{ 'recipeName' : {$eq : ?0} }")
	 List<DemoRecipeDetails> findByRecipeName(String recipeName);

	 @Query("{'$and' : [{ 'recipeId' : {$eq : ?0}}, { 'groupId' : {$eq : ?1}}]}")
	 List<DemoRecipeDetails> findByRecipeIdAnd(Integer recipeId, Integer groupId);

	 @Query("{'recipeDetailsId' : {$eq : ?0}}")
	 DemoRecipeDetails findByRecipeDetailsId(Integer recipeDetailsId);

}
