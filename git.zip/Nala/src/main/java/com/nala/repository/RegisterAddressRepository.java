package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.RegisterAddress;

public interface RegisterAddressRepository extends MongoRepository<RegisterAddress, String> {
	
	 @Query("{'actionId' : {$eq : ?0}}")
	 List<RegisterAddress> findByActionId(Integer actionId);
	
	 @Query("{'actionName' : {$eq : ?0}}")
	 List<RegisterAddress> findByActionName(String actionName);

	 @Query("{'$and' : [{ 'actionId' : {$eq : ?0}}, { 'typeOfAction' : {$eq : ?1}}]}")
	 RegisterAddress findByActionIdTypeOfAction(Integer actionId, String typeOfAction);
	
	 @Query("{'$and' : [{ 'actionName' : {$eq : ?0}}, { 'operationType' : {$eq : ?1}}]}")
	 List<RegisterAddress> findByActionNameAndOperationType(String actionName, Integer operationType);
	
	 @Query("{'$and' : [{ 'actionName' : { '$regex' : ?0 , $options: 'i'}}, { 'typeOfAction' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<RegisterAddress> findByActionNameAndTypeOfAction(String actionName, String typeOfAction);
	 
	 @Query("{'$and' : [{'actionName' : {$eq : ?0}}, {'typeOfAction' : {$eq : ?1}}]}")
	 RegisterAddress findUniqueByActionNameAndTypeOfAction(String actionName, String typeOfAction);
	 
	 @Query("{'$and' : [{'actionId' : {$eq : ?0}}, {'typeOfAction' : {$eq : ?1}}]}")
	 RegisterAddress findUniqueByActionIdAndTypeOfAction(Integer actionId, String typeOfAction);

}
