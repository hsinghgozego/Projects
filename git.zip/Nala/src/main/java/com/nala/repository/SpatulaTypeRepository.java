package com.nala.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.SpatulaType;

public interface SpatulaTypeRepository extends MongoRepository<SpatulaType, String> {
	
	 List<SpatulaType> findByName(String name);
	 
	 @Query("{'$or' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<SpatulaType> findSpatulaTypeByQuery(String name, String description);
	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'description' : { '$regex' : ?1 , $options: 'i'}}]}")
	 List<SpatulaType> findSpatulaTypeByRegexpNameAndDescription(String name, String description);
	 
	 @Query("{ 'name' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<SpatulaType> findSpatulaTypeByRegexpName(String regexp);
	 
	 @Query("{ 'description' : { '$regex' : ?0 , $options: 'i'}} ")
	 List<SpatulaType> findSpatulaTypeByRegexpDescription(String regexp);
	 
	 @Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'spatulaTypeUniqueId' : { '$regex' : ?1 , $options: 'i'}}, { 'status' : { '$regex' : ?2 , $options: 'i'}}]}") 
	 Page<SpatulaType> search(String spatulaTypeSearchName, String spatulaTypeSearchTypeId, String spatulaTypeSearchStatus, Pageable paging);

}
