package com.nala.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.User;

public interface UserRepository extends MongoRepository<User, String> {

	@Query("{ 'ssoId' : ?0 }")
	User findUsersBySSOId(String ssoId);

}
