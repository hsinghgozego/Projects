package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoRecipes;

public interface DemoRecipesRepository extends MongoRepository<DemoRecipes, String> {

	 @Query("{'isActive' : {$eq : ?0}}")
	List<DemoRecipes> getRecipesByActiveStatus(boolean isActive);

	 @Query("{'recipeId' : {$eq : ?0}}")
	List<DemoRecipes> getByRecipeId(Integer recipeId);

	 @Query("{'$and' : [{ 'recipeId' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}]}")
	DemoRecipes getByRecipeIdAndQty(Integer recipeId, Integer qty);

	 @Query("{'$and' : [{ 'recipeId' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}, { 'isActive' : {$eq : ?2}}]}")
	DemoRecipes getByRecipeIdQtyAndStatus(Integer recipeId, Integer qty, boolean isActive);

	 @Query("{'recipeName' : {$eq : ?0}}")
	List<DemoRecipes> getByRecipeName(String recipeName);

	 @Query("{'$and' : [{ 'recipeName' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}]}")
	DemoRecipes getByRecipeNameAndQty(String recipeName, Integer qty);

	 @Query("{'$and' : [{ 'recipeName' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}, { 'isActive' : {$eq : ?2}}]}")
	DemoRecipes getByRecipeNameQtyAndStatus(String recipeName, Integer qty, boolean isActive);

}
