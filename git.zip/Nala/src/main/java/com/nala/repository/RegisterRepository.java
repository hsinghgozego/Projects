package com.nala.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nala.model.Register;

public interface RegisterRepository extends MongoRepository<Register, String>{
	List<Register> findByRegisterName(String registerName);
}
