package com.nala.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.ActionDependency;

public interface ActionDependencyRepository extends MongoRepository<ActionDependency, String> {

	@Query("{'actionId' : {$eq : ?0}}")
	ActionDependency getByActionId(Integer actionId);

	@Query("{'actionName' : {$eq : ?0}}")
	ActionDependency getByActionName(String actionName);

}
