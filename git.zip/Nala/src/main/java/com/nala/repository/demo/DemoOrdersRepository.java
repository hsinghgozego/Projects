package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoOrders;

public interface DemoOrdersRepository extends MongoRepository<DemoOrders, String> {

	@Query("{'orderId' : {$eq : ?0}}")
	DemoOrders getByOrderId(Integer orderId);

	@Query("{'isActive' : {$eq : ?0}}")
	List<DemoOrders> getByActive(boolean isActive);

	@Query("{'status' : {$eq : ?0}}")
	List<DemoOrders> getByStatus(String status);

	@Query("{'recipeId' : {$eq : ?0}}")
	List<DemoOrders> getByRecipeId(Integer recipeId);

	@Query("{'$and' : [{ 'recipeId' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}]}")
	List<DemoOrders> getByRecipeIdAndQty(Integer recipeId, Integer qty);

	@Query("{'$and' : [{ 'recipeId' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}, { 'isActive' : {$eq : ?2}}]}")
	List<DemoOrders> getByRecipeIdQtyAndStatus(Integer recipeId, Integer qty, boolean isActive);

	@Query("{'recipeName' : {$eq : ?0}}")
	List<DemoOrders> getByName(String recipeName);

	@Query("{'$and' : [{ 'recipeName' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}]}")
	List<DemoOrders> getByNameAndQty(String recipeName, Integer qty);

	@Query("{'$and' : [{ 'recipeName' : {$eq : ?0}}, { 'qty' : {$eq : ?1}}, { 'isActive' : {$eq : ?2}}]}")
	List<DemoOrders> getByNameQtyAndStatus(String recipeName, Integer qty, boolean isActive);

	@Query("{'$and' : [{ 'recipeName' : { '$regex' : ?0 , $options: 'i'}},  { 'status' : { '$regex' : ?1 , $options: 'i'}}]}")
	Page<DemoOrders> search(String name, String status, Pageable pageable);

}
