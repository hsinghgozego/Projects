package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.DemoIngredients;
public interface DemoIngredientsRepository extends MongoRepository<DemoIngredients, String> {

	 @Query("{'ingredientId' : {$eq : ?0}}")
	 DemoIngredients findByIngredientId(Integer ingredientId);
	 
	 @Query("{ 'name' : {$eq : ?0} }")
	 DemoIngredients findByName(String name);

	 @Query("{ 'section' : {$eq : ?0} }")
	 List<DemoIngredients> findBySection(String section);

	 @Query("{ 'classificationType' : {$eq : ?0} }")
	 List<DemoIngredients> findByClassificationType(String classificationType);

}
