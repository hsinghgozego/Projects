package com.nala.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.Section;

public interface SectionRepository extends MongoRepository<Section, String>{
	
	@Query("{'$and' : [{ 'name' : { '$regex' : ?0 , $options: 'i'}}, { 'status' : { '$regex' : ?1 , $options: 'i'}}]}")
	Page<Section> search(String name, String status, Pageable pageable);

}
