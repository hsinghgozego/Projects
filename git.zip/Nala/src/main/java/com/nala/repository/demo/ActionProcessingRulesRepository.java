package com.nala.repository.demo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.nala.model.demo.ActionProcessingRules;

public interface ActionProcessingRulesRepository extends MongoRepository<ActionProcessingRules, String> {

	@Query("{'actionId' : {$eq : ?0}}")
	List<ActionProcessingRules> getByActionId(Integer actionId);

	@Query("{'actionName' : {$eq : ?0}}")
	List<ActionProcessingRules> getByActionName(String actionName);

	@Query("{'uniqueNo' : {$eq : ?0}}")
	ActionProcessingRules getByUniqueNo(Integer uniqueNo);
	
	@Query("{$or : [{'actionId' : {$eq : ?0}}, {'burnerNo' : {$eq : ?1}}, {'rackOrLiquid' : {$eq : ?2}}, {'sectionId' : {$eq : ?3}}]}")
	ActionProcessingRules getByActionIdBurnerNoRackOrLiquidAndSectionId(Integer actionId, Integer burnerNo, Integer rackOrLiquid, Integer sectionId);

	@Query("{'burnerNo' : {$eq : ?0}}")
	List<ActionProcessingRules> getByBurnerNo(Integer burnerNo);

	@Query("{'rackOrLiquid' : {$eq : ?0}}")
	List<ActionProcessingRules> getByRackOrLiquid(Integer rackOrLiquid);
	
	@Query("{$and : [{'actionId' : {$eq : ?0}}, {'burnerNo' : {$eq : ?1}}, {'rackOrLiquid' : {$eq : ?2}}]}")
	ActionProcessingRules getByActionIdBurnerNoRackOrLiquid(Integer actionId, Integer burnerNo, Integer rackOrLiquid);
	
	@Query("{$or : [{'actionId' : {$eq : ?0}}, {'burnerNo' : {$eq : ?1}}, {'rackOrLiquid' : {$eq : ?2}}]}")
	List<ActionProcessingRules> searchByActionIdBurnerNoRackOrLiquid(Integer actionId, Integer burnerNo, Integer rackOrLiquid);


}
