package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Flame;
import com.nala.model.User;
import com.nala.repository.FlameLevelRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class FlameController {

	private static final Logger logger = LoggerFactory.getLogger(FlameController.class);

	@Autowired
	FlameLevelRepository flameLevelRepository;

	@RequestMapping("/listFlameLevels")
	public ModelAndView listRecipeTyes() {
		Iterable<Flame> flameLevelList = flameLevelRepository.findAll();
		return new ModelAndView("/admin/flame_level_list", "flameLevelList", flameLevelList);
	}

	@RequestMapping(value = { "/searchFlameLevel" }, method = RequestMethod.GET)
	public ModelAndView searchFlameLevel(@RequestParam(value = "precentage", required = true) String percentage,
			@RequestParam(value = "description", required = true) String description) {
		logger.info("searchFlameLevel percentage: " + percentage + ", description: " + description);
		List<Flame> flameLevelList = null;
		if ((StringUtils.isNotBlank(percentage) && StringUtils.isNotEmpty(percentage))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			flameLevelList = flameLevelRepository
					.findFlameLevelByRegexpPercentageAndDescription(Integer.parseInt(percentage), description);
		} else if (StringUtils.isNotBlank(percentage) && StringUtils.isNotEmpty(percentage)) {
			flameLevelList = flameLevelRepository.findFlameLevelByRegexpPercentage(percentage);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			flameLevelList = flameLevelRepository.findFlameLevelByRegexpDescription(description);
		}
		return new ModelAndView("/admin/flame_level_list", "flameLevelList", flameLevelList);
	}

	@RequestMapping(value = "/saveFlameLevel", method = RequestMethod.POST)
	public String saveFlameLevel(@SessionAttribute("loggedInUser") User loggedInUser,
			@ModelAttribute("flameLevel") Flame flameLevel, BindingResult result) {
		logger.info("saveFlameLevel: " + flameLevel.toString());
		List<Flame> flameLevelList = flameLevelRepository.findByPercentage(flameLevel.getPercentage());
		if (flameLevelList.size() > 0) {
			logger.info("Error Flamel Level name already exists: " + flameLevel.getPercentage());
		} else {
			flameLevel.setCreatedBy(loggedInUser.getSsoId());
			flameLevel.setLastUpdatedBy(loggedInUser.getSsoId());
			flameLevel.setCreatedDateTime(new Date());
			flameLevel.setLastUpdatedDateTime(new Date());
			flameLevelRepository.save(flameLevel);
		}
		return "redirect:/admin/listFlameLevels";
	}

	@RequestMapping("/addFlameLevel")
	public ModelAndView addFlameLevel() {
		return new ModelAndView("new_flame_level", "command", new Flame());
	}

	@RequestMapping(value = { "/editFlameLevel" }, method = RequestMethod.GET)
	public ModelAndView editFlameLevel(@RequestParam(value = "id", required = true) String id) {
		logger.info("editFlameLevel id: " + id);
		Optional<Flame> flameLevelOpt = flameLevelRepository.findById(id);
		ModelAndView model = new ModelAndView();
		if (flameLevelOpt.isPresent()) {
			model.addObject("flameLevel", flameLevelOpt.get());
		} else {
			logger.info("Flamel Level not Found with the Given Id");
		}
		model.addObject("command", new Flame());
		model.setViewName("/admin/edit_flame_level");
		return model;
	}

	@RequestMapping(value = "/updateFlameLevel", method = RequestMethod.POST)
	public String updateFlameLevel(@SessionAttribute("loggedInUser") User loggedInUser,
			@ModelAttribute("flameLevel") Flame flameLevel, BindingResult result) {
		logger.info("updateFlameLevel: " + flameLevel.toString());
		Flame dbFlameLevel = null;
		Optional<Flame> flameLevelOpt = flameLevelRepository.findById(flameLevel.getId().toString());
		if (flameLevelOpt.isPresent()) {
			dbFlameLevel = flameLevelOpt.get();
			dbFlameLevel.setPercentage(flameLevel.getPercentage());
			dbFlameLevel.setDescription(flameLevel.getDescription());
			dbFlameLevel.setSequence(flameLevel.getSequence());
			dbFlameLevel.setLastUpdatedBy(loggedInUser.getSsoId());
			dbFlameLevel.setLastUpdatedDateTime(new Date());
			flameLevelRepository.save(dbFlameLevel);
		} else {
			logger.info("Unable to update Flamel Level");
		}
		return "redirect:/admin/listFlameLevels";
	}

}
