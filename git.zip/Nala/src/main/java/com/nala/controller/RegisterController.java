package com.nala.controller;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.enums.ActionEnum;
import com.nala.enums.BurnerEnum;
import com.nala.enums.RegisterEnum;
import com.nala.model.RegisterAddress;
import com.nala.model.RegisterAddressForm;
import com.nala.repository.RegisterAddressRepository;

import de.re.easymodbus.modbusclient.ModbusClient;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RegisterController {

	private static final Logger logger = LoggerFactory.getLogger(RegisterController.class);

	@Autowired
	RegisterAddressRepository registerAddressRepository;

	@RequestMapping("/openRegisterInfo")
	public ModelAndView openRegisterInfo() {
		ModelAndView model = new ModelAndView();
		model.addObject("urlPage", "openRegisterInfo");
		model.addObject("command", new RegisterAddressForm());
		model.setViewName("/admin/register_check");
		return model;
	}

	@RequestMapping(value = "/writeRegsiters", method = RequestMethod.POST)
	public ModelAndView writeRegsiters(@ModelAttribute("registerAddressForm") RegisterAddressForm form,
			BindingResult result) {
		HashMap<Integer, Integer> registerUpdateDetails = new HashMap<>();
		try {
			logger.info("writeRegsiters: " + form.toString());
			ModbusClient modbusClient = new ModbusClient("192.168.9.17", 502);
			modbusClient.Connect();

			// UTENSIL_PICK Action
			if (form.getActionName().equals(ActionEnum.UTENSIL_PICK.label)) {

				// UTENSIL_PICK_WRITE
				RegisterAddress utensilPick = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.UTENSIL_PICK_WRITE.label);
				if (utensilPick != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilPick.getBurner1Register(), 1);
						registerUpdateDetails.put(utensilPick.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(utensilPick.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilPick.getBurner2Register(), 1);
						registerUpdateDetails.put(utensilPick.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(utensilPick.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilPick.getBurner3Register(), 1);
						registerUpdateDetails.put(utensilPick.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(utensilPick.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilPick.getBurner4Register(), 1);
						registerUpdateDetails.put(utensilPick.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(utensilPick.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: UTENSIL_PICK_WRITE *******************");
				}

				// UTENSIL_TYPE_WRITE
				RegisterAddress utensilTypeWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.UTENSIL_TYPE_WRITE.label);
				if (utensilTypeWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilTypeWrite.getBurner1Register(), 1);
						registerUpdateDetails.put(utensilTypeWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilTypeWrite.getBurner2Register(), 1);
						registerUpdateDetails.put(utensilTypeWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilTypeWrite.getBurner3Register(), 1);
						registerUpdateDetails.put(utensilTypeWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(utensilTypeWrite.getBurner4Register(), 1);
						registerUpdateDetails.put(utensilTypeWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: UTENSIL_TYPE_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// SPATULA_PICK Action
			else if (form.getActionName().equals(ActionEnum.SPATULA_PICK.label)) {

				// SPATULA_PICK_WRITE
				RegisterAddress spatulaPick = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPATULA_PICK_WRITE.label);
				if (spatulaPick != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaPick.getBurner1Register(), 2);
						registerUpdateDetails.put(spatulaPick.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spatulaPick.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaPick.getBurner2Register(), 2);
						registerUpdateDetails.put(spatulaPick.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spatulaPick.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaPick.getBurner3Register(), 2);
						registerUpdateDetails.put(spatulaPick.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spatulaPick.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaPick.getBurner4Register(), 2);
						registerUpdateDetails.put(spatulaPick.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spatulaPick.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPATULA_PICK_WRITE *******************");
				}

				// SPATULA_TYPE_WRITE
				RegisterAddress spatulaTypeWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPATULA_TYPE_WRITE.label);
				if (spatulaTypeWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaTypeWrite.getBurner1Register(), 1);
						registerUpdateDetails.put(spatulaTypeWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaTypeWrite.getBurner2Register(), 1);
						registerUpdateDetails.put(spatulaTypeWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaTypeWrite.getBurner3Register(), 1);
						registerUpdateDetails.put(spatulaTypeWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spatulaTypeWrite.getBurner4Register(), 1);
						registerUpdateDetails.put(spatulaTypeWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPATULA_TYPE_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// VEG_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.VEG_COLLECTION.label)) {

				// VEG_COLLECTION_WRITE
				RegisterAddress veggColletionWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_COLLECTION_WRITE.label);
				if (veggColletionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWrite.getBurner1Register(), 3);
						registerUpdateDetails.put(veggColletionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWrite.getBurner2Register(), 3);
						registerUpdateDetails.put(veggColletionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWrite.getBurner3Register(), 3);
						registerUpdateDetails.put(veggColletionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWrite.getBurner4Register(), 3);
						registerUpdateDetails.put(veggColletionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_COLLECTION_WRITE *******************");
				}

				// VEG_COLLECTION_BIN_NUMBER_WRITE
				RegisterAddress veggColletionBinNumberWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_COLLECTION_BIN_NUMBER_WRITE.label);
				if (veggColletionBinNumberWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionBinNumberWrite.getBurner1Register(),
								form.getBin());
						registerUpdateDetails.put(veggColletionBinNumberWrite.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggColletionBinNumberWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionBinNumberWrite.getBurner2Register(),
								form.getBin());
						registerUpdateDetails.put(veggColletionBinNumberWrite.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggColletionBinNumberWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionBinNumberWrite.getBurner3Register(),
								form.getBin());
						registerUpdateDetails.put(veggColletionBinNumberWrite.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggColletionBinNumberWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionBinNumberWrite.getBurner4Register(),
								form.getBin());
						registerUpdateDetails.put(veggColletionBinNumberWrite.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggColletionBinNumberWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: VEG_COLLECTION_BIN_NUMBER_WRITE *******************");
				}

				// VEG_COLLECTION_WEIGHT_WRITE
				RegisterAddress veggColletionWeight = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_COLLECTION_WEIGHT_WRITE.label);
				if (veggColletionWeight != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWeight.getBurner1Register(), form.getQty());
						registerUpdateDetails.put(veggColletionWeight.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWeight.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWeight.getBurner2Register(), form.getQty());
						registerUpdateDetails.put(veggColletionWeight.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWeight.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWeight.getBurner3Register(), form.getQty());
						registerUpdateDetails.put(veggColletionWeight.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWeight.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggColletionWeight.getBurner4Register(), form.getQty());
						registerUpdateDetails.put(veggColletionWeight.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggColletionWeight.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_COLLECTION_WEIGHT_WRITE *******************");
				}

				// VEG_MOTOR_CUTOFF_IN_PCT_WRITE
				RegisterAddress veggMotorCutoffInPct = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label);
				if (veggMotorCutoffInPct != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorCutoffInPct.getBurner1Register(), 95);
						registerUpdateDetails.put(veggMotorCutoffInPct.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggMotorCutoffInPct.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorCutoffInPct.getBurner2Register(), 95);
						registerUpdateDetails.put(veggMotorCutoffInPct.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggMotorCutoffInPct.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorCutoffInPct.getBurner3Register(), 95);
						registerUpdateDetails.put(veggMotorCutoffInPct.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggMotorCutoffInPct.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorCutoffInPct.getBurner4Register(), 95);
						registerUpdateDetails.put(veggMotorCutoffInPct.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggMotorCutoffInPct.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_MOTOR_CUTOFF_IN_PCT_WRITE *******************");
				}

				// VEG_MOTOR_NORMAL_IN_PCT_WRITE
				RegisterAddress veggMotorNormalOperationInPct = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_MOTOR_NORMAL_IN_PCT_WRITE.label);
				if (veggMotorNormalOperationInPct != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationInPct.getBurner1Register(), 10);
						registerUpdateDetails.put(veggMotorNormalOperationInPct.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationInPct.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationInPct.getBurner2Register(), 10);
						registerUpdateDetails.put(veggMotorNormalOperationInPct.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationInPct.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationInPct.getBurner3Register(), 10);
						registerUpdateDetails.put(veggMotorNormalOperationInPct.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationInPct.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationInPct.getBurner4Register(), 10);
						registerUpdateDetails.put(veggMotorNormalOperationInPct.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationInPct.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_MOTOR_NORMAL_IN_PCT_WRITE *******************");
				}

				// VEG_MOTOR_NORMAL_SPEED_WRITE
				RegisterAddress veggMotorNormalOperationSpeed = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_MOTOR_NORMAL_SPEED_WRITE.label);
				if (veggMotorNormalOperationSpeed != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationSpeed.getBurner1Register(), 20);
						registerUpdateDetails.put(veggMotorNormalOperationSpeed.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationSpeed.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationSpeed.getBurner2Register(), 20);
						registerUpdateDetails.put(veggMotorNormalOperationSpeed.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationSpeed.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationSpeed.getBurner3Register(), 20);
						registerUpdateDetails.put(veggMotorNormalOperationSpeed.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationSpeed.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorNormalOperationSpeed.getBurner4Register(), 20);
						registerUpdateDetails.put(veggMotorNormalOperationSpeed.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggMotorNormalOperationSpeed.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_MOTOR_NORMAL_SPEED_WRITE *******************");
				}

				// VEG_MOTOR_INCHING_SPEED_WRITE
				RegisterAddress veggMotorInchingOperationSpeed = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_MOTOR_INCHING_SPEED_WRITE.label);
				if (veggMotorInchingOperationSpeed != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingOperationSpeed.getBurner1Register(), 20);
						registerUpdateDetails.put(veggMotorInchingOperationSpeed.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggMotorInchingOperationSpeed.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingOperationSpeed.getBurner2Register(), 20);
						registerUpdateDetails.put(veggMotorInchingOperationSpeed.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggMotorInchingOperationSpeed.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingOperationSpeed.getBurner3Register(), 20);
						registerUpdateDetails.put(veggMotorInchingOperationSpeed.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggMotorInchingOperationSpeed.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingOperationSpeed.getBurner4Register(), 20);
						registerUpdateDetails.put(veggMotorInchingOperationSpeed.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggMotorInchingOperationSpeed.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_MOTOR_INCHING_SPEED_WRITE *******************");
				}

				// VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE
				RegisterAddress veggMotorTimeGapBetweenNormalAndInchOperation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label);
				if (veggMotorTimeGapBetweenNormalAndInchOperation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								veggMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(), 15);
						registerUpdateDetails
								.put(veggMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												veggMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								veggMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(), 15);
						registerUpdateDetails
								.put(veggMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												veggMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								veggMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(), 15);
						registerUpdateDetails
								.put(veggMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												veggMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								veggMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(), 15);
						registerUpdateDetails
								.put(veggMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												veggMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE *******************");
				}

				// VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE
				RegisterAddress veggMotorTimeGapBetweenInching = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label);
				if (veggMotorTimeGapBetweenInching != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorTimeGapBetweenInching.getBurner1Register(), 7);
						registerUpdateDetails.put(veggMotorTimeGapBetweenInching.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggMotorTimeGapBetweenInching.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorTimeGapBetweenInching.getBurner2Register(), 7);
						registerUpdateDetails.put(veggMotorTimeGapBetweenInching.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggMotorTimeGapBetweenInching.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorTimeGapBetweenInching.getBurner3Register(), 7);
						registerUpdateDetails.put(veggMotorTimeGapBetweenInching.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggMotorTimeGapBetweenInching.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorTimeGapBetweenInching.getBurner4Register(), 7);
						registerUpdateDetails.put(veggMotorTimeGapBetweenInching.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggMotorTimeGapBetweenInching.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE *******************");
				}

				// VEG_MOTOR_INCHING_TIME_WRITE
				RegisterAddress veggMotorInchingTime = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_MOTOR_INCHING_TIME_WRITE.label);
				if (veggMotorInchingTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingTime.getBurner1Register(), 2);
						registerUpdateDetails.put(veggMotorInchingTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggMotorInchingTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingTime.getBurner2Register(), 2);
						registerUpdateDetails.put(veggMotorInchingTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggMotorInchingTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingTime.getBurner3Register(), 2);
						registerUpdateDetails.put(veggMotorInchingTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggMotorInchingTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggMotorInchingTime.getBurner4Register(), 2);
						registerUpdateDetails.put(veggMotorInchingTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggMotorInchingTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_MOTOR_INCHING_TIME_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// SPICE_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.SPICE_COLLECTION.label)) {

				// SPICE_COLLECTION_WRITE
				RegisterAddress spiceCollectionWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_COLLECTION_WRITE.label);
				if (spiceCollectionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWrite.getBurner1Register(), 4);
						registerUpdateDetails.put(spiceCollectionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWrite.getBurner2Register(), 4);
						registerUpdateDetails.put(spiceCollectionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWrite.getBurner3Register(), 4);
						registerUpdateDetails.put(spiceCollectionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWrite.getBurner4Register(), 4);
						registerUpdateDetails.put(spiceCollectionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_COLLECTION_WRITE *******************");
				}

				// SPICE_COLLECTION_BIN_NUMBER_WRITE
				RegisterAddress spiceCollectionBinNumberWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_COLLECTION_BIN_NUMBER_WRITE.label);
				if (spiceCollectionBinNumberWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionBinNumberWrite.getBurner1Register(),
								form.getBin());
						registerUpdateDetails.put(spiceCollectionBinNumberWrite.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionBinNumberWrite.getBurner2Register(),
								form.getBin());
						registerUpdateDetails.put(spiceCollectionBinNumberWrite.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionBinNumberWrite.getBurner3Register(),
								form.getBin());
						registerUpdateDetails.put(spiceCollectionBinNumberWrite.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionBinNumberWrite.getBurner4Register(),
								form.getBin());
						registerUpdateDetails.put(spiceCollectionBinNumberWrite.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: SPICE_COLLECTION_BIN_NUMBER_WRITE *******************");
				}

				// SPICE_COLLECTION_WEIGHT_WRITE
				RegisterAddress spiceCollectionWeight = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_COLLECTION_WEIGHT_WRITE.label);
				if (spiceCollectionWeight != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWeight.getBurner1Register(), form.getQty());
						registerUpdateDetails.put(spiceCollectionWeight.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWeight.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWeight.getBurner2Register(), form.getQty());
						registerUpdateDetails.put(spiceCollectionWeight.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWeight.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWeight.getBurner3Register(), form.getQty());
						registerUpdateDetails.put(spiceCollectionWeight.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWeight.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceCollectionWeight.getBurner4Register(), form.getQty());
						registerUpdateDetails.put(spiceCollectionWeight.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionWeight.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_COLLECTION_WEIGHT_WRITE *******************");
				}

				// SPICE_MOTOR_CUTOFF_IN_PCT_WRITE
				RegisterAddress spiceMotorCutoffInPct = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label);
				if (spiceMotorCutoffInPct != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorCutoffInPct.getBurner1Register(), 80);
						registerUpdateDetails.put(spiceMotorCutoffInPct.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorCutoffInPct.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorCutoffInPct.getBurner2Register(), 80);
						registerUpdateDetails.put(spiceMotorCutoffInPct.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorCutoffInPct.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorCutoffInPct.getBurner3Register(), 80);
						registerUpdateDetails.put(spiceMotorCutoffInPct.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorCutoffInPct.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorCutoffInPct.getBurner4Register(), 80);
						registerUpdateDetails.put(spiceMotorCutoffInPct.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorCutoffInPct.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: SPICE_MOTOR_CUTOFF_IN_PCT_WRITE *******************");
				}

				// SPICE_MOTOR_NORMAL_IN_PCT_WRITE
				RegisterAddress spiceMotorNormalOperationInPct = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_MOTOR_NORMAL_IN_PCT_WRITE.label);
				if (spiceMotorNormalOperationInPct != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationInPct.getBurner1Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationInPct.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationInPct.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationInPct.getBurner2Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationInPct.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationInPct.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationInPct.getBurner3Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationInPct.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationInPct.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationInPct.getBurner4Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationInPct.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationInPct.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: SPICE_MOTOR_NORMAL_IN_PCT_WRITE *******************");
				}

				// SPICE_MOTOR_NORMAL_SPEED_WRITE
				RegisterAddress spiceMotorNormalOperationSpeed = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_MOTOR_NORMAL_SPEED_WRITE.label);
				if (spiceMotorNormalOperationSpeed != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationSpeed.getBurner1Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationSpeed.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationSpeed.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationSpeed.getBurner2Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationSpeed.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationSpeed.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationSpeed.getBurner3Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationSpeed.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationSpeed.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorNormalOperationSpeed.getBurner4Register(), 20);
						registerUpdateDetails.put(spiceMotorNormalOperationSpeed.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorNormalOperationSpeed.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_MOTOR_NORMAL_SPEED_WRITE *******************");
				}

				// SPICE_MOTOR_INCHING_SPEED_WRITE
				RegisterAddress spiceMotorInchingOperationSpeed = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_MOTOR_INCHING_SPEED_WRITE.label);
				if (spiceMotorInchingOperationSpeed != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingOperationSpeed.getBurner1Register(), 20);
						registerUpdateDetails.put(spiceMotorInchingOperationSpeed.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorInchingOperationSpeed.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingOperationSpeed.getBurner2Register(), 20);
						registerUpdateDetails.put(spiceMotorInchingOperationSpeed.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorInchingOperationSpeed.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingOperationSpeed.getBurner3Register(), 20);
						registerUpdateDetails.put(spiceMotorInchingOperationSpeed.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorInchingOperationSpeed.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingOperationSpeed.getBurner4Register(), 20);
						registerUpdateDetails.put(spiceMotorInchingOperationSpeed.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorInchingOperationSpeed.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: SPICE_MOTOR_INCHING_SPEED_WRITE *******************");
				}

				// SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE
				RegisterAddress spiceMotorTimeGapBetweenNormalAndInchOperation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label);
				if (spiceMotorTimeGapBetweenNormalAndInchOperation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(), 20);
						registerUpdateDetails
								.put(spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(), 20);
						registerUpdateDetails
								.put(spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(), 20);
						registerUpdateDetails
								.put(spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(), 20);
						registerUpdateDetails
								.put(spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												spiceMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE *******************");
				}

				// SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE
				RegisterAddress spiceMotorTimeGapBetweeInching = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label);
				if (spiceMotorTimeGapBetweeInching != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorTimeGapBetweeInching.getBurner1Register(), 10);
						registerUpdateDetails.put(spiceMotorTimeGapBetweeInching.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorTimeGapBetweeInching.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorTimeGapBetweeInching.getBurner2Register(), 10);
						registerUpdateDetails.put(spiceMotorTimeGapBetweeInching.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorTimeGapBetweeInching.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorTimeGapBetweeInching.getBurner3Register(), 10);
						registerUpdateDetails.put(spiceMotorTimeGapBetweeInching.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorTimeGapBetweeInching.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorTimeGapBetweeInching.getBurner4Register(), 10);
						registerUpdateDetails.put(spiceMotorTimeGapBetweeInching.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceMotorTimeGapBetweeInching.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE *******************");
				}

				// SPICE_MOTOR_INCHING_TIME_WRITE
				RegisterAddress spiceMotorInchingTime = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_MOTOR_INCHING_TIME_WRITE.label);
				if (spiceMotorInchingTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingTime.getBurner1Register(), 4);
						registerUpdateDetails.put(spiceMotorInchingTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorInchingTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingTime.getBurner2Register(), 4);
						registerUpdateDetails.put(spiceMotorInchingTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorInchingTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingTime.getBurner3Register(), 4);
						registerUpdateDetails.put(spiceMotorInchingTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorInchingTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spiceMotorInchingTime.getBurner4Register(), 4);
						registerUpdateDetails.put(spiceMotorInchingTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spiceMotorInchingTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_MOTOR_INCHING_TIME_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// MEAT_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.MEAT_COLLECTION.label)) {

				// MEAT_COLLECTION_WRITE
				RegisterAddress meatCollectionWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_COLLECTION_WRITE.label);
				if (meatCollectionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWrite.getBurner1Register(), 5);
						registerUpdateDetails.put(meatCollectionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWrite.getBurner2Register(), 5);
						registerUpdateDetails.put(meatCollectionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWrite.getBurner3Register(), 5);
						registerUpdateDetails.put(meatCollectionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWrite.getBurner4Register(), 5);
						registerUpdateDetails.put(meatCollectionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_COLLECTION_WRITE *******************");
				}

				// MEAT_COLLECTION_BIN_NUMBER_WRITE
				RegisterAddress meatCollectionBinNumberWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_COLLECTION_BIN_NUMBER_WRITE.label);
				if (meatCollectionBinNumberWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionBinNumberWrite.getBurner1Register(),
								form.getBin());
						registerUpdateDetails.put(meatCollectionBinNumberWrite.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionBinNumberWrite.getBurner2Register(),
								form.getBin());
						registerUpdateDetails.put(meatCollectionBinNumberWrite.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionBinNumberWrite.getBurner3Register(),
								form.getBin());
						registerUpdateDetails.put(meatCollectionBinNumberWrite.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionBinNumberWrite.getBurner4Register(),
								form.getBin());
						registerUpdateDetails.put(meatCollectionBinNumberWrite.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: MEAT_COLLECTION_BIN_NUMBER_WRITE *******************");
				}

				// MEAT_COLLECTION_WEIGHT_WRITE
				RegisterAddress meatCollectionWeight = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_COLLECTION_WEIGHT_WRITE.label);
				if (meatCollectionWeight != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWeight.getBurner1Register(), form.getQty());
						registerUpdateDetails.put(meatCollectionWeight.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWeight.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWeight.getBurner2Register(), form.getQty());
						registerUpdateDetails.put(meatCollectionWeight.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWeight.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWeight.getBurner3Register(), form.getQty());
						registerUpdateDetails.put(meatCollectionWeight.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWeight.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatCollectionWeight.getBurner4Register(), form.getQty());
						registerUpdateDetails.put(meatCollectionWeight.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionWeight.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_COLLECTION_WEIGHT_WRITE *******************");
				}

				// MEAT_MOTOR_CUTOFF_IN_PCT_WRITE
				RegisterAddress meatMotorCutoffInPct = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label);
				if (meatMotorCutoffInPct != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorCutoffInPct.getBurner1Register(), 95);
						registerUpdateDetails.put(meatMotorCutoffInPct.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatMotorCutoffInPct.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorCutoffInPct.getBurner2Register(), 95);
						registerUpdateDetails.put(meatMotorCutoffInPct.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatMotorCutoffInPct.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorCutoffInPct.getBurner3Register(), 95);
						registerUpdateDetails.put(meatMotorCutoffInPct.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatMotorCutoffInPct.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorCutoffInPct.getBurner4Register(), 95);
						registerUpdateDetails.put(meatMotorCutoffInPct.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatMotorCutoffInPct.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_MOTOR_CUTOFF_IN_PCT_WRITE *******************");
				}

				// MEAT_MOTOR_NORMAL_IN_PCT_WRITE
				RegisterAddress meatMotorNormalOperationInPct = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_MOTOR_NORMAL_IN_PCT_WRITE.label);
				if (meatMotorNormalOperationInPct != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationInPct.getBurner1Register(), 90);
						registerUpdateDetails.put(meatMotorNormalOperationInPct.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationInPct.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationInPct.getBurner2Register(), 90);
						registerUpdateDetails.put(meatMotorNormalOperationInPct.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationInPct.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationInPct.getBurner3Register(), 90);
						registerUpdateDetails.put(meatMotorNormalOperationInPct.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationInPct.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationInPct.getBurner4Register(), 90);
						registerUpdateDetails.put(meatMotorNormalOperationInPct.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationInPct.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_MOTOR_NORMAL_IN_PCT_WRITE *******************");
				}

				// MEAT_MOTOR_NORMAL_SPEED_WRITE
				RegisterAddress meatMotorNormalOperationSpeed = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_MOTOR_NORMAL_SPEED_WRITE.label);
				if (meatMotorNormalOperationSpeed != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationSpeed.getBurner1Register(), 20);
						registerUpdateDetails.put(meatMotorNormalOperationSpeed.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationSpeed.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationSpeed.getBurner2Register(), 20);
						registerUpdateDetails.put(meatMotorNormalOperationSpeed.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationSpeed.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationSpeed.getBurner3Register(), 20);
						registerUpdateDetails.put(meatMotorNormalOperationSpeed.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationSpeed.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorNormalOperationSpeed.getBurner4Register(), 20);
						registerUpdateDetails.put(meatMotorNormalOperationSpeed.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatMotorNormalOperationSpeed.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_MOTOR_NORMAL_SPEED_WRITE *******************");
				}

				// MEAT_MOTOR_INCHING_SPEED_WRITE
				RegisterAddress meatMotorInchingOperationSpeed = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_MOTOR_INCHING_SPEED_WRITE.label);
				if (meatMotorInchingOperationSpeed != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingOperationSpeed.getBurner1Register(), 20);
						registerUpdateDetails.put(meatMotorInchingOperationSpeed.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatMotorInchingOperationSpeed.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingOperationSpeed.getBurner2Register(), 20);
						registerUpdateDetails.put(meatMotorInchingOperationSpeed.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatMotorInchingOperationSpeed.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingOperationSpeed.getBurner3Register(), 20);
						registerUpdateDetails.put(meatMotorInchingOperationSpeed.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatMotorInchingOperationSpeed.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingOperationSpeed.getBurner4Register(), 20);
						registerUpdateDetails.put(meatMotorInchingOperationSpeed.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatMotorInchingOperationSpeed.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_MOTOR_INCHING_SPEED_WRITE *******************");
				}

				// MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE
				RegisterAddress meatMotorTimeGapBetweenNormalAndInchOperation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label);
				if (meatMotorTimeGapBetweenNormalAndInchOperation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								meatMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(), 15);
						registerUpdateDetails
								.put(meatMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												meatMotorTimeGapBetweenNormalAndInchOperation.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								meatMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(), 15);
						registerUpdateDetails
								.put(meatMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												meatMotorTimeGapBetweenNormalAndInchOperation.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								meatMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(), 15);
						registerUpdateDetails
								.put(meatMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												meatMotorTimeGapBetweenNormalAndInchOperation.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(
								meatMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(), 15);
						registerUpdateDetails
								.put(meatMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												meatMotorTimeGapBetweenNormalAndInchOperation.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE *******************");
				}

				// MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE
				RegisterAddress meatMotorTimeGapBetweenInching = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label);
				if (meatMotorTimeGapBetweenInching != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorTimeGapBetweenInching.getBurner1Register(), 5);
						registerUpdateDetails.put(meatMotorTimeGapBetweenInching.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatMotorTimeGapBetweenInching.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorTimeGapBetweenInching.getBurner2Register(), 5);
						registerUpdateDetails.put(meatMotorTimeGapBetweenInching.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatMotorTimeGapBetweenInching.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorTimeGapBetweenInching.getBurner3Register(), 5);
						registerUpdateDetails.put(meatMotorTimeGapBetweenInching.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatMotorTimeGapBetweenInching.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorTimeGapBetweenInching.getBurner4Register(), 5);
						registerUpdateDetails.put(meatMotorTimeGapBetweenInching.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatMotorTimeGapBetweenInching.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE *******************");
				}

				// MEAT_MOTOR_INCHING_TIME_WRITE
				RegisterAddress meatMotorInchingTime = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_MOTOR_INCHING_TIME_WRITE.label);
				if (meatMotorInchingTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingTime.getBurner1Register(), 2);
						registerUpdateDetails.put(meatMotorInchingTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatMotorInchingTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingTime.getBurner2Register(), 2);
						registerUpdateDetails.put(meatMotorInchingTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatMotorInchingTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingTime.getBurner3Register(), 2);
						registerUpdateDetails.put(meatMotorInchingTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatMotorInchingTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatMotorInchingTime.getBurner4Register(), 2);
						registerUpdateDetails.put(meatMotorInchingTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatMotorInchingTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_MOTOR_INCHING_TIME_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// VEG_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.VEG_PICKUP.label)) {

				// VEG_PICKUP_WRITE
				RegisterAddress veggPickupWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_PICKUP_WRITE.label);
				if (veggPickupWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupWrite.getBurner1Register(), 6);
						registerUpdateDetails.put(veggPickupWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggPickupWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupWrite.getBurner2Register(), 6);
						registerUpdateDetails.put(veggPickupWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggPickupWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupWrite.getBurner3Register(), 6);
						registerUpdateDetails.put(veggPickupWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggPickupWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupWrite.getBurner4Register(), 6);
						registerUpdateDetails.put(veggPickupWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggPickupWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_PICKUP_WRITE *******************");
				}

				// VEG_PICKUP_LOCATION_WRITE
				RegisterAddress veggPickupLocationWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_PICKUP_LOCATION_WRITE.label);
				if (veggPickupLocationWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupLocationWrite.getBurner1Register(), 1);
						registerUpdateDetails.put(veggPickupLocationWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupLocationWrite.getBurner2Register(), 1);
						registerUpdateDetails.put(veggPickupLocationWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupLocationWrite.getBurner3Register(), 1);
						registerUpdateDetails.put(veggPickupLocationWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(veggPickupLocationWrite.getBurner4Register(), 1);
						registerUpdateDetails.put(veggPickupLocationWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_PICKUP_LOCATION_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// SPICE_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.SPICE_PICKUP.label)) {

				// SPICE_PICKUP_WRITE
				RegisterAddress spicePickupWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_PICKUP_WRITE.label);
				if (spicePickupWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupWrite.getBurner1Register(), 7);
						registerUpdateDetails.put(spicePickupWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spicePickupWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupWrite.getBurner2Register(), 7);
						registerUpdateDetails.put(spicePickupWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spicePickupWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupWrite.getBurner3Register(), 7);
						registerUpdateDetails.put(spicePickupWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spicePickupWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupWrite.getBurner4Register(), 7);
						registerUpdateDetails.put(spicePickupWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spicePickupWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_PICKUP_WRITE *******************");
				}

				// SPICE_PICKUP_LOCATION_WRITE
				RegisterAddress spicePickupLocationWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_PICKUP_LOCATION_WRITE.label);
				if (spicePickupLocationWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupLocationWrite.getBurner1Register(), 1);
						registerUpdateDetails.put(spicePickupLocationWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupLocationWrite.getBurner2Register(), 1);
						registerUpdateDetails.put(spicePickupLocationWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupLocationWrite.getBurner3Register(), 1);
						registerUpdateDetails.put(spicePickupLocationWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(spicePickupLocationWrite.getBurner4Register(), 1);
						registerUpdateDetails.put(spicePickupLocationWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_PICKUP_LOCATION_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// MEAT_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.MEAT_PICKUP.label)) {

				// MEAT_PICKUP_WRITE
				RegisterAddress meatPickupWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_PICKUP_WRITE.label);
				if (meatPickupWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupWrite.getBurner1Register(), 8);
						registerUpdateDetails.put(meatPickupWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatPickupWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupWrite.getBurner2Register(), 8);
						registerUpdateDetails.put(meatPickupWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatPickupWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupWrite.getBurner3Register(), 8);
						registerUpdateDetails.put(meatPickupWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatPickupWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupWrite.getBurner4Register(), 8);
						registerUpdateDetails.put(meatPickupWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatPickupWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_PICKUP_WRITE *******************");
				}

				// MEAT_PICKUP_LOCATION_WRITE
				RegisterAddress meatPickupLocationWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_PICKUP_LOCATION_WRITE.label);
				if (meatPickupLocationWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupLocationWrite.getBurner1Register(), 2);
						registerUpdateDetails.put(meatPickupLocationWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupLocationWrite.getBurner2Register(), 2);
						registerUpdateDetails.put(meatPickupLocationWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupLocationWrite.getBurner3Register(), 2);
						registerUpdateDetails.put(meatPickupLocationWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(meatPickupLocationWrite.getBurner4Register(), 2);
						registerUpdateDetails.put(meatPickupLocationWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_PICKUP_LOCATION_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// IGNITION Action
			else if (form.getActionName().equals(ActionEnum.IGNITION.label)) {

				// IGNITION_WRITE
				RegisterAddress ignitionWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.IGNITION_WRITE.label);
				if (ignitionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionWrite.getBurner1Register(), 9);
						registerUpdateDetails.put(ignitionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(ignitionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionWrite.getBurner2Register(), 9);
						registerUpdateDetails.put(ignitionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(ignitionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionWrite.getBurner3Register(), 9);
						registerUpdateDetails.put(ignitionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(ignitionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionWrite.getBurner4Register(), 9);
						registerUpdateDetails.put(ignitionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(ignitionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: IGNITION_WRITE *******************");
				}

				// IGNITION_DELAY_TIME_WRITE
				RegisterAddress ignitionDelayTime = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.IGNITION_DELAY_TIME_WRITE.label);
				if (ignitionDelayTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionDelayTime.getBurner1Register(), form.getTime());
						registerUpdateDetails.put(ignitionDelayTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(ignitionDelayTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionDelayTime.getBurner2Register(), form.getTime());
						registerUpdateDetails.put(ignitionDelayTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(ignitionDelayTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionDelayTime.getBurner3Register(), form.getTime());
						registerUpdateDetails.put(ignitionDelayTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(ignitionDelayTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(ignitionDelayTime.getBurner4Register(), form.getTime());
						registerUpdateDetails.put(ignitionDelayTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(ignitionDelayTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: IGNITION_DELAY_TIME_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), form.getFlame());
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), form.getFlame());
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), form.getFlame());
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), form.getFlame());
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// STIRR Action
			else if (form.getActionName().equals(ActionEnum.STIRR.label)) {

				// STIRR_WRITE
				RegisterAddress stirrActionWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.STIRR_WRITE.label);
				if (stirrActionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionWrite.getBurner1Register(), 10);
						registerUpdateDetails.put(stirrActionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(stirrActionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionWrite.getBurner2Register(), 10);
						registerUpdateDetails.put(stirrActionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(stirrActionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionWrite.getBurner3Register(), 10);
						registerUpdateDetails.put(stirrActionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(stirrActionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionWrite.getBurner4Register(), 10);
						registerUpdateDetails.put(stirrActionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(stirrActionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: STIRR_WRITE *******************");
				}

				// STIRR_TYPE_NUMBER_WRITE
				RegisterAddress stirrActionStirTypeNumberWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.STIRR_TYPE_NUMBER_WRITE.label);
				if (stirrActionStirTypeNumberWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionStirTypeNumberWrite.getBurner1Register(), 1);
						registerUpdateDetails.put(stirrActionStirTypeNumberWrite.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionStirTypeNumberWrite.getBurner2Register(), 1);
						registerUpdateDetails.put(stirrActionStirTypeNumberWrite.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionStirTypeNumberWrite.getBurner3Register(), 1);
						registerUpdateDetails.put(stirrActionStirTypeNumberWrite.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionStirTypeNumberWrite.getBurner4Register(), 1);
						registerUpdateDetails.put(stirrActionStirTypeNumberWrite.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: STIRR_TYPE_NUMBER_WRITE *******************");
				}

				// STIRR_TIME_IN_MILLI_SEC_WRITE
				RegisterAddress stirrActionTimeInMilliSec = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.STIRR_TIME_IN_MILLI_SEC_WRITE.label);
				if (stirrActionTimeInMilliSec != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionTimeInMilliSec.getBurner1Register(),
								form.getTime());
						registerUpdateDetails.put(stirrActionTimeInMilliSec.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(stirrActionTimeInMilliSec.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionTimeInMilliSec.getBurner2Register(),
								form.getTime());
						registerUpdateDetails.put(stirrActionTimeInMilliSec.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(stirrActionTimeInMilliSec.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionTimeInMilliSec.getBurner3Register(),
								form.getTime());
						registerUpdateDetails.put(stirrActionTimeInMilliSec.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(stirrActionTimeInMilliSec.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(stirrActionTimeInMilliSec.getBurner4Register(),
								form.getTime());
						registerUpdateDetails.put(stirrActionTimeInMilliSec.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(stirrActionTimeInMilliSec.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: STIRR_TIME_IN_MILLI_SEC_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// TOSS Action
			else if (form.getActionName().equals(ActionEnum.TOSS.label)) {

				// TOSS_WRITE
				RegisterAddress tossActionWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.TOSS_WRITE.label);
				if (tossActionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionWrite.getBurner1Register(), 11);
						registerUpdateDetails.put(tossActionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(tossActionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionWrite.getBurner2Register(), 11);
						registerUpdateDetails.put(tossActionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(tossActionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionWrite.getBurner3Register(), 11);
						registerUpdateDetails.put(tossActionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(tossActionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionWrite.getBurner4Register(), 11);
						registerUpdateDetails.put(tossActionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(tossActionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: TOSS_WRITE *******************");
				}

				// TOSS_TYPE_NUMBER_WRITE
				RegisterAddress tossActionTossTypeNumberWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.TOSS_TYPE_NUMBER_WRITE.label);
				if (tossActionTossTypeNumberWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTossTypeNumberWrite.getBurner1Register(), 1);
						registerUpdateDetails.put(tossActionTossTypeNumberWrite.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTossTypeNumberWrite.getBurner2Register(), 1);
						registerUpdateDetails.put(tossActionTossTypeNumberWrite.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTossTypeNumberWrite.getBurner3Register(), 1);
						registerUpdateDetails.put(tossActionTossTypeNumberWrite.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTossTypeNumberWrite.getBurner4Register(), 1);
						registerUpdateDetails.put(tossActionTossTypeNumberWrite.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: TOSS_TYPE_NUMBER_WRITE *******************");
				}

				// TOSS_TIME_IN_MILLI_SEC_WRITE
				RegisterAddress tossActionTimeInMilliSec = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.TOSS_TIME_IN_MILLI_SEC_WRITE.label);
				if (tossActionTimeInMilliSec != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTimeInMilliSec.getBurner1Register(), form.getTime());
						registerUpdateDetails.put(tossActionTimeInMilliSec.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(tossActionTimeInMilliSec.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTimeInMilliSec.getBurner2Register(), form.getTime());
						registerUpdateDetails.put(tossActionTimeInMilliSec.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(tossActionTimeInMilliSec.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTimeInMilliSec.getBurner3Register(), form.getTime());
						registerUpdateDetails.put(tossActionTimeInMilliSec.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(tossActionTimeInMilliSec.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(tossActionTimeInMilliSec.getBurner4Register(), form.getTime());
						registerUpdateDetails.put(tossActionTimeInMilliSec.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(tossActionTimeInMilliSec.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: TOSS_TIME_IN_MILLI_SEC_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// LIQUID_DISPENSING Action
			else if (form.getActionName().equals(ActionEnum.LIQUID_DISPENSING.label)) {

				// LIQUID_DISPENSING_WRITE
				RegisterAddress liquidDispensing = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.LIQUID_DISPENSING_WRITE.label);
				if (liquidDispensing != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensing.getBurner1Register(), 12);
						registerUpdateDetails.put(liquidDispensing.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensing.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensing.getBurner2Register(), 12);
						registerUpdateDetails.put(liquidDispensing.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensing.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensing.getBurner3Register(), 12);
						registerUpdateDetails.put(liquidDispensing.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensing.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensing.getBurner4Register(), 12);
						registerUpdateDetails.put(liquidDispensing.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensing.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: LIQUID_DISPENSING_WRITE *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE
				RegisterAddress liquidDispensingLiqBinNumber1 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE.label);
				if (liquidDispensingLiqBinNumber1 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber1.getBurner1Register(),
								form.getBin());
						registerUpdateDetails.put(liquidDispensingLiqBinNumber1.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber1.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber1.getBurner2Register(),
								form.getBin());
						registerUpdateDetails.put(liquidDispensingLiqBinNumber1.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber1.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber1.getBurner3Register(),
								form.getBin());
						registerUpdateDetails.put(liquidDispensingLiqBinNumber1.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber1.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber1.getBurner4Register(),
								form.getBin());
						registerUpdateDetails.put(liquidDispensingLiqBinNumber1.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber1.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE*******************");
				}

				// LIQUID_DISPENSING_DELAY_TIME_1
				RegisterAddress liquidDispensingDelayTime1 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_1_WRITE.label);
				if (liquidDispensingDelayTime1 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime1.getBurner1Register(),
								form.getTime());
						registerUpdateDetails.put(liquidDispensingDelayTime1.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime1.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime1.getBurner2Register(),
								form.getTime());
						registerUpdateDetails.put(liquidDispensingDelayTime1.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime1.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime1.getBurner3Register(),
								form.getTime());
						registerUpdateDetails.put(liquidDispensingDelayTime1.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime1.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime1.getBurner4Register(),
								form.getTime());
						registerUpdateDetails.put(liquidDispensingDelayTime1.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime1.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_DELAY_TIME_1_WRITE *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_2
				RegisterAddress liquidDispensingLiqBinNumber2 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_WRITE.label);
				if (liquidDispensingLiqBinNumber2 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber2.getBurner1Register(), 3);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber2.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber2.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber2.getBurner2Register(), 3);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber2.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber2.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber2.getBurner3Register(), 3);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber2.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber2.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber2.getBurner4Register(), 3);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber2.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber2.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_WRITE *******************");
				}

				// LIQUID_DISPENSING_DELAY_TIME_2
				RegisterAddress liquidDispensingDelayTime2 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_2_WRITE.label);
				if (liquidDispensingDelayTime2 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime2.getBurner1Register(), 30);
						registerUpdateDetails.put(liquidDispensingDelayTime2.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime2.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime2.getBurner2Register(), 30);
						registerUpdateDetails.put(liquidDispensingDelayTime2.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime2.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime2.getBurner3Register(), 30);
						registerUpdateDetails.put(liquidDispensingDelayTime2.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime2.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime2.getBurner4Register(), 30);
						registerUpdateDetails.put(liquidDispensingDelayTime2.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime2.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_DELAY_TIME_2_WRITE *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_3
				RegisterAddress liquidDispensingLiqBinNumber3 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_WRITE.label);
				if (liquidDispensingLiqBinNumber3 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber3.getBurner1Register(), 4);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber3.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber3.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber3.getBurner2Register(), 4);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber3.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber3.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber3.getBurner3Register(), 4);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber3.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber3.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber3.getBurner4Register(), 4);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber3.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber3.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_WRITE *******************");
				}

				// LIQUID_DISPENSING_DELAY_TIME_3
				RegisterAddress liquidDispensingDelayTime3 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_3_WRITE.label);
				if (liquidDispensingDelayTime3 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime3.getBurner1Register(), 20);
						registerUpdateDetails.put(liquidDispensingDelayTime3.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime3.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime3.getBurner2Register(), 20);
						registerUpdateDetails.put(liquidDispensingDelayTime3.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime3.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime3.getBurner3Register(), 20);
						registerUpdateDetails.put(liquidDispensingDelayTime3.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime3.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime3.getBurner4Register(), 20);
						registerUpdateDetails.put(liquidDispensingDelayTime3.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime3.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_DELAY_TIME_3_WRITE *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_4
				RegisterAddress liquidDispensingLiqBinNumber4 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_WRITE.label);
				if (liquidDispensingLiqBinNumber4 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber4.getBurner1Register(), 5);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber4.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber4.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber4.getBurner2Register(), 5);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber4.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber4.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber4.getBurner3Register(), 5);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber4.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber4.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber4.getBurner4Register(), 5);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber4.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber4.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_WRITE *******************");
				}

				// LIQUID_DISPENSING_DELAY_TIME_4
				RegisterAddress liquidDispensingDelayTime4 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_4_WRITE.label);
				if (liquidDispensingDelayTime4 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime4.getBurner1Register(), 25);
						registerUpdateDetails.put(liquidDispensingDelayTime4.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime4.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime4.getBurner2Register(), 25);
						registerUpdateDetails.put(liquidDispensingDelayTime4.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime4.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime4.getBurner3Register(), 25);
						registerUpdateDetails.put(liquidDispensingDelayTime4.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime4.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime4.getBurner4Register(), 25);
						registerUpdateDetails.put(liquidDispensingDelayTime4.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime4.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: LIQUID_DISPENSING_DELAY_TIME_4 *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_5
				RegisterAddress liquidDispensingLiqBinNumber5 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_WRITE.label);
				if (liquidDispensingLiqBinNumber5 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber5.getBurner1Register(), 6);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber5.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber5.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber5.getBurner2Register(), 6);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber5.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber5.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber5.getBurner3Register(), 6);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber5.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber5.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingLiqBinNumber5.getBurner4Register(), 6);
						registerUpdateDetails.put(liquidDispensingLiqBinNumber5.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingLiqBinNumber5.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_WRITE *******************");
				}

				// LIQUID_DISPENSING_DELAY_TIME_5
				RegisterAddress liquidDispensingDelayTime5 = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_5_WRITE.label);
				if (liquidDispensingDelayTime5 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime5.getBurner1Register(), 15);
						registerUpdateDetails.put(liquidDispensingDelayTime5.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime5.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime5.getBurner2Register(), 15);
						registerUpdateDetails.put(liquidDispensingDelayTime5.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime5.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime5.getBurner3Register(), 15);
						registerUpdateDetails.put(liquidDispensingDelayTime5.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime5.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(liquidDispensingDelayTime5.getBurner4Register(), 15);
						registerUpdateDetails.put(liquidDispensingDelayTime5.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingDelayTime5.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_DELAY_TIME_5_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}

			// DELAY Action
			else if (form.getActionName().equals(ActionEnum.DELAY.label)) {

				// DELAY_WRITE
				RegisterAddress delayActionWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.DELAY_WRITE.label);
				if (delayActionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionWrite.getBurner1Register(), 13);
						registerUpdateDetails.put(delayActionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(delayActionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionWrite.getBurner2Register(), 13);
						registerUpdateDetails.put(delayActionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(delayActionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionWrite.getBurner3Register(), 13);
						registerUpdateDetails.put(delayActionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(delayActionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionWrite.getBurner4Register(), 13);
						registerUpdateDetails.put(delayActionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(delayActionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: DELAY_WRITE *******************");
				}

				// DELAY_TIME_WRITE
				RegisterAddress delayActionDelayTime = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.DELAY_TIME_WRITE.label);
				if (delayActionDelayTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionDelayTime.getBurner1Register(), form.getTime());
						registerUpdateDetails.put(delayActionDelayTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(delayActionDelayTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionDelayTime.getBurner2Register(), form.getTime());
						registerUpdateDetails.put(delayActionDelayTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(delayActionDelayTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionDelayTime.getBurner3Register(), form.getTime());
						registerUpdateDetails.put(delayActionDelayTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(delayActionDelayTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(delayActionDelayTime.getBurner4Register(), form.getTime());
						registerUpdateDetails.put(delayActionDelayTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(delayActionDelayTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: DELAY_TIME_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// FRYER_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.FRYER_PICKUP.label)) {

				// FRYER_PICKUP_WRITE
				RegisterAddress fryerPickupWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_PICKUP_WRITE.label);
				if (fryerPickupWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupWrite.getBurner1Register(), 14);
						registerUpdateDetails.put(fryerPickupWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupWrite.getBurner2Register(), 14);
						registerUpdateDetails.put(fryerPickupWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupWrite.getBurner3Register(), 14);
						registerUpdateDetails.put(fryerPickupWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupWrite.getBurner4Register(), 14);
						registerUpdateDetails.put(fryerPickupWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_PICKUP_WRITE *******************");
				}

				// FRYER_PICKUP_LOCATION_WRITE
				RegisterAddress fryerPickupLocation = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_PICKUP_LOCATION_WRITE.label);
				if (fryerPickupLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupLocation.getBurner1Register(), 2);
						registerUpdateDetails.put(fryerPickupLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupLocation.getBurner2Register(), 2);
						registerUpdateDetails.put(fryerPickupLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupLocation.getBurner3Register(), 2);
						registerUpdateDetails.put(fryerPickupLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupLocation.getBurner4Register(), 2);
						registerUpdateDetails.put(fryerPickupLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_PICKUP_LOCATION_WRITE *******************");
				}

				// FRYER_PICKUP_DROP_LOCATION_WRITE
				RegisterAddress fryerPickupDropLocation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_PICKUP_DROP_LOCATION_WRITE.label);
				if (fryerPickupDropLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupDropLocation.getBurner1Register(), 1);
						registerUpdateDetails.put(fryerPickupDropLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupDropLocation.getBurner2Register(), 1);
						registerUpdateDetails.put(fryerPickupDropLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupDropLocation.getBurner3Register(), 1);
						registerUpdateDetails.put(fryerPickupDropLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupDropLocation.getBurner4Register(), 1);
						registerUpdateDetails.put(fryerPickupDropLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: FRYER_PICKUP_DROP_LOCATION_WRITE *******************");
				}

				// FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE
				RegisterAddress fryerPickupBowlChangeOrWithoutBowlChange = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE.label);
				if (fryerPickupBowlChangeOrWithoutBowlChange != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupBowlChangeOrWithoutBowlChange.getBurner1Register(),
								1);
						registerUpdateDetails.put(fryerPickupBowlChangeOrWithoutBowlChange.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(
										fryerPickupBowlChangeOrWithoutBowlChange.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupBowlChangeOrWithoutBowlChange.getBurner2Register(),
								1);
						registerUpdateDetails.put(fryerPickupBowlChangeOrWithoutBowlChange.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(
										fryerPickupBowlChangeOrWithoutBowlChange.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupBowlChangeOrWithoutBowlChange.getBurner3Register(),
								1);
						registerUpdateDetails.put(fryerPickupBowlChangeOrWithoutBowlChange.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(
										fryerPickupBowlChangeOrWithoutBowlChange.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerPickupBowlChangeOrWithoutBowlChange.getBurner4Register(),
								1);
						registerUpdateDetails.put(fryerPickupBowlChangeOrWithoutBowlChange.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(
										fryerPickupBowlChangeOrWithoutBowlChange.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// FRYER_ACTION Action
			else if (form.getActionName().equals(ActionEnum.FRYER_ACTION.label)) {

				// FRYER_ACTION_WRITE
				RegisterAddress fryerActionWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_ACTION_WRITE.label);
				if (fryerActionWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionWrite.getBurner1Register(), 15);
						registerUpdateDetails.put(fryerActionWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerActionWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionWrite.getBurner2Register(), 15);
						registerUpdateDetails.put(fryerActionWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerActionWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionWrite.getBurner3Register(), 15);
						registerUpdateDetails.put(fryerActionWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerActionWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionWrite.getBurner4Register(), 15);
						registerUpdateDetails.put(fryerActionWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerActionWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_ACTION_WRITE *******************");
				}

				// FRYER_ACTION_POOL_LOCATION_WRITE
				RegisterAddress fryerActionPoolLocation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_ACTION_POOL_LOCATION_WRITE.label);
				if (fryerActionPoolLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionPoolLocation.getBurner1Register(), 1);
						registerUpdateDetails.put(fryerActionPoolLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionPoolLocation.getBurner2Register(), 1);
						registerUpdateDetails.put(fryerActionPoolLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionPoolLocation.getBurner3Register(), 1);
						registerUpdateDetails.put(fryerActionPoolLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionPoolLocation.getBurner4Register(), 1);
						registerUpdateDetails.put(fryerActionPoolLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: FRYER_ACTION_POOL_LOCATION_WRITE *******************");
				}

				// FRYER_ACTION_LIFT_DIP_WRITE
				RegisterAddress fryerActionLiftDip = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_ACTION_LIFT_DIP_WRITE.label);
				if (fryerActionLiftDip != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionLiftDip.getBurner1Register(), form.getTime());
						registerUpdateDetails.put(fryerActionLiftDip.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDip.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionLiftDip.getBurner2Register(), form.getTime());
						registerUpdateDetails.put(fryerActionLiftDip.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDip.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionLiftDip.getBurner3Register(), form.getTime());
						registerUpdateDetails.put(fryerActionLiftDip.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDip.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerActionLiftDip.getBurner4Register(), form.getTime());
						registerUpdateDetails.put(fryerActionLiftDip.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDip.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_ACTION_LIFT_DIP_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// FRYER_SERVE Action
			else if (form.getActionName().equals(ActionEnum.FRYER_SERVE.label)) {

				// FRYER_SERVE_WRITE
				RegisterAddress fryerServeWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_SERVE_WRITE.label);
				if (fryerServeWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeWrite.getBurner1Register(), 16);
						registerUpdateDetails.put(fryerServeWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerServeWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeWrite.getBurner2Register(), 16);
						registerUpdateDetails.put(fryerServeWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerServeWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeWrite.getBurner3Register(), 16);
						registerUpdateDetails.put(fryerServeWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerServeWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeWrite.getBurner4Register(), 16);
						registerUpdateDetails.put(fryerServeWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerServeWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_SERVE_WRITE *******************");
				}

				// FRYER_SERVE_POOL_LOCATION_WRITE
				RegisterAddress fryerServePoolLocation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_SERVE_POOL_LOCATION_WRITE.label);
				if (fryerServePoolLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServePoolLocation.getBurner1Register(), 1);
						registerUpdateDetails.put(fryerServePoolLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerServePoolLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServePoolLocation.getBurner2Register(), 1);
						registerUpdateDetails.put(fryerServePoolLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerServePoolLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServePoolLocation.getBurner3Register(), 1);
						registerUpdateDetails.put(fryerServePoolLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerServePoolLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServePoolLocation.getBurner4Register(), 1);
						registerUpdateDetails.put(fryerServePoolLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerServePoolLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: FRYER_SERVE_POOL_LOCATION_WRITE *******************");
				}

				// FRYER_SERVE_TRANSFER_OR_SERVE_WRITE
				RegisterAddress fryerServeTransferOrServe = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_SERVE_TRANSFER_OR_SERVE_WRITE.label);
				if (fryerServeTransferOrServe != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeTransferOrServe.getBurner1Register(), 1);
						registerUpdateDetails.put(fryerServeTransferOrServe.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServe.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeTransferOrServe.getBurner2Register(), 1);
						registerUpdateDetails.put(fryerServeTransferOrServe.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServe.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeTransferOrServe.getBurner3Register(), 1);
						registerUpdateDetails.put(fryerServeTransferOrServe.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServe.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(fryerServeTransferOrServe.getBurner4Register(), 1);
						registerUpdateDetails.put(fryerServeTransferOrServe.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServe.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: FRYER_SERVE_TRANSFER_OR_SERVE_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			// SERVE Action
			else if (form.getActionName().equals(ActionEnum.SERVE.label)) {

				// SERVE_WRITE
				RegisterAddress serveWrite = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.SERVE_WRITE.label);
				if (serveWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveWrite.getBurner1Register(), 17);
						registerUpdateDetails.put(serveWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(serveWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveWrite.getBurner2Register(), 17);
						registerUpdateDetails.put(serveWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(serveWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveWrite.getBurner3Register(), 17);
						registerUpdateDetails.put(serveWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(serveWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveWrite.getBurner4Register(), 17);
						registerUpdateDetails.put(serveWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(serveWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SERVE_WRITE *******************");
				}

				// SERVE_TYPE_WRITE
				RegisterAddress serveTypeWrite = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SERVE_TYPE_WRITE.label);
				if (serveTypeWrite != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveTypeWrite.getBurner1Register(), 17);
						registerUpdateDetails.put(serveTypeWrite.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(serveTypeWrite.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveTypeWrite.getBurner2Register(), 17);
						registerUpdateDetails.put(serveTypeWrite.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(serveTypeWrite.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveTypeWrite.getBurner3Register(), 17);
						registerUpdateDetails.put(serveTypeWrite.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(serveTypeWrite.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(serveTypeWrite.getBurner4Register(), 17);
						registerUpdateDetails.put(serveTypeWrite.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(serveTypeWrite.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SERVE_TYPE_WRITE *******************");
				}

				// FLAME_LEVEL_WRITE
				RegisterAddress flameSetPoint = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_WRITE.label);
				if (flameSetPoint != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner1Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner2Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner3Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						modbusClient.WriteSingleRegister(flameSetPoint.getBurner4Register(), 1);
						registerUpdateDetails.put(flameSetPoint.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flameSetPoint.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_WRITE *******************");
				}

			}
			modbusClient.Disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		ModelAndView model = new ModelAndView();
		model.addObject("registerUpdateDetails", registerUpdateDetails);
		model.addObject("command", new RegisterAddressForm());
		model.setViewName("/admin/register_check");
		return model;
	}

	@RequestMapping(value = "/readRegsiters", method = RequestMethod.POST)
	public ModelAndView readRegsiters(@ModelAttribute("registerAddressForm") RegisterAddressForm form,
			BindingResult result) {

		HashMap<Integer, Integer> registerReadDetails = new HashMap<>();
		try {
			logger.info("readRegsiters: " + form.toString());
			ModbusClient modbusClient = new ModbusClient("192.168.9.17", 502);
			modbusClient.Connect();

			// UTENSIL_PICK Action
			if (form.getActionName().equals(ActionEnum.UTENSIL_PICK.label)) {

				// UTENSIL_PICK_READ
				RegisterAddress utensilPickRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.UTENSIL_PICK_READ.label);
				if (utensilPickRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(utensilPickRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(utensilPickRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(utensilPickRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(utensilPickRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(utensilPickRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(utensilPickRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(utensilPickRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(utensilPickRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: UTENSIL_PICK_READ *******************");
				}

				// UTENSIL_TYPE_READ
				RegisterAddress utensilTypeRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.UTENSIL_TYPE_READ.label);
				if (utensilTypeRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(utensilTypeRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(utensilTypeRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(utensilTypeRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(utensilTypeRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(utensilTypeRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: UTENSIL_TYPE_READ *******************");
				}

				// UTENSIL_PICK_RUN_TIME_READ
				RegisterAddress utensilPickOperationRunTimeRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.UTENSIL_PICK_RUN_TIME_READ.label);
				if (utensilPickOperationRunTimeRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(utensilPickOperationRunTimeRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(utensilPickOperationRunTimeRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(utensilPickOperationRunTimeRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(utensilPickOperationRunTimeRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(utensilPickOperationRunTimeRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(utensilPickOperationRunTimeRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(utensilPickOperationRunTimeRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(utensilPickOperationRunTimeRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: UTENSIL_PICK_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// SPATULA_PICK Action
			else if (form.getActionName().equals(ActionEnum.SPATULA_PICK.label)) {

				// SPATULA_PICK_READ
				RegisterAddress spatulaPickRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPATULA_PICK_READ.label);
				if (spatulaPickRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spatulaPickRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spatulaPickRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spatulaPickRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spatulaPickRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spatulaPickRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spatulaPickRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spatulaPickRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spatulaPickRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPATULA_PICK_READ *******************");
				}

				// SPATULA_TYPE_READ
				RegisterAddress spatulaTypeRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPATULA_TYPE_READ.label);
				if (spatulaTypeRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spatulaTypeRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spatulaTypeRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spatulaTypeRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spatulaTypeRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spatulaTypeRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPATULA_TYPE_READ *******************");
				}

				// SPATULA_PICK_RUN_TIME_READ
				RegisterAddress spatulaPickOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPATULA_PICK_RUN_TIME_READ.label);
				if (spatulaPickOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spatulaPickOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spatulaPickOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spatulaPickOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spatulaPickOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spatulaPickOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spatulaPickOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spatulaPickOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spatulaPickOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPATULA_PICK_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// VEG_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.VEG_COLLECTION.label)) {

				// VEG_COLLECTION_READ
				RegisterAddress veggCollectionRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_COLLECTION_READ.label);
				if (veggCollectionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggCollectionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggCollectionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggCollectionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggCollectionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggCollectionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggCollectionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggCollectionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggCollectionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_COLLECTION_READ *******************");
				}

				// VEG_COLLECTION_BIN_NUMBER_READ
				RegisterAddress veggCollectionBinNumberRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_COLLECTION_BIN_NUMBER_READ.label);
				if (veggCollectionBinNumberRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggCollectionBinNumberRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionBinNumberRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggCollectionBinNumberRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionBinNumberRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggCollectionBinNumberRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionBinNumberRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggCollectionBinNumberRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionBinNumberRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_COLLECTION_BIN_NUMBER_READ *******************");
				}

				// VEG_COLLECTION_ACHIEVED_WEIGHT_READ
				RegisterAddress veggCollectionAchievedWeight = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_COLLECTION_ACHIEVED_WEIGHT_READ.label);
				if (veggCollectionAchievedWeight != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggCollectionAchievedWeight.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionAchievedWeight.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggCollectionAchievedWeight.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionAchievedWeight.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggCollectionAchievedWeight.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionAchievedWeight.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggCollectionAchievedWeight.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionAchievedWeight.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: VEG_COLLECTION_ACHIEVED_WEIGHT_READ *******************");
				}

				// VEG_COLLECTION_RUN_TIME_READ
				RegisterAddress veggCollectionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_COLLECTION_RUN_TIME_READ.label);
				if (veggCollectionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggCollectionOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggCollectionOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggCollectionOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggCollectionOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggCollectionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_COLLECTION_RUN_TIME_READ *******************");
				}

				// VEG_COLLECTION_WEIGHING_RUN_TIME_READ
				RegisterAddress veggCollectionWeighingOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_COLLECTION_WEIGHING_RUN_TIME_READ.label);
				if (veggCollectionWeighingOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggCollectionWeighingOperationRunTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(
										veggCollectionWeighingOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggCollectionWeighingOperationRunTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(
										veggCollectionWeighingOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggCollectionWeighingOperationRunTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(
										veggCollectionWeighingOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggCollectionWeighingOperationRunTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(
										veggCollectionWeighingOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: VEG_COLLECTION_WEIGHING_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// SPICE_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.SPICE_COLLECTION.label)) {

				// SPICE_COLLECTION_READ
				RegisterAddress spiceCollectionRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_COLLECTION_READ.label);
				if (spiceCollectionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spiceCollectionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spiceCollectionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spiceCollectionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spiceCollectionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spiceCollectionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_COLLECTION_READ *******************");
				}

				// SPICE_COLLECTION_BIN_NUMBER_READ
				RegisterAddress spiceCollectionBinNumberRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_COLLECTION_BIN_NUMBER_READ.label);
				if (spiceCollectionBinNumberRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spiceCollectionBinNumberRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spiceCollectionBinNumberRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spiceCollectionBinNumberRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spiceCollectionBinNumberRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionBinNumberRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: SPICE_COLLECTION_BIN_NUMBER_READ *******************");
				}

				// SPICE_COLLECTION_ACHIEVED_WEIGHT_READ
				RegisterAddress spiceCollectionAchievedWeight = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_COLLECTION_ACHIEVED_WEIGHT_READ.label);
				if (spiceCollectionAchievedWeight != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spiceCollectionAchievedWeight.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionAchievedWeight.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spiceCollectionAchievedWeight.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionAchievedWeight.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spiceCollectionAchievedWeight.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionAchievedWeight.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spiceCollectionAchievedWeight.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionAchievedWeight.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: SPICE_COLLECTION_ACHIEVED_WEIGHT_READ *******************");
				}

				// SPICE_COLLECTION_RUN_TIME_READ
				RegisterAddress spiceCollectionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_COLLECTION_RUN_TIME_READ.label);
				if (spiceCollectionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spiceCollectionOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spiceCollectionOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spiceCollectionOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spiceCollectionOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spiceCollectionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_COLLECTION_RUN_TIME_READ *******************");
				}

				// SPICE_COLLECTION_WEIGHING_RUN_TIME_READ
				RegisterAddress spiceCollectionWeighingOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_COLLECTION_WEIGHING_RUN_TIME_READ.label);
				if (spiceCollectionWeighingOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spiceCollectionWeighingOperationRunTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(
										spiceCollectionWeighingOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spiceCollectionWeighingOperationRunTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(
										spiceCollectionWeighingOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spiceCollectionWeighingOperationRunTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(
										spiceCollectionWeighingOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spiceCollectionWeighingOperationRunTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(
										spiceCollectionWeighingOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: SPICE_COLLECTION_WEIGHING_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// MEAT_COLLECTION Action
			else if (form.getActionName().equals(ActionEnum.MEAT_COLLECTION.label)) {

				// MEAT_COLLECTION_READ
				RegisterAddress meatCollectionRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_COLLECTION_READ.label);
				if (meatCollectionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatCollectionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatCollectionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatCollectionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatCollectionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatCollectionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_COLLECTION_READ *******************");
				}

				// MEAT_COLLECTION_BIN_NUMBER_READ
				RegisterAddress meatCollectionBinNumberRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_COLLECTION_BIN_NUMBER_READ.label);
				if (meatCollectionBinNumberRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatCollectionBinNumberRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatCollectionBinNumberRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatCollectionBinNumberRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatCollectionBinNumberRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionBinNumberRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: MEAT_COLLECTION_BIN_NUMBER_READ *******************");
				}

				// MEAT_COLLECTION_ACHIEVED_WEIGHT_READ
				RegisterAddress meatCollectionAchievedWeight = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_COLLECTION_ACHIEVED_WEIGHT_READ.label);
				if (meatCollectionAchievedWeight != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatCollectionAchievedWeight.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionAchievedWeight.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatCollectionAchievedWeight.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionAchievedWeight.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatCollectionAchievedWeight.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionAchievedWeight.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatCollectionAchievedWeight.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionAchievedWeight.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: MEAT_COLLECTION_ACHIEVED_WEIGHT_READ *******************");
				}

				// MEAT_COLLECTION_RUN_TIME_READ
				RegisterAddress meatCollectionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_COLLECTION_RUN_TIME_READ.label);
				if (meatCollectionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatCollectionOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatCollectionOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatCollectionOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatCollectionOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatCollectionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_COLLECTION_RUN_TIME_READ *******************");
				}

				// MEAT_COLLECTION_WEIGHING_RUN_TIME_READ
				RegisterAddress meatCollectionWeighingOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_COLLECTION_WEIGHING_RUN_TIME_READ.label);
				if (meatCollectionWeighingOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatCollectionWeighingOperationRunTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(
										meatCollectionWeighingOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatCollectionWeighingOperationRunTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(
										meatCollectionWeighingOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatCollectionWeighingOperationRunTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(
										meatCollectionWeighingOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatCollectionWeighingOperationRunTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(
										meatCollectionWeighingOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: MEAT_COLLECTION_WEIGHING_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// VEG_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.VEG_PICKUP.label)) {

				// VEG_PICKUP_READ
				RegisterAddress veggPickupRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.VEG_PICKUP_READ.label);
				if (veggPickupRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggPickupRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggPickupRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggPickupRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggPickupRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggPickupRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggPickupRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggPickupRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggPickupRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_PICKUP_READ *******************");
				}

				// VEG_PICKUP_LOCATION_READ
				RegisterAddress veggPickupLocationRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_PICKUP_LOCATION_READ.label);
				if (veggPickupLocationRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggPickupLocationRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggPickupLocationRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggPickupLocationRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggPickupLocationRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(veggPickupLocationRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_PICKUP_LOCATION_READ *******************");
				}

				// VEG_PICKUP_RUN_TIME_READ
				RegisterAddress veggPickupOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.VEG_PICKUP_RUN_TIME_READ.label);
				if (veggPickupOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(veggPickupOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(veggPickupOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(veggPickupOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(veggPickupOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(veggPickupOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(veggPickupOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(veggPickupOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(veggPickupOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_PICKUP_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// SPICE_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.SPICE_PICKUP.label)) {

				// SPICE_PICKUP_READ
				RegisterAddress spicePickupRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.SPICE_PICKUP_READ.label);
				if (spicePickupRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spicePickupRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spicePickupRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spicePickupRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spicePickupRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spicePickupRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spicePickupRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spicePickupRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spicePickupRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_PICKUP_READ *******************");
				}

				// SPICE_PICKUP_LOCATION_READ
				RegisterAddress spicePickupLocationRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_PICKUP_LOCATION_READ.label);
				if (spicePickupLocationRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spicePickupLocationRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spicePickupLocationRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spicePickupLocationRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spicePickupLocationRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(spicePickupLocationRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: VEG_PICKUP_LOCATION_READ *******************");
				}

				// SPICE_PICKUP_RUN_TIME_READ
				RegisterAddress spicePickupOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SPICE_PICKUP_RUN_TIME_READ.label);
				if (spicePickupOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(spicePickupOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(spicePickupOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(spicePickupOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(spicePickupOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(spicePickupOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(spicePickupOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(spicePickupOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(spicePickupOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SPICE_PICKUP_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// MEAT_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.MEAT_PICKUP.label)) {

				// MEAT_PICKUP_READ
				RegisterAddress meatPickupRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.MEAT_PICKUP_READ.label);
				if (meatPickupRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatPickupRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatPickupRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatPickupRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatPickupRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatPickupRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatPickupRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatPickupRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatPickupRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_PICKUP_READ *******************");
				}

				// MEAT_PICKUP_LOCATION_READ
				RegisterAddress meatPickupLocationRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_PICKUP_LOCATION_READ.label);
				if (meatPickupLocationRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatPickupLocationRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatPickupLocationRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatPickupLocationRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatPickupLocationRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(meatPickupLocationRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_PICKUP_LOCATION_READ *******************");
				}

				// MEAT_PICKUP_RUN_TIME_READ
				RegisterAddress meatPickupOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.MEAT_PICKUP_RUN_TIME_READ.label);
				if (meatPickupOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(meatPickupOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(meatPickupOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(meatPickupOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(meatPickupOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(meatPickupOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(meatPickupOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(meatPickupOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(meatPickupOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: MEAT_PICKUP_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// IGNITION Action
			else if (form.getActionName().equals(ActionEnum.IGNITION.label)) {

				// IGNITION_READ
				RegisterAddress ignitionAction = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.IGNITION_READ.label);
				if (ignitionAction != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(ignitionAction.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(ignitionAction.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(ignitionAction.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(ignitionAction.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(ignitionAction.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(ignitionAction.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(ignitionAction.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(ignitionAction.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: IGNITION_READ *******************");
				}

				// IGNITION_RUN_TIME_READ
				RegisterAddress ignitionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.IGNITION_RUN_TIME_READ.label);
				if (ignitionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(ignitionOperationRunTime.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(ignitionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(ignitionOperationRunTime.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(ignitionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(ignitionOperationRunTime.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(ignitionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(ignitionOperationRunTime.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(ignitionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: IGNITION_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress registerAddress3 = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (registerAddress3 != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(registerAddress3.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(registerAddress3.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(registerAddress3.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(registerAddress3.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(registerAddress3.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(registerAddress3.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(registerAddress3.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(registerAddress3.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// STIRR Action
			else if (form.getActionName().equals(ActionEnum.STIRR.label)) {

				// STIRR_READ
				RegisterAddress stirrActionRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.STIRR_READ.label);
				if (stirrActionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(stirrActionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(stirrActionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(stirrActionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(stirrActionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(stirrActionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(stirrActionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(stirrActionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(stirrActionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: STIRR_READ *******************");
				}

				// STIRR_TYPE_NUMBER_READ
				RegisterAddress stirrActionStirTypeNumberRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.STIRR_TYPE_NUMBER_READ.label);
				if (stirrActionStirTypeNumberRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(stirrActionStirTypeNumberRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(stirrActionStirTypeNumberRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(stirrActionStirTypeNumberRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(stirrActionStirTypeNumberRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(stirrActionStirTypeNumberRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: STIRR_TYPE_NUMBER_READ *******************");
				}

				// STIRR_RUN_TIME_READ
				RegisterAddress stirrActionOpertionRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.STIRR_RUN_TIME_READ.label);
				if (stirrActionOpertionRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(stirrActionOpertionRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(stirrActionOpertionRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(stirrActionOpertionRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(stirrActionOpertionRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(stirrActionOpertionRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(stirrActionOpertionRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(stirrActionOpertionRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(stirrActionOpertionRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: STIRR_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// TOSS Action
			else if (form.getActionName().equals(ActionEnum.TOSS.label)) {

				// TOSS_READ
				RegisterAddress tossActionRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.TOSS_READ.label);
				if (tossActionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(tossActionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(tossActionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(tossActionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(tossActionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(tossActionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(tossActionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(tossActionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(tossActionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: TOSS_READ *******************");
				}

				// TOSS_TYPE_NUMBER_READ
				RegisterAddress tossActionTossTypeNumberRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.TOSS_TYPE_NUMBER_READ.label);
				if (tossActionTossTypeNumberRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(tossActionTossTypeNumberRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(tossActionTossTypeNumberRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(tossActionTossTypeNumberRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(tossActionTossTypeNumberRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(tossActionTossTypeNumberRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: TOSS_TYPE_NUMBER_READ *******************");
				}

				// TOSS_RUN_TIME_READ
				RegisterAddress tossActionOpertionRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.TOSS_RUN_TIME_READ.label);
				if (tossActionOpertionRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(tossActionOpertionRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(tossActionOpertionRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(tossActionOpertionRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(tossActionOpertionRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(tossActionOpertionRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(tossActionOpertionRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(tossActionOpertionRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(tossActionOpertionRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: TOSS_RUN_TIME *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// LIQUID_DISPENSING Action
			else if (form.getActionName().equals(ActionEnum.LIQUID_DISPENSING.label)) {

				// LIQUID_DISPENSING_READ
				RegisterAddress liquidDispensingRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.LIQUID_DISPENSING_READ.label);
				if (liquidDispensingRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(liquidDispensingRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensingRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(liquidDispensingRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensingRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(liquidDispensingRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensingRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(liquidDispensingRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(liquidDispensingRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: LIQUID_DISPENSING_READ *******************");
				}

				// LIQUID_DISPENSING_RUN_TIME_READ
				RegisterAddress liquidDispensingOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_RUN_TIME_READ.label);
				if (liquidDispensingOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(liquidDispensingOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(liquidDispensingOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(liquidDispensingOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(liquidDispensingOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(liquidDispensingOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: LIQUID_DISPENSING_RUN_TIME_READ *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_RUN_TIME_READ
				RegisterAddress liquidDispensingLiqBinNumber1OperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_RUN_TIME_READ.label);
				if (liquidDispensingLiqBinNumber1OperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber1OperationRunTime.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber1OperationRunTime.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber1OperationRunTime.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber1OperationRunTime.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber1OperationRunTime.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber1OperationRunTime.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber1OperationRunTime.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber1OperationRunTime.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_RUN_TIME_READ *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_RUN_TIME_READ
				RegisterAddress liquidDispensingLiqBinNumber2OperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_RUN_TIME_READ.label);
				if (liquidDispensingLiqBinNumber2OperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber2OperationRunTime.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber2OperationRunTime.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber2OperationRunTime.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber2OperationRunTime.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber2OperationRunTime.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber2OperationRunTime.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber2OperationRunTime.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber2OperationRunTime.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_RUN_TIME_READ *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_RUN_TIME_READ
				RegisterAddress liquidDispensingLiqBinNumber3OperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_RUN_TIME_READ.label);
				if (liquidDispensingLiqBinNumber3OperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber3OperationRunTime.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber3OperationRunTime.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber3OperationRunTime.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber3OperationRunTime.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber3OperationRunTime.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber3OperationRunTime.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber3OperationRunTime.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber3OperationRunTime.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_RUN_TIME_READ *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_RUN_TIME_READ
				RegisterAddress liquidDispensingLiqBinNumber4OperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_RUN_TIME_READ.label);
				if (liquidDispensingLiqBinNumber4OperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber4OperationRunTime.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber4OperationRunTime.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber4OperationRunTime.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber4OperationRunTime.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber4OperationRunTime.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber4OperationRunTime.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber4OperationRunTime.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber4OperationRunTime.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_RUN_TIME_READ *******************");
				}

				// LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_RUN_TIME_READ
				RegisterAddress liquidDispensingLiqBinNumber5OperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_RUN_TIME_READ.label);
				if (liquidDispensingLiqBinNumber5OperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber5OperationRunTime.getBurner1Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber5OperationRunTime.getBurner1Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber5OperationRunTime.getBurner2Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber5OperationRunTime.getBurner2Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber5OperationRunTime.getBurner3Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber5OperationRunTime.getBurner3Register(),
												1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails
								.put(liquidDispensingLiqBinNumber5OperationRunTime.getBurner4Register(),
										modbusClient.ReadHoldingRegisters(
												liquidDispensingLiqBinNumber5OperationRunTime.getBurner4Register(),
												1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// DELAY Action
			else if (form.getActionName().equals(ActionEnum.DELAY.label)) {

				// DELAY_READ
				RegisterAddress delayActionRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.DELAY_READ.label);
				if (delayActionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(delayActionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(delayActionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(delayActionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(delayActionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(delayActionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(delayActionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(delayActionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(delayActionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: DELAY_READ *******************");
				}

				// DELAY_RUN_TIME_READ
				RegisterAddress delayActionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.DELAY_RUN_TIME_READ.label);
				if (delayActionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(delayActionOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(delayActionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(delayActionOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(delayActionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(delayActionOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(delayActionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(delayActionOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(delayActionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: DELAY_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// FRYER_PICKUP Action
			else if (form.getActionName().equals(ActionEnum.FRYER_PICKUP.label)) {

				// FRYER_PICKUP_READ
				RegisterAddress fryerPickupRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_PICKUP_READ.label);
				if (fryerPickupRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerPickupRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerPickupRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerPickupRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerPickupRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_PICKUP_READ *******************");
				}

				// FRYER_PICKUP_LOCATION_READ
				RegisterAddress fryerPickupLocation = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_PICKUP_LOCATION_READ.label);
				if (fryerPickupLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerPickupLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerPickupLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerPickupLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerPickupLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_PICKUP_LOCATION_READ *******************");
				}

				// FRYER_PICKUP_DROP_LOCATION_READ
				RegisterAddress fryerPickupDropLocation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_PICKUP_DROP_LOCATION_READ.label);
				if (fryerPickupDropLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerPickupDropLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerPickupDropLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerPickupDropLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerPickupDropLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupDropLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: FRYER_PICKUP_DROP_LOCATION_READ *******************");
				}

				// FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_READ
				RegisterAddress fryerPickupBcWbc = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_READ.label);
				if (fryerPickupBcWbc != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerPickupBcWbc.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupBcWbc.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerPickupBcWbc.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupBcWbc.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerPickupBcWbc.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupBcWbc.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerPickupBcWbc.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerPickupBcWbc.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_READ *******************");
				}

				// FRYER_PICKUP_RUN_TIME_READ
				RegisterAddress fryerPickupOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_PICKUP_RUN_TIME_READ.label);
				if (fryerPickupOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerPickupOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(fryerPickupOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerPickupOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(fryerPickupOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerPickupOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(fryerPickupOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerPickupOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(fryerPickupOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_PICKUP_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// FRYER_ACTION Action
			else if (form.getActionName().equals(ActionEnum.FRYER_ACTION.label)) {

				// FRYER_ACTION_READ
				RegisterAddress fryerActionRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_ACTION_READ.label);
				if (fryerActionRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerActionRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerActionRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerActionRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerActionRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerActionRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerActionRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerActionRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerActionRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_ACTION_READ *******************");
				}

				// FRYER_ACTION_POOL_LOCATION_READ
				RegisterAddress fryerActionPoolLocation = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_ACTION_POOL_LOCATION_READ.label);
				if (fryerActionPoolLocation != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerActionPoolLocation.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerActionPoolLocation.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerActionPoolLocation.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerActionPoolLocation.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerActionPoolLocation.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out
							.println("******************* ERROR: FRYER_ACTION_POOL_LOCATION_READ *******************");
				}

				// FRYER_ACTION_LIFT_DIP_READ
				RegisterAddress fryerActionLiftDipRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_ACTION_LIFT_DIP_READ.label);
				if (fryerActionLiftDipRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerActionLiftDipRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDipRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerActionLiftDipRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDipRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerActionLiftDipRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDipRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerActionLiftDipRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerActionLiftDipRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_ACTION_LIFT_DIP_READ *******************");
				}

				// FRYER_ACTION_RUN_TIME_READ
				RegisterAddress fryerActionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_ACTION_RUN_TIME_READ.label);
				if (fryerActionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerActionOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(fryerActionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerActionOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(fryerActionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerActionOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(fryerActionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerActionOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(fryerActionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_ACTION_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}
			// FRYER_SERVE Action
			else if (form.getActionName().equals(ActionEnum.FRYER_SERVE.label)) {

				// FRYER_SERVE_READ
				RegisterAddress fryerServeRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FRYER_SERVE_READ.label);
				if (fryerServeRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerServeRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(fryerServeRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerServeRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(fryerServeRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerServeRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(fryerServeRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerServeRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(fryerServeRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_SERVE_READ *******************");
				}

				// FRYER_SERVE_POOL_LOCATION_READ
				RegisterAddress fryerServePoolLocationRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_SERVE_POOL_LOCATION_READ.label);
				if (fryerServePoolLocationRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerServePoolLocationRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(fryerServePoolLocationRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerServePoolLocationRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(fryerServePoolLocationRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerServePoolLocationRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(fryerServePoolLocationRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerServePoolLocationRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(fryerServePoolLocationRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_SERVE_POOL_LOCATION_READ *******************");
				}

				// FRYER_SERVE_TRANSFER_OR_SERVE_READ
				RegisterAddress fryerServeTransferOrServeRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_SERVE_TRANSFER_OR_SERVE_READ.label);
				if (fryerServeTransferOrServeRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerServeTransferOrServeRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServeRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerServeTransferOrServeRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServeRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerServeTransferOrServeRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServeRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerServeTransferOrServeRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(fryerServeTransferOrServeRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println(
							"******************* ERROR: FRYER_SERVE_TRANSFER_OR_SERVE_READ *******************");
				}

				// FRYER_SERVE_RUN_TIME_READ
				RegisterAddress fryerServeOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.FRYER_SERVE_RUN_TIME_READ.label);
				if (fryerServeOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(fryerServeOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(fryerServeOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(fryerServeOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(fryerServeOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(fryerServeOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(fryerServeOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(fryerServeOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(fryerServeOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FRYER_SERVE_RUN_TIME_READ *******************");
				}

			}
			// SERVE Action
			else if (form.getActionName().equals(ActionEnum.SERVE.label)) {

				// SERVE_READ
				RegisterAddress serveRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(), RegisterEnum.SERVE_READ.label);
				if (serveRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(serveRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(serveRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(serveRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(serveRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(serveRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(serveRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(serveRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(serveRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SERVE_READ *******************");
				}

				// SERVE_TYPE_READ
				RegisterAddress serveTypeRead = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SERVE_TYPE_READ.label);
				if (serveTypeRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(serveTypeRead.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(serveTypeRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(serveTypeRead.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(serveTypeRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(serveTypeRead.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(serveTypeRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(serveTypeRead.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(serveTypeRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SERVE_TYPE_READ *******************");
				}

				// SERVE_RUN_TIME_READ
				RegisterAddress serveActionOperationRunTime = registerAddressRepository
						.findUniqueByActionNameAndTypeOfAction(form.getActionName(),
								RegisterEnum.SERVE_RUN_TIME_READ.label);
				if (serveActionOperationRunTime != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(serveActionOperationRunTime.getBurner1Register(), modbusClient
								.ReadHoldingRegisters(serveActionOperationRunTime.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(serveActionOperationRunTime.getBurner2Register(), modbusClient
								.ReadHoldingRegisters(serveActionOperationRunTime.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(serveActionOperationRunTime.getBurner3Register(), modbusClient
								.ReadHoldingRegisters(serveActionOperationRunTime.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(serveActionOperationRunTime.getBurner4Register(), modbusClient
								.ReadHoldingRegisters(serveActionOperationRunTime.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: SERVE_RUN_TIME_READ *******************");
				}

				// FLAME_LEVEL_READ
				RegisterAddress flamLevelRead = registerAddressRepository.findUniqueByActionNameAndTypeOfAction(
						form.getActionName(), RegisterEnum.FLAME_LEVEL_READ.label);
				if (flamLevelRead != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner1Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner1Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner2Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner2Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner3Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner3Register(), 1)[0]);
					} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
						registerReadDetails.put(flamLevelRead.getBurner4Register(),
								modbusClient.ReadHoldingRegisters(flamLevelRead.getBurner4Register(), 1)[0]);
					}
				} else {
					System.out.println("******************* ERROR: FLAME_LEVEL_READ *******************");
				}

			}

			// Empty the registers
			List<RegisterAddress> list = registerAddressRepository.findByActionNameAndTypeOfAction(form.getActionName(),
					"");
			int[] a = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			if (list != null && !list.isEmpty()) {
				RegisterAddress tmpReg = list.get(0);
				if (tmpReg != null) {
					if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
						if (form.getBurner().equals(BurnerEnum.BURNER1.getBurnerName())) {
							modbusClient.WriteMultipleRegisters(tmpReg.getBurner1Register(), a);
							if (tmpReg.getBurner1Register() == 3021) {
								// VEG_COLLECTION
								modbusClient.WriteMultipleRegisters(3301, a);
							} else if (tmpReg.getBurner1Register() == 3031) {
								// SPICE_COLLECTION
								modbusClient.WriteMultipleRegisters(3311, a);
							} else if (tmpReg.getBurner1Register() == 3041) {
								// MEAT_COLLECTION
								modbusClient.WriteMultipleRegisters(3321, a);
							} else if (tmpReg.getBurner1Register() == 3081) {
								// IGNITION
								modbusClient.WriteMultipleRegisters(3401, a);
							} else if (tmpReg.getBurner1Register() == 3111) {
								// LIQUID_DISPENSING
								modbusClient.WriteMultipleRegisters(3121, a);
							}
						} else if (form.getBurner().equals(BurnerEnum.BURNER2.getBurnerName())) {
							modbusClient.WriteMultipleRegisters(tmpReg.getBurner2Register(), a);
							if (tmpReg.getBurner1Register() == 3521) {
								// VEG_COLLECTION
								modbusClient.WriteMultipleRegisters(3801, a);
							} else if (tmpReg.getBurner1Register() == 3531) {
								// SPICE_COLLECTION
								modbusClient.WriteMultipleRegisters(3811, a);
							} else if (tmpReg.getBurner1Register() == 3541) {
								// MEAT_COLLECTION
								modbusClient.WriteMultipleRegisters(3821, a);
							} else if (tmpReg.getBurner1Register() == 3581) {
								// IGNITION
								modbusClient.WriteMultipleRegisters(3901, a);
							} else if (tmpReg.getBurner1Register() == 3611) {
								// LIQUID_DISPENSING
								modbusClient.WriteMultipleRegisters(3621, a);
							}
						} else if (form.getBurner().equals(BurnerEnum.BURNER3.getBurnerName())) {
							modbusClient.WriteMultipleRegisters(tmpReg.getBurner3Register(), a);
							if (tmpReg.getBurner1Register() == 4021) {
								// VEG_COLLECTION
								modbusClient.WriteMultipleRegisters(4301, a);
							} else if (tmpReg.getBurner1Register() == 4031) {
								// SPICE_COLLECTION
								modbusClient.WriteMultipleRegisters(4311, a);
							} else if (tmpReg.getBurner1Register() == 4041) {
								// MEAT_COLLECTION
								modbusClient.WriteMultipleRegisters(4321, a);
							} else if (tmpReg.getBurner1Register() == 4081) {
								// IGNITION
								modbusClient.WriteMultipleRegisters(4401, a);
							} else if (tmpReg.getBurner1Register() == 4111) {
								// LIQUID_DISPENSING
								modbusClient.WriteMultipleRegisters(4121, a);
							}
						} else if (form.getBurner().equals(BurnerEnum.BURNER4.getBurnerName())) {
							modbusClient.WriteMultipleRegisters(tmpReg.getBurner4Register(), a);
							if (tmpReg.getBurner1Register() == 4521) {
								// VEG_COLLECTION
								modbusClient.WriteMultipleRegisters(4801, a);
							} else if (tmpReg.getBurner1Register() == 4531) {
								// SPICE_COLLECTION
								modbusClient.WriteMultipleRegisters(3811, a);
							} else if (tmpReg.getBurner1Register() == 4541) {
								// MEAT_COLLECTION
								modbusClient.WriteMultipleRegisters(4821, a);
							} else if (tmpReg.getBurner1Register() == 4581) {
								// IGNITION
								modbusClient.WriteMultipleRegisters(4901, a);
							} else if (tmpReg.getBurner1Register() == 4611) {
								// LIQUID_DISPENSING
								modbusClient.WriteMultipleRegisters(4621, a);
							}
						}
					}
				}
			}

			modbusClient.Disconnect();
		} catch (

		Exception e) {
			e.printStackTrace();
		}
		ModelAndView model = new ModelAndView();
		model.addObject("registerReadDetails", registerReadDetails);
		model.addObject("command", new RegisterAddressForm());
		model.setViewName("/admin/register_check");
		return model;
	}

}
