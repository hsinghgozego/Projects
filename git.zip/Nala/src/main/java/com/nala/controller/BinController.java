package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Bin;
import com.nala.model.Ingredient;
import com.nala.model.Rack;
import com.nala.model.User;
import com.nala.repository.BinRepository;
import com.nala.repository.ClassificationTypeRepository;
import com.nala.repository.IngredientRepository;
import com.nala.repository.RackRepository;

@Controller
@RequestMapping("/admin")
public class BinController {

	private static final Logger logger = LoggerFactory.getLogger(BinController.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	BinRepository binRepository;

	@Autowired
	IngredientRepository ingredientRepository;
	
	@Autowired
	RackRepository rackRepository;
	
	@Autowired
	ClassificationTypeRepository classificationTypeRepository;

	@RequestMapping("/rack-list-bins")
	public ModelAndView racklistBin(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "binSearchName", required = false) String binSearchName,
			@RequestParam(value = "binRack", required = false) String binRack,
			@RequestParam(value = "binSection", required = false) String binSection,
			@RequestParam(value = "seqRack", required = false) String seqRack,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(binSearchName==null) {
			binSearchName = "";
		}
		if(binRack==null) {
			binRack = "";
		}
		if(binSection==null) {
			binSection = "";
		}
		if(seqRack==null) {
			seqRack = "";
		}
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Bin> pageBin = binRepository.search(binSearchName, binRack, binSection, seqRack, paging);
		model.addObject("binList", pageBin.getContent());
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageBin.getTotalElements()) ? pageBin.getTotalElements() : (pageNo * pageSize)) : pageBin.getTotalElements() );
		model.addObject("totalSize", pageBin.getTotalElements());
		model.addObject("noOfPages", pageBin.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "spatulas");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_bin_grid_n");
		} else {
			model.setViewName("/admin/bin_list");
		}
		return model;
	}
	
	@RequestMapping("/addBin")
	public ModelAndView addRack(@SessionAttribute(value="loggedInUser") User loggedInUser) {
		String country=loggedInUser.getCountry();
		String weight;
		String volume;
		if(country.equals("US")) {
			weight="lb";
			volume="gallons";
		} else {
			weight="kgs";
			volume="liters";
		}
		ModelAndView model = new ModelAndView();
		model.addObject("weight", weight);
		model.addObject("volume", volume);
		model.addObject("command", new Bin());
		Iterable<Rack> rackList = rackRepository.findAll();
		Iterable<Ingredient> ingredientList = ingredientRepository.findAll();
		model.addObject("ingredientList", ingredientList);
		model.addObject("rackList", rackList);
		model.setViewName("/ajaxfiles/add_bin_n");
		return model;
	}
	
	@RequestMapping(value = { "/viewBinInfo" }, method = RequestMethod.GET)
	public ModelAndView viewRackInfo(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		Optional<Bin> obj = binRepository.findById(id);
		Bin bin = null;
		if (obj.isPresent()) {
			bin = obj.get();
		}
		model.addObject("bin", bin);
		model.setViewName("/ajaxfiles/view_bin_n");
		return model;
	}
	
	@RequestMapping(value = { "/openDeleteBin" }, method = RequestMethod.GET)
	public ModelAndView openDeleteRack(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		Bin bin = null;
		Optional<Bin> obj = binRepository.findById(id);
		if (obj.isPresent()) {
			bin = obj.get();
		}
		model.addObject("bin", bin);
		model.addObject("command", new Bin());
		model.setViewName("/ajaxfiles/delete_bin_n");
		return model;
	}

	@RequestMapping(value = { "/deleteBin" }, method = RequestMethod.POST)
	public String deleteSpatula(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "rackSearchName", required = false) String rackSearchName,
			@RequestParam(value = "rackType", required = false) String rackType,
			@RequestParam(value = "maptoRobot", required = false) String maptoRobot,
			@RequestParam(value = "rackStatus", required = false) String rackStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "id", required = true) String id,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("spatula") Rack rack, BindingResult result) {		
		binRepository.deleteById(id);
		return "redirect:/admin/rack-list-bins";
	}
	
	@RequestMapping(value = { "/openEditBin" }, method = RequestMethod.GET)
	public ModelAndView openEditBin(@SessionAttribute(value="loggedInUser") User loggedInUser, @RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Bin());
		Bin bin = null;
		Iterable<Rack> rackList = rackRepository.findAll();
		
		model.addObject("rackList", rackList);
		Optional<Bin> obj = binRepository.findById(id);
		if (obj.isPresent()) {
			bin = obj.get();
		}
		model.addObject("bin", bin);
		model.addObject("command", new Bin());
		String country=loggedInUser.getCountry();
		String weight;
		String volume;
		if(country.equals("US")) {
			weight="lb";
			volume="gallons";
		} else {
			weight="kgs";
			volume="liters";
		}
		model.addObject("weight", weight);
		model.addObject("volume", volume);
		Iterable<Ingredient> ingredientList = ingredientRepository.findAll();
		model.addObject("ingredientList", ingredientList);
		model.setViewName("/ajaxfiles/update_bin_n");
		return model;
	}
	
	@RequestMapping(value = "/saveBin", method = RequestMethod.POST)
	public String saveBin(@SessionAttribute("loggedInUser") User loggedInUser, @ModelAttribute("bin") Bin bin, BindingResult result) {
		logger.info("saveBin: " + bin.toString());
		List<Bin> binList = binRepository.findByName(bin.getName());
		if (binList.size() > 0) {
			logger.info("Error Bin name already exists");
		} else {
			Optional<Ingredient> ingredient=ingredientRepository.findById(bin.getIngredient().getId().toString());
			Optional<Rack> rack=rackRepository.findById(bin.getRack().getId().toString());
			if(rack.isPresent()) {
				bin.setRack(rack.get());
				bin.setIngredient(ingredient.get());
			}
			bin.setCreatedBy(loggedInUser.getSsoId());
			bin.setLastUpdatedBy(loggedInUser.getSsoId());			
			bin.setCreatedDateTime(new Date());
			bin.setLastUpdatedDateTime(new Date());
			binRepository.save(bin);
		}
		return "redirect:/admin/rack-list-bins";
	}

	

	@RequestMapping(value = { "/searchBin" }, method = RequestMethod.GET)
	public ModelAndView searchBin(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
		logger.info("searchBin name: " + name + ", description: " + description);
		List<Bin> binList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			binList = binRepository.findBinByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			binList = binRepository.findBinByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			binList = binRepository.findBinByRegexpDescription(description);
		}
		return new ModelAndView("/admin/bin_list", "binList", binList);
	}

	@RequestMapping(value = "/updateBin", method = RequestMethod.POST)
	public String updateRack(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "binSearchName", required = false) String binSearchName,
			@RequestParam(value = "rackId", required = false) String rackId,
			@RequestParam(value = "section", required = false) String section,
			@RequestParam(value = "seqInRack", required = false) String seqInRack,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("bin") Bin bin, BindingResult result) {
		logger.info("save bin: " + bin.toString());
		Bin dbBin = null;
		Optional<Bin> obj  = binRepository.findById(bin.getId().toString());
		Optional<Rack> rack=rackRepository.findById(bin.getRack().getId().toString());
		Optional<Ingredient> ingredient=ingredientRepository.findById(bin.getIngredient().getId().toString());
		if (obj.isPresent()) {
			dbBin = obj.get();
			dbBin.setName(bin.getName());
			dbBin.setDescription(bin.getDescription());
			dbBin.setIngredient(ingredient.get());
			dbBin.setRack(rack.get());
			dbBin.setSection(bin.getSection());
			dbBin.setSeqRack(bin.getSeqRack());
			dbBin.setMinVolume(bin.getMinVolume());
			dbBin.setMaxVolume(bin.getMaxVolume());
			dbBin.setThresholdVolume(bin.getThresholdVolume());
			dbBin.setMinQty(bin.getMinQty());
			dbBin.setMaxQty(bin.getMaxQty());
			dbBin.setThresholdQty(bin.getThresholdQty());
			dbBin.setPresentQty(bin.getPresentQty());
			dbBin.setCreatedBy(loggedInUser.getSsoId());
			dbBin.setCreatedDateTime(new Date());
			dbBin.setLastUpdatedBy(loggedInUser.getSsoId());
			dbBin.setLastUpdatedDateTime(new Date());
		}
		binRepository.save(dbBin);
		return "redirect:/admin/rack-list-bins";
	}

}
