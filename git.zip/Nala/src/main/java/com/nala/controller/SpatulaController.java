package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Spatula;
import com.nala.model.SpatulaType;
import com.nala.model.User;
import com.nala.repository.SpatulaRepository;
import com.nala.repository.SpatulaTypeRepository;

@Controller
@RequestMapping("/admin")
public class SpatulaController {

	private static final Logger logger = LoggerFactory.getLogger(SpatulaController.class);

	@Autowired
	SpatulaRepository spatulaRepository;
	
	@Autowired
	SpatulaTypeRepository spatulaTypeRepository;


	@RequestMapping("/list-spatulas")
	public ModelAndView spatula(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaSearchName", required = false) String spatulaSearchName,
			@RequestParam(value = "spatulaSearchType", required = false) String spatulaSearchType,
			@RequestParam(value = "spatulaSearchStatus", required = false) String spatulaSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(spatulaSearchName==null) {
			spatulaSearchName = "";
		}
		if(spatulaSearchType==null) {
			spatulaSearchType = "";
		}
		if(spatulaSearchStatus==null) {
			spatulaSearchStatus = "";
		}
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Spatula> pageSpatula = spatulaRepository.search(spatulaSearchName, spatulaSearchType, spatulaSearchStatus, paging);
		List<SpatulaType> spatulaTypeList=spatulaTypeRepository.findAll();
		model.addObject("spatulaTypeList", spatulaTypeList);
		model.addObject("spatulaList", pageSpatula.getContent());
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageSpatula.getTotalElements()) ? pageSpatula.getTotalElements() : (pageNo * pageSize)) : pageSpatula.getTotalElements() );
		model.addObject("totalSize", pageSpatula.getTotalElements());
		model.addObject("noOfPages", pageSpatula.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "spatulas");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_spatula_grid_n");
		} else {
			model.setViewName("/admin/spatula_list");
		}
		return model;
		
	}

	@RequestMapping("/addSpatula")
	public ModelAndView addSpatula() {
		ModelAndView model = new ModelAndView();
		List<SpatulaType> spatulaTypeList=spatulaTypeRepository.findAll();
		model.addObject("spatulaTypeList", spatulaTypeList);
		model.addObject("command", new Spatula());
		model.setViewName("/ajaxfiles/add_spatula_n");
		return model;
	}

	@RequestMapping(value = "/saveSpatula", method = RequestMethod.POST)
	public String addSpatula(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaSearchName", required = false) String spatulaSearchName,
			@RequestParam(value = "spatulaSearchType", required = false) String spatulaSearchType,
			@RequestParam(value = "spatulaSearchStatus", required = false) Boolean spatulaSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("spatula") Spatula spatula, BindingResult result) {
		logger.info("save spatula: " + spatula.toString());
		Optional<SpatulaType> spatuleType=spatulaTypeRepository.findById(spatula.getSpatulaType().getId().toString());
		spatula.setSpatulaType(spatuleType.get());
		spatula.setStatus("Active");
		spatula.setCreatedBy(loggedInUser.getSsoId());
		spatula.setCreatedDateTime(new Date());
		spatula.setLastUpdatedBy(loggedInUser.getSsoId());
		spatula.setLastUpdatedDateTime(new Date());
		spatulaRepository.save(spatula);
		return "redirect:/admin/list-spatulas";
	}

	@RequestMapping(value = { "/viewSpatulaInfo" }, method = RequestMethod.GET)
	public ModelAndView viewSpatulaInfo(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Spatula());
		Optional<Spatula> obj = spatulaRepository.findById(id);
		Spatula spatula = null;
		if (obj.isPresent()) {
			spatula = obj.get();
		}
		model.addObject("spatula", spatula);
		model.setViewName("/ajaxfiles/view_spatula_info");
		return model;
	}

	@RequestMapping(value = { "/openEditSpatula" }, method = RequestMethod.GET)
	public ModelAndView openEditSpatula(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Spatula());
		Spatula spatula = null;
		Optional<Spatula> obj = spatulaRepository.findById(id);
		List<SpatulaType> spatulaTypeList=spatulaTypeRepository.findAll();
		model.addObject("spatulaTypeList", spatulaTypeList);
		if (obj.isPresent()) {
			spatula = obj.get();
		}
		model.addObject("spatula", spatula);
		model.addObject("command", new Spatula());
		model.setViewName("/ajaxfiles/update_spatula_n");
		return model;
	}

	@RequestMapping(value = "/updateSpatula", method = RequestMethod.POST)
	public String editSpatula(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaSearchName", required = false) String spatulaSearchName,
			@RequestParam(value = "spatulaSearchType", required = false) String spatulaSearchType,
			@RequestParam(value = "spatulaSearchStatus", required = false) Boolean spatulaSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("spatula") Spatula spatula, BindingResult result) {
		logger.info("save spatula: " + spatula.toString());
		Spatula dbSpatula = null;
		Optional<Spatula> obj = spatulaRepository.findById(spatula.getId().toString());
		Optional<SpatulaType> spatuleType=spatulaTypeRepository.findById(spatula.getSpatulaType().getId().toString());
		if (obj.isPresent()) {
			dbSpatula = obj.get();
			dbSpatula.setSpatulaType(spatuleType.get());
			dbSpatula.setName(spatula.getName());
			dbSpatula.setDescription(spatula.getDescription());
			dbSpatula.setCreatedBy(loggedInUser.getSsoId());
			dbSpatula.setCreatedDateTime(new Date());
			dbSpatula.setLastUpdatedBy(loggedInUser.getSsoId());
			dbSpatula.setLastUpdatedDateTime(new Date());
		}
		spatulaRepository.save(dbSpatula);
		return "redirect:/admin/list-spatulas";
	}

	@RequestMapping(value = { "/openDeleteSpatula" }, method = RequestMethod.GET)
	public ModelAndView openDeleteSpatula(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		Spatula spatula = null;
		Optional<Spatula> obj = spatulaRepository.findById(id);
		if (obj.isPresent()) {
			spatula = obj.get();
		}
		model.addObject("spatula", spatula);
		model.addObject("command", new Spatula());
		model.setViewName("/ajaxfiles/delete_spatula_n");
		return model;
	}

	@RequestMapping(value = { "/deleteSpatula" }, method = RequestMethod.POST)
	public String deleteSpatula(Device device,
			@RequestParam(value = "spatulaSearchName", required = false) String spatulaSearchName,
			@RequestParam(value = "spatulaSearchType", required = false) String spatulaSearchType,
			@RequestParam(value = "spatulaSearchStatus", required = false) Boolean spatulaSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("spatula") Spatula spatula, BindingResult result) {		
		spatulaRepository.deleteById(id);
		return "redirect:/admin/list-spatulas";
	}
	
}
