package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.BowlType;
import com.nala.model.User;
import com.nala.repository.BowlTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class BowlTypeController {

	private static final Logger logger = LoggerFactory.getLogger(BowlTypeController.class);

	@Autowired
	BowlTypeRepository bowlTypeRepository;

	@RequestMapping("/list-bowlTypes")
	public ModelAndView listBowlType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "bowlTypeSearchName", required = false) String bowlTypeSearchName,
			@RequestParam(value = "bowlTypeSearchDescription", required = false) String bowlTypeSearchDescription,
			@RequestParam(value = "bowlTypeSearchStatus", required = false) String bowlTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(bowlTypeSearchName==null) {
			bowlTypeSearchName = "";
		}
		if(bowlTypeSearchDescription==null) {
			bowlTypeSearchDescription = "";
		}
		if(bowlTypeSearchStatus==null) {
			bowlTypeSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<BowlType> pageBowlType = bowlTypeRepository.search(bowlTypeSearchName, bowlTypeSearchDescription,bowlTypeSearchStatus, paging);
		
		model.addObject("bowlTypeList", pageBowlType.getContent());
		model.addObject("currentPage", pageBowlType.getNumber());
		model.addObject("totalItems", pageBowlType.getTotalElements());
		model.addObject("totalPages", pageBowlType.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageBowlType.getTotalElements()) ? pageBowlType.getTotalElements() : (pageNo * pageSize)) : pageBowlType.getTotalElements() );
		model.addObject("totalSize", pageBowlType.getTotalElements());
		model.addObject("noOfPages", pageBowlType.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "bowlTypes");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_bowlType_grid_n");
		} else {
			model.setViewName("/admin/bowlType_list");
		}
		
		return model;
	}
	
	@RequestMapping(value = "/saveBowlType", method = RequestMethod.POST)
	public String saveBowlType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "bowlTypeSearchName", required = false) String bowlTypeSearchName,
			@RequestParam(value = "bowlTypeSearchDescription", required = false) String bowlTypeSearchDescription,
			@RequestParam(value = "bowlTypeSearchStatus", required = false) String bowlTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("bowlType") BowlType bowlType, BindingResult result) {
		
		logger.info("save bowlType: " + bowlType.toString());
		
		List<BowlType> bowlTypeList = bowlTypeRepository.findAll();
		bowlType.setSequence(bowlTypeList.size() + 1);
		bowlType.setCreatedBy(loggedInUser.getSsoId());
		bowlType.setCreatedDateTime(new Date());
		bowlType.setLastUpdatedBy(loggedInUser.getSsoId());
		bowlType.setLastUpdatedDateTime(new Date());
		bowlTypeRepository.save(bowlType);
		return "redirect:/admin/list-bowlTypes";
		
	}
	
	@RequestMapping("/addBowlType")
	public ModelAndView addBowlType() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new BowlType());
		model.setViewName("/ajaxfiles/add_bowlType_n");
		return model;
	}

	@RequestMapping(value = "/updateBowlType", method = RequestMethod.POST)
	public String updateBowlType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "bowlTypeSearchName", required = false) String bowlTypeSearchName,
			@RequestParam(value = "bowlTypeSearchDescription", required = false) String bowlTypeSearchDescription,
			@RequestParam(value = "bowlTypeSearchStatus", required = false) String bowlTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("bowlType") BowlType bowlType, BindingResult result) {
		
		logger.info("Updating bowlType: " + bowlType.toString());

		BowlType dbBowlType = null;
		Optional<BowlType> obj = bowlTypeRepository.findById(bowlType.getId().toString());
		if (obj.isPresent()) {
			dbBowlType = obj.get();
			dbBowlType.setName(bowlType.getName());
			dbBowlType.setDescription(bowlType.getDescription());
			dbBowlType.setStatus(bowlType.getStatus());
			dbBowlType.setLastUpdatedBy(loggedInUser.getSsoId());
			dbBowlType.setLastUpdatedDateTime(new Date());
		
		}
		bowlTypeRepository.save(dbBowlType);
		return "redirect:/admin/list-bowlTypes";
	}

	@RequestMapping(value = { "/viewBowlTypeInfo" }, method = RequestMethod.GET)
	public ModelAndView viewBowlTypeInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new BowlType());
				
		Optional<BowlType> obj = bowlTypeRepository.findById(id);
		BowlType bowlType = null;
		if (obj.isPresent()) {
			bowlType = obj.get();
		}
		
		model.addObject("bowlType", bowlType);
		model.setViewName("/ajaxfiles/view_bowlType_n");
		return model;
	}
	
	@RequestMapping(value = { "/openEditBowlType" }, method = RequestMethod.GET)
	public ModelAndView openEditBowlType(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		model.addObject("command", new BowlType());
		
		Optional<BowlType> obj = bowlTypeRepository.findById(id);
		BowlType bowlType = null;
		if (obj.isPresent()) {
			bowlType = obj.get();
		}
		
		model.addObject("bowlType", bowlType);
		model.setViewName("/ajaxfiles/update_bowlType_n");
		return model;
	}

	@RequestMapping(value = { "/openDeleteBowlType" }, method = RequestMethod.GET)
	public ModelAndView openDeleteBowlType(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<BowlType> obj = bowlTypeRepository.findById(id);
		BowlType bowlType = null;
		if (obj.isPresent()) {
			bowlType = obj.get();
		}
		
		model.addObject("bowlType", bowlType);
		model.addObject("command", new BowlType());
		model.setViewName("/ajaxfiles/delete_bowlType_n");
		return model;
	}
	
	@RequestMapping(value = { "/deleteBowlType" }, method = RequestMethod.POST)
	public String deleteBowlType(Device device,
			@RequestParam(value = "bowlTypeSearchName", required = false) String bowlTypeSearchName,
			@RequestParam(value = "bowlTypeSearchDescription", required = false) String bowlTypeSearchDescription,
			@RequestParam(value = "bowlTypeSearchStatus", required = false) String bowlTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("bowlType") BowlType bowlType, BindingResult result) {
		
		bowlTypeRepository.deleteById(id);
		return "redirect:/admin/list-bowlTypes";
		
	}
	
}
