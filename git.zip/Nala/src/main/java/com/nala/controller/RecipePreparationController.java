package com.nala.controller;

import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Burner;
import com.nala.model.Recipe;
import com.nala.model.RecipeDetail;
import com.nala.repository.ActionRepository;
import com.nala.repository.BinRepository;
import com.nala.repository.BurnerRepository;
import com.nala.repository.FlameLevelRepository;
import com.nala.repository.RecipeDetailRepository;
import com.nala.repository.RecipeRepository;
import com.nala.repository.RecipeTypeRepository;
import com.nala.repository.StirTypeRepository;

import de.re.easymodbus.modbusclient.ModbusClient;

//import de.re.easymodbus.modbusclient.ModbusClient;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RecipePreparationController {

	private static final Logger logger = LoggerFactory.getLogger(RecipeDetailController.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	ActionRepository actionRepository;

	@Autowired
	BinRepository binRepository;

	@Autowired
	FlameLevelRepository flameLevelRepository;

	@Autowired
	RecipeTypeRepository recipeTypeRepository;

	@Autowired
	RecipeRepository recipeRepository;

	@Autowired
	RecipeDetailRepository recipeDetailRepository;

	@Autowired
	StirTypeRepository stirTypeRepository;

	@Autowired
	BurnerRepository burnerRepository;

	private static String UTENCILE_PICK = "Utensile Pick";
	private static String SPATULA_PICK = "Spatula Pick";
	private static String VEG_COLLECT = "Veg Collect";
	private static String SPICE_COLLECT = "Spice Collect";
	private static String NON_VEG_COLLECT = "Non Veg Collect";
	private static String VEG_PICKUP = "Veg Pickup";
	private static String SPICE_PICKUP = "Spice Pickup";
	private static String NON_VEG_PICKUP = "Non Veg Pickup";
	private static String IGNITION = "Ignition";
	private static String STIR = "Stir";
	private static String TOSS = "Toss";
	private static String LIQUID_DISPENSE = "Liquid Dispense";
	private static String DELAY = "Delay";
	private static String SERVE = "Serve";

	@RequestMapping(value = { "/listRecipePreparationSteps" }, method = RequestMethod.GET)
	public ModelAndView listRecipePreparationSteps(@RequestParam(value = "id", required = true) String id,
			@RequestParam(value = "stepNo", required = true) String stepNo) {

		List<RecipeDetail> recipeDetailsList = recipeDetailRepository.findByRecipeId(id);
		RecipeDetail nextRecipeDetail = null;
		ModelAndView model = new ModelAndView();
		if (Integer.parseInt(stepNo) <= recipeDetailsList.size()) {
			nextRecipeDetail = recipeDetailRepository.findByStepNoAndRecipeId(Integer.parseInt(stepNo), id);
		}
		model.addObject("recipeDetailsList", recipeDetailsList);
		model.addObject("nextRecipeDetail", nextRecipeDetail);
		model.addObject("command", new RecipeDetail());
		model.setViewName("/admin/recipe_preparation_list");
		return model;

	}

	@RequestMapping(value = "/executeRecipePreparationStep", method = RequestMethod.POST)
	@Transactional
	public String executeRecipePreparationStep(@ModelAttribute("recipeDetail") RecipeDetail recipeDetail,
			BindingResult result) {
		if (recipeDetail.getId() != null) {
			Optional<RecipeDetail> recipeDetailOpt = recipeDetailRepository.findById(recipeDetail.getId().toString());
			if(recipeDetailOpt.isPresent()) {
			recipeDetail = recipeDetailOpt.get();
			List<RecipeDetail> recipeDetailsList = recipeDetailRepository
					.findByRecipeId(recipeDetail.getRecipe().getId().toString());
			String actionName = recipeDetail.getAction().getName();
		//	int actionSequenceNo = recipeDetail.getAction().getSequence();
			int actionSequenceNo = 1;
			int binSequenceNo = 0;
			int valueInGmsMl = 0;
			int delayInMilliSeconds = 0;
			int utensilSequenceNo = 0;
			int spatulaSequenceNo = 0;
			int stirSequenceNo = 0;
			int tossSequenceNo = 0;
			int flamelevelSequenceNo = recipeDetail.getFlameLevel().getSequence();
			String tossId = "";
			if (actionName.contentEquals(VEG_COLLECT) || actionName.equalsIgnoreCase(SPICE_COLLECT)) {
				binSequenceNo = 0;
				valueInGmsMl = recipeDetail.getValueInGmsMl();
			} else if (actionName.equalsIgnoreCase(NON_VEG_COLLECT)
					|| actionName.equalsIgnoreCase(LIQUID_DISPENSE)) {
				binSequenceNo = 0;
				delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
			} else if (actionName.contentEquals(VEG_PICKUP) || actionName.contentEquals(SPICE_PICKUP)
					|| actionName.contentEquals(NON_VEG_PICKUP)) {
			} else if (actionName.contentEquals(UTENCILE_PICK) || actionName.contentEquals(SPATULA_PICK)) {
				utensilSequenceNo = recipeDetail.getUtensil().getSequence();
			} else if (actionName.contentEquals(STIR)) {
				stirSequenceNo = recipeDetail.getStir().getSequence();
				delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
			} else if (actionName.contentEquals(TOSS)) {
				// need clarification
				tossSequenceNo = recipeDetail.getToss().getSequence();
				delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
			} else if (actionName.contentEquals(DELAY)) {
				delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
			} else if (actionName.contentEquals(SERVE)) {
			}
			int currentStepNo = recipeDetail.getStepNo();
			int nextStep = 0;
			try {
				ModbusClient modbusClient = new ModbusClient("192.168.9.17", 502);
				modbusClient.Connect();
				if (actionSequenceNo != 0) {
					modbusClient.WriteSingleRegister(2001, actionSequenceNo);
				}
				if (binSequenceNo != 0) {
					modbusClient.WriteSingleRegister(2002, binSequenceNo);
				}
				if (utensilSequenceNo != 0) {
					modbusClient.WriteSingleRegister(2002, utensilSequenceNo);
				}
				if (valueInGmsMl != 0) {
					modbusClient.WriteSingleRegister(2003, valueInGmsMl);
				}
				if (delayInMilliSeconds != 0) {
					modbusClient.WriteSingleRegister(2004, delayInMilliSeconds);
				}
				if (stirSequenceNo != 0) {
					modbusClient.WriteSingleRegister(2002, stirSequenceNo);
				}
				if (flamelevelSequenceNo != 0) {
					modbusClient.WriteSingleRegister(2009, flamelevelSequenceNo);
				}

				while (true) {
					nextStep = modbusClient.ReadHoldingRegisters(2011, 1)[0];
					if (nextStep == (currentStepNo + 1)) {
						break;
					}
				}
				modbusClient.Disconnect();
			} catch (Exception e) {

			}
			System.out.println("currentStepNo" + currentStepNo);
			System.out.println("nextStep" + nextStep);
			currentStepNo = currentStepNo + 1;
			return "redirect:/admin/listRecipePreparationSteps?id=" + recipeDetail.getRecipe().getId() + "&stepNo="
					+ currentStepNo;
			} else {
				logger.info("Recipe not Found with the Given Id");
				return "redirect:/admin/listRecipePreparationSteps";
			}
		} else {
			logger.info("Recipe Id is null");
			return "redirect:/admin/listRecipePreparationSteps";
		}
	}

	@RequestMapping(value = { "/recipeCookingProcess" }, method = RequestMethod.GET)
	public ModelAndView recipeCookingProcess() {
		List<Burner> burnersList = burnerRepository.findAll();
		List<Recipe> recipeList = recipeRepository.findAll();
		ModelAndView model = new ModelAndView();
		model.addObject("burnersList", burnersList);
		model.addObject("recipeList", recipeList);
		model.setViewName("/admin/recipe_preparation_process");
		return model;

	}

	@RequestMapping(value = "/getCookingProcessDetails/{recipeId}/{stepNo}", method = RequestMethod.GET, headers = "Accept=*/*")
	public ModelAndView getCookingProcessDetails(@PathVariable("recipeId") String recipeId,
			@PathVariable("stepNo") int stepNo) {
		List<RecipeDetail> recipeDetailsList = recipeDetailRepository.findByRecipeObjectId(new ObjectId(recipeId));
		for (RecipeDetail recipeDetail : recipeDetailsList) {
			setItemValueBasedOnAction(recipeDetail);
		}
		RecipeDetail currentRecipeDetail = null;
		if (stepNo != 0) {
			currentRecipeDetail = recipeDetailRepository.findByStepNoAndRecipeId(stepNo, recipeId);
			setItemValueBasedOnAction(currentRecipeDetail);
		}
		ModelAndView model = new ModelAndView();
		model.addObject("recipeDetailsList", recipeDetailsList);
		model.addObject("currentRecipeDetail", currentRecipeDetail);
		model.setViewName("/admin/recipe_selection");
		return model;
	}
	
	@RequestMapping(value = "/stopCookingProcess", method = RequestMethod.GET, headers = "Accept=*/*")
	public @ResponseBody String stopCookingProcess() {
		try {
			
			  ModbusClient modbusClient = new ModbusClient("192.168.9.17", 502);
			  modbusClient.Connect(); 
			  modbusClient.WriteSingleRegister(2001, 0);
			  modbusClient.WriteSingleRegister(2002, 0);
			  modbusClient.WriteSingleRegister(2003, 0);
			  modbusClient.WriteSingleRegister(2004, 0);
			  modbusClient.WriteSingleRegister(2005, 0);
			  modbusClient.WriteSingleRegister(2006, 0);
			  modbusClient.WriteSingleRegister(2007, 0);
			  modbusClient.WriteSingleRegister(2008, 0);
			  modbusClient.WriteSingleRegister(2009, 0);
			  modbusClient.WriteSingleRegister(2011, 0); 
			  modbusClient.Disconnect();
			 
		} catch (Exception e) {

		}
		return "Stopped Cooking Process";
	}


	@RequestMapping(value = { "/executeCookingProcessStep" }, method = RequestMethod.POST)
	public ModelAndView deleteCountry(@RequestParam(value = "burner", required = true) String burner,
			@RequestParam(value = "recipe", required = true) String recipe,
			@RequestParam(value = "stepNo", required = true) String stepNo) {
		int burnerSequenceNo = 0;
		Optional<Burner> burnerOpt = burnerRepository.findById(burner);
		if(burnerOpt.isPresent()) {
			burnerSequenceNo = burnerOpt.get().getSequence();
		}
		RecipeDetail recipeDetail = recipeDetailRepository.findByStepNoAndRecipeId(Integer.parseInt(stepNo), recipe);
		List<RecipeDetail> recipeDetailsList = recipeDetailRepository.findByRecipeId(recipe);
		String actionName = recipeDetail.getAction().getName();
		//int actionSequenceNo = recipeDetail.getAction().getSequence();
		int actionSequenceNo = 1;
		int mainItemSequenceNo=0;
		int valueInGmsMl = 0;
		int delayInMilliSeconds = 0;
		int flamelevel = 0;
		int tossSequenceNo = 0;
		if(recipeDetail.getFlameLevel()!=null && !recipeDetail.getFlameLevel().getPercentage().equalsIgnoreCase("OFF") && !recipeDetail.getFlameLevel().getPercentage().equalsIgnoreCase("Ignition")) {
			flamelevel=Integer.parseInt(recipeDetail.getFlameLevel().getPercentage());
		}
		if (actionName.contentEquals(VEG_COLLECT) || actionName.equalsIgnoreCase(SPICE_COLLECT)) {
			mainItemSequenceNo = 0;
			valueInGmsMl = recipeDetail.getValueInGmsMl();
		} else if (actionName.equalsIgnoreCase(NON_VEG_COLLECT)
				|| actionName.equalsIgnoreCase(LIQUID_DISPENSE)) {
			mainItemSequenceNo = 0;
			delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
		} else if (actionName.contentEquals(UTENCILE_PICK)) {
			mainItemSequenceNo = recipeDetail.getUtensil().getSequence();
		} else if (actionName.contentEquals(SPATULA_PICK)) {
			mainItemSequenceNo = recipeDetail.getSpatula().getSequence();
		} else if (actionName.contentEquals(STIR)) {
			mainItemSequenceNo = recipeDetail.getStir().getSequence();
			delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
		} else if (actionName.contentEquals(TOSS)) {
			// need clarification
			tossSequenceNo = recipeDetail.getToss().getSequence();
			delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
		} else if (actionName.contentEquals(DELAY)) {
			delayInMilliSeconds = recipeDetail.getDelayInMilliSeconds();
		} else if (actionName.contentEquals(VEG_PICKUP) || actionName.contentEquals(SPICE_PICKUP) || actionName.contentEquals(NON_VEG_PICKUP)) {
			mainItemSequenceNo=1;
		}
		int nextStep = 0;
		try {
			ModbusClient modbusClient = new ModbusClient("192.168.9.17", 502);
			modbusClient.Connect();
			
			//for first step set the row counter to 1
			if(recipeDetail.getStepNo()==1) {
				modbusClient.WriteSingleCoil(2001, true);
				Thread.sleep(500);
				modbusClient.WriteSingleCoil(2001, false);
				modbusClient.WriteSingleRegister(2011, 1);
				modbusClient.WriteSingleRegister(2012, recipeDetailsList.size());
				
				
			}
			
			if (actionSequenceNo != 0) {
				modbusClient.WriteSingleRegister(2001, actionSequenceNo);
			} else {
				modbusClient.WriteSingleRegister(2001, 0);
			}
			if (mainItemSequenceNo != 0) {
				modbusClient.WriteSingleRegister(2002, mainItemSequenceNo);
			} else {
				modbusClient.WriteSingleRegister(2002, 0);
			}
			
			if (valueInGmsMl != 0) {
				modbusClient.WriteSingleRegister(2003, valueInGmsMl);
			} else {
				modbusClient.WriteSingleRegister(2003, 0);
			}
			if (delayInMilliSeconds != 0) {
				modbusClient.WriteSingleRegister(2004, delayInMilliSeconds);
			} else {
				modbusClient.WriteSingleRegister(2004, 0);
			}
			modbusClient.WriteSingleRegister(2009, flamelevel);
			while (true) {
				nextStep = modbusClient.ReadHoldingRegisters(2011, 1)[0];
				if (nextStep == (Integer.parseInt(stepNo) + 1)) {
					break;
				}
			}
			//process complete
			if(recipeDetail.getStepNo()==recipeDetailsList.size()) {
				  modbusClient.WriteSingleRegister(2001, 0);
				  modbusClient.WriteSingleRegister(2002, 0);
				  modbusClient.WriteSingleRegister(2003, 0);
				  modbusClient.WriteSingleRegister(2004, 0);
				  modbusClient.WriteSingleRegister(2005, 0);
				  modbusClient.WriteSingleRegister(2006, 0);
				  modbusClient.WriteSingleRegister(2007, 0);
				  modbusClient.WriteSingleRegister(2008, 0);
				  modbusClient.WriteSingleRegister(2009, 0);
				  modbusClient.WriteSingleRegister(2011, 1);
				  modbusClient.WriteSingleRegister(2012, 0);
			}
			modbusClient.Disconnect();
		} catch (Exception e) {

		}
		ModelAndView model = new ModelAndView();
		model.addObject("rowIncrement", nextStep);
		model.addObject("currentRecipeDetail", recipeDetail);
		model.setViewName("/admin/currentRecipeDetails");
		return model;

	}
	
	public void setItemValueBasedOnAction(RecipeDetail recipeDetail) {

		if (recipeDetail.getAction() != null) {
			String actionName = recipeDetail.getAction().getName();
			if (actionName.equalsIgnoreCase(VEG_COLLECT) || actionName.equalsIgnoreCase(SPICE_COLLECT) || actionName.equalsIgnoreCase(NON_VEG_COLLECT) || actionName.equalsIgnoreCase(LIQUID_DISPENSE)) {
				recipeDetail.setMainItemId(recipeDetail.getBin().getName());
			} else if (actionName.equalsIgnoreCase(UTENCILE_PICK) || actionName.equalsIgnoreCase(SPATULA_PICK)) {
				recipeDetail.setMainItemId(recipeDetail.getUtensil().getName());
			} else if (actionName.equalsIgnoreCase(STIR)) {
				recipeDetail.setMainItemId(recipeDetail.getStir().getName());
			} else if (actionName.equalsIgnoreCase(TOSS)) {
				recipeDetail.setMainItemId(recipeDetail.getToss().getName());
			}
		}
	
	}
}
