package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Burner;
import com.nala.model.User;
import com.nala.model.Utensil;
import com.nala.model.UtensilType;
import com.nala.repository.BurnerRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class BurnerController {

	private static final Logger logger = LoggerFactory.getLogger(BurnerController.class);
	
	@Autowired
	BurnerRepository burnerRepository;

	@RequestMapping("/listBurners")
	public ModelAndView listBurners(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilSearchName", required = false) String utensilSearchName,
			@RequestParam(value = "utensilSearchType", required = false) String utensilSearchType,
			@RequestParam(value = "utensilSearchStatus", required = false) String utensilSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax){
		
		Iterable<Burner> burnersList = burnerRepository.findAll();
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Burner());
		model.addObject("burnersList", burnersList);
		model.setViewName("/admin/burners_list");
		return model;
				
	}

	@RequestMapping(value = { "/searchBurner" }, method = RequestMethod.GET)
	public ModelAndView searchBurner(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {

		List<Burner> burnersList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			burnersList = burnerRepository.findBurnerByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			burnersList = burnerRepository.findBurnerByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			burnersList = burnerRepository.findBurnerByRegexpDescription(description);
		}
		return new ModelAndView("/admin/burners_list", "burnersList", burnersList);
	}

	@RequestMapping(value = "/saveBurner", method = RequestMethod.POST)
	public String saveBurner(@SessionAttribute("loggedInUser") User loggedInUser,
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("burner") Burner burner, BindingResult result) throws IOException {
		List<Burner> burberList = burnerRepository.findByName(burner.getName());
		
			if(!image.isEmpty()) {
			
					burner.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
			
			}
		
		
		if (burberList.size() > 0) {
			System.out.println("Error: Burner Name Already Exist");
		} else {
			System.out.println("Ok: Adding New Burner");
			burner.setCreatedBy(loggedInUser.getSsoId());
			burner.setLastUpdatedBy(loggedInUser.getSsoId());
			burner.setCreatedDateTime(new Date());
			burner.setLastUpdatedDateTime(new Date());
			burnerRepository.save(burner);
		}
		return "redirect:/admin/listBurners";
	}

	@RequestMapping("/addBurner")
	public ModelAndView addBurner() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Burner());
		
		model.setViewName("/ajaxfiles/add_burner_n");
		return model;
		
	}

	@RequestMapping(value = { "/editBurner" }, method = RequestMethod.GET)
	public ModelAndView editBurner(@RequestParam(value = "id", required = true) String id) {
		Optional<Burner> burnerOpt = burnerRepository.findById(id);
		ModelAndView model = new ModelAndView();
		if (burnerOpt.isPresent()) {
			model.addObject("burner", burnerOpt.get());
		} else {
			logger.info("Burner not found with the Given Id");
		}
		model.addObject("command", new Burner());
		model.setViewName("/admin/edit_burner");
		return model;
	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/updateBurner", method = RequestMethod.POST)
	public String updateBurner(@SessionAttribute("loggedInUser") User loggedInUser,
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("burner") Burner burner, BindingResult result) {
		Burner dbBurner = null;
		Optional<Burner> burnerOpt = burnerRepository.findById(burner.getId().toString());
		if (burnerOpt.isPresent()) {
			dbBurner = burnerOpt.get();
			
			try {
				
				if(!image.isEmpty()) {
					
					dbBurner.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
					
				}
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
				
			
			dbBurner.setName(burner.getName());
			dbBurner.setDescription(burner.getDescription());
			dbBurner.setSequence(burner.getSequence());
			dbBurner.setLastUpdatedBy(loggedInUser.getSsoId());
			dbBurner.setLastUpdatedDateTime(new Date());
			dbBurner.setMapToStation(burner.getMapToStation());
			dbBurner.setStatus(burner.getStatus());
			burnerRepository.save(dbBurner);
		} else {
			System.out.println("Unable to update action");
		}
		return "redirect:/admin/listBurners";
	}
	
	
	
	@RequestMapping(value = { "/viewBurnerInfo" }, method = RequestMethod.GET)
	public ModelAndView viewBurnerInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Utensil());
		
				
		Optional<Burner> obj = burnerRepository.findById(id);
		Burner burner = null;
		if (obj.isPresent()) {
			burner = obj.get();
		}
			
		model.addObject("burner", burner);
		try{
			
			if(burner.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (burner.getImage().getData()) );	
				
			} 
			 
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		 
		model.setViewName("/ajaxfiles/view_burner_info");
		return model;
	}
	
	//openEditBurner
	@RequestMapping(value = { "/openEditBurner" }, method = RequestMethod.GET)
	public ModelAndView openEditBurner(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		
		//model.addObject("command", new Utensil());
		
		Optional<Burner> obj = burnerRepository.findById(id);
		Burner burner = null;
		if (obj.isPresent()) {
			burner = obj.get();
		}
		
		model.addObject("burner", burner);
		model.addObject("command", new Burner());
		//model.addObject("command", new BurnerType());
		
		try{
			if(burner.getImage()!=null){
			 model.addObject("image", Base64.getEncoder().encodeToString (burner.getImage().getData()) );
			}
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		//List<UtensilType> utensilTypeList = utensilTypeRepository.findAll();
	//	model.addObject("utensilTypeList", utensilTypeList);
		
		
		model.setViewName("/ajaxfiles/update_burner_n");
		return model;
	}
	
	
	
	@RequestMapping(value = { "/openDeleteBurner" }, method = RequestMethod.GET)
	public ModelAndView openDeleteBurner(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<Burner> obj = burnerRepository.findById(id);
		Burner burner = null;
		if (obj.isPresent()) {
			burner = obj.get();
		}
			
		model.addObject("burner", burner);
		model.addObject("command", new Burner());
		model.setViewName("/ajaxfiles/delete_burner_n");
		return model;
	}
	
	
	//deleteBurner
	@RequestMapping(value = { "/deleteBurner" }, method = RequestMethod.POST)
	public String deleteBurner(Device device,
			@RequestParam(value = "burnerSearchName", required = false) String burnerSearchName,
			@RequestParam(value = "burnerSearchType", required = false) String burnerSearchType,
			@RequestParam(value = "burnerSearchStatus", required = false) Boolean burnerSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("burner") Burner burner, BindingResult result) {
		
		
		burnerRepository.deleteById(id);
		return "redirect:/admin/listBurners";
		

	}
	
	
	

}
