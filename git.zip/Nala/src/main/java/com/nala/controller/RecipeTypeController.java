package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.RecipeType;
import com.nala.repository.RecipeTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RecipeTypeController {

	private static final Logger logger = LoggerFactory.getLogger(RecipeTypeController.class);

	@Autowired
	RecipeTypeRepository recipeTypeRepository;

	@RequestMapping("/listRecipeTypes")
	public ModelAndView listRecipeTyes() {
		Iterable<RecipeType> recipeTypeList = recipeTypeRepository.findAll();
		return new ModelAndView("/admin/recipe_type_list", "recipeTypeList", recipeTypeList);
	}

	@RequestMapping(value = { "/searchRecipeType" }, method = RequestMethod.GET)
	public ModelAndView searchRecipeType(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
    	logger.info("searchRecipeType name: " + name + ", description: " + description);
		List<RecipeType> recipeTypeList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			recipeTypeList = recipeTypeRepository.findRecipeTypeByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			recipeTypeList = recipeTypeRepository.findRecipeTypeByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			recipeTypeList = recipeTypeRepository.findRecipeTypeByRegexpDescription(description);
		}
		return new ModelAndView("/admin/recipe_type_list", "recipeTypeList", recipeTypeList);
	}

	@RequestMapping(value = "/saveRecipeType", method = RequestMethod.POST)
	public String saveRecipeType(@ModelAttribute("recipeType") RecipeType recipeType, BindingResult result) {
    	logger.info("saveRecipeType: " + recipeType.toString());
		List<RecipeType> recipeTypeList = recipeTypeRepository.findByName(recipeType.getName());
		if (recipeTypeList.size() > 0) {
			logger.info("Error Recipe Type name already exists: " + recipeType.getName());
		} else {
			recipeType.setCreatedBy("Satish");
			recipeType.setLastUpdatedBy("Satish");
			recipeType.setCreatedDateTime(new Date());
			recipeType.setLastUpdatedDateTime(new Date());
			recipeTypeRepository.save(recipeType);
		}
		return "redirect:/listRecipeTypes";
	}

	@RequestMapping("/addReceipeType")
	public ModelAndView addReceipeType() {
		return new ModelAndView("/admin/new_recipe_type", "command", new RecipeType());
	}

	@RequestMapping(value = { "/editRecipeType" }, method = RequestMethod.GET)
	public ModelAndView editRecipeType(@RequestParam(value = "id", required = true) String id) {
    	logger.info("editRecipeType id: " + id);
		Optional<RecipeType> recipeTypeOpt = recipeTypeRepository.findById(id);
		ModelAndView model = new ModelAndView();
		model.addObject("command", new RecipeType());
		model.setViewName("/admin/edit_recipe_type");
		if(recipeTypeOpt.isPresent()) {
			model.addObject("recipeType", recipeTypeOpt.get());
		} else {
			logger.info("Unable to Edit Recipe Type");
		}
		return model;
	}

	@RequestMapping(value = "/updateRecipeType", method = RequestMethod.POST)
	public String updateRecipeType(@ModelAttribute("recipeType") RecipeType recipeType, BindingResult result) {
    	logger.info("updateRecipeType: " + recipeType.toString());
    	RecipeType dbRecipeType = null;
    	Optional<RecipeType> recipeTypeOpt = recipeTypeRepository.findById(recipeType.getId().toString());
		if (recipeTypeOpt != null) {
			dbRecipeType = recipeTypeOpt.get();
			dbRecipeType.setName(recipeType.getName());
			dbRecipeType.setShortDescription(recipeType.getShortDescription());
			dbRecipeType.setDescription(recipeType.getDescription());
			dbRecipeType.setSequence(recipeType.getSequence());
			dbRecipeType.setLastUpdatedBy("Satish");
			dbRecipeType.setLastUpdatedDateTime(new Date());
			recipeTypeRepository.save(dbRecipeType);
		} else {
			logger.info("Unable to update Recipe Type");
		}
		return "redirect:/admin/listRecipeTypes";
	}

}
