package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Fryer;
import com.nala.model.User;
import com.nala.repository.FryerRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class FryerController {

	private static final Logger logger = LoggerFactory.getLogger(FryerController.class);

	@Autowired
	FryerRepository fryerRepository;
	
	@RequestMapping("/list-fryers")
	public ModelAndView fryer(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "fryerSearchName", required = false) String fryerSearchName,
			@RequestParam(value = "fryerSearchStatus", required = false) String fryerSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(fryerSearchName==null) {
			fryerSearchName = "";
		}
		if(fryerSearchStatus==null) {
			fryerSearchStatus = "";
		}
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Fryer> pageFryer = fryerRepository.search(fryerSearchName, fryerSearchStatus, paging);
		model.addObject("fryerList", pageFryer.getContent());
		model.addObject("currentPage", pageFryer.getNumber());
		model.addObject("totalItems", pageFryer.getTotalElements());
		model.addObject("totalPages", pageFryer.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageFryer.getTotalElements()) ? pageFryer.getTotalElements() : (pageNo * pageSize)) : pageFryer.getTotalElements() );
		model.addObject("totalSize", pageFryer.getTotalElements());
		model.addObject("noOfPages", pageFryer.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "fryers");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_fryer_grid_n");
		} else {
			model.setViewName("/admin/fryer_list");
		}
		return model;
		
	}

	@RequestMapping("/addFryer")
	public ModelAndView addFryer() {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Fryer());
		model.setViewName("/ajaxfiles/add_fryer_n");
		return model;
	}

	@RequestMapping(value = "/saveFryer", method = RequestMethod.POST)
	public String addFryer(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "fryerSearchName", required = false) String fryerSearchName,
			@RequestParam(value = "fryerSearchStatus", required = false) Boolean fryerSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("fryer") Fryer fryer, BindingResult result) throws IOException {
		logger.info("save fryer: " + fryer.toString());
		
		List<Fryer> fryerList = fryerRepository.findAll();
		fryer.setSequence(fryerList.size() + 1);
		fryer.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
		fryer.setCreatedBy(loggedInUser.getSsoId());
		fryer.setCreatedDateTime(new Date());
		fryer.setLastUpdatedBy(loggedInUser.getSsoId());
		fryer.setLastUpdatedDateTime(new Date());
		fryerRepository.save(fryer);
		
		return "redirect:/admin/list-fryers";
	}

	@RequestMapping(value = { "/viewFryerInfo" }, method = RequestMethod.GET)
	public ModelAndView viewFryerInfo(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Fryer());
		Optional<Fryer> obj = fryerRepository.findById(id);
		Fryer fryer = null;
		if (obj.isPresent()) {
			fryer = obj.get();
		}
		
		try{
			
			if(fryer.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (fryer.getImage().getData()) );	
				
			} 
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		model.addObject("fryer", fryer);
		model.setViewName("/ajaxfiles/view_fryer_n");
		return model;
	}

	@RequestMapping(value = { "/openEditFryer" }, method = RequestMethod.GET)
	public ModelAndView openEditFryer(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Fryer());
		Fryer fryer = null;
		Optional<Fryer> obj = fryerRepository.findById(id);
		if (obj.isPresent()) {
			fryer = obj.get();
		}
		
		try{
			if(fryer.getImage()!=null){
			 model.addObject("image", Base64.getEncoder().encodeToString (fryer.getImage().getData()) );
			}
			}catch(Exception e) {
				e.printStackTrace();
			}	
		
		model.addObject("fryer", fryer);
		model.addObject("command", new Fryer());
		model.setViewName("/ajaxfiles/edit_fryer_n");
		return model;
	}

	@RequestMapping(value = "/updateFryer", method = RequestMethod.POST)
	public String editFryer(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "fryerSearchName", required = false) String fryerSearchName,
			@RequestParam(value = "fryerSearchStatus", required = false) Boolean fryerSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = false) String id,
			@ModelAttribute("fryer") Fryer fryer, BindingResult result) {
		logger.info("save fryer: " + fryer.toString());
		Fryer dbFryer = null;
		//System.out.println("fryer.getId().toString()==>"+fryer.getId());
		
		
		//System.out.println("ID==>"+id);
		
		Optional<Fryer> obj = fryerRepository.findById(fryer.getId().toString());
		if (obj.isPresent()) {
			dbFryer = obj.get();
			dbFryer.setName(fryer.getName());
			dbFryer.setDescription(fryer.getDescription());
			dbFryer.setCreatedBy(loggedInUser.getSsoId());
			dbFryer.setCreatedDateTime(new Date());
			dbFryer.setLastUpdatedBy(loggedInUser.getSsoId());
			dbFryer.setLastUpdatedDateTime(new Date());
		}
		fryerRepository.save(dbFryer);
		return "redirect:/admin/list-fryers";
	}

	@RequestMapping(value = { "/openDeleteFryer" }, method = RequestMethod.GET)
	public ModelAndView openDeleteFryer(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		Fryer fryer = null;
		Optional<Fryer> obj = fryerRepository.findById(id);
		if (obj.isPresent()) {
			fryer = obj.get();
		}
		model.addObject("fryer", fryer);
		model.addObject("command", new Fryer());
		model.setViewName("/ajaxfiles/delete_fryer_n");
		return model;
	}

	@RequestMapping(value = { "/deleteFryer" }, method = RequestMethod.POST)
	public String deleteFryer(Device device,
			@RequestParam(value = "fryerSearchName", required = false) String fryerSearchName,
			@RequestParam(value = "fryerSearchStatus", required = false) Boolean fryerSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("fryer") Fryer fryer, BindingResult result) {		
		fryerRepository.deleteById(id);
		return "redirect:/admin/list-fryers";
	}

}
