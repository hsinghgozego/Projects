package com.nala.controller;

import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Section;
import com.nala.model.Spatula;
import com.nala.model.SpatulaType;
import com.nala.model.User;
import com.nala.repository.SectionRepository;
import com.nala.repository.SpatulaTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class SectionController {

	private static final Logger logger = LoggerFactory.getLogger(SectionController.class);

	@Autowired
	SectionRepository sectionRepository;

	@RequestMapping("/list-sections")
	public ModelAndView listSections(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "sectionSearchName", required = false) String sectionSearchName,
			@RequestParam(value = "sectionSearchStatus", required = false) String sectionSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {

		ModelAndView model = new ModelAndView();
		if (pageNo == null || pageNo < 1) {
			pageNo = 1;
		}
		if (pageSize == null || pageSize < 0) {
			pageSize = 10;
		}
		if (sectionSearchName == null) {
			sectionSearchName = "";
		}
		if (sectionSearchStatus == null) {
			sectionSearchStatus = "";
		}

		Pageable paging = PageRequest.of(pageNo - 1, pageSize);
		Page<Section> pageSection = sectionRepository.search(sectionSearchName, sectionSearchStatus, paging);
		// System.out.println("pageUtensilType.getContent()>>"+pageUtensilType.getContent());
		model.addObject("sctionList", pageSection.getContent());
		model.addObject("currentPage", pageSection.getNumber());
		model.addObject("totalItems", pageSection.getTotalElements());
		model.addObject("totalPages", pageSection.getTotalPages());

		model.addObject("startNo", (pageNo > 1) ? ((pageNo - 1) * pageSize) + 1 : 1);
		model.addObject("endNo",
				(pageNo > 1) ? (((pageNo * pageSize) > pageSection.getTotalElements())
						? pageSection.getTotalElements()
						: (pageNo * pageSize)) : pageSection.getTotalElements());
		model.addObject("totalSize", pageSection.getTotalElements());
		model.addObject("noOfPages", pageSection.getTotalPages());
		model.addObject("pno", pageNo);

		model.addObject("urlPage", "sections");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_section_grid_n");
		} else {
			model.setViewName("/admin/section_list");
		}

		return model;
	}

	@RequestMapping("/addSection")
	public ModelAndView addSection() {

		ModelAndView model = new ModelAndView();
		model.addObject("command", new Section());
		model.setViewName("/ajaxfiles/add_section_n");
		return model;
	}

	@RequestMapping(value = "/saveSection", method = RequestMethod.POST)
	public String saveSection(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "sectionSearchName", required = false) String sectionSearchName,
			@RequestParam(value = "sectionSearchStatus", required = false) String sectionSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("section") Section section, BindingResult result) {
		logger.info("save section: " + section.toString());
		// ]utensilType.setStatus("Active");
		section.setLastUpdatedBy(loggedInUser.getSsoId());
		section.setCreatedBy(loggedInUser.getSsoId());
		section.setCreatedDateTime(new Date());
		section.setLastUpdatedDateTime(new Date());
		sectionRepository.save(section);
		return "redirect:/admin/list-sections";
	}

	@RequestMapping(value = { "/openEditSection" }, method = RequestMethod.GET)
	public ModelAndView openEditUtensilType(@RequestParam(value = "id", required = true) String id) {

		// System.out.println("inside openEditUtensilType");
		ModelAndView model = new ModelAndView();
		model.addObject("command", new SpatulaType());

		Optional<Section> obj = sectionRepository.findById(id);
		Section section = null;
		if (obj.isPresent()) {
			section = obj.get();
		}

		model.addObject("section", section);
		model.addObject("command", new Section());
		model.setViewName("/ajaxfiles/edit_section_n");
		return model;
	}

	@RequestMapping(value = "/updateSection", method = RequestMethod.POST)
	public String editUtensilType(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "sectionSearchName", required = false) String sectionSearchName,
			@RequestParam(value = "sectionSearchStatus", required = false) String sectionSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("section") Section section, BindingResult result) {
		Section dbsection = null;
		Optional<Section> obj = sectionRepository.findById(section.getId().toString());
		if (obj.isPresent()) {
			dbsection = obj.get();
			dbsection.setName(section.getName());
			dbsection.setDescription(section.getDescription());
			dbsection.setStatus(section.getStatus());
			dbsection.setCreatedBy(loggedInUser.getSsoId());
			dbsection.setCreatedDateTime(new Date());
			dbsection.setLastUpdatedBy(loggedInUser.getSsoId());
			dbsection.setLastUpdatedDateTime(new Date());

		}
		sectionRepository.save(dbsection);
		return "redirect:/admin/list-sections";

	}
	
	@RequestMapping(value = { "/viewSectionInfo" }, method = RequestMethod.GET)
	public ModelAndView viewSectionInfo(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Spatula());
		Optional<Section> obj = sectionRepository.findById(id);
		Section section = null;
		if (obj.isPresent()) {
			section = obj.get();
		}
		model.addObject("section", section);
		model.setViewName("/ajaxfiles/view_section_n");
		return model;
	}

	@RequestMapping(value = { "/openDeleteSection" }, method = RequestMethod.GET)
	public ModelAndView openDeleteSpatulaType(@RequestParam(value = "id", required = true) String id) {
		// System.out.println("Inside openDeleteUtensilType java ");
		ModelAndView model = new ModelAndView();

		Optional<Section> obj = sectionRepository.findById(id);
		Section section = null;
		if (obj.isPresent()) {
			section = obj.get();
		}

		model.addObject("section", section);
		model.addObject("command", new Section());
		model.setViewName("/ajaxfiles/delete_section_n");
		return model;
	}

	@RequestMapping(value = { "/deleteSection" }, method = RequestMethod.POST)
	public String deleteUtensilType(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "sectionSearchName", required = false) String sectionSearchName,
			@RequestParam(value = "sectionSearchStatus", required = false) String sectionSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("section") Section section, BindingResult result) {
		sectionRepository.deleteById(id);
		return "redirect:/admin/list-sections";
	}

}
