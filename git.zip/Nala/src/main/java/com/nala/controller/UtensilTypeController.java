package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.User;
import com.nala.model.UtensilType;
import com.nala.repository.UtensilTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class UtensilTypeController {

	private static final Logger logger = LoggerFactory.getLogger(UtensilTypeController.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	UtensilTypeRepository utensilTypeRepository;
	
	@RequestMapping("/list-utensilTypes")
	public ModelAndView listUtensilType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilTypeSearchName", required = false) String utensilTypeSearchName,
			@RequestParam(value = "utensilTypeSearchTypeId", required = false) String utensilTypeSearchTypeId,
			@RequestParam(value = "utensilTypeSearchStatus", required = false) String utensilTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(utensilTypeSearchName==null) {
			utensilTypeSearchName = "";
		}
		if(utensilTypeSearchTypeId==null) {
			utensilTypeSearchTypeId = "";
		}
		if(utensilTypeSearchStatus==null) {
			utensilTypeSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<UtensilType> pageUtensilType = utensilTypeRepository.search(utensilTypeSearchName, utensilTypeSearchTypeId, utensilTypeSearchStatus, paging);
		//System.out.println("pageUtensilType.getContent()>>"+pageUtensilType.getContent());
		model.addObject("utensilTypeList", pageUtensilType.getContent());
		model.addObject("currentPage", pageUtensilType.getNumber());
		model.addObject("totalItems", pageUtensilType.getTotalElements());
		model.addObject("totalPages", pageUtensilType.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageUtensilType.getTotalElements()) ? pageUtensilType.getTotalElements() : (pageNo * pageSize)) : pageUtensilType.getTotalElements() );
		model.addObject("totalSize", pageUtensilType.getTotalElements());
		model.addObject("noOfPages", pageUtensilType.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "utensilTypes");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_utensilType_grid_n");
		} else {
			model.setViewName("/admin/utensilType_list");
		}
		
		
		return model;
	}

	
	@RequestMapping("/addUtensilType")
	public ModelAndView addUtensilType() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new UtensilType());
		model.setViewName("/ajaxfiles/add_utensilType_n");
		return model;
	}

	@RequestMapping(value = "/saveUtensilType", method = RequestMethod.POST)
	public String saveUtensilType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilTypeSearchName", required = false) String utensilTypeSearchName,
			@RequestParam(value = "utensilTypeSearchTypeId", required = false) String utensilTypeSearchTypeId,
			@RequestParam(value = "utensilTypeSearchStatus", required = false) Boolean utensilTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("utensilType") UtensilType utensilType, BindingResult result) {
		logger.info("save utensilType: " + utensilType.toString());
		List<UtensilType> utensilTypeList = utensilTypeRepository.findAll();
		//]utensilType.setStatus("Active");
		utensilType.setSequence(utensilTypeList.size() + 1);
		utensilType.setCreatedBy(loggedInUser.getSsoId());
		utensilType.setCreatedDateTime(new Date());
		utensilType.setLastUpdatedBy(loggedInUser.getSsoId());
		utensilType.setLastUpdatedDateTime(new Date());
		utensilTypeRepository.save(utensilType);
		return "redirect:/admin/list-utensilTypes";
		

	}
	
	
	@RequestMapping(value = { "/openEditUtensilType" }, method = RequestMethod.GET)
	public ModelAndView openEditUtensilType(@RequestParam(value = "id", required = true) String id) {
	
		//System.out.println("inside openEditUtensilType");
		ModelAndView model = new ModelAndView();
		model.addObject("command", new UtensilType());
		
		Optional<UtensilType> obj = utensilTypeRepository.findById(id);
		UtensilType utensilType = null;
		if (obj.isPresent()) {
			utensilType = obj.get();
		}
		
		model.addObject("utensilType", utensilType);
		model.addObject("command", new UtensilType());
		model.setViewName("/ajaxfiles/update_utensilType_n");
		return model;
	}
	
	
	@RequestMapping(value = "/updateUtensilType", method = RequestMethod.POST)
	public String editUtensilType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilTypeSearchName", required = false) String utensilTypeSearchName,
			@RequestParam(value = "utensilTypeSearchTypeId", required = false) String utensilTypeSearchTypeId,
			@RequestParam(value = "utensilTypeSearchStatus", required = false) Boolean utensilTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("utensilType") UtensilType utensilType, BindingResult result) {
		logger.info("save utensilType: " + utensilType.toString());

		//System.out.println("inside editUtensilType");
		
		UtensilType dbUtensilType = null;
		Optional<UtensilType> obj = utensilTypeRepository.findById(utensilType.getId().toString());
		if (obj.isPresent()) {
		dbUtensilType = obj.get();
		dbUtensilType.setName(utensilType.getName());
		dbUtensilType.setStatus(utensilType.getStatus());
		dbUtensilType.setTypeid(utensilType.getTypeid());
		dbUtensilType.setCreatedBy(loggedInUser.getSsoId());
		dbUtensilType.setCreatedDateTime(new Date());
		dbUtensilType.setLastUpdatedBy(loggedInUser.getSsoId());
		dbUtensilType.setLastUpdatedDateTime(new Date());
		
		}
		utensilTypeRepository.save(dbUtensilType);
		return "redirect:/admin/list-utensilTypes";
		
		
	}
	
	
	@RequestMapping(value = { "/openDeleteUtensilType" }, method = RequestMethod.GET)
	public ModelAndView openDeleteUtensilType(@RequestParam(value = "id", required = true) String id) {
		//System.out.println("Inside openDeleteUtensilType java ");
		ModelAndView model = new ModelAndView();
		
		Optional<UtensilType> obj = utensilTypeRepository.findById(id);
		UtensilType utensilType = null;
		if (obj.isPresent()) {
			utensilType = obj.get();
		}
		
		
		model.addObject("utensilType", utensilType);
		model.addObject("command", new UtensilType());
		model.setViewName("/ajaxfiles/delete_utensilType_n");
		return model;
	}
	
	@RequestMapping(value = { "/deleteUtensilType" }, method = RequestMethod.POST)
	public String deleteUtensilType(Device device,
			@RequestParam(value = "utensilTypeSearchName", required = false) String utensilTypeSearchName,
			@RequestParam(value = "utensilTypeSearchTypeId", required = false) String utensilTypeSearchTypeId,
			@RequestParam(value = "utensilTypeSearchStatus", required = false) Boolean utensilTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("utensilType") UtensilType utensilType, BindingResult result) {
		
		
		//System.out.println("Inside deleteUtensilType java ");
		
		utensilTypeRepository.deleteById(id);
		return "redirect:/admin/list-utensilTypes";
		

	}
	
	
}
