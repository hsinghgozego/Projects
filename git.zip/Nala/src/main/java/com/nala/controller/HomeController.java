package com.nala.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.nala.model.User;
import com.nala.repository.UserRepository;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@SessionAttributes({ "loggedInUser" })
public class HomeController {

    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	UserRepository userRepository;
	
	@Lazy
	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home(Locale locale, Model model) {
    	logger.info("Home page");
        return "welcome";
    }
	@RequestMapping(value = { "/access_denied" })
	public String accessDeniedPage(ModelMap model) {
		return "accessDenied_n";
	}
	

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/login", method = {RequestMethod.GET})
	public String loginPage(HttpServletRequest request, ModelMap model,
			Authentication authentication) {
    	logger.info("HomeController login");
		if (isCurrentAuthenticationAnonymous()) {
			return "login";
		} else {

			boolean isSuperAdmin = false;
			boolean isAdmin = false;
			boolean isUser = false;

			List<GrantedAuthority> authorities = (List<GrantedAuthority>) authentication.getAuthorities();
			for (GrantedAuthority grantedAuthority : authorities) {
				if (grantedAuthority.getAuthority().equals("ROLE_USER")) {
					isUser = true;
					break;
				} else if (grantedAuthority.getAuthority().equals("ROLE_ADMIN")) {
					isAdmin = true;
					break;
				} else if (grantedAuthority.getAuthority().equals("ROLE_SUPERADMIN")) {
					isSuperAdmin = true;
					break;
				}
			}
			if (isSuperAdmin || isAdmin || isUser) {
				String userName = null;
				Object principal = authentication.getPrincipal();
				if (principal instanceof UserDetails) {
					userName = ((UserDetails) principal).getUsername();
				} else {
					userName = principal.toString();
				}
				User tmpUser = userRepository.findUsersBySSOId(userName);
				HttpSession session = request.getSession(true);
				if (tmpUser != null) {
					if (session.getAttribute("loggedInUser") == null) {
						session.setAttribute("loggedInUser", tmpUser);
					}
				} else {
					throw new IllegalStateException();
				}
				return "redirect:/admin/dashboard";
			} else {
				throw new IllegalStateException();
			}
		}
	}

	/**
	 * This method returns true if users is already authenticated [logged-in], else
	 * false.
	 */
	private boolean isCurrentAuthenticationAnonymous() {
		final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return authenticationTrustResolver.isAnonymous(authentication);
	}

}
