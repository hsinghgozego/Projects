package com.nala.controller.demo;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.enums.OrderPreparingStatusEnum;
import com.nala.model.User;
import com.nala.model.demo.DemoOrders;
import com.nala.model.demo.DemoRecipes;
import com.nala.repository.demo.DemoOrdersRepository;
import com.nala.repository.demo.DemoRecipesRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class OrderDemoController {

	@Autowired
	DemoOrdersRepository demoOrdersRepository;
	
	@Autowired
	DemoRecipesRepository demoRecipesRepository;
	
	private static final String RECIPE_NAME="Recipe Name";
	private static final String ORDER_STATUS="Order Status";
	private static final String ASENDING="Asc";
	private static final String DESENDING="Desc";

	@RequestMapping("/list-orders")
	public ModelAndView listOrders(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "recipeSearchName", required = false) String recipeSearchName,
			@RequestParam(value = "orderSearchStatus", required = false) String orderSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) String sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if (pageNo == null || pageNo < 1) {
			pageNo = 1;
		}
		if (pageSize == null || pageSize < 0) {
			pageSize = 10;
		}
		if (recipeSearchName == null) {
			recipeSearchName = "";
		}
		if (orderSearchStatus == null) {
			orderSearchStatus = "";
		}
		if (sortBy == null) {
			sortBy = "";
		}
		if (sortOrder == null) {
			sortOrder = "";
		}
	
		Pageable paging = PageRequest.of(pageNo - 1, pageSize);
		Page<DemoOrders> OrderType = demoOrdersRepository.search(recipeSearchName, orderSearchStatus,paging);
		List<DemoOrders>  modifiableList = new ArrayList<DemoOrders>(OrderType.getContent());
		if(sortBy.equalsIgnoreCase(RECIPE_NAME) && sortOrder.equals(ASENDING)) {
			modifiableList.sort((DemoOrders d1, DemoOrders d2) -> d1.getRecipeName().compareTo(d2.getRecipeName()));
		} else if(sortBy.equalsIgnoreCase(RECIPE_NAME) && sortOrder.equals(DESENDING)) {
			modifiableList.sort((DemoOrders d1, DemoOrders d2) -> d2.getRecipeName().compareTo(d1.getRecipeName()));
		} else if(sortBy.equalsIgnoreCase(ORDER_STATUS) && sortOrder.equals(ASENDING)) {
			modifiableList.sort((DemoOrders d1, DemoOrders d2) -> d1.getStatus().compareTo(d2.getStatus()));
		} else if(sortBy.equalsIgnoreCase(ORDER_STATUS) && sortOrder.equals(DESENDING)) {
			modifiableList.sort((DemoOrders d1, DemoOrders d2) -> d2.getStatus().compareTo(d1.getStatus()));
		} else {
			modifiableList.sort((DemoOrders d1, DemoOrders d2) -> d2.getCreatedDateTime().compareTo(d1.getCreatedDateTime()));
		}
		List<DemoRecipes> recipesList= demoRecipesRepository.getRecipesByActiveStatus(true);
		model.addObject("recipesList", recipesList); 
		model.addObject("orderList", modifiableList);
		model.addObject("currentPage", OrderType.getNumber());
		model.addObject("totalItems", OrderType.getTotalElements());
		model.addObject("totalPages", OrderType.getTotalPages());

		model.addObject("startNo", (pageNo > 1) ? ((pageNo - 1) * pageSize) + 1 : 1);
		model.addObject("endNo",
				(pageNo > 1) ? (((pageNo * pageSize) > OrderType.getTotalElements())
						? OrderType.getTotalElements()
						: (pageNo * pageSize)) : OrderType.getTotalElements());
		model.addObject("totalSize", OrderType.getTotalElements());
		model.addObject("noOfPages", OrderType.getTotalPages());
		model.addObject("pno", pageNo);

		model.addObject("urlPage", "Order");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/order_list");
		} else {
			model.setViewName("/admin/order");
		}
		return model;
	}

	@RequestMapping(value = "/newOrder/{id}", method = RequestMethod.GET, headers = "Accept=*/*")
	public ModelAndView newOrder(@SessionAttribute(value = "loggedInUser") User loggedInUser,
			@PathVariable("id") String id) {
		Optional<DemoRecipes> demoRecipe=demoRecipesRepository.findById(id);
		DemoOrders demoOrder = new DemoOrders();
		demoOrder.setRecipeName(demoRecipe.get().getRecipeName());
		demoOrder.setRecipeId(demoRecipe.get().getRecipeId());
		demoOrder.setActive(true);
		demoOrder.setQty(1);
		demoOrder.setStatus(OrderPreparingStatusEnum.CREATED.getStatusDescription());
		Random rnd = new Random();
		demoOrder.setOrderId(100000 + rnd.nextInt(900000));
		demoOrder.setActive(true);
		demoOrder.setWaitingTime(10);
		demoOrder.setCreatedBy(loggedInUser.getSsoId());
		demoOrder.setCreatedDateTime(new Date());
		demoOrder.setLastUpdatedBy(loggedInUser.getSsoId());
		demoOrder.setLastUpdatedDateTime(new Date());
		demoOrdersRepository.save(demoOrder);
		List<DemoOrders> orderList =demoOrdersRepository.findAll(Sort.by(Sort.Direction.DESC, "createdDateTime"));
		ModelAndView model = new ModelAndView();
		model.addObject("orderList", orderList);
		model.setViewName("/ajaxfiles/order_list");
		return model;
	}

}
