package com.nala.controller;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.User;
import com.nala.model.UserProfile;
import com.nala.repository.UserProfileRepository;
import com.nala.repository.UserRepository;

@Controller
@SessionAttributes({ "user" })
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserProfileRepository userProfileRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices;

	@RequestMapping("/admin/listUserProfileAction")
	public ModelAndView listUserProfile() {
		List<UserProfile> userProfileList = userProfileRepository.findAll();
		return new ModelAndView("/admin/list-user-profile", "userProfileList", userProfileList);
	}

	@RequestMapping(value = "/admin/userProfileAction", method = RequestMethod.GET)
	public ModelAndView userProfile() {

		ModelAndView model = new ModelAndView();
		model.addObject("command", new UserProfile());
		model.setViewName("/admin/add-user-profile");
		return model;
	}


	/**
	 * This method handles logout requests. Toggle the handlers if you are
	 * RememberMe functionality is useless in your app.
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			// new SecurityContextLogoutHandler().logout(request, response,
			// auth);
			persistentTokenBasedRememberMeServices.logout(request, response, auth);
			SecurityContextHolder.getContext().setAuthentication(null);
		}
		return "redirect:/login";
	}

	@RequestMapping(value = "/admin/saveProfile", method = RequestMethod.POST)
	@Transactional
	public String saveProfile(@ModelAttribute("userProfile") UserProfile userProfile, BindingResult result) {

		UserProfile dbUserProfile = userProfileRepository.findByType(userProfile.getType());
		if (dbUserProfile != null) {
			logger.info("Error action name already exists");
		} else {
			userProfile.setCreatedBy("Satish");
			userProfile.setLastUpdatedBy("Satish");
			userProfile.setCreatedDateTime(new Date());
			userProfile.setLastUpdatedDateTime(new Date());
			userProfileRepository.save(userProfile);
		}
		return "redirect:/listUserProfileAction";
	}

	@RequestMapping(value = "/admin/newUser", method = RequestMethod.GET)
	public ModelAndView newUser() {
		List<UserProfile> userProfileList = userProfileRepository.findAll();
		ModelAndView model = new ModelAndView();
		model.addObject("userProfileList", userProfileList);
		model.addObject("command", new User());
		model.setViewName("/admin/add_user");
		return model;
	}

	@RequestMapping(value = "/access_denied", method = RequestMethod.GET)
	public ModelAndView accessDenied() {
		ModelAndView model = new ModelAndView();
		model.setViewName("accessDenied_c");
		return model;
	}

	@RequestMapping(value = "/admin/saveUser", method = RequestMethod.POST)
	@Transactional
	public String saveUser(@ModelAttribute("user") User user, BindingResult result) {

		User dbUser = userRepository.findUsersBySSOId(user.getSsoId());
		if (dbUser != null) {
			logger.info("Error action name already exists");
		} else {
			Optional<UserProfile> userProfileOpt = userProfileRepository.findById("5fc0a119359a8f258d71df29");
			if (userProfileOpt.isPresent()) {
				Set<UserProfile> userProfiles = new HashSet<>();
				userProfiles.add(userProfileOpt.get());
				user.setUserProfiles(userProfiles);
				user.setCreatedBy("Satish");
				user.setLastUpdatedBy("Satish");
				user.setCreatedDateTime(new Date());
				user.setLastUpdatedDateTime(new Date());
				userRepository.save(user);
			} else {
				logger.info("Unable to Save User");
			}
		}
		return "redirect:/admin/listUsers";
	}

	@RequestMapping("/admin/listUsers")
	public ModelAndView listUsers() {
		List<User> userList = userRepository.findAll();
		return new ModelAndView("/admin/users_list", "userList", userList);
	}

}
