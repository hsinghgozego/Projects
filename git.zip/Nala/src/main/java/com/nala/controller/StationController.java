package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Burner;
import com.nala.model.Station;
import com.nala.model.User;
import com.nala.model.Utensil;
import com.nala.repository.StationRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class StationController {

	
	@Autowired
	StationRepository stationRepository;
	
	//list-stations
	@RequestMapping("/list-stations")
	public ModelAndView listStation(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stationSearchName", required = false) String stationSearchName,
			@RequestParam(value = "stationSearchType", required = false) String stationSearchType,
			@RequestParam(value = "stationSearchStatus", required = false) String stationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax){
		
		Iterable<Station> stationList = stationRepository.findAll();
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Station());
		model.addObject("stationList", stationList);
		model.setViewName("/admin/station_list");
		return model;
				
	}
	
	
	@RequestMapping("/addStation")
	public ModelAndView addStation() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Station());
		
		model.setViewName("/ajaxfiles/add_station_n");
		return model;
		
	}
	
	
	
	@RequestMapping(value = "/saveStation", method = RequestMethod.POST)
	public String saveStation(@SessionAttribute("loggedInUser") User loggedInUser,
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("station") Station station, BindingResult result) throws IOException {
		List<Station> burberList = stationRepository.findByName(station.getName());
		
			if(!image.isEmpty()) {
			
					station.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
			
			}
		
		
		if (burberList.size() > 0) {
			System.out.println("Error: Station Name Already Exist");
		} else {
			System.out.println("Ok: Adding New Station");
			station.setCreatedBy(loggedInUser.getSsoId());
			station.setLastUpdatedBy(loggedInUser.getSsoId());
			station.setCreatedDateTime(new Date());
			station.setLastUpdatedDateTime(new Date());
			stationRepository.save(station);
		}
		return "redirect:/admin/list-stations";
	}
	
	
	//viewStationInfo
	@RequestMapping(value = { "/viewStationInfo" }, method = RequestMethod.GET)
	public ModelAndView viewStationInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Utensil());
		
				
		Optional<Station> obj = stationRepository.findById(id);
		Station station = null;
		if (obj.isPresent()) {
			station = obj.get();
		}
			
		model.addObject("station", station);
		try{
			
			if(station.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (station.getImage().getData()) );	
				
			} 
			 
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		 
		model.setViewName("/ajaxfiles/view_station_info");
		return model;
	}
	
	//openEditStation
	@RequestMapping(value = { "/openEditStation" }, method = RequestMethod.GET)
	public ModelAndView openEditStation(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		
		//model.addObject("command", new Utensil());
		
		Optional<Station> obj = stationRepository.findById(id);
		Station station = null;
		if (obj.isPresent()) {
			station = obj.get();
		}
		
		model.addObject("station", station);
		model.addObject("command", new Station());
		//model.addObject("command", new BurnerType());
		
		try{
			if(station.getImage()!=null){
			 model.addObject("image", Base64.getEncoder().encodeToString (station.getImage().getData()) );
			}
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		//List<UtensilType> utensilTypeList = utensilTypeRepository.findAll();
	//	model.addObject("utensilTypeList", utensilTypeList);
		
		
		model.setViewName("/ajaxfiles/update_station_n");
		return model;
	}
	
	
	//updateStation
	@RequestMapping(value = "/updateStation", method = RequestMethod.POST)
	public String updateStation(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stationSearchName", required = false) String stationSearchName,
			@RequestParam(value = "stationSearchType", required = false) String stationSearchType,
			@RequestParam(value = "stationSearchStatus", required = false) Boolean utensilSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("station") Station station, BindingResult result) throws IOException {
		//logger.info("save utensil: " + utensil.toString());
		
		Station dbStation = null;
		Optional<Station> obj = stationRepository.findById(station.getId().toString());
		if (obj.isPresent()) {
		dbStation = obj.get();
		
		try {
					
			if(!image.isEmpty()) {
				
				dbStation.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		dbStation.setName(station.getName());
		dbStation.setStatus(station.getStatus());
		dbStation.setDescription(station.getDescription());
		dbStation.setMapToBurner(station.getMapToBurner()); 
		dbStation.setMapToRobot(station.getMapToRobot());
		dbStation.setMapToFryer(station.getMapToFryer());
		dbStation.setMapToLiquidBin(station.getMapToLiquidBin());
		dbStation.setMapToServingStation(station.getMapToServingStation());
		dbStation.setMapToHoldingStation(station.getMapToHoldingStation());
		
		
		//
		dbStation.setCreatedBy(loggedInUser.getSsoId());
		dbStation.setCreatedDateTime(new Date());
		dbStation.setLastUpdatedBy(loggedInUser.getSsoId());
		dbStation.setLastUpdatedDateTime(new Date());
		
		}
		stationRepository.save(dbStation);
		return "redirect:/admin/list-stations";
		
		
	}
	
	
	//openDeleteStation
	@RequestMapping(value = { "/openDeleteStation" }, method = RequestMethod.GET)
	public ModelAndView openDeleteStation(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<Station> obj = stationRepository.findById(id);
		Station station = null;
		if (obj.isPresent()) {
			station = obj.get();
		}
			
		model.addObject("station", station);
		model.addObject("command", new Station());
		model.setViewName("/ajaxfiles/delete_station_n");
		return model;
	}
	
	
	//deleteStation
	@RequestMapping(value = { "/deleteStation" }, method = RequestMethod.POST)
	public String deleteStation(Device device,
			@RequestParam(value = "stationSearchName", required = false) String stationSearchName,
			@RequestParam(value = "stationSearchType", required = false) String stationSearchType,
			@RequestParam(value = "stationSearchStatus", required = false) Boolean stationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("station") Station station, BindingResult result) {
		
		
		stationRepository.deleteById(id);
		return "redirect:/admin/list-stations";
		

	}
	
	
}
