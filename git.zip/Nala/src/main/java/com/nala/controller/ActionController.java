package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Action;
import com.nala.model.ActionType;
import com.nala.model.Spatula;
import com.nala.model.User;
import com.nala.repository.ActionRepository;
import com.nala.repository.ActionTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class ActionController {

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	ActionRepository actionRepository;

	@Autowired
	ActionTypeRepository actionTypeRepository;

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping("/list-actions")
	public ModelAndView listAactions() {
		ModelAndView model = new ModelAndView();
		model.setViewName("/admin/action_list");
		return model;
	}
	
	@RequestMapping("/addAction1")
	public ModelAndView addAction1() {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Spatula());
		model.setViewName("/ajaxfiles/add_action_n");
		return model;
	}
	
	@RequestMapping("/addAction")
	public ModelAndView addAction() {
		Iterable<ActionType> actionTypeList = actionTypeRepository.findAll();
		ModelAndView model = new ModelAndView();
		model.addObject("actionTypeList", actionTypeList);
		model.addObject("command", new Action());
		model.setViewName("/admin/new_action");
		return model;
	}

	@RequestMapping(value = "/saveAction", method = RequestMethod.POST)
	@Transactional
	public String saveAction(@SessionAttribute("loggedInUser") User loggedInUser, 
			@ModelAttribute("action") Action action, BindingResult result) {
    	logger.info("saveAction: " + action.toString());
		List<Action> actionList = actionRepository.findByName(action.getName());
		if (actionList.size() > 0) {
			logger.info("Error action name already exists");
		} else {
			ActionType actionType = null;
			Optional<ActionType> obj = actionTypeRepository.findById(action.getId().toString());
			if (obj.isPresent()) {
				actionType = obj.get();
			}
			if(action.getActionType()!=null && action.getActionType().getId()!=null) {
				Optional<ActionType> obj2 = actionTypeRepository.findById(action.getActionType().getId().toString());
				if (obj2.isPresent()) {
					actionType = obj2.get();
					action.setActionType(actionType);
				}
			} else {
				action.setActionType(null);
			}
			action.setCreatedBy(loggedInUser.getSsoId());
			action.setLastUpdatedBy(loggedInUser.getSsoId());
			action.setCreatedDateTime(new Date());
			action.setLastUpdatedDateTime(new Date());
			actionRepository.save(action);
		}
		return "redirect:/admin/listActions";
	}

	@RequestMapping(value = "/updateAction", method = RequestMethod.POST)
	@Transactional
	public String updateAction(@SessionAttribute("loggedInUser") User loggedInUser, @ModelAttribute("action") Action action, BindingResult result) {
    	logger.info("updateAction: " + action.toString());
		Action obj = null;
		Optional<Action> objOpt = actionRepository.findById(action.getId().toString());
		if (objOpt.isPresent()) {
			obj = objOpt.get();
			obj.setName(action.getName());
			obj.setDescription(action.getDescription());
			ActionType actionType = null;
			Optional<ActionType> actionTypeOpt = actionTypeRepository.findById(action.getId().toString());
			if (actionTypeOpt.isPresent()) {
				actionType = actionTypeOpt.get();
			}
			if(action.getActionType()!=null && action.getActionType().getId()!=null) {
				Optional<ActionType> obj2 = actionTypeRepository.findById(action.getActionType().getId().toString());
				if (obj2.isPresent()) {
					actionType = obj2.get();
					obj.setActionType(actionType);
				}
			} else {
				obj.setActionType(null);
			}
			obj.setLastUpdatedBy(loggedInUser.getSsoId());
			obj.setLastUpdatedDateTime(new Date());
			actionRepository.save(obj);
		} else {
			logger.info("Unable to update action");
		}
		return "redirect:/admin/listActions";
	}

	@RequestMapping(value = { "/editAction" }, method = RequestMethod.GET)
	public ModelAndView editAction(@RequestParam(value = "id", required = true) String id) {
    	logger.info("editAction id: " + id);
    	Action action = null;
    	Optional<Action> obj = actionRepository.findById(id);
    	if (obj.isPresent()) {
    		action = obj.get();
    	}
		ModelAndView model = new ModelAndView();
		Iterable<ActionType> actionTypeList = actionTypeRepository.findAll();
		model.addObject("actionTypeList", actionTypeList);
		model.addObject("action", action);
		model.addObject("command", new Action());
		model.setViewName("/admin/edit_action");
		return model;
	}

	@RequestMapping(value = { "/searchAction" }, method = RequestMethod.GET)
	public ModelAndView searchAction(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
    	logger.info("editAction name: " + name + " description: " + description);
		List<Action> actionList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			actionList = actionRepository.findActionsByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			actionList = actionRepository.findActionsByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			actionList = actionRepository.findActionsByRegexpDescription(description);
		}
		return new ModelAndView("/admin/action_list", "actionList", actionList);
	}

	@RequestMapping("/listActions")
	public ModelAndView listActions() {
		List<Action> actionList = actionRepository.findAll();
		return new ModelAndView("/admin/action_list", "actionList", actionList);
	}
	
	@RequestMapping("/securedlistActions")
	public ModelAndView securedlistActions() {
		List<Action> actionList = actionRepository.findAll();
		return new ModelAndView("/admin/action_list", "actionList", actionList);
	}

}
