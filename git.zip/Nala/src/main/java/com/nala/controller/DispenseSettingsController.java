package com.nala.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.DispenseSettings;
import com.nala.model.Ingredient;
import com.nala.model.User;
import com.nala.repository.DispenseSettingsRepository;
import com.nala.repository.IngredientRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class DispenseSettingsController {

	
	@Autowired
	IngredientRepository ingredientRepository;
	
	@Autowired
	DispenseSettingsRepository dispenseSettingsRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(IngredientController.class);

	@SuppressWarnings("unused")
	@RequestMapping(value = { "/listDispenseSettings" }, method = RequestMethod.GET)
	public ModelAndView listDispenseSettings(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "dispenseSettingsStart", required = false) String dispenseSettingsStart,
			@RequestParam(value = "dispenseSettingsSearchName", required = false) String dispenseSettingsSearchName,
			@RequestParam(value = "dispenseSettingsSearchType", required = false) String dispenseSettingsSearchType,
			@RequestParam(value = "dispenseSettingsSearchStatus", required = false) String dispenseSettingsSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax,
			@RequestParam(value = "id", required = true) String id) {
	

		ModelAndView model = new ModelAndView();
		
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		
		
		
		
	//	Page<DispenseSettings> pageDispenseSettings = dispenseSettingsRepository.search( dispenseSettingsStart, paging);
		
	//	model.addObject("dispenseSettingsList", (List<DispenseSettings>) pageDispenseSettings.getContent());
	//	model.addObject("currentPage", pageDispenseSettings.getNumber());
	//	model.addObject("totalItems", pageDispenseSettings.getTotalElements());
	//	model.addObject("totalPages", pageDispenseSettings.getTotalPages());
		
	//	model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
	//	model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageDispenseSettings.getTotalElements()) ? pageDispenseSettings.getTotalElements() : (pageNo * pageSize)) : pageDispenseSettings.getTotalElements() );
	//	model.addObject("totalSize", pageDispenseSettings.getTotalElements());
	//	model.addObject("noOfPages", pageDispenseSettings.getTotalPages());
	//	model.addObject("pno", pageNo);
		
	//	model.addObject("urlPage", "dispenseSettings");
		
		
		
		
		
		
		Optional<Ingredient> obj = ingredientRepository.findById(id);
		Ingredient ingredient = null;
		if (obj.isPresent()) {
			ingredient = obj.get();
		}
		
		model.addObject("ingredient", ingredient);
		model.addObject("command", new Ingredient());
			
		List<Ingredient> ingredientList = ingredientRepository.findAll();
		
		List<DispenseSettings> dispenseSettingsList = ingredient.getDispenseSettings() ;
		
		model.addObject("dispenseSettingsList", dispenseSettingsList);
		
		
		
		model.setViewName("/admin/dispenseSettings_list");
		
		
		
		return model;
	}
	
	
	//addDispenseSettings

		@RequestMapping("/addDispenseSettings")
		public ModelAndView addDispenseSettings(@RequestParam(value = "id", required = false) String id) {
			
			ModelAndView model = new ModelAndView();
			model.addObject("command", new DispenseSettings());
			
			Optional<Ingredient> obj = ingredientRepository.findById(id);
			Ingredient ingredient = null;
			if (obj.isPresent()) {
				ingredient = obj.get();
			}
			
			ObjectId ingredientId = ingredient.getId() ;
			
			model.addObject("ingredientId", ingredientId);
		    model.addObject("DispenseSettings",new DispenseSettings());

			model.setViewName("/ajaxfiles/add_dispenseSettings_n");
			return model;
		}
		
	
		//saveDispenseSettings
		@RequestMapping(value = "/saveDispenseSettings", method = RequestMethod.POST)
		public String saveDispenseSettings(Device device,
				@SessionAttribute(value="loggedInUser") User loggedInUser,
				@RequestParam(value = "dispenseSettingsSearchName", required = false) String dispenseSettingsSearchName,
				@RequestParam(value = "dispenseSettingsSearchType", required = false) String dispenseSettingsSearchType,
				@RequestParam(value = "dispenseSettingsSearchStatus", required = false) Boolean dispenseSettingsSearchStatus,
				@RequestParam(value = "sortBy", required = false) String sortBy,
				@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
				@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
				@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
				@RequestParam(value = "pageNo", required = false) Integer pageNo,
				@RequestParam(value = "pageSize", required = false) Integer pageSize, 
				@RequestParam(value = "ingredientId", required = false ) ObjectId ingredientId,
				@RequestParam(value = "id", required = false) String id,
				@ModelAttribute("dispenseSettings") DispenseSettings dispenseSettings, BindingResult result) throws IOException {
			
			logger.info("saveAction: " + dispenseSettings.toString());
			
			List<DispenseSettings> dispenseSettingsList = dispenseSettingsRepository.findAll();
				
			ObjectId oid = new ObjectId();

			dispenseSettings.setId( oid );
			
			dispenseSettings.setSequence(dispenseSettingsList.size() + 1);
			dispenseSettings.setCreatedBy(loggedInUser.getSsoId());
			dispenseSettings.setLastUpdatedBy(loggedInUser.getSsoId());
			dispenseSettings.setCreatedDateTime(new Date());
			dispenseSettings.setLastUpdatedDateTime(new Date());
			dispenseSettingsRepository.save(dispenseSettings);	
			
			Optional<Ingredient> obj = ingredientRepository.findById(id);
			Ingredient ingredient = null;
			if (obj.isPresent()) {
				ingredient = obj.get();
			}
			
			ingredient.setDispenseSettings(dispenseSettings);
			
			ingredientRepository.save(ingredient);

			return "redirect:/admin/listDispenseSettings?id="+id;
		}
		
		
		
		//openDeleteDispenseSettings
		@RequestMapping(value = { "/openDeleteDispenseSettings" }, method = RequestMethod.GET)
		public ModelAndView openDeleteDispenseSettings(@RequestParam(value = "id", required = true) String id,
														@RequestParam(value = "igid", required = true) String igid) {
			
			ModelAndView model = new ModelAndView();

			Optional<Ingredient> obj2 = ingredientRepository.findById(igid);
			Ingredient ingredient = null;
			if (obj2.isPresent()) {
				ingredient = obj2.get();
			}
				
			model.addObject("ingredient", ingredient);
			
			model.addObject("command", new Ingredient());
		
			model.addObject("ingredientid", igid);
			model.addObject("dispenseSettingsId", id);
			
			model.setViewName("/ajaxfiles/delete_dispenseSettings_n");
			return model;
		}
		
		
		
		//deleteDispenseSettings
		@RequestMapping(value = { "/deleteDispenseSettings" }, method = RequestMethod.POST)
		public String deleteDispenseSettings(Device device,
				@RequestParam(value = "dispenseSettingsSearchName", required = false) String dispenseSettingsSearchName,
				@RequestParam(value = "dispenseSettingsSearchType", required = false) String dispenseSettingsSearchType,
				@RequestParam(value = "dispenseSettingsSearchStatus", required = false) Boolean dispenseSettingsSearchStatus,
				@RequestParam(value = "sortBy", required = false) String sortBy,
				@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
				@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
				@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
				@RequestParam(value = "pageNo", required = false) Integer pageNo,
				@RequestParam(value = "pageSize", required = false) Integer pageSize, 
				@RequestParam(value = "id", required = false) String id,
				@RequestParam(value = "ingredientid", required = true) String ingredientid,
				@RequestParam(value = "dispenseSettingsId", required = true) String dispenseSettingsId,
				@ModelAttribute("ingredient") Ingredient ingredient, BindingResult result) {
				
			Optional<Ingredient> obj2 = ingredientRepository.findById(ingredientid);
			Ingredient ingredient2 = null;
			if (obj2.isPresent()) {
				ingredient2 = obj2.get();
			}
			List<DispenseSettings> dispenseSettingsList = ingredient2.getDispenseSettings() ;
			
			DispenseSettings dispenseSettings = new DispenseSettings();
			
			for (int i = 0; i < dispenseSettingsList.size(); i++)   
			{  
		
			if( dispenseSettingsList.get(i).getId().toString().equals(dispenseSettingsId) ) {
				
				dispenseSettings.setId(dispenseSettingsList.get(i).getId());
				dispenseSettings.setBulkFeedPercentage(dispenseSettingsList.get(i).getBulkFeedPercentage());
				dispenseSettings.setCreatedBy(dispenseSettingsList.get(i).getCreatedBy());
				dispenseSettings.setCreatedDateTime(dispenseSettingsList.get(i).getCreatedDateTime());
				dispenseSettings.setCutOfPercentage(dispenseSettingsList.get(i).getCutOfPercentage());
				dispenseSettings.setEnd(dispenseSettingsList.get(i).getEnd());
				dispenseSettings.setGapTimerSeconds(dispenseSettingsList.get(i).getGapTimerSeconds());
				dispenseSettings.setInchOffTimer(dispenseSettingsList.get(i).getInchOffTimer());
				dispenseSettings.setInchOnTimer(dispenseSettingsList.get(i).getInchOnTimer());
				dispenseSettings.setLastUpdatedBy(dispenseSettingsList.get(i).getLastUpdatedBy());
				dispenseSettings.setLastUpdatedDateTime(dispenseSettingsList.get(i).getLastUpdatedDateTime());
				dispenseSettings.setRPM(dispenseSettingsList.get(i).getRPM());
				dispenseSettings.setSequence(dispenseSettingsList.get(i).getSequence());
				dispenseSettings.setStart(dispenseSettingsList.get(i).getStart());
				dispenseSettings.setStatus(dispenseSettingsList.get(i).getStatus());
				
				
			}
			
			
			}
			
			
			ingredient2.removeDispenseSettings(dispenseSettings);
			
			ingredientRepository.save(ingredient2);
			
			return "redirect:/admin/listDispenseSettings?id="+ingredientid;
			

		}
		
		
		
		
		@RequestMapping(value = { "/openEditDispenseSettings" }, method = RequestMethod.GET)
		public ModelAndView openEditDispenseSettings(@RequestParam(value = "id", required = true) String id,
													@RequestParam(value = "igid", required = true) String igid) {
		
			
			
			Optional<Ingredient> obj2 = ingredientRepository.findById(igid);
			Ingredient ingredient = null;
			if (obj2.isPresent()) {
				ingredient = obj2.get();
			}
			List<DispenseSettings> dispenseSettingsList = ingredient.getDispenseSettings() ;
			
			DispenseSettings dispenseSettings = new DispenseSettings();
			
			for (int i = 0; i < dispenseSettingsList.size(); i++)   
			{  
		
			if( dispenseSettingsList.get(i).getId().toString().equals(id) ) {
				
				dispenseSettings.setId(dispenseSettingsList.get(i).getId());
				dispenseSettings.setBulkFeedPercentage(dispenseSettingsList.get(i).getBulkFeedPercentage());
				dispenseSettings.setCreatedBy(dispenseSettingsList.get(i).getCreatedBy());
				dispenseSettings.setCreatedDateTime(dispenseSettingsList.get(i).getCreatedDateTime());
				dispenseSettings.setCutOfPercentage(dispenseSettingsList.get(i).getCutOfPercentage());
				dispenseSettings.setEnd(dispenseSettingsList.get(i).getEnd());
				dispenseSettings.setGapTimerSeconds(dispenseSettingsList.get(i).getGapTimerSeconds());
				dispenseSettings.setInchOffTimer(dispenseSettingsList.get(i).getInchOffTimer());
				dispenseSettings.setInchOnTimer(dispenseSettingsList.get(i).getInchOnTimer());
				dispenseSettings.setLastUpdatedBy(dispenseSettingsList.get(i).getLastUpdatedBy());
				dispenseSettings.setLastUpdatedDateTime(dispenseSettingsList.get(i).getLastUpdatedDateTime());
				dispenseSettings.setRPM(dispenseSettingsList.get(i).getRPM());
				dispenseSettings.setSequence(dispenseSettingsList.get(i).getSequence());
				dispenseSettings.setStart(dispenseSettingsList.get(i).getStart());
				dispenseSettings.setStatus(dispenseSettingsList.get(i).getStatus());
				
				
			}
			
			
			} 
			
			
			
			ModelAndView model = new ModelAndView();
			model.addObject("command", new DispenseSettings());
			model.addObject("dispenseSettings", dispenseSettings);
			
			model.addObject("ingredientid", igid);
						
			model.setViewName("/ajaxfiles/update_dispenseSettings_n");
			return model;
		}
		
		
		
		
		@RequestMapping(value = { "/viewDispenseSettingsInfo" }, method = RequestMethod.GET)
		public ModelAndView viewDispenseSettingsInfo(@RequestParam(value = "id", required = true) String id,
													@RequestParam(value = "igid", required = true) String igid) {
			
			
			
			Optional<Ingredient> obj2 = ingredientRepository.findById(igid);
			Ingredient ingredient = null;
			if (obj2.isPresent()) {
				ingredient = obj2.get();
			}
			
			List<DispenseSettings> dispenseSettingsList = ingredient.getDispenseSettings() ;		
				
			DispenseSettings dispenseSettings = new DispenseSettings();
			
			for (int i = 0; i < dispenseSettingsList.size(); i++)   
			{  
		
			if( dispenseSettingsList.get(i).getId().toString().equals(id) ) {
				
				dispenseSettings.setId(dispenseSettingsList.get(i).getId());
				dispenseSettings.setBulkFeedPercentage(dispenseSettingsList.get(i).getBulkFeedPercentage());
				dispenseSettings.setCreatedBy(dispenseSettingsList.get(i).getCreatedBy());
				dispenseSettings.setCreatedDateTime(dispenseSettingsList.get(i).getCreatedDateTime());
				dispenseSettings.setCutOfPercentage(dispenseSettingsList.get(i).getCutOfPercentage());
				dispenseSettings.setEnd(dispenseSettingsList.get(i).getEnd());
				dispenseSettings.setGapTimerSeconds(dispenseSettingsList.get(i).getGapTimerSeconds());
				dispenseSettings.setInchOffTimer(dispenseSettingsList.get(i).getInchOffTimer());
				dispenseSettings.setInchOnTimer(dispenseSettingsList.get(i).getInchOnTimer());
				dispenseSettings.setLastUpdatedBy(dispenseSettingsList.get(i).getLastUpdatedBy());
				dispenseSettings.setLastUpdatedDateTime(dispenseSettingsList.get(i).getLastUpdatedDateTime());
				dispenseSettings.setRPM(dispenseSettingsList.get(i).getRPM());
				dispenseSettings.setSequence(dispenseSettingsList.get(i).getSequence());
				dispenseSettings.setStart(dispenseSettingsList.get(i).getStart());
				dispenseSettings.setStatus(dispenseSettingsList.get(i).getStatus());
				
				
			}
			
			
			} 
			ModelAndView model = new ModelAndView();
			model.addObject("command", new DispenseSettings());
			model.addObject("dispenseSettings", dispenseSettings);
					
			model.setViewName("/ajaxfiles/view_dispenseSettings_n");
			
			return model;
		}
		
		
		
		@RequestMapping(value = "/updateDispenseSettings", method = RequestMethod.POST)
		public String updateDispenseSettings(@RequestParam(value = "id", required = false) String id,
											@RequestParam(value = "ingredientid", required = false ) String ingredientid,
											@ModelAttribute("dispenseSettings") DispenseSettings dispenseSettings, BindingResult result) {
			logger.info("updateDispenseSettings: " + dispenseSettings.toString());
			
		
			DispenseSettings dbDispenseSettings = null;
			Optional<DispenseSettings> dispenseSettingsOpt = dispenseSettingsRepository.findById(dispenseSettings.getId().toString());
			if (dispenseSettingsOpt.isPresent()) {
				
				dbDispenseSettings = dispenseSettingsOpt.get();
				
				dbDispenseSettings.setStart(dispenseSettings.getStart());
				dbDispenseSettings.setEnd(dispenseSettings.getEnd());
				dbDispenseSettings.setBulkFeedPercentage(dispenseSettings.getBulkFeedPercentage());
				dbDispenseSettings.setGapTimerSeconds(dispenseSettings.getGapTimerSeconds());
				dbDispenseSettings.setInchOnTimer(dispenseSettings.getInchOnTimer());
				dbDispenseSettings.setInchOffTimer(dispenseSettings.getInchOffTimer());
				dbDispenseSettings.setCutOfPercentage(dispenseSettings.getCutOfPercentage());
				dbDispenseSettings.setRPM(dispenseSettings.getRPM());
				dbDispenseSettings.setSequence(dispenseSettings.getSequence());
					
				dbDispenseSettings.setStatus(dispenseSettings.getStatus());
				dbDispenseSettings.setCreatedBy(dispenseSettings.getCreatedBy());
				dbDispenseSettings.setCreatedDateTime(dispenseSettings.getCreatedDateTime());
				
				dbDispenseSettings.setLastUpdatedBy("Satish");
				dbDispenseSettings.setLastUpdatedDateTime(new Date());
				dispenseSettingsRepository.save(dbDispenseSettings);
				
			} else {
				logger.info("Unable to update ingredient");
			}
			
			
			Optional<Ingredient> obj = ingredientRepository.findById(ingredientid);
			Ingredient ingredient = null;
			if (obj.isPresent()) {
				ingredient = obj.get();
			}
			
			ingredient.setDispenseSettings(dispenseSettings);
			
			ingredientRepository.save(ingredient);
			
			
			//return "redirect:/admin/listIngredients";
			
			return "redirect:/admin/listDispenseSettings?id="+ingredientid;
		}
		
		
}
