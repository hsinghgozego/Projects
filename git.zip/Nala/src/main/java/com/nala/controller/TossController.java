package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Toss;
import com.nala.model.TossType;
import com.nala.model.User;
import com.nala.repository.TossRepository;
import com.nala.repository.TossTypeRepository;

@Controller
@RequestMapping("/admin")
public class TossController {
private static final Logger logger = LoggerFactory.getLogger(TossController.class);
	
	@Autowired
	private TossRepository tossRepository; 
	
	@Autowired
	private TossTypeRepository tossTypeRepository;
	
	@RequestMapping("/list-tosses")
	public ModelAndView listTosses(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "tossSearchName", required = false) String tossSearchName,
			@RequestParam(value = "tossSearchType", required = false) String tossSearchType,
			@RequestParam(value = "tossSearchStatus", required = false) String tossSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(tossSearchName==null) {
			tossSearchName = "";
		}
		if(tossSearchType==null) {
			tossSearchType = "";
		}
		if(tossSearchStatus==null) {
			tossSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Toss> pageToss = tossRepository.search(tossSearchName, tossSearchType, tossSearchStatus, paging);
		
		model.addObject("tossList", pageToss.getContent());
		model.addObject("currentPage", pageToss.getNumber());
		model.addObject("totalItems", pageToss.getTotalElements());
		model.addObject("totalPages", pageToss.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageToss.getTotalElements()) ? pageToss.getTotalElements() : (pageNo * pageSize)) : pageToss.getTotalElements() );
		model.addObject("totalSize", pageToss.getTotalElements());
		model.addObject("noOfPages", pageToss.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "tosses");
		model.addObject("command", new TossType());
		List<TossType> tossTypeList = tossTypeRepository.findAll();
		model.addObject("tossTypeList", tossTypeList);
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_toss_grid_n");
		} else {
			model.setViewName("/admin/toss_list");
		}
		
		return model;
	}
	
	@RequestMapping("/addToss")
	public ModelAndView addToss() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Toss());
		model.addObject("command", new TossType());
		List<TossType> tossTypeList = tossTypeRepository.findAll();
		model.addObject("tossTypeList", tossTypeList);

		model.setViewName("/ajaxfiles/add_toss_n");
		return model;
	}
	
	@RequestMapping(value = "/saveToss", method = RequestMethod.POST)
	public String saveToss(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "tossSearchName", required = false) String tossSearchName,
			@RequestParam(value = "tossSearchType", required = false) String tossSearchType,
			@RequestParam(value = "tossSearchStatus", required = false) Boolean tossSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("toss") Toss toss, BindingResult result) throws IOException{
		
		logger.info("save toss: " + toss.toString());
		
		if(!image.isEmpty()) {
			
			toss.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
			
		}

		List<Toss> tossList = tossRepository.findAll();
		Optional<TossType> tossType=tossTypeRepository.findById(toss.getTossType().getId().toString());
		if(tossType.isPresent()) {
			toss.setTossType(tossType.get());
		}
		//toss.setStatus("Active");
		toss.setSequence(tossList.size() + 1);
		toss.setCreatedBy(loggedInUser.getSsoId());
		toss.setCreatedDateTime(new Date());
		toss.setLastUpdatedBy(loggedInUser.getSsoId());
		toss.setLastUpdatedDateTime(new Date());
		tossRepository.save(toss);
		return "redirect:/admin/list-tosses";
		
	}
	
	@RequestMapping(value = { "/viewTossInfo" }, method = RequestMethod.GET)
	public ModelAndView viewTossInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Toss());
				
		Optional<Toss> obj = tossRepository.findById(id);
		Toss toss = null;
		if (obj.isPresent()) {
			toss = obj.get();
		}
		
		model.addObject("toss", toss);
		
		try {
			if(toss.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (toss.getImage().getData()) );	
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		model.setViewName("/ajaxfiles/view_toss_n");
		return model;
	}
	
	@RequestMapping(value = { "/openEditToss" }, method = RequestMethod.GET)
	public ModelAndView openEditToss(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		
		Optional<Toss> obj = tossRepository.findById(id);
		Toss toss = null;
		if (obj.isPresent()) {
			toss = obj.get();
		}
		
		model.addObject("toss", toss);
		model.addObject("command", new Toss());
		model.addObject("command", new TossType());
		
		try {
			if(toss.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (toss.getImage().getData()) );	
				
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		List<TossType> tossTypeList = tossTypeRepository.findAll();
		model.addObject("tossTypeList", tossTypeList);
		model.setViewName("/ajaxfiles/update_toss_n");
		return model;
	}

	@RequestMapping(value = { "/openDeleteToss" }, method = RequestMethod.GET)
	public ModelAndView openDeleteToss(@RequestParam(value = "id", required = true) String id) {
		//System.out.println("Inside openDeleteToss java ");
		ModelAndView model = new ModelAndView();
		
		Optional<Toss> obj = tossRepository.findById(id);
		Toss toss = null;
		if (obj.isPresent()) {
			toss = obj.get();
		}
		
		
		model.addObject("toss", toss);
		model.addObject("command", new Toss());
		model.setViewName("/ajaxfiles/delete_toss_n");
		return model;
	}
	
	@RequestMapping(value = { "/deleteToss" }, method = RequestMethod.POST)
	public String deleteToss(Device device,
			@RequestParam(value = "tossSearchName", required = false) String tossSearchName,
			@RequestParam(value = "tossSearchType", required = false) String tossSearchType,
			@RequestParam(value = "tossSearchStatus", required = false) Boolean tossSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("toss") Toss toss, BindingResult result) {
		
		
		//System.out.println("Inside deleteToss java ");
		
		tossRepository.deleteById(id);
		return "redirect:/admin/list-tosses";
		

	}
	
	@RequestMapping(value = "/updateToss", method = RequestMethod.POST)
	public String editToss(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "tossSearchName", required = false) String tossSearchName,
			@RequestParam(value = "tossSearchType", required = false) String tossSearchType,
			@RequestParam(value = "tossSearchStatus", required = false) Boolean tossSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("toss") Toss toss, BindingResult result) {
		logger.info("save toss: " + toss.toString());

		//System.out.println("inside updateToss");
		
		Toss dbToss = null;
		Optional<Toss> obj = tossRepository.findById(toss.getId().toString());
		if (obj.isPresent()) {
			dbToss = obj.get();
			dbToss.setName(toss.getName());
			dbToss.setDescription(toss.getDescription());
			dbToss.setStatus(toss.getStatus());
			Optional<TossType> tossType=tossTypeRepository.findById(toss.getTossType().getId().toString());
			if(tossType.isPresent()) {
				dbToss.setTossType(tossType.get());
				//System.out.println(tossType);
			}
			//dbToss.setImages("image");
			try {
				
				if(!image.isEmpty()) {
					
					dbToss.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
					
				}
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			dbToss.setVideoLink(toss.getVideoLink());
			dbToss.setLastUpdatedBy(loggedInUser.getSsoId());
			dbToss.setLastUpdatedDateTime(new Date());
		
		}
		tossRepository.save(dbToss);
		return "redirect:/admin/list-tosses";
	
	}
}
