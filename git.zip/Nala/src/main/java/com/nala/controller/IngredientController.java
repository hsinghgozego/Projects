package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Classification;
import com.nala.model.Ingredient;
import com.nala.model.User;
import com.nala.repository.ClassificationTypeRepository;
import com.nala.repository.DispenseSettingsRepository;
import com.nala.repository.IngredientRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class IngredientController {

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	ClassificationTypeRepository classificationTypeRepository;

	@Autowired
	DispenseSettingsRepository dispenseSettingsRepository;
	
	@Autowired
	IngredientRepository ingredientRepository;

	private static final Logger logger = LoggerFactory.getLogger(IngredientController.class);

	@RequestMapping("/addIngredient")
	public ModelAndView addIngredient() {
		Iterable<Classification> classificationTypeList = classificationTypeRepository.findAll();
		ModelAndView model = new ModelAndView();
		model.addObject("classificationTypeList", classificationTypeList);
		model.addObject("command", new Ingredient());
		model.setViewName("/ajaxfiles/add_ingredient_n");
		return model;
	}

	@RequestMapping(value = "/saveIngredient", method = RequestMethod.POST)
	public String saveIngredient(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "ingredientSearchName", required = false) String ingredientSearchName,
			@RequestParam(value = "ingredientSearchClassification", required = false) String ingredientSearchClassification,
			@RequestParam(value = "ingredientSearchTypeOfUsage", required = false) String ingredientSearchTypeOfUsage,
			@RequestParam(value = "ingredientSearchStatus", required = false) Boolean ingredientSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("ingredient") Ingredient ingredient, BindingResult result) throws IOException {
		
		logger.info("saveAction: " + ingredient.toString());
		
		List<Ingredient> ingredientList = ingredientRepository.findAll();
		
		
		//ingredientList.parallelStream().map
		
		ingredient.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
		
		ingredient.setSequence(ingredientList.size() + 1);
		ingredient.setCreatedBy(loggedInUser.getSsoId());
		ingredient.setLastUpdatedBy(loggedInUser.getSsoId());
		ingredient.setCreatedDateTime(new Date());
		ingredient.setLastUpdatedDateTime(new Date());
		ingredientRepository.save(ingredient);
		
		
		return "redirect:/admin/listIngredients";
	}

	@RequestMapping(value = "/updateIngredient", method = RequestMethod.POST)
	public String updateIngredient(@ModelAttribute("ingredient") Ingredient ingredient, BindingResult result) {
		logger.info("updateIngredient: " + ingredient.toString());
		Ingredient dbIngredient = null;
		Optional<Ingredient> ingredientOpt = ingredientRepository.findById(ingredient.getId().toString());
		if (ingredientOpt.isPresent()) {
			dbIngredient = ingredientOpt.get();
			dbIngredient.setName(ingredient.getName());
			dbIngredient.setDescription(ingredient.getDescription());
			dbIngredient.setIngredientClassificationType(ingredient.getIngredientClassificationType());
			dbIngredient.setStatus(ingredient.getStatus());
			dbIngredient.setIngredientTypeOfUsage(ingredient.getIngredientTypeOfUsage());
			dbIngredient.setIngredientWeightToVolumeRatio(ingredient.getIngredientWeightToVolumeRatio());
			dbIngredient.setIngredientType(ingredient.getIngredientType());
			dbIngredient.setSequence(ingredient.getSequence());
				
			dbIngredient.setLastUpdatedBy("Satish");
			dbIngredient.setLastUpdatedDateTime(new Date());
			ingredientRepository.save(dbIngredient);
		} else {
			logger.info("Unable to update ingredient");
		}
		return "redirect:/admin/listIngredients";
	}

	@RequestMapping(value = { "/editIngredient" }, method = RequestMethod.GET)
	public ModelAndView editIngredient(@RequestParam(value = "id", required = true) String id) {
		logger.info("editIngredient id: " + id);
		Optional<Ingredient> ingredientOpt = ingredientRepository.findById(id);
		ModelAndView model = new ModelAndView();
		Iterable<Classification> classificationTypeList = classificationTypeRepository.findAll();
		model.addObject("classificationTypeList", classificationTypeList);
		if (ingredientOpt.isPresent()) {
			model.addObject("ingredient", ingredientOpt.get());
		} else {
			logger.info("Ingredient not found with the given Id");
		}
		model.addObject("command", new Ingredient());
		model.setViewName("/admin/edit_ingredient");
		return model;
	}

	@RequestMapping(value = { "/searchIngredients" }, method = RequestMethod.GET)
	public ModelAndView searchIngredients(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
		logger.info("Ingredient name: " + name + " description: " + description);
		List<Ingredient> ingredientList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			ingredientList = ingredientRepository.findIngredientsByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			ingredientList = ingredientRepository.findIngredientsByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			ingredientList = ingredientRepository.findIngredientsByRegexpDescription(description);
		}
		return new ModelAndView("/admin/ingredient_list", "ingredientList", ingredientList);
	}

	@RequestMapping("/listIngredients")
	public ModelAndView listIngredients(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "ingredientSearchName", required = false) String ingredientSearchName,
			@RequestParam(value = "ingredientSearchClassification", required = false) String ingredientSearchClassification,
			@RequestParam(value = "ingredientSearchTypeOfUsage", required = false) String ingredientSearchTypeOfUsage,
			@RequestParam(value = "ingredientSearchStatus", required = false) String ingredientSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(ingredientSearchName==null) {
			ingredientSearchName = "";
		}
		if(ingredientSearchClassification==null) {
			ingredientSearchClassification = "";
		}
		if(ingredientSearchTypeOfUsage==null) {
			ingredientSearchTypeOfUsage = "";
		}
		if(ingredientSearchStatus==null) {
			ingredientSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		
		Page<Ingredient> pageIngredient = ingredientRepository.search(ingredientSearchName, ingredientSearchClassification, ingredientSearchTypeOfUsage, ingredientSearchStatus, paging);
		
		model.addObject("ingredientList", pageIngredient.getContent());
		model.addObject("currentPage", pageIngredient.getNumber());
		model.addObject("totalItems", pageIngredient.getTotalElements());
		model.addObject("totalPages", pageIngredient.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageIngredient.getTotalElements()) ? pageIngredient.getTotalElements() : (pageNo * pageSize)) : pageIngredient.getTotalElements() );
		model.addObject("totalSize", pageIngredient.getTotalElements());
		model.addObject("noOfPages", pageIngredient.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "ingredients");
		
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_ingredient_grid_n");
		} else {
			model.setViewName("/admin/ingredient_list");
		}
		
		
		return model;
		
	}
	
	
	//
	
	
	
	//

	//
	
	
	
	@RequestMapping(value = { "/viewIngredientInfo" }, method = RequestMethod.GET)
	public ModelAndView viewIngredientInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Ingredient());
				
		Optional<Ingredient> obj = ingredientRepository.findById(id);
		Ingredient ingredient = null;
		if (obj.isPresent()) {
			ingredient = obj.get();
		}
			
		try{
			
			if(ingredient.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (ingredient.getImage().getData()) );	
				
			} 
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		 
		
		model.addObject("ingredient", ingredient);
		model.setViewName("/ajaxfiles/view_ingredient_n");
		
		return model;
	}
	
	
	@RequestMapping(value = { "/openEditIngredient" }, method = RequestMethod.GET)
	public ModelAndView openEditIngredient(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Ingredient());
		
		Optional<Ingredient> obj = ingredientRepository.findById(id);
		Ingredient ingredient = null;
		if (obj.isPresent()) {
			ingredient = obj.get();
		}
		
		model.addObject("ingredient", ingredient);
		model.addObject("command", new Ingredient());
		
		try{
			if(ingredient.getImage()!=null){
			 model.addObject("image", Base64.getEncoder().encodeToString (ingredient.getImage().getData()) );
			}
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		model.setViewName("/ajaxfiles/update_ingredient_n");
		return model;
	}
	
	//openDeleteIngredient
	
	@RequestMapping(value = { "/openDeleteIngredient" }, method = RequestMethod.GET)
	public ModelAndView openDeleteIngredient(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<Ingredient> obj = ingredientRepository.findById(id);
		Ingredient ingredient = null;
		if (obj.isPresent()) {
			ingredient = obj.get();
		}
			
		model.addObject("ingredient", ingredient);
		model.addObject("command", new Ingredient());
		model.setViewName("/ajaxfiles/delete_ingredient_n");
		return model;
	}
	
	//
	
	

	@RequestMapping(value = { "/deleteIngredient" }, method = RequestMethod.POST)
	public String deleteIngredient(Device device,
			@RequestParam(value = "ingredientSearchName", required = false) String ingredientSearchName,
			@RequestParam(value = "ingredientSearchType", required = false) String ingredientSearchType,
			@RequestParam(value = "ingredientSearchStatus", required = false) Boolean ingredientSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("ingredient") Ingredient ingredient, BindingResult result) {
		
		
		ingredientRepository.deleteById(id);
		return "redirect:/admin/listIngredients";
		

	}
	
	//
	
	
	//
	
	
	
	//
	
	
}
