package com.nala.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Action;
import com.nala.model.Bin;
import com.nala.model.Flame;
import com.nala.model.ItemType;
import com.nala.model.Recipe;
import com.nala.model.RecipeDetail;
import com.nala.model.RecipeDetailsForm;
import com.nala.model.RecipeType;
import com.nala.model.Spatula;
import com.nala.model.Stir;
import com.nala.model.StirType;
import com.nala.model.Toss;
import com.nala.model.Utensil;
import com.nala.repository.ActionRepository;
import com.nala.repository.BinRepository;
import com.nala.repository.FlameLevelRepository;
import com.nala.repository.RecipeDetailRepository;
import com.nala.repository.RecipeRepository;
import com.nala.repository.RecipeTypeRepository;
import com.nala.repository.SpatulaRepository;
import com.nala.repository.StirRepository;
import com.nala.repository.StirTypeRepository;
import com.nala.repository.TossRepository;
import com.nala.repository.UtensilRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RecipeDetailController {

	private static final String UTENSIL = "Utensil";

	private static final Logger logger = LoggerFactory.getLogger(RecipeDetailController.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	ActionRepository actionRepository;

	@Autowired
	BinRepository binRepository;

	@Autowired
	FlameLevelRepository flameLevelRepository;

	@Autowired
	SpatulaRepository spatulaRepository;

	@Autowired
	RecipeTypeRepository recipeTypeRepository;

	@Autowired
	RecipeRepository recipeRepository;

	@Autowired
	RecipeDetailRepository recipeDetailRepository;

	@Autowired
	StirTypeRepository stirTypeRepository;

	@Autowired
	StirRepository stirRepository;

	@Autowired
	TossRepository tossRepository;

	@Autowired
	UtensilRepository utensilRepository;

	private static String UTENSILE_PICK = "UTENSILE_PICK";
	private static String SPATULA_PICK = "SPATULA_PICK";
	private static String VEG_COLLECT = "VEG_COLLECT";
	private static String SPICE_COLLECT = "SPICE_COLLECT";
	private static String MEAT_COLLECT = "MEAT_COLLECT";
	private static String VEG_PICKUP = "VEG_PICKUP";
	private static String SPICE_PICKUP = "SPICE_PICKUP";
	private static String MEAT_PICKUP = "MEAT_PICKUP";
	private static String IGNITION = "IGNITION";
	private static String STIR = "STIR";
	private static String TOSS = "TOSS";
	private static String LIQUID_DISPENSE = "LIQUID_DISPENSE";
	private static String DELAY = "DELAY";
	private static String SERVE = "SERVE";

	@RequestMapping("/newRecipeDetail")
	public ModelAndView newRecipeDetail() {
		Iterable<Recipe> recipeList = recipeRepository.findAll();
		Iterable<Action> actionList = actionRepository.findAll();
		Iterable<Bin> binList = binRepository.findAll();
		Iterable<Flame> flameLevelList = flameLevelRepository.findAll();
		Iterable<Spatula> spatulaList = spatulaRepository.findAll();
		Iterable<Utensil> utensilList = utensilRepository.findAll();
		ModelAndView model = new ModelAndView();
		model.addObject("recipeList", recipeList);
		model.addObject("actionList", actionList);
		model.addObject("binList", binList);
		model.addObject("spatulaList", spatulaList);
		model.addObject("utensilList", utensilList);
		model.addObject("flameLevelList", flameLevelList);
		model.addObject("command", new RecipeDetail());
		model.setViewName("/admin/new_recipeDetail");
		return model;
	}

	@RequestMapping(value = "/saveRecipeDetail", method = RequestMethod.POST)
	public String saveRecipeDetail(@ModelAttribute("recipeDetail") RecipeDetail recipeDetail, BindingResult result) {
		logger.info("saveRecipeDetail: " + recipeDetail.toString());
		RecipeDetail obj = recipeDetailRepository.findByStepNoAndRecipeName(recipeDetail.getStepNo(),
				recipeDetail.getRecipe().getName());
		if (obj != null) {
			logger.info("Error Recipe Detail Step No already exists");
		} else {
			Recipe recipe = null;
			Optional<Recipe> recipeopt = recipeRepository.findById(recipeDetail.getRecipe().getId().toString());
			if (recipeopt.isPresent()) {
				recipe = recipeopt.get();
			}
			Action action = null;
			Optional<Action> actionOpt = actionRepository.findById(recipeDetail.getAction().getId().toString());
			if (actionOpt.isPresent()) {
				action = actionOpt.get();
				if (action.getName().equals(UTENSIL)) {
					Optional<Bin> binOpt = binRepository.findById(recipeDetail.getBin().getId().toString());
					if (binOpt.isPresent()) {
						recipeDetail.setBin(binOpt.get());
					}
				} else {
					Optional<Utensil> utensilOpt = utensilRepository
							.findById(recipeDetail.getUtensil().getId().toString());
					if (utensilOpt.isPresent()) {
						recipeDetail.setUtensil(utensilOpt.get());
					}
				}
			}
			Optional<Flame> flameLevelOpt = flameLevelRepository
					.findById(recipeDetail.getFlameLevel().getId().toString());
			if (flameLevelOpt.isPresent()) {
				recipeDetail.setFlameLevel(flameLevelOpt.get());
			}
			recipeDetail.setRecipe(recipe);
			recipeDetail.setAction(action);
			recipeDetail.setCreatedBy("Satish");
			recipeDetail.setCreatedDateTime(new Date());
			recipeDetail.setLastUpdatedBy("Satish");
			recipeDetail.setLastUpdatedDateTime(new Date());
			recipeDetailRepository.save(recipeDetail);
		}
		return "redirect:/admin/listRecipeDetails";
	}

	@RequestMapping(value = { "/editRecipeDetail" }, method = RequestMethod.GET)
	public ModelAndView editRecipeDetail(@RequestParam(value = "id", required = true) String id) {
		logger.info("editRecipeDetail id: " + id);
		Optional<Recipe> recipeOpt = recipeRepository.findById(id);
		ModelAndView model = new ModelAndView();
		Iterable<RecipeType> recipeTypeList = recipeTypeRepository.findAll();
		model.addObject("recipeTypeList", recipeTypeList);
		if (recipeOpt.isPresent()) {
			model.addObject("recipe", recipeOpt.get());
		} else {
			logger.info("Recipe not found with the Given Id");
		}
		model.addObject("command", new Recipe());
		model.setViewName("/admin/edit_recipeDetail");
		return model;
	}

	@RequestMapping(value = { "/searchRecipeDetail" }, method = RequestMethod.GET)
	public ModelAndView searchRecipeDetail(@RequestParam(value = "recipeName", required = true) String recipeName,
			@RequestParam(value = "stepNo", required = true) int stepNo) {
		logger.info("searchRecipe recipeName: " + recipeName + ", String: " + stepNo);
		List<RecipeDetail> recipeDetailList = recipeDetailRepository.findRecipeDetailByQuery(stepNo, recipeName);
		return new ModelAndView("/admin/recipe_detail_list", "recipeDetailList", recipeDetailList);
	}

	/*
	 * @RequestMapping(value = { "/listRecipesDeatils" }, method =
	 * RequestMethod.GET) public ModelAndView listRecipeDetail(@RequestParam(value =
	 * "id", required = true) String id) { Recipe recipe = null; Optional<Recipe>
	 * recipeOpt = recipeRepository.findById(id); if (recipeOpt.isPresent()) {
	 * List<RecipeDetail> recipeDetails =
	 * recipeDetailRepository.findByRecipeId(recipe.getId().toString()); List<Bin>
	 * binList = binRepository.findAll();
	 * 
	 * Map<String, Set<Bin>> binClassificationMap = new HashMap<String, Set<Bin>>();
	 * for (Bin tmpbin : binList) { if (tmpbin != null &&
	 * tmpbin.getClassificationType() != null &&
	 * tmpbin.getClassificationType().getName() != null) { Set<Bin> binSet = null;
	 * if (binClassificationMap.get(tmpbin.getClassificationType().getName()) !=
	 * null) { binSet =
	 * binClassificationMap.get(tmpbin.getClassificationType().getName()); } else {
	 * binSet = new HashSet<>(); } binSet.add(tmpbin);
	 * binClassificationMap.put(tmpbin.getClassificationType().getName(), binSet); }
	 * }
	 * 
	 * List<Utensil> utensilList = utensilRepository.findAll(); List<Spatula>
	 * spatulaList = spatulaRepository.findAll(); List<Stir> stirList =
	 * stirRepository.findAll(); List<Toss> tossList = tossRepository.findAll(); for
	 * (RecipeDetail recipeDetail : recipeDetails) { List<ItemType> mainItemTypeList
	 * = new ArrayList<>(); if (recipeDetail.getAction() != null) { Action action =
	 * recipeDetail.getAction(); String actionName =
	 * recipeDetail.getAction().getName(); if
	 * (actionName.equalsIgnoreCase(VEG_COLLECT)) { if
	 * (binClassificationMap.get(action.getActionType().getName()) != null) { for
	 * (Bin bin : binClassificationMap.get(action.getActionType().getName())) {
	 * ItemType itemType = new ItemType(); itemType.setId("B" + "|" +
	 * bin.getId().toString()); itemType.setName(bin.getIngredient().getName());
	 * mainItemTypeList.add(itemType); } } recipeDetail.setMainItemId("B" + "|" +
	 * recipeDetail.getBin().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(SPICE_COLLECT)) { if
	 * (binClassificationMap.get(action.getActionType().getName()) != null) { for
	 * (Bin bin : binClassificationMap.get(action.getActionType().getName())) {
	 * ItemType itemType = new ItemType(); itemType.setId("B" + "|" +
	 * bin.getId().toString()); itemType.setName(bin.getIngredient().getName());
	 * mainItemTypeList.add(itemType); } } recipeDetail.setMainItemId("B" + "|" +
	 * recipeDetail.getBin().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(NON_VEG_COLLECT)) { if
	 * (binClassificationMap.get(action.getActionType().getName()) != null) { for
	 * (Bin bin : binClassificationMap.get(action.getActionType().getName())) {
	 * ItemType itemType = new ItemType(); itemType.setId("B" + "|" +
	 * bin.getId().toString()); itemType.setName(bin.getIngredient().getName());
	 * mainItemTypeList.add(itemType); } } recipeDetail.setMainItemId("B" + "|" +
	 * recipeDetail.getBin().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(LIQUID_DISPENSE)) { if
	 * (binClassificationMap.get(action.getActionType().getName()) != null) { for
	 * (Bin bin : binClassificationMap.get(action.getActionType().getName())) {
	 * ItemType itemType = new ItemType(); itemType.setId("B" + "|" +
	 * bin.getId().toString()); itemType.setName(bin.getIngredient().getName());
	 * mainItemTypeList.add(itemType); } } recipeDetail.setMainItemId("B" + "|" +
	 * recipeDetail.getBin().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(UTENSILE_PICK)) { for (Utensil utensil :
	 * utensilList) { ItemType itemType = new ItemType(); itemType.setId("E" + "|" +
	 * utensil.getId().toString()); itemType.setName(utensil.getName());
	 * mainItemTypeList.add(itemType); } recipeDetail.setMainItemId("E" + "|" +
	 * recipeDetail.getUtensil().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(SPATULA_PICK)) { for (Spatula spatula :
	 * spatulaList) { ItemType itemType = new ItemType(); itemType.setId("E" + "|" +
	 * spatula.getId().toString()); itemType.setName(spatula.getName());
	 * mainItemTypeList.add(itemType); } recipeDetail.setMainItemId("E" + "|" +
	 * recipeDetail.getSpatula().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(STIR)) { for (Stir stir : stirList) { ItemType
	 * itemType = new ItemType(); itemType.setId("S" + "|" +
	 * stir.getId().toString()); itemType.setName(stir.getName());
	 * mainItemTypeList.add(itemType); } recipeDetail.setMainItemId("S" + "|" +
	 * recipeDetail.getStir().getId().toString()); } else if
	 * (actionName.equalsIgnoreCase(TOSS)) { Toss mainActiontoss =
	 * recipeDetail.getToss(); ItemType itemType = new ItemType();
	 * itemType.setId("T" + "|" + mainActiontoss.getId().toString());
	 * itemType.setName(mainActiontoss.getName()); mainItemTypeList.add(itemType);
	 * recipeDetail.setMainItemId("T" + "|" +
	 * recipeDetail.getToss().getId().toString()); }
	 * recipeDetail.setMainItemList(mainItemTypeList); }
	 * 
	 * } List<Action> actionList = new ArrayList<>(); if
	 * (recipe.getRecipeType().getName().equalsIgnoreCase("Non Veg")) { actionList =
	 * actionRepository.findAll(); } else { actionList =
	 * actionRepository.findByClassificationTypeNotInActions("Non Veg"); } //
	 * List<StirType> stirList = stirTypeRepository.findAll(); Iterable<Flame>
	 * flameLevelList = flameLevelRepository.findAll(); RecipeDetailsForm
	 * recipeDetailsForm = new RecipeDetailsForm();
	 * recipeDetailsForm.setRecipeDetails(recipeDetails);
	 * 
	 * ModelAndView model = new ModelAndView(); model.addObject("recipe", recipe);
	 * model.addObject("actionList", actionList); model.addObject("stirList",
	 * stirList); model.addObject("flameLevelList", flameLevelList);
	 * model.addObject("binList", binList); model.addObject("utensilList",
	 * utensilList); model.addObject("tossList", tossList);
	 * model.addObject("recipeDetailsForm", recipeDetailsForm);
	 * model.setViewName("/admin/recipe_detail_list"); return model; } else
	 * 
	 * { logger.info("Error in Recipe Get"); return null; } }
	 */

	@RequestMapping(value = "/updateRecipeDetail", method = RequestMethod.POST)
	public String updateRecipeDetail(@ModelAttribute("recipeDetailsForm") RecipeDetailsForm recipeDetailsForm,
			BindingResult result) {

		String recipeId = "";
		int stepNo = 1;
		boolean flag = false;
		Recipe recipe = null;
		List<RecipeDetail> objList = new ArrayList<>();
		for (RecipeDetail recipeDetail : recipeDetailsForm.getRecipeDetails()) {
			if (recipeDetail.getRecipe() != null) {
				if (!flag) {
					Optional<Recipe> recipeOpt = recipeRepository.findById(recipeDetail.getRecipe().getId().toString());
					if (recipeOpt.isPresent()) {
						recipe = recipeOpt.get();
						flag = true;
					}
				}
				RecipeDetail obj = null;
				if (recipeDetail.getId() != null) {
					Optional<RecipeDetail> recipeDetailOpt = recipeDetailRepository
							.findById(recipeDetail.getId().toString());
					if (recipeDetailOpt.isPresent()) {
						obj = recipeDetailOpt.get();
					} else {
						obj = new RecipeDetail();
					}
				}
				obj.setStepNo(stepNo);
				obj.setValueInGmsMl(recipeDetail.getValueInGmsMl());
				obj.setDelayInMilliSeconds(recipeDetail.getDelayInMilliSeconds());

				recipeId = recipe.getId().toString();
				obj.setRecipe(recipe);
				if (recipeDetail.getAction() != null && recipeDetail.getAction().getId() != null) {
					Action action = null;
					Optional<Action> actionOpt = actionRepository.findById(recipeDetail.getAction().getId().toString());
					if (actionOpt.isPresent()) {
						obj.setAction(actionOpt.get());
					}
				}
				String mainItemStr = recipeDetail.getMainItemId();
				if (StringUtils.isNotBlank(mainItemStr) && StringUtils.isNotEmpty(mainItemStr)) {
					String[] str = mainItemStr.split("|", 3);
					if ("B".equals(str[0])) {
						Optional<Bin> binOpt = binRepository.findById(str[2]);
						if (binOpt.isPresent()) {
							obj.setBin(binOpt.get());
						}
					} else if ("E".equals(str[0])) {
						Optional<Utensil> utensilOpt = utensilRepository.findById(str[2]);
						if (utensilOpt.isPresent()) {
							obj.setUtensil(utensilOpt.get());
						}
					} else if ("S".equals(str[0])) {
						Optional<Stir> stirOpt = stirRepository.findById(str[2]);
						if (stirOpt.isPresent()) {
							obj.setStir(stirOpt.get());
						}
					} else if ("T".equals(str[0])) {
						Optional<Toss> tossOpt = tossRepository.findById(str[2]);
						if (tossOpt.isPresent()) {
							obj.setToss(tossOpt.get());
						}
					}
				}
				if (recipeDetail.getFlameLevel() != null && recipeDetail.getFlameLevel().getId() != null) {
					Optional<Flame> flameLevelOpt = flameLevelRepository
							.findById(recipeDetail.getFlameLevel().getId().toString());
					if (flameLevelOpt.isPresent()) {
						obj.setFlameLevel(flameLevelOpt.get());
					}
				} else {
					obj.setFlameLevel(null);
				}
				objList.add(obj);
				stepNo = stepNo + 1;

			}
		}
		List<RecipeDetail> recipeDetails = recipeDetailRepository.findByRecipeId(recipeId);
		recipeDetailRepository.deleteAll(recipeDetails);
		recipeDetailRepository.insert(objList);
		return "redirect:/admin/listRecipesDeatils?id=" + recipeId;
	}

	@RequestMapping(value = "/getDropDownOptions/{actionId}", method = RequestMethod.GET, headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody List<ItemType> getDropDownOptions(@PathVariable("actionId") String actionId) {
		Action action = null;
		Optional<Action> actionOpt = actionRepository.findById(actionId);
		if (actionOpt.isPresent()) {
			action = actionOpt.get();
			String actionName = action.getName();
			List<ItemType> itemTypeList = new ArrayList<>();
			if (actionName.equalsIgnoreCase(VEG_COLLECT)) {
				List<Bin> binList = binRepository
						.findBinsByClassificationTypeName(action.getActionType().getName());
				for (Bin bin : binList) {
					ItemType itemType = new ItemType();
					itemType.setId("B" + "|" + bin.getId().toString());
					itemType.setName("");
					itemTypeList.add(itemType);
				}
			} else if (actionName.equalsIgnoreCase(SPICE_COLLECT)) {
				List<Bin> binList = binRepository
						.findBinsByClassificationTypeName(action.getActionType().getName());
				for (Bin bin : binList) {
					ItemType itemType = new ItemType();
					itemType.setId("B" + "|" + bin.getId().toString());
					itemType.setName("");
					itemTypeList.add(itemType);
				}
			} else if (actionName.equalsIgnoreCase(MEAT_COLLECT)) {
				List<Bin> binList = binRepository
						.findBinsByClassificationTypeName(action.getActionType().getName());
				for (Bin bin : binList) {
					ItemType itemType = new ItemType();
					itemType.setId("B" + "|" + bin.getId().toString());
					itemType.setName("");
					itemTypeList.add(itemType);
				}
			} else if (actionName.equalsIgnoreCase(UTENSILE_PICK)) {
				List<Utensil> utensilList = utensilRepository.findAll();
				for (Utensil utensil : utensilList) {
					ItemType itemType = new ItemType();
					itemType.setId("E" + "|" + utensil.getId().toString());
					itemType.setName(utensil.getName());
					itemTypeList.add(itemType);
				}
			} else if (actionName.equalsIgnoreCase(SPATULA_PICK)) {
				List<Spatula> spatulaList = spatulaRepository.findAll();
				for (Spatula spatula : spatulaList) {
					ItemType itemType = new ItemType();
					itemType.setId("E" + "|" + spatula.getId().toString());
					itemType.setName(spatula.getName());
					itemTypeList.add(itemType);
				}
			} else if (actionName.equalsIgnoreCase(LIQUID_DISPENSE)) {
				List<Bin> binList = binRepository
						.findBinsByClassificationTypeName(action.getActionType().getName());
				for (Bin bin : binList) {
					ItemType itemType = new ItemType();
					itemType.setId("B" + "|" + bin.getId().toString());
					itemType.setName("");
					itemTypeList.add(itemType);
				}
			} else if (actionName.equalsIgnoreCase(STIR)) {
				List<StirType> stirList = stirTypeRepository.findAll();
				for (StirType stirType : stirList) {
					ItemType itemType = new ItemType();
					itemType.setId("S" + "|" + stirType.getId().toString());
					itemType.setName(stirType.getName());
					itemTypeList.add(itemType);
				}
			}
			return itemTypeList;
		} else {
			logger.info("Action Not found with the Give Id");
			return null;
		}

	}

}