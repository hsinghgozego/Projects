package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Bowl;
import com.nala.model.BowlType;
import com.nala.model.User;
import com.nala.repository.BowlRepository;
import com.nala.repository.BowlTypeRepository;

@Controller
@RequestMapping("/admin")
public class BowlController {

	private static final Logger logger = LoggerFactory.getLogger(BowlController.class);

	@Autowired
	BowlRepository bowlRepository;

	@Autowired
	BowlTypeRepository bowlTypeRepository;
	
	@RequestMapping("/list-bowls")
	public ModelAndView listBowls(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "bowlSearchName", required = false) String bowlSearchName,
			@RequestParam(value = "bowlSearchType", required = false) String bowlSearchType,
			@RequestParam(value = "bowlSearchStatus", required = false) String bowlSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(bowlSearchName==null) {
			bowlSearchName = "";
		}
		if(bowlSearchType==null) {
			bowlSearchType = "";
		}
		if(bowlSearchStatus==null) {
			bowlSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Bowl> pageBowl = bowlRepository.search(bowlSearchName, bowlSearchType, bowlSearchStatus, paging);
		
		model.addObject("bowlList", pageBowl.getContent());
		model.addObject("currentPage", pageBowl.getNumber());
		model.addObject("totalItems", pageBowl.getTotalElements());
		model.addObject("totalPages", pageBowl.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageBowl.getTotalElements()) ? pageBowl.getTotalElements() : (pageNo * pageSize)) : pageBowl.getTotalElements() );
		model.addObject("totalSize", pageBowl.getTotalElements());
		model.addObject("noOfPages", pageBowl.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "bowls");
		model.addObject("command", new BowlType());
		List<BowlType> bowlTypeList = bowlTypeRepository.findAll();
		model.addObject("bowlTypeList", bowlTypeList);
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_bowl_grid_n");
		} else {
			model.setViewName("/admin/bowl_list");
		}
		
		return model;
	}

	@RequestMapping("/addBowl")
	public ModelAndView addBowl() {
		
		ModelAndView model = new ModelAndView();
		
		model.addObject("command", new Bowl());
		model.addObject("command", new BowlType());
		
		List<BowlType> bowlTypeList = bowlTypeRepository.findAll();
		
		model.addObject("bowlTypeList", bowlTypeList);
		model.setViewName("/ajaxfiles/add_bowl_n");
		
		return model;
		
	}


	@RequestMapping(value = "/saveBowl", method = RequestMethod.POST)
	public String saveBowl(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "bowlSearchName", required = false) String bowlSearchName,
			@RequestParam(value = "bowlSearchType", required = false) String bowlSearchType,
			@RequestParam(value = "bowlSearchStatus", required = false) String bowlSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("bowl") Bowl bowl, BindingResult result) throws IOException{
		
		logger.info("save bowl: " + bowl.toString());
		
		if(!image.isEmpty()) {
			
			bowl.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
			
		}

		Optional<BowlType> bowlType=bowlTypeRepository.findById(bowl.getBowlType().getId().toString());
		if(bowlType.isPresent()) {
			bowl.setBowlType(bowlType.get());
		}
		bowl.setCreatedBy(loggedInUser.getSsoId());
		bowl.setCreatedDateTime(new Date());
		bowl.setLastUpdatedBy(loggedInUser.getSsoId());
		bowl.setLastUpdatedDateTime(new Date());
		bowlRepository.save(bowl);
		return "redirect:/admin/list-bowls";
		
	}

	@RequestMapping(value = { "/viewBowlInfo" }, method = RequestMethod.GET)
	public ModelAndView viewBowlInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Bowl());
				
		Optional<Bowl> obj = bowlRepository.findById(id);
		Bowl bowl = null;
		if (obj.isPresent()) {
			bowl = obj.get();
		}
		
		model.addObject("bowl", bowl);
		logger.info("view bowl: " + bowl.toString());
		
		try {
			if(bowl.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (bowl.getImage().getData()) );	
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		model.setViewName("/ajaxfiles/view_bowl_n");
		return model;
	}
	
	@RequestMapping(value = { "/openEditBowl" }, method = RequestMethod.GET)
	public ModelAndView openEditBowl(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		
		Optional<Bowl> obj = bowlRepository.findById(id);
		Bowl bowl = null;
		if (obj.isPresent()) {
			bowl = obj.get();
		}
		
		model.addObject("bowl", bowl);
		model.addObject("command", new Bowl());
		model.addObject("command", new BowlType());
		
		try {
			if(bowl.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (bowl.getImage().getData()) );	
				
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		List<BowlType> bowlTypeList = bowlTypeRepository.findAll();
		model.addObject("bowlTypeList", bowlTypeList);
		model.setViewName("/ajaxfiles/update_bowl_n");
		return model;
	}
	
	@RequestMapping(value = { "/openDeleteBowl" }, method = RequestMethod.GET)
	public ModelAndView openDeleteBowl(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<Bowl> obj = bowlRepository.findById(id);
		Bowl bowl = null;
		if (obj.isPresent()) {
			bowl = obj.get();
		}
		
		model.addObject("bowl", bowl);
		model.addObject("command", new Bowl());
		model.setViewName("/ajaxfiles/delete_bowl_n");
		return model;
	}

	@RequestMapping(value = { "/deleteBowl" }, method = RequestMethod.POST)
	public String deleteBowl(Device device,
			@RequestParam(value = "bowlSearchName", required = false) String bowlSearchName,
			@RequestParam(value = "bowlSearchType", required = false) String bowlSearchType,
			@RequestParam(value = "bowlSearchStatus", required = false) String bowlSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("bowl") Bowl bowl, BindingResult result) {
		
		bowlRepository.deleteById(id);
		return "redirect:/admin/list-bowls";
		
	}

	@RequestMapping(value = "/updateBowl", method = RequestMethod.POST)
	public String updateBowl(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "bowlSearchName", required = false) String bowlSearchName,
			@RequestParam(value = "bowlSearchType", required = false) String bowlSearchType,
			@RequestParam(value = "bowlSearchStatus", required = false) String bowlSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("bowl") Bowl bowl, BindingResult result) {
		
		logger.info("save bowl: " + bowl.toString());

		Bowl dbBowl = null;
		Optional<Bowl> obj = bowlRepository.findById(bowl.getId().toString());
		
		if (obj.isPresent()) {
			dbBowl = obj.get();
			dbBowl.setName(bowl.getName());
			dbBowl.setDescription(bowl.getDescription());
			dbBowl.setStatus(bowl.getStatus());
			Optional<BowlType> bowlType=bowlTypeRepository.findById(bowl.getBowlType().getId().toString());
			if(bowlType.isPresent()) {
				dbBowl.setBowlType(bowlType.get());
			}
			
			try {
				if(!image.isEmpty()) {
					dbBowl.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			dbBowl.setLastUpdatedBy(loggedInUser.getSsoId());
			dbBowl.setLastUpdatedDateTime(new Date());
		
		}
		
		bowlRepository.save(dbBowl);
		return "redirect:/admin/list-bowls";
	
	}
	
}
