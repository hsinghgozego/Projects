package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.TossType;
import com.nala.model.User;
import com.nala.repository.TossTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class TossTypeController {
	private static final Logger logger=LoggerFactory.getLogger(TossTypeController.class);
	
	@Autowired
	private TossTypeRepository tossTypeRepository;
	
	@RequestMapping("/list-tossTypes")
	public ModelAndView listTossType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "tossTypeSearchName", required = false) String tossTypeSearchName,
			@RequestParam(value = "tossTypeSearchTypeId", required = false) String tossTypeSearchTypeId,
			@RequestParam(value = "tossTypeSearchStatus", required = false) String tossTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(tossTypeSearchName==null) {
			tossTypeSearchName = "";
		}
		if(tossTypeSearchTypeId==null) {
			tossTypeSearchTypeId = "";
		}
		if(tossTypeSearchStatus==null) {
			tossTypeSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<TossType> pageTossType = tossTypeRepository.search(tossTypeSearchName, tossTypeSearchTypeId, paging);
		
		model.addObject("tossTypeList", pageTossType.getContent());
		//System.out.println(pageTossType.getContent());
		model.addObject("currentPage", pageTossType.getNumber());
		model.addObject("totalItems", pageTossType.getTotalElements());
		model.addObject("totalPages", pageTossType.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageTossType.getTotalElements()) ? pageTossType.getTotalElements() : (pageNo * pageSize)) : pageTossType.getTotalElements() );
		model.addObject("totalSize", pageTossType.getTotalElements());
		model.addObject("noOfPages", pageTossType.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "tossTypes");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_tossType_grid_n");
		} else {
			model.setViewName("/admin/tossType_list");
		}
		
		
		return model;
	}

	@RequestMapping(value = "/saveTossType", method = RequestMethod.POST)
	public String saveTossType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "tossTypeSearchName", required = false) String tossTypeSearchName,
			@RequestParam(value = "tossTypeSearchTypeId", required = false) String tossTypeSearchTypeId,
			@RequestParam(value = "tossTypeSearchStatus", required = false) Boolean tossTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("tossType") TossType tossType, BindingResult result) {
		logger.info("save tossType: " + tossType.toString());
		List<TossType> tossTypeList = tossTypeRepository.findAll();
		//tossType.setStatus("Active");
		tossType.setSequence(tossTypeList.size() + 1);
		tossType.setCreatedBy(loggedInUser.getSsoId());
		tossType.setCreatedDateTime(new Date());
		tossType.setLastUpdatedBy(loggedInUser.getSsoId());
		tossType.setLastUpdatedDateTime(new Date());
		tossTypeRepository.save(tossType);
		return "redirect:/admin/list-tossTypes";
		

	}
	
	@RequestMapping("/addTossType")
	public ModelAndView addTossType() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new TossType());
		model.setViewName("/ajaxfiles/add_tossType_n");
		return model;
	}

	@RequestMapping(value = "/updateTossType", method = RequestMethod.POST)
	public String editTossType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "tossTypeSearchName", required = false) String tossTypeSearchName,
			@RequestParam(value = "tossTypeSearchTypeId", required = false) String tossTypeSearchTypeId,
			@RequestParam(value = "tossTypeSearchStatus", required = false) Boolean tossTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@ModelAttribute("tossType") TossType tossType, BindingResult result) {
		logger.info("Updating tossType: " + tossType.toString());

		//System.out.println("inside editTossType");
		
		TossType dbTossType = null;
		Optional<TossType> obj = tossTypeRepository.findById(tossType.getId().toString());
		if (obj.isPresent()) {
			dbTossType = obj.get();
			dbTossType.setName(tossType.getName());
			dbTossType.setTypeid(tossType.getTypeid());
			dbTossType.setDescription(tossType.getDescription());
			dbTossType.setStatus(tossType.getStatus());
			dbTossType.setCreatedBy(loggedInUser.getSsoId());
			dbTossType.setCreatedDateTime(new Date());
			dbTossType.setLastUpdatedBy(loggedInUser.getSsoId());
			dbTossType.setLastUpdatedDateTime(new Date());
		
		}
		tossTypeRepository.save(dbTossType);
		return "redirect:/admin/list-tossTypes";
	}
	
	@RequestMapping(value = { "/viewTossTypeInfo" }, method = RequestMethod.GET)
	public ModelAndView viewTossTypeInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new TossType());
				
		Optional<TossType> obj = tossTypeRepository.findById(id);
		TossType tossType = null;
		if (obj.isPresent()) {
			tossType = obj.get();
		}
		
		model.addObject("tossType", tossType);
		model.setViewName("/ajaxfiles/view_tossType_n");
		return model;
	}
	
	@RequestMapping(value = { "/openEditTossType" }, method = RequestMethod.GET)
	public ModelAndView openEditTossType(@RequestParam(value = "id", required = true) String id) {
	
		//System.out.println("inside openEditTossType");
		ModelAndView model = new ModelAndView();
		model.addObject("command", new TossType());
		
		Optional<TossType> obj = tossTypeRepository.findById(id);
		TossType tossType = null;
		if (obj.isPresent()) {
			tossType = obj.get();
		}
		
		model.addObject("tossType", tossType);
		model.addObject("command", new TossType());
		model.setViewName("/ajaxfiles/update_tossType_n");
		return model;
	}
	
	@RequestMapping(value = { "/openDeleteTossType" }, method = RequestMethod.GET)
	public ModelAndView openDeleteTossType(@RequestParam(value = "id", required = true) String id) {
		//System.out.println("Inside openDeleteTossType java ");
		ModelAndView model = new ModelAndView();
		
		Optional<TossType> obj = tossTypeRepository.findById(id);
		TossType tossType = null;
		if (obj.isPresent()) {
			tossType = obj.get();
		}
		
		
		model.addObject("tossType", tossType);
		model.addObject("command", new TossType());
		model.setViewName("/ajaxfiles/delete_tossType_n");
		return model;
	}
	
	@RequestMapping(value = { "/deleteTossType" }, method = RequestMethod.POST)
	public String deleteTossType(Device device,
			@RequestParam(value = "tossTypeSearchName", required = false) String tossTypeSearchName,
			@RequestParam(value = "tossTypeSearchTypeId", required = false) String tossTypeSearchTypeId,
			@RequestParam(value = "tossTypeSearchStatus", required = false) Boolean tossTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("tossType") TossType tossType, BindingResult result) {
		
		//System.out.println("Inside deleteTossType java ");
		
		tossTypeRepository.deleteById(id);
		return "redirect:/admin/list-tossTypes";
		
	}

}




