package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Classification;
import com.nala.model.User;
import com.nala.repository.ClassificationTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class ClassificationController {

	private static final Logger logger = LoggerFactory.getLogger(ClassificationController.class);

	@Autowired
	ClassificationTypeRepository classificationTypeRepository;

	@RequestMapping("/listClassificationTypes")
	public ModelAndView listClassificationTypes() {
		Iterable<Classification> classificationTypeList = classificationTypeRepository.findAll();
		return new ModelAndView("/admin/classification_type_list", "classificationTypeList", classificationTypeList);
	}

	@RequestMapping(value = { "/searchClassificationType" }, method = RequestMethod.GET)
	public ModelAndView searchClassificationType(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
		logger.info("searchActionType name: " + name + ", description: " + description);
		List<Classification> classificationTypeList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			classificationTypeList = classificationTypeRepository.findClassificationTypeByRegexpNameAndDescription(name,
					description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			classificationTypeList = classificationTypeRepository.findClassificationTypeByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			classificationTypeList = classificationTypeRepository
					.findClassificationTypeByRegexpDescription(description);
		}
		return new ModelAndView("/admin/classification_type_list", "classificationTypeList", classificationTypeList);
	}

	@RequestMapping(value = "/saveClassificationType", method = RequestMethod.POST)
	@Transactional
	public String saveClassificationType(@SessionAttribute("loggedInUser") User loggedInUser,
			@ModelAttribute("classificationType") Classification classificationType, BindingResult result) {
		logger.info("classificationType: " + classificationType.toString());
		List<Classification> classificationTypeList = classificationTypeRepository
				.findByName(classificationType.getName());
		if (classificationTypeList.size() > 0) {
			logger.info("Error Classification Type name already exists: " + classificationType.getName());
		} else {
			classificationType.setCreatedBy(loggedInUser.getSsoId());
			classificationType.setLastUpdatedBy(loggedInUser.getSsoId());
			classificationType.setCreatedDateTime(new Date());
			classificationType.setLastUpdatedDateTime(new Date());
			classificationTypeRepository.save(classificationType);
		}
		return "redirect:/admin/listClassificationTypes";
	}

	@RequestMapping("/addClassificationType")
	public ModelAndView addClassificationType() {
		return new ModelAndView("/admin/new_classification_type", "command", new Classification());
	}

	@RequestMapping(value = { "/editClassificationType" }, method = RequestMethod.GET)
	public ModelAndView editClassificationType(@RequestParam(value = "id", required = true) String id) {
		logger.info("ClassificationType id: " + id);
		Optional<Classification> classificationTypeOpt = classificationTypeRepository.findById(id);
		ModelAndView model = new ModelAndView();
		if (classificationTypeOpt.isPresent()) {
			model.addObject("classificationType", classificationTypeOpt.get());
		} else {
			logger.info("classificationType Type not found with the Given Id");
		}
		model.addObject("command", new Classification());
		model.setViewName("/admin/edit_classification_type");
		return model;
	}

	@RequestMapping(value = "/updateClassificationType", method = RequestMethod.POST)
	@Transactional
	public String updateClassificationType(@SessionAttribute("loggedInUser") User loggedInUser,
			@ModelAttribute("classificationType") Classification classificationType, BindingResult result) {
		logger.info("update claupdateClassificationTypessificationType: " + classificationType.toString());
		Classification dbClassificationType = null;
		Optional<Classification> classificationTypeOpt = classificationTypeRepository
				.findById(classificationType.getId().toString());
		if (classificationTypeOpt.isPresent()) {
			dbClassificationType = classificationTypeOpt.get();
			dbClassificationType.setName(classificationType.getName());
			dbClassificationType.setDescription(classificationType.getDescription());
			dbClassificationType.setSequence(classificationType.getSequence());
			dbClassificationType.setLastUpdatedBy(loggedInUser.getSsoId());
			dbClassificationType.setLastUpdatedDateTime(new Date());
			classificationTypeRepository.save(dbClassificationType);
		} else {
			logger.info("Unable to update classificationType Type");
		}
		return "redirect:/admin/listClassificationTypes";
	}

}
