package com.nala.controller;

import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.SpatulaType;
import com.nala.model.User;
import com.nala.repository.SpatulaTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class SpatulaTypeController {

	private static final Logger logger = LoggerFactory.getLogger(UtensilTypeController.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	SpatulaTypeRepository spatulaTypeRepository;

	@RequestMapping("/list-spatulaTypes")
	public ModelAndView listUtensilType(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaTypeSearchName", required = false) String spatulaTypeSearchName,
			@RequestParam(value = "spatulaTypeSearchTypeId", required = false) String spatulaTypeSearchTypeId,
			@RequestParam(value = "spatulaTypeSearchStatus", required = false) String spatulaTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {

		ModelAndView model = new ModelAndView();
		if (pageNo == null || pageNo < 1) {
			pageNo = 1;
		}
		if (pageSize == null || pageSize < 0) {
			pageSize = 10;
		}
		if (spatulaTypeSearchName == null) {
			spatulaTypeSearchName = "";
		}
		if (spatulaTypeSearchTypeId == null) {
			spatulaTypeSearchTypeId = "";
		}
		if (spatulaTypeSearchStatus == null) {
			spatulaTypeSearchStatus = "";
		}

		Pageable paging = PageRequest.of(pageNo - 1, pageSize);
		Page<SpatulaType> pageSpatulaType = spatulaTypeRepository.search(spatulaTypeSearchName, spatulaTypeSearchTypeId,
				spatulaTypeSearchStatus, paging);
		// System.out.println("pageUtensilType.getContent()>>"+pageUtensilType.getContent());
		model.addObject("spatulaTypeList", pageSpatulaType.getContent());
		model.addObject("currentPage", pageSpatulaType.getNumber());
		model.addObject("totalItems", pageSpatulaType.getTotalElements());
		model.addObject("totalPages", pageSpatulaType.getTotalPages());

		model.addObject("startNo", (pageNo > 1) ? ((pageNo - 1) * pageSize) + 1 : 1);
		model.addObject("endNo",
				(pageNo > 1) ? (((pageNo * pageSize) > pageSpatulaType.getTotalElements())
						? pageSpatulaType.getTotalElements()
						: (pageNo * pageSize)) : pageSpatulaType.getTotalElements());
		model.addObject("totalSize", pageSpatulaType.getTotalElements());
		model.addObject("noOfPages", pageSpatulaType.getTotalPages());
		model.addObject("pno", pageNo);

		model.addObject("urlPage", "spatulaTypes");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_spatulaType_grid_n");
		} else {
			model.setViewName("/admin/spatula_type_list");
		}

		return model;
	}

	@RequestMapping("/addSpatulaType")
	public ModelAndView addUtensilType() {

		ModelAndView model = new ModelAndView();
		model.addObject("command", new SpatulaType());
		model.setViewName("/ajaxfiles/add_spatulaType_n");
		return model;
	}

	@RequestMapping(value = "/saveSpatulaType", method = RequestMethod.POST)
	public String saveUtensilType(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaTypeSearchName", required = false) String spatulaTypeSearchName,
			@RequestParam(value = "spatulaTypeSearchTypeId", required = false) String spatulaTypeSearchTypeId,
			@RequestParam(value = "spatulaTypeSearchStatus", required = false) String spatulaTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("spatulaType") SpatulaType spatulaType, BindingResult result) {
		logger.info("save utensilType: " + spatulaType.toString());
		// ]utensilType.setStatus("Active");
		spatulaType.setLastUpdatedBy(loggedInUser.getSsoId());
		spatulaType.setCreatedBy(loggedInUser.getSsoId());
		spatulaType.setCreatedDateTime(new Date());
		spatulaType.setLastUpdatedDateTime(new Date());
		spatulaTypeRepository.save(spatulaType);
		return "redirect:/admin/list-spatulaTypes";
	}

	@RequestMapping(value = { "/openEditSpatulaType" }, method = RequestMethod.GET)
	public ModelAndView openEditUtensilType(@RequestParam(value = "id", required = true) String id) {

		// System.out.println("inside openEditUtensilType");
		ModelAndView model = new ModelAndView();
		model.addObject("command", new SpatulaType());

		Optional<SpatulaType> obj = spatulaTypeRepository.findById(id);
		SpatulaType spatulaType = null;
		if (obj.isPresent()) {
			spatulaType = obj.get();
		}

		model.addObject("spatulaType", spatulaType);
		model.addObject("command", new SpatulaType());
		model.setViewName("/ajaxfiles/update_spatulaType_n");
		return model;
	}

	@RequestMapping(value = "/updateSpatulaType", method = RequestMethod.POST)
	public String editUtensilType(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaTypeSearchName", required = false) String spatulaTypeSearchName,
			@RequestParam(value = "spatulaTypeSearchTypeId", required = false) String spatulaTypeSearchTypeId,
			@RequestParam(value = "spatulaTypeSearchStatus", required = false) String spatulaTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("spatulaType") SpatulaType spatulaType, BindingResult result) {
		SpatulaType dbSpatulaType = null;
		Optional<SpatulaType> obj = spatulaTypeRepository.findById(spatulaType.getId().toString());
		if (obj.isPresent()) {
			dbSpatulaType = obj.get();
			dbSpatulaType.setName(spatulaType.getName());
			dbSpatulaType.setStatus(spatulaType.getStatus());
			dbSpatulaType.setSpatulaTypeUniqueId(spatulaType.getSpatulaTypeUniqueId());
			dbSpatulaType.setCreatedBy(loggedInUser.getSsoId());
			dbSpatulaType.setCreatedDateTime(new Date());
			dbSpatulaType.setLastUpdatedBy(loggedInUser.getSsoId());
			dbSpatulaType.setLastUpdatedDateTime(new Date());

		}
		spatulaTypeRepository.save(dbSpatulaType);
		return "redirect:/admin/list-spatulaTypes";

	}

	@RequestMapping(value = { "/openDeleteSpatulaType" }, method = RequestMethod.GET)
	public ModelAndView openDeleteSpatulaType(@RequestParam(value = "id", required = true) String id) {
		// System.out.println("Inside openDeleteUtensilType java ");
		ModelAndView model = new ModelAndView();

		Optional<SpatulaType> obj = spatulaTypeRepository.findById(id);
		SpatulaType spatulaType = null;
		if (obj.isPresent()) {
			spatulaType = obj.get();
		}

		model.addObject("spatulaType", spatulaType);
		model.addObject("command", new SpatulaType());
		model.setViewName("/ajaxfiles/delete_spatulaType_n");
		return model;
	}

	@RequestMapping(value = { "/deleteSpatulaType" }, method = RequestMethod.POST)
	public String deleteUtensilType(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "spatulaTypeSearchName", required = false) String spatulaTypeSearchName,
			@RequestParam(value = "spatulaTypeSearchTypeId", required = false) String spatulaTypeSearchTypeId,
			@RequestParam(value = "spatulaTypeSearchStatus", required = false) String spatulaTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("spatulaType") SpatulaType spatulaType, BindingResult result) {
		spatulaTypeRepository.deleteById(id);
		return "redirect:/admin/list-spatulaTypes";
	}

}
