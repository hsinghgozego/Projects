package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Recipe;
import com.nala.model.RecipeType;
import com.nala.repository.RecipeRepository;
import com.nala.repository.RecipeTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RecipeController {

	private static final Logger logger = LoggerFactory.getLogger(RecipeController.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	RecipeTypeRepository recipeTypeRepository;

	@Autowired
	RecipeRepository recipeRepository;

	@RequestMapping("/newRecipe")
	public ModelAndView newRecipe() {
		Iterable<RecipeType> recipeTypeList = recipeTypeRepository.findAll();
		ModelAndView model = new ModelAndView();
		model.addObject("recipeTypeList", recipeTypeList);
		model.addObject("command", new Recipe());
		model.setViewName("/admin/new_recipe");
		return model;
	}

	@RequestMapping(value = "/saveRecipe", method = RequestMethod.POST)
	public String saveRecipe(@ModelAttribute("recipe") Recipe recipe, BindingResult result) {
		logger.info("saveRecipe: " + recipe.toString());
		List<Recipe> recipeList = recipeRepository.findByName(recipe.getName());
		if (recipeList.size() > 0) {
			logger.info("Error Recipe name already exists");
		} else {
			Optional<RecipeType> recipeTypeOpt = recipeTypeRepository
					.findById(recipe.getRecipeType().getId().toString());
			if (recipeTypeOpt.isPresent()) {
				recipe.setRecipeType(recipeTypeOpt.get());
			}
			recipe.setCreatedBy("Satish");
			recipe.setCreatedDateTime(new Date());
			recipe.setLastUpdatedBy("Satish");
			recipe.setLastUpdatedDateTime(new Date());
			recipeRepository.save(recipe);
		}
		return "redirect:/admin/listRecipes";
	}

	@RequestMapping(value = { "/editRecipe" }, method = RequestMethod.GET)
	public ModelAndView editRecipe(@RequestParam(value = "id", required = true) String id) {
		logger.info("editRecipe id: " + id);
		Recipe recipe = null;
		Optional<Recipe> recipeOpt = recipeRepository.findById(id);
		ModelAndView model = new ModelAndView();
		Iterable<RecipeType> recipeTypeList = recipeTypeRepository.findAll();
		model.addObject("recipeTypeList", recipeTypeList);
		if (recipeOpt.isPresent()) {
			recipe = recipeOpt.get();
		} else {
			logger.info("Recipe not found with the Given Id");
		}
		model.addObject("recipe", recipe);
		model.addObject("command", new Recipe());
		model.setViewName("/admin/edit_recipe");
		return model;
	}

	@RequestMapping("/listRecipes")
	public ModelAndView listRecipe() {
		Iterable<Recipe> recipeList = recipeRepository.findAll();
		return new ModelAndView("/admin/recipe_list", "recipeList", recipeList);
	}

	@RequestMapping(value = { "/searchRecipe" }, method = RequestMethod.GET)
	public ModelAndView searchRecipe(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
		logger.info("searchRecipe name: " + name + ", description: " + description);
		List<Recipe> recipeList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			recipeList = recipeRepository.findRecipeByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			recipeList = recipeRepository.findRecipeByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			recipeList = recipeRepository.findRecipeByRegexpDescription(description);
		}
		return new ModelAndView("/admin/recipe_list", "recipeList", recipeList);
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/updateRecipe", method = RequestMethod.POST)
	public String updateRecipe(@ModelAttribute("recipe") Recipe recipe, BindingResult result) {
		logger.info("updateRecipe: " + recipe.toString());
		Recipe dbRecipe = null;
		Optional<Recipe> recipeOpt = recipeRepository.findById(recipe.getId().toString());
		if (recipeOpt.isPresent()) {
			dbRecipe = recipeOpt.get();
			dbRecipe.setName(recipe.getName());
			dbRecipe.setShortDescription(recipe.getShortDescription());
			dbRecipe.setDescription(recipe.getDescription());
			dbRecipe.setSequence(recipe.getSequence());
			RecipeType recipeType = null;
			Optional<RecipeType> recipeTypeOpt = recipeTypeRepository
					.findById(recipe.getRecipeType().getId().toString());
			if (recipeTypeOpt.isPresent()) {
				dbRecipe.setRecipeType(recipeTypeOpt.get());
			}
			dbRecipe.setLastUpdatedBy("Satish");
			dbRecipe.setLastUpdatedDateTime(new Date());
			recipeRepository.save(dbRecipe);
		} else {
			logger.info("Unable to update Recipe");
		}
		return "redirect:/admin/listRecipes";
	}

}
