package com.nala.controller;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.nala.model.User;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
    
    @RequestMapping(value = "/dashboard")
    public String homePage(Locale locale, Model model, 
    		@SessionAttribute("loggedInUser") User loggedInUser) {
		model.addAttribute("urlPage", "dashboard");
    	logger.info("Home page");
        return "admin/home";
    }

}
