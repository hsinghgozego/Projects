package com.nala.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nala.model.demo.DemoRecipeDetails;
import com.nala.repository.IngredientRepository;
import com.nala.repository.RegisterAddressRepository;
import com.nala.repository.demo.CoilAddressRepository;
import com.nala.repository.demo.DemoBinsRepository;
import com.nala.repository.demo.DemoIngredientsRepository;
import com.nala.repository.demo.DemoRacksRepository;
import com.nala.repository.demo.DemoRecipeDetailsRepository;

@RestController
@RequestMapping("/admin")
public class RecipeStepController {

	private static final Logger logger = LoggerFactory.getLogger(RecipeStepController.class);

	@Autowired
	CoilAddressRepository coilAddressRepository;

	@Autowired
	DemoBinsRepository demoBinsRepository;

	@Autowired
	DemoRacksRepository demoRacksRepository;

	@Autowired
	DemoIngredientsRepository demoIngredientsRepository;

	@Autowired
	IngredientRepository ingredientRepository;

	@Autowired
	RegisterAddressRepository registerAddressRepository;

	@Autowired
	DemoRecipeDetailsRepository testRecipeRepository;

	@GetMapping("/recipeDetails")
	List<DemoRecipeDetails> all() {
		return testRecipeRepository.findAll();
	}

	@GetMapping("/recipeDetails/{id}")
	List<DemoRecipeDetails> findByRecipeId(@PathVariable Integer recipeId) {
		logger.info("findByRecipeId recipeId: " + recipeId);
		return testRecipeRepository.findByRecipeId(recipeId);
	}

}
