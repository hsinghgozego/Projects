package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.StirType;
import com.nala.model.User;
import com.nala.repository.StirTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class StirTypeController {

	private static final Logger logger = LoggerFactory.getLogger(StirTypeController.class);
	
	@Autowired
	StirTypeRepository stirTypeRepository;

	@RequestMapping("/list-stirTypes")
	public ModelAndView listStirTypes(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stirTypeSearchName", required = false) String stirTypeSearchName,
			@RequestParam(value = "stirTypeSearchTypeId", required = false) String stirTypeSearchTypeId,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax ) {
		
		ModelAndView model = new ModelAndView();
		
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(stirTypeSearchName==null) {
			stirTypeSearchName = "";
		}
		if(stirTypeSearchTypeId==null) {
			stirTypeSearchTypeId = "";
		}

		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<StirType> pageStirType = stirTypeRepository.search(stirTypeSearchName, stirTypeSearchTypeId, paging);
		
		model.addObject("stirTypeList", pageStirType.getContent());
		model.addObject("currentPage", pageStirType.getNumber());
		model.addObject("totalItems", pageStirType.getTotalElements());
		model.addObject("totalPages", pageStirType.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageStirType.getTotalElements()) ? pageStirType.getTotalElements() : (pageNo * pageSize)) : pageStirType.getTotalElements() );
		model.addObject("totalSize", pageStirType.getTotalElements());
		model.addObject("noOfPages", pageStirType.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "stirTypes");

		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_stirType_grid_n");
		} else {
			model.setViewName("/admin/stir_type_list");
		}
		return model;
	
	}

	@RequestMapping(value = "/saveStirType", method = RequestMethod.POST)
	public String saveStirType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stirTypeSearchName", required = false) String stirTypeSearchName,
			@RequestParam(value = "stirTypeSearchTypeId", required = false) String stirTypeSearchTypeId,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("stirType") StirType stirType, BindingResult result) {
    	
		logger.info("save stirType: " + stirType.toString());
		List<StirType> stirTypeList = stirTypeRepository.findAll();
		stirType.setSequence(stirTypeList.size() + 1);
		stirType.setCreatedBy(loggedInUser.getSsoId());
		stirType.setCreatedDateTime(new Date());
		stirType.setLastUpdatedBy(loggedInUser.getSsoId());
		stirType.setLastUpdatedDateTime(new Date());
		stirTypeRepository.save(stirType);
		return "redirect:/admin/list-stirTypes";
		
	}

	@RequestMapping("/addStirType")
	public ModelAndView addStirType() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new StirType());
		model.setViewName("/ajaxfiles/add_stirType_n");
		return model;
		
	}
	
	@RequestMapping(value = "/updateStirType", method = RequestMethod.POST)
	public String updateStirType(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stirTypeSearchName", required = false) String stirTypeSearchName,
			@RequestParam(value = "stirTypeSearchTypeId", required = false) String stirTypeSearchTypeId,
			@RequestParam(value = "stirTypeSearchStatus", required = false) Boolean stirTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,	
			@ModelAttribute("stirType") StirType stirType, BindingResult result) {
		StirType dbStirType = null;
		Optional<StirType> stirTypeOpt = stirTypeRepository.findById(stirType.getId().toString());
		if (stirTypeOpt.isPresent()) {
			dbStirType = stirTypeOpt.get();
			dbStirType.setName(stirType.getName());
			dbStirType.setStirTypeId(stirType.getStirTypeId());
			dbStirType.setDescription(stirType.getDescription());
			dbStirType.setSequence(stirType.getSequence());
			dbStirType.setStatus(stirType.getStatus());
			dbStirType.setLastUpdatedBy(loggedInUser.getSsoId());
			dbStirType.setLastUpdatedDateTime(new Date());
			stirTypeRepository.save(dbStirType);
		} else {
			System.out.println("Unable to update Stir Type");
		}
		return "redirect:/admin/list-stirTypes";
	}

	@RequestMapping(value = { "/viewStirTypeInfo" }, method = RequestMethod.GET)
	public ModelAndView viewTossTypeInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new StirType());
				
		Optional<StirType> obj = stirTypeRepository.findById(id);
		StirType stirType = null;
		if (obj.isPresent()) {
			stirType = obj.get();
		}
		
		model.addObject("stirType", stirType);
		model.setViewName("/ajaxfiles/view_stirType_n");
		return model;
	}
	
	@RequestMapping(value = { "/openEditStirType" }, method = RequestMethod.GET)
	public ModelAndView openEditStirType(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		model.addObject("command", new StirType());
		
		Optional<StirType> obj = stirTypeRepository.findById(id);
		StirType stirType = null;
		if (obj.isPresent()) {
			stirType = obj.get();
		}
		
		model.addObject("stirType", stirType);
		model.addObject("command", new StirType());
		model.setViewName("/ajaxfiles/update_stirType_n");
		return model;
	}
	
	@RequestMapping(value = { "/openDeleteStirType" }, method = RequestMethod.GET)
	public ModelAndView openDeleteStirType(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<StirType> obj = stirTypeRepository.findById(id);
		StirType stirType = null;
		if (obj.isPresent()) {
			stirType = obj.get();
		}
		
		model.addObject("stirType", stirType);
		model.addObject("command", new StirType());
		model.setViewName("/ajaxfiles/delete_stirType_n");
		return model;
	}
	
	@RequestMapping(value = { "/deleteStirType" }, method = RequestMethod.POST)
	public String deleteStirType(Device device,
			@RequestParam(value = "stirTypeSearchName", required = false) String stirTypeSearchName,
			@RequestParam(value = "stirTypeSearchTypeId", required = false) String stirTypeSearchTypeId,
			@RequestParam(value = "stirTypeSearchStatus", required = false) Boolean stirTypeSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("stirType") StirType stirType, BindingResult result) {
		
		stirTypeRepository.deleteById(id);
		return "redirect:/admin/list-stirTypes";
	}
	
}
