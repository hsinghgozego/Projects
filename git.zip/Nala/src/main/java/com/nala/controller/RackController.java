package com.nala.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Rack;
import com.nala.model.Section;
import com.nala.model.User;
import com.nala.repository.RackRepository;
import com.nala.repository.SectionRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class RackController {
	private static final Logger logger = LoggerFactory.getLogger(RackController.class);
	
	@Autowired
	RackRepository rackRepository;
	
	@Autowired
	SectionRepository sectionRepository;

	@RequestMapping("/list-racks")
	public ModelAndView racks(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "rackSearchName", required = false) String rackSearchName,
			@RequestParam(value = "rackSearchstatus", required = false) String rackSearchstatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(rackSearchName==null) {
			rackSearchName = "";
		}
		if(rackSearchstatus==null) {
			rackSearchstatus = "";
		}
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Rack> pageRack = rackRepository.search(rackSearchName, rackSearchstatus, paging);
		model.addObject("rackList", pageRack.getContent());
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageRack.getTotalElements()) ? pageRack.getTotalElements() : (pageNo * pageSize)) : pageRack.getTotalElements() );
		model.addObject("totalSize", pageRack.getTotalElements());
		model.addObject("noOfPages", pageRack.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "racks");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_rack_grid_n");
		} else {
			model.setViewName("/admin/rack_list");
		}
		return model;
		
	}

	@RequestMapping("/addRack")
	public ModelAndView addRack() {
		ModelAndView model = new ModelAndView();
		List<Section> sectionList=sectionRepository.findAll();
		model.addObject("sectionList", sectionList);
		model.addObject("command", new Rack());
		model.setViewName("/ajaxfiles/add_rack_n");
		return model;
	}

	@RequestMapping(value = "/saveRack", method = RequestMethod.POST)
	public String saveRack(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "rackSearchName", required = false) String rackSearchName,
			@RequestParam(value = "rackStatus", required = false) String rackStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("spatula") Rack rack, BindingResult result) {
		logger.info("save spatula: " + rack.toString());
		String [] sectionIds=rack.getSectionIds();
		if(sectionIds!=null && sectionIds.length>0) {
			List<Section> sectionList=new ArrayList<Section>();
			for(int i=0;i<sectionIds.length;i++) {
				String sectionId=sectionIds[i];
				sectionList.add(sectionRepository.findById(sectionId).get());
			}
			rack.setSections(sectionList);
		}
		rack.setStatus("Active");
		rack.setCreatedBy(loggedInUser.getSsoId());
		rack.setCreatedDateTime(new Date());
		rack.setLastUpdatedBy(loggedInUser.getSsoId());
		rack.setLastUpdatedDateTime(new Date());
		rackRepository.save(rack);
		return "redirect:/admin/list-racks";
	}
	
	@RequestMapping(value = { "/viewRackInfo" }, method = RequestMethod.GET)
	public ModelAndView viewRackInfo(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		Optional<Rack> obj = rackRepository.findById(id);
		Rack rack = null;
		if (obj.isPresent()) {
			rack = obj.get();
		}
		model.addObject("rack", rack);
		model.setViewName("/ajaxfiles/view_rack_n");
		return model;
	}

	@RequestMapping(value = { "/openEditRack" }, method = RequestMethod.GET)
	public ModelAndView openEditRack(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Rack());
		Rack rack = null;
		Optional<Rack> obj = rackRepository.findById(id);
		if (obj.isPresent()) {
			rack = obj.get();
		}
		model.addObject("rack", rack);
		List<Section> sectionList=sectionRepository.findAll();
		model.addObject("sectionList", sectionList);
		model.addObject("command", new Rack());
		model.setViewName("/ajaxfiles/update_rack_n");
		return model;
	}
	
	@RequestMapping(value = "/updateRack", method = RequestMethod.POST)
	public String updateRack(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "rackSearchName", required = false) String rackSearchName,
			@RequestParam(value = "rackStatus", required = false) String rackStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("spatula") Rack rack, BindingResult result) {
		logger.info("save spatula: " + rack.toString());
		Rack dbRack = null;
		Optional<Rack> obj  = rackRepository.findById(rack.getId().toString());
		if (obj.isPresent()) {
			dbRack = obj.get();
			dbRack.setName(rack.getName());
			dbRack.setRackId(rack.getRackId());
			dbRack.setCreatedBy(loggedInUser.getSsoId());
			dbRack.setCreatedDateTime(new Date());
			dbRack.setLastUpdatedBy(loggedInUser.getSsoId());
			dbRack.setLastUpdatedDateTime(new Date());
			String [] sectionIds=rack.getSectionIds();
			if(sectionIds!=null && sectionIds.length>0) {
				List<Section> sectionList=new ArrayList<Section>();
				for(int i=0;i<sectionIds.length;i++) {
					String sectionId=sectionIds[i];
					sectionList.add(sectionRepository.findById(sectionId).get());
				}
				dbRack.setSections(sectionList);
			}
		}
		rackRepository.save(dbRack);
		return "redirect:/admin/list-racks";
	}
	
	@RequestMapping(value = { "/openDeleteRack" }, method = RequestMethod.GET)
	public ModelAndView openDeleteRack(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		Rack rack = null;
		Optional<Rack> obj = rackRepository.findById(id);
		if (obj.isPresent()) {
			rack = obj.get();
		}
		model.addObject("spatula", rack);
		model.addObject("command", new Rack());
		model.setViewName("/ajaxfiles/delete_rack_n");
		return model;
	}

	@RequestMapping(value = { "/deleteRack" }, method = RequestMethod.POST)
	public String deleteSpatula(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "rackSearchName", required = false) String rackSearchName,
			@RequestParam(value = "rackStatus", required = false) String rackStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "id", required = true) String id,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("spatula") Rack rack, BindingResult result) {		
		rackRepository.deleteById(id);
		return "redirect:/admin/list-racks";
	}
}
