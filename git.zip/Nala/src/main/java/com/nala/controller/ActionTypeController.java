package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.ActionType;
import com.nala.model.User;
import com.nala.repository.ActionTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class ActionTypeController {

	private static final Logger logger = LoggerFactory.getLogger(ActionTypeController.class);

	@Autowired
	ActionTypeRepository actionTypeRepository;

	@RequestMapping("/listActionTypes")
	public ModelAndView listActionTyes() {
		Iterable<ActionType> actionTypeList = actionTypeRepository.findAll();
		return new ModelAndView("/admin/action_type_list", "actionTypeList", actionTypeList);
	}

	@RequestMapping(value = { "/searchActionType" }, method = RequestMethod.GET)
	public ModelAndView searchActionType(@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "description", required = true) String description) {
		logger.info("searchActionType name: " + name + ", description: " + description);
		List<ActionType> actionTypeList = null;
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name))
				&& (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description))) {
			actionTypeList = actionTypeRepository.findActionTypeByRegexpNameAndDescription(name, description);
		} else if (StringUtils.isNotBlank(name) && StringUtils.isNotEmpty(name)) {
			actionTypeList = actionTypeRepository.findActionTypeByRegexpName(name);
		} else if (StringUtils.isNotBlank(description) && StringUtils.isNotEmpty(description)) {
			actionTypeList = actionTypeRepository.findActionTypeByRegexpDescription(description);
		}
		return new ModelAndView("/admin/action_type_list", "actionTypeList", actionTypeList);
	}

	@RequestMapping(value = "/saveActionType", method = RequestMethod.POST)
	public String saveActionType(@SessionAttribute("loggedInUser") User loggedInUser,
			@ModelAttribute("actionType") ActionType actionType, BindingResult result) {
		logger.info("saveActionType: " + actionType.toString());
		List<ActionType> actionTypeList = actionTypeRepository.findByName(actionType.getName());
		if (actionTypeList.size() > 0) {
			logger.info("Error Action Type name already exists: " + actionType.getName());
		} else {
			actionType.setCreatedBy(loggedInUser.getSsoId());
			actionType.setLastUpdatedBy(loggedInUser.getSsoId());
			actionType.setCreatedDateTime(new Date());
			actionType.setLastUpdatedDateTime(new Date());
			actionTypeRepository.save(actionType);
		}
		return "redirect:/admin/listActionTypes";
	}

	@RequestMapping("/addActionType")
	public ModelAndView addActionType() {
		return new ModelAndView("/admin/new_action_type", "command", new ActionType());
	}

	@RequestMapping(value = { "/editActionType" }, method = RequestMethod.GET)
	public ModelAndView editActionType(@RequestParam(value = "id", required = true) String id) {
		logger.info("editActionType id: " + id);
		ActionType actionType = null;
		Optional<ActionType> actionTypeOpt = actionTypeRepository.findById(id);
		if (actionTypeOpt.isPresent()) {
			actionType = actionTypeOpt.get();
		}
		ModelAndView model = new ModelAndView();
		model.addObject("actionType", actionType);
		model.addObject("command", new ActionType());
		model.setViewName("/admin/edit_action_type");
		return model;
	}

	@RequestMapping(value = "/updateActionType", method = RequestMethod.POST)
	public String updateActionType(@SessionAttribute("loggedInUser") User loggedInUser,
			@ModelAttribute("actionType") ActionType actionType, BindingResult result) {
		logger.info("updateActionType: " + actionType.toString());
		ActionType tmpActionType = null;
		Optional<ActionType> actionTypeOpt = actionTypeRepository.findById(actionType.getId().toString());
		if (actionTypeOpt.isPresent()) {
			tmpActionType = actionTypeOpt.get();
			tmpActionType.setName(actionType.getName());
			tmpActionType.setDescription(actionType.getDescription());
			tmpActionType.setActionTypeId(actionType.getActionTypeId());
			tmpActionType.setLastUpdatedBy(loggedInUser.getSsoId());
			tmpActionType.setLastUpdatedDateTime(new Date());
			actionTypeRepository.save(tmpActionType);
		} else {
			logger.info("Unable to update Action Type");
		}
		return "redirect:/admin/listActionTypes";
	}

}
