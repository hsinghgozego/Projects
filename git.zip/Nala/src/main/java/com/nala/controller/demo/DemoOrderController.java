package com.nala.controller.demo;

import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nala.actions.Delay;
import com.nala.actions.FryerActionDB;
import com.nala.actions.FryerPickupDB;
import com.nala.actions.FryerServeDB;
import com.nala.actions.Ignition;
import com.nala.actions.LiquidDispensing;
import com.nala.actions.MeatCollection;
import com.nala.actions.MeatPickup;
import com.nala.actions.Serve;
import com.nala.actions.SpatulaPick;
import com.nala.actions.SpiceCollection;
import com.nala.actions.SpicePickup;
import com.nala.actions.Stirr;
import com.nala.actions.Toss;
import com.nala.actions.UtensilPick;
import com.nala.actions.VegCollection;
import com.nala.actions.VegPickup;
import com.nala.enums.ActionEnum;
import com.nala.enums.BurnerEnum;
import com.nala.enums.CoilEnum;
import com.nala.enums.DemoRecipeDetailsStatusEnum;
import com.nala.enums.OperationTypeEnum;
import com.nala.enums.OrderPreparingStatusEnum;
import com.nala.enums.RegisterEnum;
import com.nala.enums.SectionEnum;
import com.nala.model.DispenseSetting;
import com.nala.model.RegisterAddress;
import com.nala.model.demo.DemoActions;
import com.nala.model.demo.DemoBins;
import com.nala.model.demo.DemoBurners;
import com.nala.model.demo.DemoIngredients;
import com.nala.model.demo.DemoOrderProcessing;
import com.nala.model.demo.DemoOrderSteps;
import com.nala.model.demo.DemoOrders;
import com.nala.model.demo.DemoRecipeDetails;
import com.nala.model.demo.DemoRecipes;
import com.nala.model.helper.FryerAction;
import com.nala.model.helper.FryerPickup;
import com.nala.model.helper.FryerServe;
import com.nala.model.helper.LiquidBin;
import com.nala.repository.demo.ActionProcessingRulesRepository;
import com.nala.repository.RegisterAddressRepository;
import com.nala.repository.demo.CoilAddressRepository;
import com.nala.repository.demo.DemoActionsRepository;
import com.nala.repository.demo.DemoBinsRepository;
import com.nala.repository.demo.DemoBurnersRepository;
import com.nala.repository.demo.DemoIngredientsRepository;
import com.nala.repository.demo.DemoOrderProcessingRespository;
import com.nala.repository.demo.DemoOrderStepsRepository;
import com.nala.repository.demo.DemoOrdersRepository;
import com.nala.repository.demo.DemoRacksRepository;
import com.nala.repository.demo.DemoRecipeDetailsRepository;
import com.nala.repository.demo.DemoRecipesRepository;

import de.re.easymodbus.exceptions.ModbusException;
import de.re.easymodbus.modbusclient.ModbusClient;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class DemoOrderController {

	private static final Logger logger = LoggerFactory.getLogger(DemoOrderController.class);

	private static final String IP_ADDR = "192.168.9.18";
	private static final Integer PORT = 502;
	private static final Integer COIL_STRAT_ADDRESS = 5000;
	private static final Integer NO_OF_COILS_TO_READ = 1990;
	private static final Integer IDLE_FLAME = 5;

	@Autowired
	ActionProcessingRulesRepository actionProcessingRulesRepository;

	@Autowired
	CoilAddressRepository coilAddressRepository;

	@Autowired
	DemoActionsRepository demoActionsRepository;

	@Autowired
	DemoBinsRepository demoBinsRepository;

	@Autowired
	DemoBurnersRepository demoBurnersRepository;

	@Autowired
	DemoIngredientsRepository demoIngredientsRepository;

	@Autowired
	DemoOrdersRepository demoOrdersRepository;

	@Autowired
	DemoOrderStepsRepository demoOrderStepsRepository;

	@Autowired
	DemoOrderProcessingRespository demoOrderProcessingRespository;

	@Autowired
	DemoRacksRepository demoRacksRepository;

	@Autowired
	DemoRecipesRepository demoRecipesRepository;

	@Autowired
	DemoRecipeDetailsRepository demoRecipeDetailsRepository;

	@Autowired
	RegisterAddressRepository registerAddressRepository;

	ModbusClient mc = null;

	// Updated after Each Serve Action Completion
	private static boolean isBurner1Free = false;
	private static boolean isBurner2Free = false;
	private static boolean isBurner3Free = false;
	private static boolean isBurner4Free = false;

	// Updated at Each Action
	private static Integer burner1CurrentGroupId = 0;
	private static Integer burner2CurrentGroupId = 0;
	private static Integer burner3CurrentGroupId = 0;
	private static Integer burner4CurrentGroupId = 0;

	// Updated at Robot Actions
	private static Integer station1ActiveBurner = 0;
	private static Integer station2ActiveBurner = 0;

	// Updated during Pool Actions
	private static Integer station1ActivePool = 0;
	private static Integer station2ActivePool = 0;

	// Updated at start and at each Fryer Actions
	private static boolean isFryer1VegPoolFree = false;
	private static boolean isFryer1MeatPoolFree = false;
	private static boolean isFryer2VegPoolFree = false;
	private static boolean isFryer2MeatPoolFree = false;

	private static boolean yeildFlag1 = false;
	private static boolean yeildFlag2 = false;

	private static Map<Integer, Map<Integer, Integer>> burnerToActionToCoilMap = new HashMap<>();
	private static Map<Integer, DemoActions> actionMap = new HashMap<>();
	private static Map<String, RegisterAddress> registerAddressMap = new HashMap<>();
	private static Map<Integer, List<RegisterAddress>> actionRegisterAddressListMap = new HashMap<>();
	private static Map<Integer, List<RegisterAddress>> actionRegisterAddressWriteMap = new HashMap<>();
	private static Map<Integer, List<RegisterAddress>> actionRegisterAddressReadMap = new HashMap<>();

	private static List<RegisterAddress> registerAddresses = null;

	private static List<DemoActions> actionsList = null;
	private static Map<Integer, Integer> burnerFlameAddressMap = null;
	private static List<DemoBurners> _burnersList = null;

	@RequestMapping(value = "/startCooking", method = RequestMethod.GET)
	public ModelAndView stratCooking() {
		try {

			demoOrderProcessingRespository.deleteAll();
			demoOrdersRepository.deleteAll();
			demoOrderStepsRepository.deleteAll();
			_burnersList = demoBurnersRepository.findAll();
			if (_burnersList != null) {
				_burnersList.forEach(bu -> {
					bu.setIsFree(true);
					demoBurnersRepository.save(bu);
				});
			}

			if (writeAllRegistersWithZero()) {
				mc = new ModbusClient(IP_ADDR, PORT);
				// Get Actions List from DB
				actionsList = demoActionsRepository.findAll();
				// Burners List
				_burnersList = demoBurnersRepository.findAll();
				// Get Register Address List from DB
				registerAddresses = registerAddressRepository.findAll();

				_burnersList.forEach(burner -> {
					if (burnerToActionToCoilMap.get(burner.getBurnerNo()) == null) {
						Map<Integer, Integer> acMap = new HashMap<>();
						actionsList.forEach(action -> {
							acMap.put(action.getActionId(), getCoilAddress(burner.getBurnerNo(), action.getActionId()));
						});
						burnerToActionToCoilMap.put(burner.getBurnerNo(), acMap);
					}
				});

				_burnersList = demoBurnersRepository.findAll();
				for (DemoBurners _db : _burnersList) {
					if (_db.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())) {
						isBurner1Free = _db.getIsFree();
					} else if (_db.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
						isBurner2Free = _db.getIsFree();
					} else if (_db.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())) {
						isBurner3Free = _db.getIsFree();
					} else if (_db.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
						isBurner4Free = _db.getIsFree();
					}
				}

				registerAddresses.forEach(registerAddress -> {
					List<RegisterAddress> _list = null;
					List<RegisterAddress> _wlist = null;
					List<RegisterAddress> _rlist = null;
					registerAddressMap.put(registerAddress.getTypeOfAction(), registerAddress);
					if (actionRegisterAddressListMap.get(registerAddress.getActionId()) != null) {
						_list = actionRegisterAddressListMap.get(registerAddress.getActionId());
					} else {
						_list = new ArrayList<>();
					}
					_list.add(registerAddress);
					actionRegisterAddressListMap.put(registerAddress.getActionId(), _list);

					if (registerAddress.getOperationType().equals(OperationTypeEnum.WRITE.getValue())) {
						if (actionRegisterAddressWriteMap.get(registerAddress.getActionId()) != null) {
							_wlist = actionRegisterAddressWriteMap.get(registerAddress.getActionId());
						} else {
							_wlist = new ArrayList<>();
						}
						_wlist.add(registerAddress);
						actionRegisterAddressWriteMap.put(registerAddress.getActionId(), _wlist);
					} else if (registerAddress.getOperationType().equals(OperationTypeEnum.READ.getValue())) {
						if (actionRegisterAddressReadMap.get(registerAddress.getActionId()) != null) {
							_rlist = actionRegisterAddressReadMap.get(registerAddress.getActionId());
						} else {
							_rlist = new ArrayList<>();
						}
						_rlist.add(registerAddress);
						actionRegisterAddressReadMap.put(registerAddress.getActionId(), _rlist);
					}

				});

				burnerFlameAddressMap = getBurnerWiseFlameAddressMap();
				actionsList.forEach(action -> actionMap.put(action.getActionId(), action));

				// Add Order to Burners
				addRecipiesToDemoOrderProcessingCreated();

			} else {
				logger.error("*********** Error Exception in writeAllRegistersWithZero() method............");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.error("*************** IOException ERROR IN EXECUTING: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}

		ModelAndView model = new ModelAndView();
		model.addObject("urlPage", "4BurnerCooking");
		model.setViewName("/admin/orderCooking");
		return model;
	}

	public void addRecipiesToDemoOrderProcessingCreated() {
		// Get Orders List from DB
		List<DemoOrders> ordersList = demoOrdersRepository
				.getByStatus(OrderPreparingStatusEnum.CREATED.getStatusDescription());

		if (ordersList != null && !ordersList.isEmpty()) {

			for (DemoOrders demoOrders : ordersList) {

				int recipeId = demoOrders.getRecipeId();

				DemoRecipes demoRecipes = demoRecipesRepository.getByRecipeIdQtyAndStatus(recipeId, demoOrders.getQty(),
						true);

				if (demoRecipes != null) {

					_burnersList = demoBurnersRepository.findAll();
					for (DemoBurners _db : _burnersList) {
						if (_db.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())) {
							isBurner1Free = _db.getIsFree();
						} else if (_db.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
							isBurner2Free = _db.getIsFree();
						} else if (_db.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())) {
							isBurner3Free = _db.getIsFree();
						} else if (_db.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
							isBurner4Free = _db.getIsFree();
						}
					}

					int burnerNo = 0;

					if (isBurner1Free && isBurner2Free && isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER1.getBurnerNo();
					} else if (!isBurner1Free && isBurner2Free && isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER3.getBurnerNo();
					} else if (isBurner1Free && !isBurner2Free && isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER4.getBurnerNo();
					} else if (isBurner1Free && isBurner2Free && !isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER1.getBurnerNo();
					} else if (isBurner1Free && isBurner2Free && isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER2.getBurnerNo();
					} else if (isBurner1Free && isBurner2Free && !isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER1.getBurnerNo();
					} else if (!isBurner1Free && !isBurner2Free && isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER3.getBurnerNo();
					} else if (isBurner1Free && !isBurner2Free && isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER1.getBurnerNo();
					} else if (!isBurner1Free && isBurner2Free && !isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER2.getBurnerNo();
					} else if (!isBurner1Free && isBurner2Free && isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER3.getBurnerNo();
					} else if (isBurner1Free && !isBurner2Free && !isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER4.getBurnerNo();
					} else if (isBurner1Free && !isBurner2Free && !isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER1.getBurnerNo();
					} else if (!isBurner1Free && isBurner2Free && !isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER2.getBurnerNo();
					} else if (!isBurner1Free && !isBurner2Free && isBurner3Free && !isBurner4Free) {
						burnerNo = BurnerEnum.BURNER3.getBurnerNo();
					} else if (!isBurner1Free && !isBurner2Free && !isBurner3Free && isBurner4Free) {
						burnerNo = BurnerEnum.BURNER4.getBurnerNo();
					}

					DemoBurners db = null;
					if (burnerNo != 0) {
						db = demoBurnersRepository.getByBurnerNo(burnerNo);

						if (db != null) {

							if (getIngredientAvailability(db.getBurnerNo(), recipeId)
									&& getUtensilAvailability(db.getStationId(), recipeId)
									&& getSpatulaAvailability(db.getStationId(), recipeId)
									&& getBowlAvailability(db.getStationId(), recipeId)
									&& getHelathChecks(db.getBurnerNo(), recipeId)) {

								List<DemoRecipeDetails> demoRecipeDetailsList = demoRecipeDetailsRepository
										.findByRecipeId(recipeId);

								if (demoRecipeDetailsList != null && !demoRecipeDetailsList.isEmpty()) {

									if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
										isBurner1Free = false;
										burner1CurrentGroupId = 1;
									} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
										isBurner2Free = false;
										burner2CurrentGroupId = 1;
									} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
										isBurner3Free = false;
										burner3CurrentGroupId = 1;
									} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
										isBurner4Free = false;
										burner4CurrentGroupId = 1;
									}

									List<DemoOrderProcessing> demoOrderProcessingList = new ArrayList<>();
									for (DemoRecipeDetails demoRecipeDetails : demoRecipeDetailsList) {
										DemoOrderProcessing dop = new DemoOrderProcessing();
										dop.setOrderId(demoOrders.getOrderId());
										dop.setRecipeId(recipeId);
										dop.setRecipeName(demoRecipes.getRecipeName());
										dop.setStationId(db.getStationId());
										dop.setBurnerNo(burnerNo);
										dop.setRobotId(db.getRobotId());
										dop.setRecipeDetailsId(demoRecipeDetails.getRecipeDetailsId());
										int actionId = demoRecipeDetails.getActionId();
										dop.setActionId(actionId);
										if (actionId == ActionEnum.VEG_COLLECTION.actionId
												|| actionId == ActionEnum.SPICE_COLLECTION.actionId
												|| actionId == ActionEnum.MEAT_COLLECTION.actionId
												|| actionId == ActionEnum.VEG_PICKUP.actionId
												|| actionId == ActionEnum.SPICE_PICKUP.actionId
												|| actionId == ActionEnum.MEAT_PICKUP.actionId
												|| actionId == ActionEnum.FRYER_PICKUP.actionId
												|| actionId == ActionEnum.LIQUID_DISPENSING.actionId) {

											if (actionId == ActionEnum.VEG_PICKUP.actionId
													|| actionId == ActionEnum.MEAT_PICKUP.actionId
													|| actionId == ActionEnum.SPICE_PICKUP.actionId) {
												dop.setBcWbc((Integer) demoRecipeDetails.getSourceOrType());
											}
											if (actionId == ActionEnum.VEG_COLLECTION.actionId
													|| actionId == ActionEnum.VEG_PICKUP.actionId) {
												dop.setSectionId(SectionEnum.VEG.getLoc());
											} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId
													|| actionId == ActionEnum.MEAT_PICKUP.actionId) {
												dop.setSectionId(SectionEnum.MEAT.getLoc());
											} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId
													|| actionId == ActionEnum.SPICE_PICKUP.actionId) {
												dop.setSectionId(SectionEnum.SPICE.getLoc());
											} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
												dop.setFryerId(db.getFryerId());
												ObjectMapper mapper = new ObjectMapper();
												FryerPickup fp = mapper.convertValue(
														demoRecipeDetails.getSourceOrType(),
														new TypeReference<FryerPickup>() {
														});
												dop.setSectionId(fp.getPickLocation());
												dop.setPoolId(fp.getDropLocation());
												dop.setBcWbc(fp.getBcWbc());
											} else {
												dop.setSectionId(SectionEnum.NOTHING.getLoc());
											}
											dop.setRackId(db.getRackId());
										} else if (actionId == ActionEnum.FRYER_ACTION.actionId
												|| actionId == ActionEnum.FRYER_SERVE.actionId) {
											dop.setFryerId(db.getFryerId());
											ObjectMapper mapper = new ObjectMapper();
											if (actionId == ActionEnum.FRYER_ACTION.actionId) {
												FryerAction fa = mapper.convertValue(
														demoRecipeDetails.getSourceOrType(),
														new TypeReference<FryerAction>() {
														});
												dop.setPoolId(fa.getPoolLocation());
												dop.setSectionId(0);
											} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
												FryerServe fs = mapper.convertValue(demoRecipeDetails.getSourceOrType(),
														new TypeReference<FryerServe>() {
														});
												dop.setPoolId(fs.getPoolLoc());
												dop.setSectionId(0);
											}
										} else {
											dop.setSectionId(0);
										}
										dop.setSourceOrType(demoRecipeDetails.getSourceOrType());
										dop.setQty(demoRecipeDetails.getQty());
										dop.setTime(demoRecipeDetails.getTime());
										dop.setFlame(demoRecipeDetails.getFlame());
										dop.setGroupId(demoRecipeDetails.getGroupId());
										if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.UTENSIL_PICK_WRITE.label())));
										} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.SPATULA_PICK_WRITE.label())));
										} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.VEG_COLLECTION_WRITE.label())));
											dop.setMotorAddressId(getAddress(burnerNo, registerAddressMap
													.get(RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label())));
											dop.setNoOfMotorRegistersToRead(
													actionMap.get(actionId).getNoOfRegistersToRead());
										} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
											dop.setAddressId(getAddress(burnerNo, registerAddressMap
													.get(RegisterEnum.MEAT_COLLECTION_WRITE.label())));
											dop.setMotorAddressId(getAddress(burnerNo, registerAddressMap
													.get(RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label())));
											dop.setNoOfMotorRegistersToRead(
													actionMap.get(actionId).getNoOfRegistersToRead());
										} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
											dop.setAddressId(getAddress(burnerNo, registerAddressMap
													.get(RegisterEnum.SPICE_COLLECTION_WRITE.label())));
											dop.setMotorAddressId(getAddress(burnerNo, registerAddressMap
													.get(RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label())));
											dop.setNoOfMotorRegistersToRead(
													actionMap.get(actionId).getNoOfRegistersToRead());
										} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.VEG_PICKUP_WRITE.label())));
										} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.MEAT_PICKUP_WRITE.label())));
										} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.SPICE_PICKUP_WRITE.label())));
										} else if (actionId == ActionEnum.IGNITION.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.IGNITION_WRITE.label())));
										} else if (actionId == ActionEnum.STIRR.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.STIRR_WRITE.label())));
										} else if (actionId == ActionEnum.TOSS.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.TOSS_WRITE.label())));
										} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
											dop.setAddressId(getAddress(burnerNo, registerAddressMap
													.get(RegisterEnum.LIQUID_DISPENSING_WRITE.label())));
										} else if (actionId == ActionEnum.DELAY.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.DELAY_WRITE.label())));
										} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.FRYER_PICKUP_WRITE.label())));
										} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.FRYER_ACTION_WRITE.label())));
										} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.FRYER_SERVE_WRITE.label())));
										} else if (actionId == ActionEnum.SERVE.actionId) {
											dop.setAddressId(getAddress(burnerNo,
													registerAddressMap.get(RegisterEnum.SERVE_WRITE.label())));
										}
										dop.setFlameAddressId(burnerFlameAddressMap.get(burnerNo));
										dop.setNoOfRegistersToRead(actionMap.get(actionId).getNoOfRegistersToRead());
										dop.setStatus(DemoRecipeDetailsStatusEnum.CREATED.getStatusValue());
										dop.setCreatedTime(new Date(System.currentTimeMillis()));
										demoOrderProcessingList.add(dop);
									}
									// Inserting the Data into DemoOrderProcessing
									demoOrderProcessingRespository.insert(demoOrderProcessingList);
									// Updating the Order Status to Executing
									demoOrders.setStatus(OrderPreparingStatusEnum.EXECUTING.getStatusDescription());
									demoOrders.setActive(false);
									demoOrdersRepository.save(demoOrders);
									// Updating the Burner Free Status
									db.setIsFree(false);
									demoBurnersRepository.save(db);
								} else {
									logger.error("Demo Recipe Details List is Empty or Null for Recipe Id : "
											+ demoOrders.getRecipeId());
								}

							} else {
								logger.error(
										"One of the Status Check failed for Ingredients, Utensils, Spatulas, Bowls, HelathChecks");
							}
						} else {
							logger.error("No Burner Found with the Given Burner No: " + burnerNo
									+ " is Empty or Null for Recipe Id : " + demoOrders.getRecipeId());
						}

					} else {
						logger.info("Burner are Not avialable for the Recipe Id : " + demoOrders.getRecipeId()
								+ ", at this Moment : " + new Date());
					}

				} else {
					logger.error("Recipe Not Found with the Given Recipe Id : " + demoOrders.getRecipeId()
							+ ", for Order : " + demoOrders.getOrderId());
				}
			} // End of DemoOrders For Loop

		} else {
			logger.info("No New Orders found at this Moment : " + new Date());
			if (isBurner1Free && isBurner2Free && isBurner3Free && isBurner4Free) {
				try {
					logger.info("Program is waiting for Next Orders");
					Thread.sleep(1000 * 5);
				} catch (Exception e) {
					logger.error("*********** Error Occured While Thread is Waiting for Orders to be Processed");
					e.printStackTrace();
				}
				addRecipiesToDemoOrderProcessingCreated();
			}
		}

		// Add Data from Create to Active Que
		writeDataToPLCForNextGroupofSteps();
	}

	public void writeDataToPLCForNextGroupofSteps() {

		List<DemoOrderProcessing> s1ActiveList = null;
		List<DemoOrderProcessing> s2ActiveList = null;

		List<DemoOrderProcessing> createdList = demoOrderProcessingRespository
				.getByStatus(DemoRecipeDetailsStatusEnum.CREATED.getStatusValue());

		if (createdList != null && !createdList.isEmpty()) {

			createdList.sort(
					(DemoOrderProcessing d1, DemoOrderProcessing d2) -> d1.getGroupId().compareTo(d2.getGroupId()));
			Map<Integer, Map<Integer, List<DemoOrderProcessing>>> _cMap = new HashMap<>();
			createdList.forEach(_dop -> {
				Map<Integer, List<DemoOrderProcessing>> _tMap = null;
				List<DemoOrderProcessing> _tList = null;
				if (_cMap.get(_dop.getBurnerNo()) != null) {
					_tMap = _cMap.get(_dop.getBurnerNo());
					if (_tMap != null && _tMap.get(_dop.getGroupId()) != null) {
						_tList = _tMap.get(_dop.getGroupId());
					} else {
						_tList = new ArrayList<>();
					}
				} else {
					_tMap = new HashMap<>();
					_tList = new ArrayList<>();
				}
				_tList.add(_dop);
				_tMap.put(_dop.getGroupId(), _tList);
				_cMap.put(_dop.getBurnerNo(), _tMap);
			});

			List<DemoOrderProcessing> _activeList = new ArrayList<>();

			if (station1ActiveBurner == 0 && _cMap.get(BurnerEnum.BURNER1.getBurnerNo()) != null) {
				station1ActiveBurner = BurnerEnum.BURNER1.getBurnerNo();
			} else if (station1ActiveBurner == 0 && _cMap.get(BurnerEnum.BURNER1.getBurnerNo()) == null
					&& _cMap.get(BurnerEnum.BURNER2.getBurnerNo()) != null) {
				station1ActiveBurner = BurnerEnum.BURNER2.getBurnerNo();
			}
			if (station2ActiveBurner == 0 && _cMap.get(BurnerEnum.BURNER3.getBurnerNo()) != null) {
				station2ActiveBurner = BurnerEnum.BURNER3.getBurnerNo();
			} else if (station2ActiveBurner == 0 && _cMap.get(BurnerEnum.BURNER3.getBurnerNo()) == null
					&& _cMap.get(BurnerEnum.BURNER4.getBurnerNo()) != null) {
				station2ActiveBurner = BurnerEnum.BURNER4.getBurnerNo();
			}

			if (station1ActiveBurner.equals(BurnerEnum.BURNER1.getBurnerNo())) {
				Map<Integer, List<DemoOrderProcessing>> _tMap = _cMap.get(BurnerEnum.BURNER1.getBurnerNo());
				if (_tMap != null && _tMap.get(burner1CurrentGroupId) != null) {
					s1ActiveList = _tMap.get(burner1CurrentGroupId);
				}
			} else if (station1ActiveBurner.equals(BurnerEnum.BURNER2.getBurnerNo())) {
				Map<Integer, List<DemoOrderProcessing>> _tMap = _cMap.get(BurnerEnum.BURNER2.getBurnerNo());
				if (_tMap != null && _tMap.get(burner2CurrentGroupId) != null) {
					s1ActiveList = _tMap.get(burner2CurrentGroupId);
				}
			}
			if (station2ActiveBurner.equals(BurnerEnum.BURNER3.getBurnerNo())) {
				Map<Integer, List<DemoOrderProcessing>> _tMap = _cMap.get(BurnerEnum.BURNER3.getBurnerNo());
				if (_tMap != null && _tMap.get(burner3CurrentGroupId) != null) {
					s2ActiveList = _tMap.get(burner3CurrentGroupId);
				}
			} else if (station2ActiveBurner.equals(BurnerEnum.BURNER4.getBurnerNo())) {
				Map<Integer, List<DemoOrderProcessing>> _tMap = _cMap.get(BurnerEnum.BURNER4.getBurnerNo());
				if (_tMap != null && _tMap.get(burner4CurrentGroupId) != null) {
					s2ActiveList = _tMap.get(burner4CurrentGroupId);
				}
			}

			if (s1ActiveList != null && !s1ActiveList.isEmpty()) {
				_activeList.addAll(s1ActiveList);
			}
			if (s2ActiveList != null && !s2ActiveList.isEmpty()) {
				_activeList.addAll(s2ActiveList);
			}

			// Adding Steps from Created List to Active List
			for (DemoOrderProcessing edp : _activeList) {

				// WRITE REGISTERS
				List<RegisterAddress> writeList = actionRegisterAddressWriteMap.get(edp.getActionId());
				if (writeList != null && !writeList.isEmpty()) {
					// Writing Data to Registers
					edp.setStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
					edp.setUpdatedTime(new Date(System.currentTimeMillis()));
					edp = demoOrderProcessingRespository.save(edp);

					updateCurrentBurnerGroupId(edp.getBurnerNo(), edp.getGroupId());
					if (edp.getActionId() == ActionEnum.UTENSIL_PICK.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.UTENSIL_PICK_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.UTENSIL_TYPE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: UTENSIL_PICK - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("UTENSIL_PICK flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.SPATULA_PICK.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.SPATULA_PICK_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.SPATULA_TYPE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: SPATULA_PICK - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("SPATULA_PICK flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.VEG_COLLECTION.actionId) {
						DispenseSetting ds = null;
						DemoBins db = null;
						List<DispenseSetting> dss = null;
						List<DemoBins> dbList = null;

						DemoIngredients ingredient = demoIngredientsRepository
								.findByIngredientId((Integer) edp.getSourceOrType());
						if (ingredient != null) {
							if (ingredient.getDispenseSettings() != null
									&& !ingredient.getDispenseSettings().isEmpty()) {
								dss = ingredient.getDispenseSettings();
								for (DispenseSetting _ds : dss) {
									if ((edp.getQty() >= _ds.getMin()) && (edp.getQty() <= _ds.getMax())) {
										ds = _ds;
										break;
									}
								}

								if (ds != null) {
									dbList = demoBinsRepository.findByIngredientIdRackId(ingredient.getIngredientId(),
											edp.getRackId());
									if (dbList != null && !dbList.isEmpty()) {
										db = dbList.get(0);

										for (RegisterAddress obj : writeList) {
											if (obj.getTypeOfAction().equals(RegisterEnum.VEG_COLLECTION_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_COLLECTION_BIN_NUMBER_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_COLLECTION_WEIGHT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), edp.getQty(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getCutOffPct(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getNormalOpsInPct(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_MOTOR_NORMAL_SPEED_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getNormalOpsSpeed(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_MOTOR_INCHING_SPEED_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getInchingSpeed(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction().equals(
													RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getGapBtwNormalAndInch(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction().equals(
													RegisterEnum.VEG_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getGapBtwInch(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.VEG_MOTOR_INCHING_TIME_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getInchingTime(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else {
												logger.error("******** ERROR: VEG_COLLECTION - Type Of Action : "
														+ obj.getTypeOfAction() + "  ********");
											}
										}

										boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
												edp.getFlame(), edp.getRecipeName());
										logger.info("VEG_COLLECTION flameWrite : " + flameWrite);
									} else {
										logger.error("VEG_COLLECTION Bins not found for Ingredient: "
												+ ingredient.getName());
									}
								} else {
									logger.error("VEG_COLLECTION Dispense Settings not found for the Given Qty: "
											+ edp.getQty() + " for Ingredient: " + ingredient.getName());
								}
							} else {
								logger.error("VEG_COLLECTION Dispense Settings not found for the Ingredient: "
										+ ingredient.getName());
							}
						} else {
							logger.error("VEG_COLLECTION Ingredient not found with the Id: "
									+ (Integer) edp.getSourceOrType());
						}
					} else if (edp.getActionId() == ActionEnum.MEAT_COLLECTION.actionId) {
						DispenseSetting ds = null;
						DemoBins db = null;
						List<DispenseSetting> dss = null;
						List<DemoBins> dbList = null;

						DemoIngredients ingredient = demoIngredientsRepository
								.findByIngredientId((Integer) edp.getSourceOrType());
						if (ingredient != null) {
							if (ingredient.getDispenseSettings() != null
									&& !ingredient.getDispenseSettings().isEmpty()) {
								dss = ingredient.getDispenseSettings();
								for (DispenseSetting _ds : dss) {
									if ((edp.getQty() >= _ds.getMin()) && (edp.getQty() <= _ds.getMax())) {
										ds = _ds;
										break;
									}
								}

								if (ds != null) {
									dbList = demoBinsRepository.findByIngredientIdRackId(ingredient.getIngredientId(),
											edp.getRackId());
									if (dbList != null && !dbList.isEmpty()) {
										db = dbList.get(0);

										for (RegisterAddress obj : writeList) {
											if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_COLLECTION_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_COLLECTION_BIN_NUMBER_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_COLLECTION_WEIGHT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), edp.getQty(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getCutOffPct(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getNormalOpsInPct(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_MOTOR_NORMAL_SPEED_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getNormalOpsSpeed(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_MOTOR_INCHING_SPEED_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getInchingSpeed(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction().equals(
													RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getGapBtwNormalAndInch(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction().equals(
													RegisterEnum.MEAT_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getGapBtwInch(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.MEAT_MOTOR_INCHING_TIME_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getInchingTime(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else {
												logger.error("******** ERROR: MEAT_COLLECTION - Type Of Action : "
														+ obj.getTypeOfAction() + "  ********");
											}
										}

										boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
												edp.getFlame(), edp.getRecipeName());
										logger.info("MEAT_COLLECTION flameWrite : " + flameWrite);
									} else {
										logger.error("MEAT_COLLECTION Bins not found for Ingredient: "
												+ ingredient.getName());
									}
								} else {
									logger.error("MEAT_COLLECTION Dispense Settings not found for the Given Qty: "
											+ edp.getQty() + " for Ingredient: " + ingredient.getName());
								}
							} else {
								logger.error("MEAT_COLLECTION Dispense Settings not found for the Ingredient: "
										+ ingredient.getName());
							}
						} else {
							logger.error("MEAT_COLLECTION Ingredient not found with the Id: "
									+ (Integer) edp.getSourceOrType());
						}
					} else if (edp.getActionId() == ActionEnum.SPICE_COLLECTION.actionId) {
						DispenseSetting ds = null;
						DemoBins db = null;
						List<DispenseSetting> dss = null;
						List<DemoBins> dbList = null;

						DemoIngredients ingredient = demoIngredientsRepository
								.findByIngredientId((Integer) edp.getSourceOrType());
						if (ingredient != null) {
							if (ingredient.getDispenseSettings() != null
									&& !ingredient.getDispenseSettings().isEmpty()) {
								dss = ingredient.getDispenseSettings();
								for (DispenseSetting _ds : dss) {
									if ((edp.getQty() >= _ds.getMin()) && (edp.getQty() <= _ds.getMax())) {
										ds = _ds;
										break;
									}
								}

								if (ds != null) {
									dbList = demoBinsRepository.findByIngredientIdRackId(ingredient.getIngredientId(),
											edp.getRackId());
									if (dbList != null && !dbList.isEmpty()) {
										db = dbList.get(0);

										for (RegisterAddress obj : writeList) {
											if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_COLLECTION_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), edp.getActionId(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_COLLECTION_BIN_NUMBER_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_COLLECTION_WEIGHT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), edp.getQty(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_MOTOR_CUTOFF_IN_PCT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getCutOffPct(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_MOTOR_NORMAL_IN_PCT_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getNormalOpsInPct(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_MOTOR_NORMAL_SPEED_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getNormalOpsSpeed(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_MOTOR_INCHING_SPEED_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getInchingSpeed(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction().equals(
													RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_NORMAL_AND_INCH_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getGapBtwNormalAndInch(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction().equals(
													RegisterEnum.SPICE_MOTOR_TIME_GAP_BETWEEN_INCHING_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getGapBtwInch(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else if (obj.getTypeOfAction()
													.equals(RegisterEnum.SPICE_MOTOR_INCHING_TIME_WRITE.label)) {
												boolean result = invokeWriteToRegisterAPI(
														getAddress(edp.getBurnerNo(), obj), ds.getInchingTime(),
														edp.getRecipeName());
												logger.info(obj.getTypeOfAction() + " : " + result);
											} else {
												logger.error("******** ERROR: SPICE_COLLECTION - Type Of Action : "
														+ obj.getTypeOfAction() + "  ********");
											}
										}

										boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(),
												edp.getFlame(), edp.getRecipeName());
										logger.info("SPICE_COLLECTION flameWrite : " + flameWrite);
									} else {
										logger.error("SPICE_COLLECTION Bins not found for Ingredient: "
												+ ingredient.getName());
									}
								} else {
									logger.error("SPICE_COLLECTION Dispense Settings not found for the Given Qty: "
											+ edp.getQty() + " for Ingredient: " + ingredient.getName());
								}
							} else {
								logger.error("SPICE_COLLECTION Dispense Settings not found for the Ingredient: "
										+ ingredient.getName());
							}
						} else {
							logger.error("SPICE_COLLECTION Ingredient not found with the Id: "
									+ (Integer) edp.getSourceOrType());
						}
					} else if (edp.getActionId() == ActionEnum.VEG_PICKUP.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.VEG_PICKUP_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.VEG_PICKUP_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: VEG_PICKUP- Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("VEG_PICKUP flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.MEAT_PICKUP.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_PICKUP_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.MEAT_PICKUP_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: MEAT_PICKUP- Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("MEAT_PICKUP flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.SPICE_PICKUP.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_PICKUP_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.SPICE_PICKUP_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: SPICE_PICKUP - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("SPICE_PICKUP flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.IGNITION.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.IGNITION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.IGNITION_DELAY_TIME_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getTime(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.FLAME_LEVEL_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
										edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: IGNITION - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}
					} else if (edp.getActionId() == ActionEnum.STIRR.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_TYPE_NUMBER_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.STIRR_TIME_IN_MILLI_SEC_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getTime(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: STIRR - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("STIRR flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.TOSS.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_TYPE_NUMBER_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.TOSS_TIME_IN_MILLI_SEC_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getTime(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.info("******** ERROR: TOSS - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("TOSS flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.LIQUID_DISPENSING.actionId) {
						ObjectMapper mapper = new ObjectMapper();
						List<LiquidBin> lb = mapper.convertValue(edp.getSourceOrType(),
								new TypeReference<List<LiquidBin>>() {
								});

						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.LIQUID_DISPENSING_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_1_WRITE.label)) {
								if (lb.size() > 0) {
									List<DemoBins> dbList = demoBinsRepository.findByIngredientId(lb.get(0).getIngId());
									if (!dbList.isEmpty()) {
										DemoBins db = null;
										if (dbList.get(0) != null
												&& (edp.getBurnerNo() == 1 || edp.getBurnerNo() == 2)) {
											db = dbList.get(0);
										} else if (dbList.get(1) != null
												&& (edp.getBurnerNo() == 3 || edp.getBurnerNo() == 4)) {
											db = dbList.get(1);
										}
										if (db != null && db.getBinNo() != null) {
											boolean result = invokeWriteToRegisterAPI(
													getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
													edp.getRecipeName());
											logger.info(obj.getTypeOfAction() + " : " + result);
										} else {
											logger.error("Invalid Mapping for address: " + edp.getAddressId()
													+ ", No Bin found with the Liquid 1 Mapping : "
													+ lb.get(0).getIngId());
										}
									} else {
										logger.error("address: " + edp.getAddressId()
												+ ", No Bin 1 found with the Liquid Mapping : " + lb.get(0).getIngId());
									}
								} else {
									logger.info("address: " + edp.getAddressId()
											+ ", Need to Dispense atleast 1 Liquid from Bin");
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_1_WRITE.label)) {
								if (lb.size() > 0) {
									boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
											lb.get(0).getMs() / 100, edp.getRecipeName());
									logger.info(obj.getTypeOfAction() + " : " + result);
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_2_WRITE.label)) {
								if (lb.size() >= 2) {
									List<DemoBins> dbList = demoBinsRepository.findByIngredientId(lb.get(1).getIngId());
									if (!dbList.isEmpty()) {
										DemoBins db = null;
										if (dbList.get(0) != null
												&& (edp.getBurnerNo() == 1 || edp.getBurnerNo() == 2)) {
											db = dbList.get(0);
										} else if (dbList.get(1) != null
												&& (edp.getBurnerNo() == 3 || edp.getBurnerNo() == 4)) {
											db = dbList.get(1);
										}
										if (db != null && db.getBinNo() != null) {
											boolean result = invokeWriteToRegisterAPI(
													getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
													edp.getRecipeName());
											logger.info(obj.getTypeOfAction() + " : " + result);
										} else {
											logger.error("Invalid Mapping for address: " + edp.getAddressId()
													+ ", No Bin found with the Liquid 2 Mapping : "
													+ lb.get(1).getIngId());
										}
									} else {
										logger.error("address: " + edp.getAddressId()
												+ ", No Bin found with the Liquid 2 Mapping : " + lb.get(1).getIngId());
									}
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_2_WRITE.label)) {
								if (lb.size() >= 2) {
									boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
											lb.get(1).getMs() / 100, edp.getRecipeName());
									logger.info(obj.getTypeOfAction() + " : " + result);
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_3_WRITE.label)) {
								if (lb.size() >= 3) {
									List<DemoBins> dbList = demoBinsRepository.findByIngredientId(lb.get(2).getIngId());
									if (!dbList.isEmpty()) {
										DemoBins db = null;
										if (dbList.get(0) != null
												&& (edp.getBurnerNo() == 1 || edp.getBurnerNo() == 2)) {
											db = dbList.get(0);
										} else if (dbList.get(1) != null
												&& (edp.getBurnerNo() == 3 || edp.getBurnerNo() == 4)) {
											db = dbList.get(1);
										}
										if (db != null && db.getBinNo() != null) {
											boolean result = invokeWriteToRegisterAPI(
													getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
													edp.getRecipeName());
											logger.info(obj.getTypeOfAction() + " : " + result);
										} else {
											logger.error("Invalid Mapping for address: " + edp.getAddressId()
													+ ", No Bin found with the Liquid 3 Mapping : "
													+ lb.get(2).getIngId());
										}
									} else {
										logger.error("address: " + edp.getAddressId()
												+ ", No Bin found with the Liquid 3 Mapping : " + lb.get(2).getIngId());
									}
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_3_WRITE.label)) {
								if (lb.size() >= 3) {
									boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
											lb.get(2).getMs() / 100, edp.getRecipeName());
									logger.info(obj.getTypeOfAction() + " : " + result);
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_4_WRITE.label)) {
								if (lb.size() >= 4) {
									List<DemoBins> dbList = demoBinsRepository.findByIngredientId(lb.get(3).getIngId());
									if (!dbList.isEmpty()) {
										DemoBins db = null;
										if (dbList.get(0) != null
												&& (edp.getBurnerNo() == 1 || edp.getBurnerNo() == 2)) {
											db = dbList.get(0);
										} else if (dbList.get(1) != null
												&& (edp.getBurnerNo() == 3 || edp.getBurnerNo() == 4)) {
											db = dbList.get(1);
										}
										if (db != null && db.getBinNo() != null) {
											boolean result = invokeWriteToRegisterAPI(
													getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
													edp.getRecipeName());
											logger.info(obj.getTypeOfAction() + " : " + result);
										} else {
											logger.error("Invalid Mapping for address: " + edp.getAddressId()
													+ ", No Bin found with the Liquid 4 Mapping : "
													+ lb.get(3).getIngId());
										}
									} else {
										logger.error("address: " + edp.getAddressId()
												+ ", No Bin found with the Liquid 4 Mapping : " + lb.get(3).getIngId());
									}
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_4_WRITE.label)) {
								if (lb.size() >= 4) {
									boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
											lb.get(3).getMs() / 100, edp.getRecipeName());
									logger.info(obj.getTypeOfAction() + " : " + result);
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_LIQ_BIN_NUMBER_5_WRITE.label)) {
								if (lb.size() >= 5) {
									List<DemoBins> dbList = demoBinsRepository.findByIngredientId(lb.get(4).getIngId());
									if (!dbList.isEmpty()) {
										DemoBins db = null;
										if (dbList.get(0) != null
												&& (edp.getBurnerNo() == 1 || edp.getBurnerNo() == 2)) {
											db = dbList.get(0);
										} else if (dbList.get(1) != null
												&& (edp.getBurnerNo() == 3 || edp.getBurnerNo() == 4)) {
											db = dbList.get(1);
										}
										if (db != null && db.getBinNo() != null) {
											boolean result = invokeWriteToRegisterAPI(
													getAddress(edp.getBurnerNo(), obj), db.getBinNo(),
													edp.getRecipeName());
											logger.info(obj.getTypeOfAction() + " : " + result);
										} else {
											logger.error("Invalid Mapping for address: " + edp.getAddressId()
													+ ", No Bin found with the Liquid 5 Mapping : "
													+ lb.get(4).getIngId());
										}
									} else {
										logger.info("address: " + edp.getAddressId()
												+ ", No Bin found with the Liquid 5 Mapping : " + lb.get(4).getIngId());
									}
								}
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.LIQUID_DISPENSING_DELAY_TIME_5_WRITE.label)) {
								if (lb.size() >= 5) {
									boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
											lb.get(4).getMs() / 100, edp.getRecipeName());
									logger.info(obj.getTypeOfAction() + " : " + result);
								}
							} else {
								logger.error("******** ERROR: LIQUID_DISPENSING - Type Of Action : "
										+ obj.getTypeOfAction() + "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("LIQUID_DISPENSING flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.DELAY.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.DELAY_TIME_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getTime(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: DELAY - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("*************************        DELAY flameWrite : " + flameWrite);

						if (edp.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())
								|| edp.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
							if (!isBurner1Free && !isBurner2Free) {
								yeildFlag1 = true;
							}
						} else if (edp.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())
								|| edp.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
							if (!isBurner3Free && !isBurner4Free) {
								yeildFlag2 = true;
							}
						}
					} else if (edp.getActionId() == ActionEnum.FRYER_PICKUP.actionId) {
						ObjectMapper mapper = new ObjectMapper();
						FryerPickup fp = mapper.convertValue(edp.getSourceOrType(), new TypeReference<FryerPickup>() {
						});
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_PICKUP_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fp.getPickLocation(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.FRYER_PICKUP_DROP_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fp.getDropLocation(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.FRYER_PICKUP_BOWL_CHANGE_OR_WITHOUT_BOWL_CHANGE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fp.getBcWbc(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: FRYER_PICKUP - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("FRYER_PICKUP flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.FRYER_ACTION.actionId) {
						ObjectMapper mapper = new ObjectMapper();
						FryerAction fa = mapper.convertValue(edp.getSourceOrType(), new TypeReference<FryerAction>() {
						});
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_ACTION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.FRYER_ACTION_POOL_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fa.getPoolLocation(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_ACTION_LIFT_DIP_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fa.getLiftDip(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.error("******** ERROR: FRYER_ACTION - Type Of Action : " + obj.getTypeOfAction()
										+ "  ********");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("FRYER_ACTION flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.FRYER_SERVE.actionId) {
						ObjectMapper mapper = new ObjectMapper();
						FryerServe fs = mapper.convertValue(edp.getSourceOrType(), new TypeReference<FryerServe>() {
						});
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.FRYER_SERVE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.FRYER_SERVE_POOL_LOCATION_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fs.getPoolLoc(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.FRYER_SERVE_TRANSFER_OR_SERVE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										fs.getTransOrServe(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.info("******************* ERROR: FRYER_SERVE *******************");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("FRYER_SERVE flameWrite : " + flameWrite);
					} else if (edp.getActionId() == ActionEnum.SERVE.actionId) {
						for (RegisterAddress obj : writeList) {
							if (obj.getTypeOfAction().equals(RegisterEnum.SERVE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										edp.getActionId(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else if (obj.getTypeOfAction()
									.equals(RegisterEnum.SERVE_TYPE_WRITE.label)) {
								boolean result = invokeWriteToRegisterAPI(getAddress(edp.getBurnerNo(), obj),
										(Integer) edp.getSourceOrType(), edp.getRecipeName());
								logger.info(obj.getTypeOfAction() + " : " + result);
							} else {
								logger.info("******************* ERROR: SERVE *******************");
							}
						}

						boolean flameWrite = invokeWriteToRegisterAPI(edp.getFlameAddressId(), edp.getFlame(),
								edp.getRecipeName());
						logger.info("SERVE flameWrite : " + flameWrite);
					}

				} else {
					logger.error(
							"No WRITE REGISTERS found in " + actionMap.get(edp.getActionId()).getName() + " Action");
				}

			}

		} else {
			logger.info("No Instructions found in the Created Que to Write data to PLC..............");
		}

		// Read Coils Status
		readCoilsAndUpdateActiveQue();
	}

	public void readCoilsAndUpdateActiveQue() {

		boolean considerBurner1 = false;
		boolean considerBurner2 = false;
		boolean considerBurner3 = false;
		boolean considerBurner4 = false;

		List<DemoOrderProcessing> activeList = demoOrderProcessingRespository
				.getByStatus(DemoRecipeDetailsStatusEnum.ACTIVE.getStatusValue());
		activeList.sort((DemoOrderProcessing d1, DemoOrderProcessing d2) -> d1.getGroupId().compareTo(d2.getGroupId()));
		Map<Integer, Map<Integer, List<DemoOrderProcessing>>> _aMap = new HashMap<>();
		activeList.forEach(_dop -> {
			Map<Integer, List<DemoOrderProcessing>> _tMap = null;
			List<DemoOrderProcessing> _tList = null;
			if (_aMap.get(_dop.getBurnerNo()) != null) {
				_tMap = _aMap.get(_dop.getBurnerNo());
				if (_tMap != null && _tMap.get(_dop.getGroupId()) != null) {
					_tList = _tMap.get(_dop.getGroupId());
				} else {
					_tList = new ArrayList<>();
				}
			} else {
				_tMap = new HashMap<>();
				_tList = new ArrayList<>();
			}
			_tList.add(_dop);
			_tMap.put(_dop.getGroupId(), _tList);
			_aMap.put(_dop.getBurnerNo(), _tMap);
		});

		List<DemoOrderProcessing> b1ActiveList = null;
		List<DemoOrderProcessing> b2ActiveList = null;
		List<DemoOrderProcessing> b3ActiveList = null;
		List<DemoOrderProcessing> b4ActiveList = null;

		Map<Integer, List<DemoOrderProcessing>> b1ActiveMap = _aMap.get(BurnerEnum.BURNER1.getBurnerNo());
		Map<Integer, List<DemoOrderProcessing>> b2ActiveMap = _aMap.get(BurnerEnum.BURNER2.getBurnerNo());
		Map<Integer, List<DemoOrderProcessing>> b3ActiveMap = _aMap.get(BurnerEnum.BURNER3.getBurnerNo());
		Map<Integer, List<DemoOrderProcessing>> b4ActiveMap = _aMap.get(BurnerEnum.BURNER4.getBurnerNo());

		if (b1ActiveMap != null && b1ActiveMap.get(burner1CurrentGroupId) != null) {
			b1ActiveList = b1ActiveMap.get(burner1CurrentGroupId);
			considerBurner1 = true;
		} else {
			considerBurner1 = false;
		}
		if (b2ActiveMap != null && b2ActiveMap.get(burner2CurrentGroupId) != null) {
			b2ActiveList = b2ActiveMap.get(burner2CurrentGroupId);
			considerBurner2 = true;
		} else {
			considerBurner2 = false;
		}
		if (b3ActiveMap != null && b3ActiveMap.get(burner3CurrentGroupId) != null) {
			b3ActiveList = b3ActiveMap.get(burner3CurrentGroupId);
			considerBurner3 = true;
		} else {
			considerBurner3 = false;
		}
		if (b4ActiveMap != null && b4ActiveMap.get(burner4CurrentGroupId) != null) {
			b4ActiveList = b4ActiveMap.get(burner4CurrentGroupId);
			considerBurner4 = true;
		} else {
			considerBurner4 = false;
		}

		// Switching Burner When Delay is started
		if (yeildFlag1) {
			if (station1ActiveBurner == 1) {
				station1ActiveBurner = 2;
			} else if (station1ActiveBurner == 2) {
				station1ActiveBurner = 1;
			}
			yeildFlag1 = false;
		}
		if (yeildFlag2) {
			if (station2ActiveBurner == 3) {
				station2ActiveBurner = 4;
			} else if (station2ActiveBurner == 4) {
				station2ActiveBurner = 3;
			}
			yeildFlag2 = false;
		}

		// Coil Status Reading
		boolean flag = true;
		int count = 0;
		while (flag) {
			try {
				Thread.sleep(1000);
				++count;
				logger.info("Iteration Count: " + count);
				List<DemoOrderProcessing> b1ListToRemove = new ArrayList<>();
				List<DemoOrderProcessing> b2ListToRemove = new ArrayList<>();
				List<DemoOrderProcessing> b3ListToRemove = new ArrayList<>();
				List<DemoOrderProcessing> b4ListToRemove = new ArrayList<>();
				boolean[] coilsArray = invokeReadCoilsAPI();
				if (activeList != null && !activeList.isEmpty() && flag) {

					for (DemoOrderProcessing _dop : activeList) {
						int tmpAddress = burnerToActionToCoilMap.get(_dop.getBurnerNo()).get(_dop.getActionId());
						boolean tmpVale = coilsArray[tmpAddress % 5000];
						if (tmpVale) {
							int[] registerValues = invokePrintReadHoldingRegistersAPI(_dop.getRecipeName(),
									_dop.getActionId(), _dop.getAddressId(), _dop.getNoOfRegistersToRead());
							int[] flameValues = invokePrintReadHoldingRegistersAPI(_dop.getRecipeName(),
									_dop.getActionId(), _dop.getFlameAddressId(), 2);
							invokeWriteToMultipeRegisterAPI(_dop.getRecipeName(), _dop.getActionId(),
									_dop.getAddressId(), _dop.getNoOfRegistersToRead());

							int[] motorRegisterValues = null;
							if (_dop.getActionId().equals(ActionEnum.VEG_COLLECTION.actionId)
									|| _dop.getActionId().equals(ActionEnum.MEAT_COLLECTION.actionId)
									|| _dop.getActionId().equals(ActionEnum.SPICE_COLLECTION.actionId)) {
								motorRegisterValues = invokePrintReadHoldingRegistersAPI(_dop.getRecipeName(),
										_dop.getActionId(), _dop.getMotorAddressId(),
										_dop.getNoOfMotorRegistersToRead());
								invokeWriteToMultipeRegisterAPI(_dop.getRecipeName(), _dop.getActionId(),
										_dop.getAddressId(), _dop.getNoOfMotorRegistersToRead());
							}
							if (_dop.getActionId().equals(ActionEnum.DELAY.actionId)) {
								invokeWriteToRegisterAPI(burnerFlameAddressMap.get(_dop.getBurnerNo()), IDLE_FLAME,
										_dop.getRecipeName());
							}

							_dop.setStatus(DemoRecipeDetailsStatusEnum.DONE.getStatusValue());
							_dop.setDoneTime(new Date(System.currentTimeMillis()));
							demoOrderProcessingRespository.save(_dop);

							// Write Executed Data to DB
							writeDataToDB(_dop, registerValues, flameValues, motorRegisterValues);

							if (_dop.getActionId().equals(ActionEnum.STIRR.actionId)
									|| _dop.getActionId().equals(ActionEnum.TOSS.actionId)) {
								if (_dop.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())
										|| _dop.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
									if (!isBurner1Free && !isBurner2Free) {
										yeildFlag1 = true;
									}
								} else if (_dop.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())
										|| _dop.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
									if (!isBurner3Free && !isBurner4Free) {
										yeildFlag2 = true;
									}
								}
								invokeWriteToRegisterAPI(burnerFlameAddressMap.get(_dop.getBurnerNo()), IDLE_FLAME,
										_dop.getRecipeName());
							}

							if (_dop.getActionId().equals(ActionEnum.SERVE.actionId)) {
								if (_dop.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())
										|| _dop.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
									station1ActiveBurner = 0;
								}
								if (_dop.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())
										|| _dop.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
									station2ActiveBurner = 0;
								}
								if (_dop.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())) {
									isBurner1Free = true;
								} else if (_dop.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
									isBurner2Free = true;
								} else if (_dop.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())) {
									isBurner3Free = true;
								} else if (_dop.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
									isBurner4Free = true;
								}
								DemoBurners db = demoBurnersRepository.getByBurnerNo(_dop.getBurnerNo());
								if (db != null) {
									db.setIsFree(true);
									demoBurnersRepository.save(db);
									DemoOrders demoOrders = demoOrdersRepository.getByOrderId(_dop.getOrderId());
									if (demoOrders != null) {
										// Making the Order Completion
										demoOrders.setStatus(OrderPreparingStatusEnum.COMPLETED.getStatusDescription());
										demoOrdersRepository.save(demoOrders);
										// Making the Burner free
										db.setIsFree(true);
										demoBurnersRepository.save(db);
									} else {
										logger.error(
												"DemoOrders not Found with the given OrderId : " + _dop.getOrderId());
									}
								} else {
									logger.error(
											"DemoBurners not Found with the given BurnerNo : " + _dop.getBurnerNo());
								}
							}

							if (_dop.getBurnerNo().equals(BurnerEnum.BURNER1.getBurnerNo())) {
								b1ListToRemove.add(_dop);
							}
							if (_dop.getBurnerNo().equals(BurnerEnum.BURNER2.getBurnerNo())) {
								b2ListToRemove.add(_dop);
							}
							if (_dop.getBurnerNo().equals(BurnerEnum.BURNER3.getBurnerNo())) {
								b3ListToRemove.add(_dop);
							}
							if (_dop.getBurnerNo().equals(BurnerEnum.BURNER4.getBurnerNo())) {
								b4ListToRemove.add(_dop);
							}

							if (yeildFlag1) {
								if (station1ActiveBurner == 1) {
									station1ActiveBurner = 2;
								} else if (station1ActiveBurner == 2) {
									station1ActiveBurner = 1;
								}
								yeildFlag1 = false;
							}
							if (yeildFlag2) {
								if (station2ActiveBurner == 3) {
									station2ActiveBurner = 4;
								} else if (station2ActiveBurner == 4) {
									station2ActiveBurner = 3;
								}
								yeildFlag2 = false;
							}
						}
					}

					if (!b1ListToRemove.isEmpty() && b1ActiveList != null) {
						activeList.removeAll(b1ListToRemove);
						b1ActiveList.removeAll(b1ListToRemove);
					}
					if (!b2ListToRemove.isEmpty() && b2ActiveList != null) {
						activeList.removeAll(b2ListToRemove);
						b2ActiveList.removeAll(b2ListToRemove);
					}
					if (!b3ListToRemove.isEmpty() && b3ActiveList != null) {
						activeList.removeAll(b3ListToRemove);
						b3ActiveList.removeAll(b3ListToRemove);
					}
					if (!b4ListToRemove.isEmpty() && b4ActiveList != null) {
						activeList.removeAll(b4ListToRemove);
						b4ActiveList.removeAll(b4ListToRemove);
					}

					if (considerBurner1 && (b1ActiveList == null || (b1ActiveList != null && b1ActiveList.isEmpty()))) {
						flag = false;
						burner1CurrentGroupId += 1;
					}
					if (considerBurner2 && (b2ActiveList == null || (b2ActiveList != null && b2ActiveList.isEmpty()))) {
						flag = false;
						burner2CurrentGroupId += 1;
					}
					if (considerBurner3 && (b3ActiveList == null || (b3ActiveList != null && b3ActiveList.isEmpty()))) {
						flag = false;
						burner3CurrentGroupId += 1;
					}
					if (considerBurner4 && (b4ActiveList == null || (b4ActiveList != null && b4ActiveList.isEmpty()))) {
						flag = false;
						burner4CurrentGroupId += 1;
					}

					if (!flag) {
						break;
					}

				} else {
					flag = false;
					break;
				}
			} catch (Exception e) {
				logger.error("*************** ERROR IN EXECUTING readCoilsAndUpdateActiveQue()");
				e.printStackTrace();
			}
		}

		// Checking are there any New Recipe to add
		addRecipiesToDemoOrderProcessingCreated();
	}

	public void writeDataToDB(DemoOrderProcessing _dop, int[] registerValues, int[] flameValues,
			int[] motorRegisterValues) {
		DemoOrderSteps dos = new DemoOrderSteps();
		dos.setBurnerNo(_dop.getBurnerNo());
		dos.setOrderId(_dop.getOrderId());
		dos.setRecipeId(_dop.getRecipeId());
		dos.setRecipeName(_dop.getRecipeName());
		dos.setDop(_dop);
		if (_dop.getActionId().equals(ActionEnum.UTENSIL_PICK.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				UtensilPick up = new UtensilPick();
				up.setUtensil_pick_write(registerValues[0]);
				up.setUtensil_type_write(registerValues[1]);
				up.setUtensil_pick_read(registerValues[4]);
				up.setUtensil_type_read(registerValues[5]);
				up.setUtensil_pick_run_time_read(registerValues[6]);
				dos.setUtensilPick(up);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.SPATULA_PICK.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				SpatulaPick sp = new SpatulaPick();
				sp.setSpatula_pick_write(registerValues[0]);
				sp.setSpatula_type_write(registerValues[1]);
				sp.setSpatula_pick_read(registerValues[4]);
				sp.setSpatula_type_read(registerValues[5]);
				sp.setSpatula_pick_run_time_read(registerValues[6]);
				dos.setSpatulaPick(sp);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.VEG_COLLECTION.actionId)) {
			VegCollection vc = new VegCollection();
			if (registerValues != null && registerValues.length > 0) {
				vc.setVeg_collection_write(registerValues[0]);
				vc.setVeg_collection_bin_number_write(registerValues[1]);
				vc.setVeg_collection_weight_write(registerValues[2]);
				vc.setVeg_collection_read(registerValues[4]);
				vc.setVeg_collection_bin_number_read(registerValues[5]);
				vc.setVeg_collection_achieved_weight_read(registerValues[6]);
				vc.setVeg_collection_run_time_read(registerValues[7]);
				vc.setVeg_collection_weighing_run_time_read(registerValues[8]);
			}
			if (motorRegisterValues != null && motorRegisterValues.length > 0) {
				vc.setVeg_motor_cutoff_in_pct_write(motorRegisterValues[0]);
				vc.setVeg_motor_normal_in_pct_write(motorRegisterValues[1]);
				vc.setVeg_motor_normal_speed_write(motorRegisterValues[2]);
				vc.setVeg_motor_inching_speed_write(motorRegisterValues[3]);
				vc.setVeg_motor_time_gap_between_normal_and_inch_write(motorRegisterValues[4]);
				vc.setVeg_motor_time_gap_between_inching_write(motorRegisterValues[5]);
				vc.setVeg_motor_inching_time_write(motorRegisterValues[6]);
			}
			dos.setVegCollection(vc);
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.MEAT_COLLECTION.actionId)) {
			MeatCollection mc = new MeatCollection();
			if (registerValues != null && registerValues.length > 0) {
				mc.setMeat_collection_write(registerValues[0]);
				mc.setMeat_collection_bin_number_write(registerValues[1]);
				mc.setMeat_collection_weight_write(registerValues[2]);
				mc.setMeat_collection_read(registerValues[4]);
				mc.setMeat_collection_bin_number_read(registerValues[5]);
				mc.setMeat_collection_achieved_weight_read(registerValues[6]);
				mc.setMeat_collection_run_time_read(registerValues[7]);
				mc.setMeat_collection_weighing_run_time_read(registerValues[8]);
			}
			if (motorRegisterValues != null && motorRegisterValues.length > 0) {
				mc.setMeat_motor_cutoff_in_pct_write(motorRegisterValues[0]);
				mc.setMeat_motor_normal_in_pct_write(motorRegisterValues[1]);
				mc.setMeat_motor_normal_speed_write(motorRegisterValues[2]);
				mc.setMeat_motor_inching_speed_write(motorRegisterValues[3]);
				mc.setMeat_motor_time_gap_between_normal_and_inch_write(motorRegisterValues[4]);
				mc.setMeat_motor_time_gap_between_inching_write(motorRegisterValues[5]);
				mc.setMeat_motor_inching_time_write(motorRegisterValues[6]);
			}
			dos.setMeatCollection(mc);
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.SPICE_COLLECTION.actionId)) {
			SpiceCollection sc = new SpiceCollection();
			if (registerValues != null && registerValues.length > 0) {
				sc.setSpice_collection_write(registerValues[0]);
				sc.setSpice_collection_bin_number_write(registerValues[1]);
				sc.setSpice_collection_weight_write(registerValues[2]);
				sc.setSpice_collection_read(registerValues[4]);
				sc.setSpice_collection_bin_number_read(registerValues[5]);
				sc.setSpice_collection_achieved_weight_read(registerValues[6]);
				sc.setSpice_collection_run_time_read(registerValues[7]);
				sc.setSpice_collection_weighing_run_time_read(registerValues[8]);
			}
			if (motorRegisterValues != null && motorRegisterValues.length > 0) {
				sc.setSpice_motor_cutoff_in_pct_write(motorRegisterValues[0]);
				sc.setSpice_motor_normal_in_pct_write(motorRegisterValues[1]);
				sc.setSpice_motor_normal_speed_write(motorRegisterValues[2]);
				sc.setSpice_motor_inching_speed_write(motorRegisterValues[3]);
				sc.setSpice_motor_time_gap_between_normal_and_inch_write(motorRegisterValues[4]);
				sc.setSpice_motor_time_gap_between_inching_write(motorRegisterValues[5]);
				sc.setSpice_motor_inching_time_write(motorRegisterValues[6]);
			}
			dos.setSpiceCollection(sc);
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.VEG_PICKUP.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				VegPickup vp = new VegPickup();
				vp.setVeg_pickup_write(registerValues[0]);
				vp.setVeg_pickup_location_write(registerValues[1]);
				vp.setVeg_pickup_read(registerValues[4]);
				vp.setVeg_pickup_location_read(registerValues[5]);
				vp.setVeg_pickup_run_time_read(registerValues[6]);
				dos.setVegPickup(vp);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.MEAT_PICKUP.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				MeatPickup mp = new MeatPickup();
				mp.setMeat_pickup_write(registerValues[0]);
				mp.setMeat_pickup_location_write(registerValues[1]);
				mp.setMeat_pickup_read(registerValues[4]);
				mp.setMeat_pickup_location_read(registerValues[5]);
				mp.setMeat_pickup_run_time_read(registerValues[6]);
				dos.setMeatPickup(mp);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.SPICE_PICKUP.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				SpicePickup sp = new SpicePickup();
				sp.setSpice_pickup_write(registerValues[0]);
				sp.setSpice_pickup_location_write(registerValues[1]);
				sp.setSpice_pickup_read(registerValues[4]);
				sp.setSpice_pickup_location_read(registerValues[5]);
				sp.setSpice_pickup_run_time_read(registerValues[6]);
				dos.setSpicePickup(sp);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.IGNITION.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				Ignition ig = new Ignition();
				ig.setIgnition_write(registerValues[0]);
				ig.setIgnition_delay_time_write(registerValues[3]);
				ig.setIgnition_read(registerValues[4]);
				ig.setIgnition_run_time_read(registerValues[6]);
				if (flameValues != null && flameValues.length > 0) {
					ig.setFlame_level_write(flameValues[0]);
					ig.setFlame_level_read(flameValues[1]);
					dos.setFlameWrite(flameValues[0]);
					dos.setFlameRead(flameValues[1]);
				}
				dos.setIgnition(ig);
			}
		} else if (_dop.getActionId().equals(ActionEnum.STIRR.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				Stirr st = new Stirr();
				st.setStirr_write(registerValues[0]);
				st.setStirr_stir_type_number_write(registerValues[1]);
				st.setStirr_time_in_milli_sec_write(registerValues[2]);
				st.setStirr_read(registerValues[4]);
				st.setStirr_stir_type_number_read(registerValues[5]);
				st.setStirr_run_time_read(registerValues[6]);
				dos.setStirr(st);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.TOSS.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				Toss to = new Toss();
				to.setToss_write(registerValues[0]);
				to.setToss_toss_type_number_write(registerValues[1]);
				to.setToss_time_in_milli_sec_write(registerValues[2]);
				to.setToss_read(registerValues[4]);
				to.setToss_toss_type_number_read(registerValues[5]);
				to.setToss_run_time_read(registerValues[6]);
				dos.setToss(to);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.LIQUID_DISPENSING.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				LiquidDispensing ld = new LiquidDispensing();
				ld.setLiquid_dispensing_write(registerValues[0]);
				ld.setLiquid_dispensing_liq_bin_number_1_write(registerValues[1]);
				ld.setLiquid_dispensing_delay_time_1_write(registerValues[2]);
				ld.setLiquid_dispensing_liq_bin_number_2_write(registerValues[3]);
				ld.setLiquid_dispensing_delay_time_2_write(registerValues[4]);
				ld.setLiquid_dispensing_liq_bin_number_3_write(registerValues[5]);
				ld.setLiquid_dispensing_delay_time_3_write(registerValues[6]);
				ld.setLiquid_dispensing_liq_bin_number_4_write(registerValues[7]);
				ld.setLiquid_dispensing_delay_time_4_write(registerValues[8]);
				ld.setLiquid_dispensing_liq_bin_number_5_write(registerValues[9]);
				ld.setLiquid_dispensing_delay_time_5_write(registerValues[10]);
				ld.setLiquid_dispensing_liq_bin_number_1_run_time_read(registerValues[11]);
				ld.setLiquid_dispensing_liq_bin_number_2_run_time_read(registerValues[12]);
				ld.setLiquid_dispensing_liq_bin_number_3_run_time_read(registerValues[13]);
				ld.setLiquid_dispensing_liq_bin_number_4_run_time_read(registerValues[14]);
				ld.setLiquid_dispensing_liq_bin_number_5_run_time_read(registerValues[15]);
				ld.setLiquid_dispensing_read(registerValues[18]);
				ld.setLiquid_dispensing_run_time_read(registerValues[19]);
				dos.setLiquidDispensing(ld);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.DELAY.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				Delay de = new Delay();
				de.setDelay_write(registerValues[0]);
				de.setDelay_time_write(registerValues[3]);
				de.setDelay_read(registerValues[4]);
				de.setDelay_run_time_read(registerValues[6]);
				dos.setDelay(de);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.FRYER_PICKUP.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				FryerPickupDB fpdb = new FryerPickupDB();
				fpdb.setFryer_pickup_write(registerValues[0]);
				fpdb.setFryer_pickup_location_write(registerValues[1]);
				fpdb.setFryer_pickup_drop_location_write(registerValues[2]);
				fpdb.setFryer_pickup_bowl_change_or_without_bowl_change_write(registerValues[3]);
				fpdb.setFryer_pickup_read(registerValues[4]);
				fpdb.setFryer_pickup_location_read(registerValues[5]);
				fpdb.setFryer_pickup_drop_location_read(registerValues[6]);
				fpdb.setFryer_pickup_bowl_change_or_without_bowl_change_read(registerValues[7]);
				fpdb.setFryer_pickup_run_time_read(registerValues[8]);
				dos.setFryerPickupDB(fpdb);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.FRYER_ACTION.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				FryerActionDB fadb = new FryerActionDB();
				fadb.setFryer_action_write(registerValues[0]);
				fadb.setFryer_action_pool_location_write(registerValues[1]);
				fadb.setFryer_action_lift_dip_write(registerValues[2]);
				fadb.setFryer_action_read(registerValues[4]);
				fadb.setFryer_action_pool_location_read(registerValues[5]);
				fadb.setFryer_action_lift_dip_read(registerValues[6]);
				fadb.setFryer_action_run_time_read(registerValues[7]);
				dos.setFryerActionDB(fadb);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.FRYER_SERVE.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				FryerServeDB fsdb = new FryerServeDB();
				fsdb.setFryer_serve_write(registerValues[0]);
				fsdb.setFryer_serve_pool_location_write(registerValues[1]);
				fsdb.setFryer_serve_transfer_or_serve_write(registerValues[2]);
				fsdb.setFryer_serve_read(registerValues[4]);
				fsdb.setFryer_serve_pool_location_read(registerValues[5]);
				fsdb.setFryer_serve_transfer_or_serve_read(registerValues[6]);
				fsdb.setFryer_serve_run_time_read(registerValues[7]);
				dos.setFryerServeDB(fsdb);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
		} else if (_dop.getActionId().equals(ActionEnum.SERVE.actionId)) {
			if (registerValues != null && registerValues.length > 0) {
				Serve se = new Serve();
				se.setServe_write(registerValues[0]);
				se.setServe_type_write(registerValues[1]);
				se.setServe_read(registerValues[4]);
				se.setServe_type_read(registerValues[5]);
				se.setServe_run_time_read(registerValues[6]);
				dos.setServe(se);
			}
			if (flameValues != null && flameValues.length > 0) {
				dos.setFlameWrite(flameValues[0]);
				dos.setFlameRead(flameValues[1]);
			}
			dos.setUpdatedTime(new Date(System.currentTimeMillis()));
		}
		demoOrderStepsRepository.save(dos);
	}

	public void updateCurrentBurnerGroupId(Integer currentBurnerId, Integer groupId) {
		if (currentBurnerId.equals(BurnerEnum.BURNER1.getBurnerNo())) {
			burner1CurrentGroupId = groupId;
		} else if (currentBurnerId.equals(BurnerEnum.BURNER2.getBurnerNo())) {
			burner2CurrentGroupId = groupId;
		} else if (currentBurnerId.equals(BurnerEnum.BURNER3.getBurnerNo())) {
			burner3CurrentGroupId = groupId;
		} else if (currentBurnerId.equals(BurnerEnum.BURNER4.getBurnerNo())) {
			burner4CurrentGroupId = groupId;
		}
	}

	public List<DemoBurners> getAvailableBurners() {
		return demoBurnersRepository.getActiveFreeBurners(true, true);
	}

	public boolean getIngredientAvailability(int burnerNo, int recipeId) {
		return true;
	}

	public boolean getUtensilAvailability(int stationId, int recipeId) {
		return true;
	}

	public boolean getUtensilAvailabilityByType(int holdingStationId, int utensilType) {
		return true;
	}

	public boolean getSpatulaAvailability(int stationId, int recipeId) {
		return true;
	}

	public boolean getSpatulaAvailabilityByType(int holdingStationId, int spatulaType) {
		return true;
	}

	public boolean getBowlAvailability(int stationId, int recipeId) {
		return true;
	}

	public boolean getBowlAvailabilityByType(int stationId, int bowlType) {
		return true;
	}

	public boolean getHelathChecks(int burnerNo, int recipeId) {
		return true;
	}

	public boolean getServingStationPositionFree(int servingStationId, int positionId) {
		return true;
	}

	public boolean invokeWriteToRegisterAPI(int address, int value, String recipeName) {
		boolean invokeAPISuccess = false;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			mc.WriteSingleRegister(address, value);
			logger.info("Writing to Address:" + mc.ReadHoldingRegisters(address, 1)[0]);
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			logger.info("*************** UnknownHostException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}

	public boolean invokeWriteToMultipeRegisterAPI(String recipeName, Integer actionId, Integer registerAddress,
			int registerCount) {
		boolean invokeAPISuccess = false;
		try {
			int[] registerValues = new int[registerCount];
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			int[] a = new int[registerCount];
			mc.WriteMultipleRegisters(registerAddress, a);
			registerValues = mc.ReadHoldingRegisters(registerAddress, registerCount);
			for (int i = 0; i < registerValues.length; i++) {
				logger.info("Recipe - " + recipeName + " with Action - " + actionId + "Read Address: "
						+ (registerAddress + i) + " - " + registerValues[i]);
			}
			invokeAPISuccess = true;
		} catch (UnknownHostException e) {
			logger.info("*************** UnknownHostException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** SocketException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ModbusException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("*************** ERROR IN EXECUTING: " + recipeName);
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}

		return invokeAPISuccess;
	}

	public int[] invokePrintReadHoldingRegistersAPI(String recipeName, Integer actionId, Integer registerAddress,
			int registerCount) {
		int[] registerValues = new int[registerCount];
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			registerValues = mc.ReadHoldingRegisters(registerAddress, registerCount);
			for (int i = 0; i < registerValues.length; i++) {
				logger.info("Recipe - " + recipeName + " with Action - " + actionId + "Read Address: "
						+ (registerAddress + i) + " - " + registerValues[i]);
			}
		} catch (UnknownHostException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** ERROR IN EXECUTING invokePrintReadHoldingRegistersAPI ");
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN EXECUTING: " + recipeName);
					e.printStackTrace();
				}
			}
		}
		return registerValues;
	}

	public boolean[] invokeReadCoilsAPI() {
		boolean[] status = null;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			status = mc.ReadCoils(COIL_STRAT_ADDRESS, NO_OF_COILS_TO_READ);
		} catch (UnknownHostException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN READING COILS");
					e.printStackTrace();
				}
			}
		}

		return status;
	}

	private Integer getAddress(Integer burnerNo, RegisterAddress obj) {
		int address = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			address = obj.getBurner1Register();
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			address = obj.getBurner2Register();
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			address = obj.getBurner3Register();
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			address = obj.getBurner4Register();
		}
		return address;
	}

	private Integer getCoilAddress(Integer burnerNo, Integer actionId) {
		int coilAddress = 0;
		if (burnerNo == BurnerEnum.BURNER1.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_1_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_1_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_1_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_1_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_1_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_1_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER2.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_2_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_2_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_2_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_2_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_2_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_2_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER3.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_3_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_3_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_3_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_3_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_3_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_3_SERVE_DONE.coilAddress;
			}
		} else if (burnerNo == BurnerEnum.BURNER4.getBurnerNo()) {
			if (actionId == ActionEnum.UTENSIL_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_UTENSIL_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPATULA_PICK.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPATULA_PICK_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_COLLECTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_COLLECTION_DONE.coilAddress;
			} else if (actionId == ActionEnum.VEG_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_VEG_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.SPICE_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_SPICE_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.MEAT_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_MEAT_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.IGNITION.actionId) {
				coilAddress = CoilEnum.BURNER_4_IGNITION_DONE.coilAddress;
			} else if (actionId == ActionEnum.STIRR.actionId) {
				coilAddress = CoilEnum.BURNER_4_STIRR_DONE.coilAddress;
			} else if (actionId == ActionEnum.TOSS.actionId) {
				coilAddress = CoilEnum.BURNER_4_TOSS_DONE.coilAddress;
			} else if (actionId == ActionEnum.LIQUID_DISPENSING.actionId) {
				coilAddress = CoilEnum.BURNER_4_LIQUID_DISPENSING_DONE.coilAddress;
			} else if (actionId == ActionEnum.DELAY.actionId) {
				coilAddress = CoilEnum.BURNER_4_DELAY_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_PICKUP.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_PICKUP_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_ACTION.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_DONE.coilAddress;
			} else if (actionId == ActionEnum.FRYER_SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_FRYER_SERVE_DONE.coilAddress;
			} else if (actionId == ActionEnum.SERVE.actionId) {
				coilAddress = CoilEnum.BURNER_4_SERVE_DONE.coilAddress;
			}
		}
		return coilAddress;
	}

	private Map<Integer, Integer> getBurnerWiseFlameAddressMap() {
		RegisterAddress registerAddress = registerAddressRepository
				.findByActionIdTypeOfAction(ActionEnum.IGNITION.actionId, RegisterEnum.FLAME_LEVEL_WRITE.label);
		if (registerAddress != null) {
			Map<Integer, Integer> burnerFlameAddressMap = new HashMap<>();
			burnerFlameAddressMap.put(1, registerAddress.getBurner1Register());
			burnerFlameAddressMap.put(2, registerAddress.getBurner2Register());
			burnerFlameAddressMap.put(3, registerAddress.getBurner3Register());
			burnerFlameAddressMap.put(4, registerAddress.getBurner4Register());
			return burnerFlameAddressMap;
		} else {
			return null;
		}
	}

	private boolean writeAllRegistersWithZero() {
		boolean flag = false;
		try {
			mc = new ModbusClient(IP_ADDR, PORT);
			mc.Connect();
			for (int b = 3001; b < 6000;) {
				int[] a = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
				mc.WriteMultipleRegisters(b, a);
				b += 30;
			}
			mc.Disconnect();
			flag = true;
		} catch (UnknownHostException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (SocketException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (ModbusException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("*************** ERROR IN EXECUTING InvokeReadCoilAPI ");
			e.printStackTrace();
		} finally {
			if (mc != null) {
				try {
					mc.Disconnect();
				} catch (IOException e) {
					logger.info("*************** IOException ERROR IN READING COILS");
					e.printStackTrace();
				}
			}
		}
		return flag;
	}

}
