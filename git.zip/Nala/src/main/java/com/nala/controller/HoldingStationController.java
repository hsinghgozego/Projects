package com.nala.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.HoldingStation;
import com.nala.model.Station;
import com.nala.model.User;
import com.nala.repository.HoldingStationRepository;
import com.nala.repository.StationRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class HoldingStationController {

	private static final Logger logger = LoggerFactory.getLogger(HoldingStationController.class);

	@Autowired
	HoldingStationRepository holdingStationRepository;

	@Autowired
	StationRepository stationRepository;

	@RequestMapping("/list-holdingStations")
	public ModelAndView holdingStation(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "holdingStationSearchName", required = false) String holdingStationSearchName,
			@RequestParam(value = "mappedStationSearchName", required = false) String mappedStationSearchName,
			@RequestParam(value = "holdingStationSearchStatus", required = false) String holdingStationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {

		ModelAndView model = new ModelAndView();
		if (pageNo == null || pageNo < 1) {
			pageNo = 1;
		}
		if (pageSize == null || pageSize < 0) {
			pageSize = 10;
		}
		if (holdingStationSearchName == null) {
			holdingStationSearchName = "";
		}
		if (mappedStationSearchName == null) {
			mappedStationSearchName = "";
		}
		if (holdingStationSearchStatus == null) {
			holdingStationSearchStatus = "";
		}
		Pageable paging = PageRequest.of(pageNo - 1, pageSize);
		Page<HoldingStation> pageHoldingStation = holdingStationRepository.search(holdingStationSearchName,mappedStationSearchName,
				holdingStationSearchStatus, paging);
		List<Station> stationList = stationRepository.findAll();
		model.addObject("stationList", stationList);
		model.addObject("holdingStationList", pageHoldingStation.getContent());
		model.addObject("startNo", (pageNo > 1) ? ((pageNo - 1) * pageSize) + 1 : 1);
		model.addObject("endNo",
				(pageNo > 1) ? (((pageNo * pageSize) > pageHoldingStation.getTotalElements())
						? pageHoldingStation.getTotalElements()
						: (pageNo * pageSize)) : pageHoldingStation.getTotalElements());
		model.addObject("totalSize", pageHoldingStation.getTotalElements());
		model.addObject("noOfPages", pageHoldingStation.getTotalPages());
		model.addObject("pno", pageNo);

		model.addObject("urlPage", "holdingStations");
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_holdingStation_grid_n");
		} else {
			model.setViewName("/admin/holdingStation_list");
		}
		return model;

	}

	@RequestMapping("/addHoldingStation")
	public ModelAndView addHoldingStation() {
		ModelAndView model = new ModelAndView();
		List<Station> stationList = stationRepository.findAll();
		model.addObject("stationList", stationList);
		model.addObject("command", new HoldingStation());
		model.setViewName("/ajaxfiles/add_holdingStation_n");
		return model;
	}

	@RequestMapping(value = "/saveHoldingStation", method = RequestMethod.POST)
	public String addHoldingStation(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "holdingStationSearchName", required = false) String holdingStationSearchName,
			@RequestParam(value = "holdingStationSearchType", required = false) String holdingStationSearchType,
			@RequestParam(value = "holdingStationSearchStatus", required = false) Boolean holdingStationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("holdingStation") HoldingStation holdingStation, BindingResult result) {
		logger.info("save holdingStation: " + holdingStation.toString());
		if (holdingStation.getStation().getId() != null) {
			Optional<Station> obj = stationRepository.findById(holdingStation.getStation().getId().toString());
			if (obj.isPresent()) {
				holdingStation.setStation(obj.get());
			}
		}
		holdingStation.setCreatedBy(loggedInUser.getSsoId());
		holdingStation.setCreatedDateTime(new Date());
		holdingStation.setLastUpdatedBy(loggedInUser.getSsoId());
		holdingStation.setLastUpdatedDateTime(new Date());
		holdingStationRepository.save(holdingStation);
		return "redirect:/admin/list-holdingStations";
	}

	@RequestMapping(value = { "/viewHoldingStationInfo" }, method = RequestMethod.GET)
	public ModelAndView viewHoldingStationInfo(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new HoldingStation());
		Optional<HoldingStation> obj = holdingStationRepository.findById(id);
		HoldingStation holdingStation = null;
		if (obj.isPresent()) {
			holdingStation = obj.get();
		}
		model.addObject("holdingStation", holdingStation);
		model.setViewName("/ajaxfiles/view_holdingStation_info");
		return model;
	}

	@RequestMapping(value = { "/openEditHoldingStation" }, method = RequestMethod.GET)
	public ModelAndView openEditHoldingStation(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new HoldingStation());
		HoldingStation holdingStation = null;
		Optional<HoldingStation> obj = holdingStationRepository.findById(id);
		if (obj.isPresent()) {
			holdingStation = obj.get();
		}
		List<Station> stationList = stationRepository.findAll();
		model.addObject("stationList", stationList);
		model.addObject("holdingStation", holdingStation);
		model.addObject("command", new HoldingStation());
		model.setViewName("/ajaxfiles/update_holdingStation_n");
		return model;
	}

	@RequestMapping(value = "/updateHoldingStation", method = RequestMethod.POST)
	public String editHoldingStation(Device device, @SessionAttribute(value = "loggedInUser") User loggedInUser,
			@RequestParam(value = "holdingStationSearchName", required = false) String holdingStationSearchName,
			@RequestParam(value = "holdingStationSearchType", required = false) String holdingStationSearchType,
			@RequestParam(value = "holdingStationSearchStatus", required = false) Boolean holdingStationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@ModelAttribute("holdingStation") HoldingStation holdingStation, BindingResult result) {
		logger.info("save holdingStation: " + holdingStation.toString());
		HoldingStation dbHoldingStation = null;
		Optional<HoldingStation> obj = holdingStationRepository.findById(holdingStation.getId().toString());
		if (obj.isPresent()) {
			dbHoldingStation = obj.get();
			dbHoldingStation.setName(holdingStation.getName());
			dbHoldingStation.setDescription(holdingStation.getDescription());
			dbHoldingStation.setNoOfUtensils(holdingStation.getNoOfUtensils());
			dbHoldingStation.setNoOfSpatulas(holdingStation.getNoOfSpatulas());
			dbHoldingStation.setNoOfBowls(holdingStation.getNoOfBowls());
			dbHoldingStation.setCreatedBy(loggedInUser.getSsoId());
			dbHoldingStation.setCreatedDateTime(new Date());
			dbHoldingStation.setLastUpdatedBy(loggedInUser.getSsoId());
			dbHoldingStation.setLastUpdatedDateTime(new Date());
		}
		holdingStationRepository.save(dbHoldingStation);
		return "redirect:/admin/list-holdingStations";
	}

	@RequestMapping(value = { "/openDeleteHoldingStation" }, method = RequestMethod.GET)
	public ModelAndView openDeleteHoldingStation(@RequestParam(value = "id", required = true) String id) {
		ModelAndView model = new ModelAndView();
		HoldingStation holdingStation = null;
		Optional<HoldingStation> obj = holdingStationRepository.findById(id);
		if (obj.isPresent()) {
			holdingStation = obj.get();
		}
		model.addObject("holdingStation", holdingStation);
		model.addObject("command", new HoldingStation());
		model.setViewName("/ajaxfiles/delete_holdingStation_n");
		return model;
	}

	@RequestMapping(value = { "/deleteHoldingStation" }, method = RequestMethod.POST)
	public String deleteHoldingStation(Device device,
			@RequestParam(value = "holdingStationSearchName", required = false) String holdingStationSearchName,
			@RequestParam(value = "holdingStationSearchType", required = false) String holdingStationSearchType,
			@RequestParam(value = "holdingStationSearchStatus", required = false) Boolean holdingStationSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("holdingStation") HoldingStation holdingStation, BindingResult result) {
		holdingStationRepository.deleteById(id);
		return "redirect:/admin/list-holdingStations";
	}

}
