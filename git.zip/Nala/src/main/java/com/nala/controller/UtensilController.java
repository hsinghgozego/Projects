package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.User;
import com.nala.model.Utensil;
import com.nala.model.UtensilType;

import com.nala.repository.UtensilRepository;
import com.nala.repository.UtensilTypeRepository;

@Controller
@RequestMapping("/admin")
public class UtensilController {

	private static final Logger logger = LoggerFactory.getLogger(BinController.class);



	@Autowired
	UtensilRepository utensilRepository;
	
	@Autowired
	UtensilTypeRepository utensilTypeRepository;
	


	@RequestMapping("/addUtensil")
	public ModelAndView addUtensil() {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Utensil());
		model.addObject("command", new UtensilType());
		List<UtensilType> utensilTypeList = utensilTypeRepository.findAll();
		model.addObject("utensilTypeList", utensilTypeList);

		model.setViewName("/ajaxfiles/add_utensil_n");
		return model;
	}

	@RequestMapping("/list-utensils")
	public ModelAndView listUtensil(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilSearchName", required = false) String utensilSearchName,
			@RequestParam(value = "utensilSearchType", required = false) String utensilSearchType,
			@RequestParam(value = "utensilSearchStatus", required = false) String utensilSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(utensilSearchName==null) {
			utensilSearchName = "";
		}
		if(utensilSearchType==null) {
			utensilSearchType = "";
		}
		if(utensilSearchStatus==null) {
			utensilSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Utensil> pageUtensil = utensilRepository.search(utensilSearchName, utensilSearchType, utensilSearchStatus, paging);
		
		
		model.addObject("utensilList", pageUtensil.getContent());
		model.addObject("currentPage", pageUtensil.getNumber());
		model.addObject("totalItems", pageUtensil.getTotalElements());
		model.addObject("totalPages", pageUtensil.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageUtensil.getTotalElements()) ? pageUtensil.getTotalElements() : (pageNo * pageSize)) : pageUtensil.getTotalElements() );
		model.addObject("totalSize", pageUtensil.getTotalElements());
		model.addObject("noOfPages", pageUtensil.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "utensils");
		model.addObject("command", new UtensilType());
		List<UtensilType> utensilTypeList = utensilTypeRepository.findAll();
		model.addObject("utensilTypeList", utensilTypeList);
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_utensil_grid_n");
		} else {
			model.setViewName("/admin/utensil_list");
		}
		
		
		return model;
	}

	@RequestMapping(value = "/saveUtensil", method = RequestMethod.POST)
	public String saveUtensil(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilSearchName", required = false) String utensilSearchName,
			@RequestParam(value = "utensilSearchType", required = false) String utensilSearchType,
			@RequestParam(value = "utensilSearchStatus", required = false) Boolean utensilSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("utensil") Utensil utensil, BindingResult result) throws IOException{
		logger.info("save utensil: " + utensil.toString());
			
		
		List<Utensil> utensilList = utensilRepository.findAll();
		
		if(!image.isEmpty()) {
			
			utensil.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
			
		}
		
		
		
		//utensil.setStatus("Active");
		utensil.setSequence(utensilList.size() + 1);
		utensil.setCreatedBy(loggedInUser.getSsoId());
		utensil.setCreatedDateTime(new Date());
		utensil.setLastUpdatedBy(loggedInUser.getSsoId());
		utensil.setLastUpdatedDateTime(new Date());
		utensilRepository.save(utensil);
		return "redirect:/admin/list-utensils";
		

	}

	@RequestMapping(value = { "/viewUtensilInfo" }, method = RequestMethod.GET)
	public ModelAndView viewUtensilInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Utensil());
		
				
		Optional<Utensil> obj = utensilRepository.findById(id);
		Utensil utensil = null;
		if (obj.isPresent()) {
			utensil = obj.get();
		}
			
		model.addObject("utensil", utensil);
		try{
			
			if(utensil.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (utensil.getImage().getData()) );	
				
			} 
			 
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		 
		model.setViewName("/ajaxfiles/view_utensil_info");
		return model;
	}

	@RequestMapping(value = { "/openEditUtensil" }, method = RequestMethod.GET)
	public ModelAndView openEditUtensil(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Utensil());
		
		Optional<Utensil> obj = utensilRepository.findById(id);
		Utensil utensil = null;
		if (obj.isPresent()) {
			utensil = obj.get();
		}
		
		model.addObject("utensil", utensil);
		model.addObject("command", new Utensil());
		model.addObject("command", new UtensilType());
		
		try{
			if(utensil.getImage()!=null){
			 model.addObject("image", Base64.getEncoder().encodeToString (utensil.getImage().getData()) );
			}
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		List<UtensilType> utensilTypeList = utensilTypeRepository.findAll();
		model.addObject("utensilTypeList", utensilTypeList);
		model.setViewName("/ajaxfiles/update_utensil_n");
		return model;
	}

	@RequestMapping(value = "/updateUtensil", method = RequestMethod.POST)
	public String editUtensil(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "utensilSearchName", required = false) String utensilSearchName,
			@RequestParam(value = "utensilSearchType", required = false) String utensilSearchType,
			@RequestParam(value = "utensilSearchStatus", required = false) Boolean utensilSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("utensil") Utensil utensil, BindingResult result) throws IOException {
		logger.info("save utensil: " + utensil.toString());
		
		Utensil dbUtensil = null;
		Optional<Utensil> obj = utensilRepository.findById(utensil.getId().toString());
		if (obj.isPresent()) {
		dbUtensil = obj.get();
		
		try {
					
			if(!image.isEmpty()) {
				
				dbUtensil.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		dbUtensil.setName(utensil.getName());
		dbUtensil.setStatus(utensil.getStatus());
		dbUtensil.setDescription(utensil.getDescription());
		dbUtensil.setUtensilType(utensil.getUtensilType());
		dbUtensil.setCreatedBy(loggedInUser.getSsoId());
		dbUtensil.setCreatedDateTime(new Date());
		dbUtensil.setLastUpdatedBy(loggedInUser.getSsoId());
		dbUtensil.setLastUpdatedDateTime(new Date());
		
		}
		utensilRepository.save(dbUtensil);
		return "redirect:/admin/list-utensils";
		
		
	}

	@RequestMapping(value = { "/openDeleteUtensil" }, method = RequestMethod.GET)
	public ModelAndView openDeleteUtensil(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<Utensil> obj = utensilRepository.findById(id);
		Utensil utensil = null;
		if (obj.isPresent()) {
			utensil = obj.get();
		}
			
		model.addObject("utensil", utensil);
		model.addObject("command", new Utensil());
		model.setViewName("/ajaxfiles/delete_utensil_n");
		return model;
	}

	@RequestMapping(value = { "/deleteUtensil" }, method = RequestMethod.POST)
	public String deleteUtensil(Device device,
			@RequestParam(value = "utensilSearchName", required = false) String utensilSearchName,
			@RequestParam(value = "utensilSearchType", required = false) String utensilSearchType,
			@RequestParam(value = "utensilSearchStatus", required = false) Boolean utensilSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("utensil") Utensil utensil, BindingResult result) {
		
		
		utensilRepository.deleteById(id);
		return "redirect:/admin/list-utensils";
		

	}
	
	
}
