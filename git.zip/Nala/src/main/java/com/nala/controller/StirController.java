package com.nala.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mobile.device.Device;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nala.model.Stir;
import com.nala.model.StirType;
import com.nala.model.User;
import com.nala.repository.StirRepository;
import com.nala.repository.StirTypeRepository;

@Controller
@SessionAttributes
@RequestMapping("/admin")
public class StirController {
	
	private static final Logger logger = LoggerFactory.getLogger(StirController.class);

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	StirRepository stirRepository;
	
	@Autowired
	StirTypeRepository stirTypeRepository;

	@RequestMapping("/list-stirs")
	public ModelAndView listStirs(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stirSearchName", required = false) String stirSearchName,
			@RequestParam(value = "stirSearchType", required = false) String stirSearchType,
			@RequestParam(value = "stirSearchStatus", required = false) String stirSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "ajax", required = false) Boolean ajax) {
		
		ModelAndView model = new ModelAndView();
		if(pageNo==null || pageNo<1) {
			pageNo = 1;
		}
		if(pageSize==null || pageSize<0) {
			pageSize = 10;
		}
		if(stirSearchName==null) {
			stirSearchName = "";
		}
		if(stirSearchType==null) {
			stirSearchType = "";
		}
		if(stirSearchStatus==null) {
			stirSearchStatus = "";
		}
		
		Pageable paging = PageRequest.of(pageNo-1, pageSize);
		Page<Stir> pageStir = stirRepository.search(stirSearchName, stirSearchType, stirSearchStatus, paging);
		
		model.addObject("stirList", pageStir.getContent());
		model.addObject("currentPage", pageStir.getNumber());
		model.addObject("totalItems", pageStir.getTotalElements());
		model.addObject("totalPages", pageStir.getTotalPages());
		
		model.addObject("startNo", (pageNo>1)? ((pageNo - 1) * pageSize)+1 : 1);
		model.addObject("endNo", (pageNo>1) ? ( ((pageNo * pageSize)>pageStir.getTotalElements()) ? pageStir.getTotalElements() : (pageNo * pageSize)) : pageStir.getTotalElements() );
		model.addObject("totalSize", pageStir.getTotalElements());
		model.addObject("noOfPages", pageStir.getTotalPages());
		model.addObject("pno", pageNo);
		
		model.addObject("urlPage", "stirs");
		model.addObject("command", new StirType());
		List<StirType> stirTypeList = stirTypeRepository.findAll();
		model.addObject("stirTypeList", stirTypeList);
		if (ajax != null && ajax) {
			model.setViewName("/ajaxfiles/list_stir_grid_n");
		} else {
			model.setViewName("/admin/stir_list");
		}
		
		return model;
	}

	@RequestMapping("/addStir")
	public ModelAndView addStir() {
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Stir());
		model.addObject("command", new StirType());
		List<StirType> stirTypeList = stirTypeRepository.findAll();
		model.addObject("stirTypeList", stirTypeList);
		
		
		model.setViewName("/ajaxfiles/add_stir_n");
		return model;
	}
	
	@RequestMapping(value = "/saveStir", method = RequestMethod.POST)
	public String saveStir(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stirSearchName", required = false) String stirSearchName,
			@RequestParam(value = "stirSearchType", required = false) String stirSearchType,
			@RequestParam(value = "stirSearchStatus", required = false) String stirSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("stir") Stir stir, BindingResult result) throws IOException{
		
		logger.info("save stir: " + stir.toString());
		
		if(!image.isEmpty()) {
			
			stir.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));
			
		}

		List<Stir> stirList = stirRepository.findAll();
		Optional<StirType> stirType=stirTypeRepository.findById(stir.getStirType().getId().toString());
		if(stirType.isPresent()) {
			stir.setStirType(stirType.get());
		}
	
		stir.setSequence(stirList.size() + 1);
		stir.setCreatedBy(loggedInUser.getSsoId());
		stir.setCreatedDateTime(new Date());
		stir.setLastUpdatedBy(loggedInUser.getSsoId());
		stir.setLastUpdatedDateTime(new Date());
		stirRepository.save(stir);
		return "redirect:/admin/list-stirs";
		
	}
	
	@RequestMapping(value = { "/viewStirInfo" }, method = RequestMethod.GET)
	public ModelAndView viewStirInfo(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		model.addObject("command", new Stir());
				
		Optional<Stir> obj = stirRepository.findById(id);
		Stir stir = null;
		if (obj.isPresent()) {
			stir = obj.get();
		}
		
		model.addObject("stir", stir);
		
		try {
			if(stir.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (stir.getImage().getData()) );	
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		model.setViewName("/ajaxfiles/view_stir_n");
		return model;
	}

	@RequestMapping(value = { "/openEditStir" }, method = RequestMethod.GET)
	public ModelAndView openEditStir(@RequestParam(value = "id", required = true) String id) {
	
		ModelAndView model = new ModelAndView();
		
		Optional<Stir> obj = stirRepository.findById(id);
		Stir stir = null;
		if (obj.isPresent()) {
			stir = obj.get();
		}
		
		model.addObject("stir", stir);
		model.addObject("command", new Stir());
		model.addObject("command", new StirType());
		
		try {
			if(stir.getImage()!=null){
				
				 model.addObject("image", Base64.getEncoder().encodeToString (stir.getImage().getData()) );	
				
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		List<StirType> stirTypeList = stirTypeRepository.findAll();
		model.addObject("stirTypeList", stirTypeList);
		model.setViewName("/ajaxfiles/update_stir_n");
		return model;
	}
	
	@RequestMapping(value = { "/openDeleteStir" }, method = RequestMethod.GET)
	public ModelAndView openDeleteStir(@RequestParam(value = "id", required = true) String id) {
		
		ModelAndView model = new ModelAndView();
		
		Optional<Stir> obj = stirRepository.findById(id);
		Stir stir = null;
		if (obj.isPresent()) {
			stir = obj.get();
		}
		
		
		model.addObject("stir", stir);
		model.addObject("command", new Stir());
		model.setViewName("/ajaxfiles/delete_stir_n");
		return model;
	}
	
	@RequestMapping(value = { "/deleteStir" }, method = RequestMethod.POST)
	public String deleteStir(Device device,
			@RequestParam(value = "stirSearchName", required = false) String stirSearchName,
			@RequestParam(value = "stirSearchType", required = false) String stirSearchType,
			@RequestParam(value = "stirSearchStatus", required = false) String stirSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "id", required = true) String id,
			@ModelAttribute("stir") Stir stir, BindingResult result) {
		
		stirRepository.deleteById(id);
		return "redirect:/admin/list-stirs";
		
	}
	
	@RequestMapping(value = "/updateStir", method = RequestMethod.POST)
	public String editStir(Device device,
			@SessionAttribute(value="loggedInUser") User loggedInUser,
			@RequestParam(value = "stirSearchName", required = false) String stirSearchName,
			@RequestParam(value = "stirSearchType", required = false) String stirSearchType,
			@RequestParam(value = "stirSearchStatus", required = false) String stirSearchStatus,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) Boolean sortOrder,
			@RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date fromDate,
			@RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "MM-dd-yyyy") Date toDate,
			@RequestParam(value = "pageNo", required = false) Integer pageNo,
			@RequestParam(value = "pageSize", required = false) Integer pageSize, 
			@RequestParam(value = "image", required = false ) MultipartFile image,
			@ModelAttribute("stir") Stir stir, BindingResult result) {
		
		logger.info("Updating stir: " + stir.toString());
		
		Stir dbStir = null;
		Optional<Stir> obj = stirRepository.findById(stir.getId().toString());
		if (obj.isPresent()) {
			dbStir = obj.get();
			dbStir.setName(stir.getName());
			dbStir.setDescription(stir.getDescription());
			Optional<StirType> stirType=stirTypeRepository.findById(stir.getStirType().getId().toString());
			if(stirType.isPresent()) {
				dbStir.setStirType(stirType.get());
			}
			
			try {
				
				if(!image.isEmpty()) {
					dbStir.setImage(new Binary(BsonBinarySubType.BINARY, image.getBytes()));	
				}
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			dbStir.setVideoLink(stir.getVideoLink());
			dbStir.setStatus(stir.getStatus());
			dbStir.setCreatedBy(loggedInUser.getSsoId());
			dbStir.setCreatedDateTime(new Date());
			dbStir.setLastUpdatedBy(loggedInUser.getSsoId());
			dbStir.setLastUpdatedDateTime(new Date());
		
		}
		stirRepository.save(dbStir);
		return "redirect:/admin/list-stirs";
	
	}

}
