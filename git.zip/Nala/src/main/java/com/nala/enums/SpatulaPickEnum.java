package com.nala.enums;

public enum SpatulaPickEnum {
	
	WRITE(3011),
	TYPE(3012),
	READ(3015),
	NUMBER(3016),
	OPERATION_RUNTIME(3017);

	private final int address;

    private SpatulaPickEnum(int address) {
        this.address = address;
    }

	public int getAddress() {
		return address;
	}

}
