package com.nala.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Multiple fields have been added and the Labeled interface is implemented.
 */
public enum UtensilPickEnum implements Labeled {
	
	BURNER1("BURNER1", 3001, 3005, 3006, 3007),
	BURNER2("BURNER2", 3001, 3005, 3006, 3007),
	BURNER3("BURNER3", 3001, 3005, 3006, 3007),
	BURNER4("BURNER4", 3001, 3005, 3006, 3007);	

    /** final variables to store the values, which can't be changed */
	private final String label;
	private final int write;
	private final int read;
	private final int number;
	private final int operationRunTime;

    /** 
     * Maps cache labels and their associated UtensilPick instances.
     * Note that this only works if the values are all unique!
     */
    private static final Map<String, UtensilPickEnum> BY_LABEL = new HashMap<>();
    private static final Map<Integer, UtensilPickEnum> BY_WRITE = new HashMap<>();
    private static final Map<Integer, UtensilPickEnum> BY_READ = new HashMap<>();
    private static final Map<Integer, UtensilPickEnum> BY_NUMBER = new HashMap<>();
    private static final Map<Integer, UtensilPickEnum> BY_OPERATION_RUN_TIME = new HashMap<>();

    /** populate the caches */
    static {
        for (UtensilPickEnum e : values()) {
            BY_LABEL.put(e.label, e);
        	BY_WRITE.put(e.write, e);
        	BY_WRITE.put(e.write, e);
        	BY_READ.put(e.read, e);
        	BY_NUMBER.put(e.number, e);
        	BY_OPERATION_RUN_TIME.put(e.operationRunTime, e);
        }
    }

    private UtensilPickEnum(String label, int write, int read, int number, int operationRunTime) {
        this.label = label;
        this.write = write;
        this.read = read;
        this.number = number;
        this.operationRunTime = operationRunTime;
    }
    
    /**
     * Implement the Labeled interface.
     * @return the label value
     */
    @Override
    public String label() {
        return label;
    }
    
    /**
     * Look up UtensilPick instances by the label field. This implementation finds the label in the BY_LABEL cache.
     * @param label The label to look up
     * @return The UtensilPick instance with the label, or null if not found.
     */
    public static UtensilPickEnum valueOfLabel(String label) {
        return BY_LABEL.get(label);
    }
    
    /**
     * Look up UtensilPick instances by the write field. This implementation finds the write address in the cache.
     * @param write the address to look up
     * @return The UtensilPick instance with the label, or null if not found.
     */
    public static UtensilPickEnum valueOfWrite(int write) {
        return BY_WRITE.get(write);
    }
    
    /**
     * Look up UtensilPick instances by the read field. This implementation finds the read address in the cache.
     * @param read the address to look up
     * @return The UtensilPick instance with the read, or null if not found.
     */
    public static UtensilPickEnum valueOfRead(int read) {
        return BY_READ.get(read);
    }

    /**
     * Look up UtensilPick instances by the number field. This implementation finds the number address in the cache.
     * @param number the address to look up
     * @return The UtensilPick instance with the number, or null if not found.
     */
    public static UtensilPickEnum valueOfNumber(int number) {
        return BY_NUMBER.get(number);
    }

    /**
     * Look up UtensilPick instances by the operationRunTime field. This implementation finds the operationRunTime address in the cache.
     * @param operationRunTime the address to look up
     * @return The UtensilPick instance with the operationRunTime, or null if not found.
     */
    public static UtensilPickEnum valueOfOperationRunTime(int operationRunTime) {
        return BY_OPERATION_RUN_TIME.get(operationRunTime);
    }
    
    /**
     * Override the toString() method to return the label instead of the declared name.
     * @return 
     */
    @Override
    public String toString() {
        return this.label;
    }

}
