package com.nala.enums;

public enum SectionEnum {
	
	VEG(1),
	MEAT(2),
	SPICE(3),
	NOTHING(-1);

	private final int loc;

    private SectionEnum(int loc) {
        this.loc = loc;
    }

	public int getLoc() {
		return loc;
	}

}
