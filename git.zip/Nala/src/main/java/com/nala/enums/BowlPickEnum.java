package com.nala.enums;

public enum BowlPickEnum {
	
	BC(1),
	WBC(2);

	private final int changeType;

    private BowlPickEnum(int changeType) {
        this.changeType = changeType;
    }

	public int getChangeType() {
		return changeType;
	}

}
