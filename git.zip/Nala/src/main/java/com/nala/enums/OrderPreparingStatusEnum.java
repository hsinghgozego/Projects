package com.nala.enums;

public enum OrderPreparingStatusEnum {
	
	CREATED("Created", 1),
	EXECUTING("Executing", 2),
	COMPLETED("Completed", 3),
	ERROR("Error", -1);
	

    public final String statusDescription;

    public final int statusValue;

    private OrderPreparingStatusEnum(String description, int value) {
        this.statusDescription = description;
        this.statusValue = value;
    }

	public String getStatusDescription() {
		return statusDescription;
	}

	public int getStatusValue() {
		return statusValue;
	}	

}
