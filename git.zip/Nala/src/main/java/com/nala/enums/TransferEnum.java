package com.nala.enums;

public enum TransferEnum {
	
	BURNER(1),
	SERVING_STATION(2);

	private final int loc;

    private TransferEnum(int loc) {
        this.loc = loc;
    }

	public int getLoc() {
		return loc;
	}

}
