package com.nala.enums;

public enum CoilTypeEnum {
	
	RECIPE_START_OR_STOP(1),
	ACTION_DONE(2),
	HEALTHY_STATUS_CHECKS(3),
	ALARMS(4);

	private final int coilTypeId;

    private CoilTypeEnum(int coilTypeId) {
        this.coilTypeId = coilTypeId;
    }

	public int getCoilTypeId() {
		return coilTypeId;
	}

}
