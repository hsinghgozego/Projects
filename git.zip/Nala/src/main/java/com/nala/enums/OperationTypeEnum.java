package com.nala.enums;

public enum OperationTypeEnum {
	
	WRITE(1),
	READ(2);

	private final int value;

    private OperationTypeEnum(int value) {
        this.value = value;
    }

	public int getValue() {
		return value;
	}

}
