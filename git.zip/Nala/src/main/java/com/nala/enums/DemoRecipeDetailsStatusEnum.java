package com.nala.enums;

public enum DemoRecipeDetailsStatusEnum {
	
	CREATED("Created", 1),
	ACTIVE("Active", 2),
	DONE("Done", 3),
	ERROR("Error", -1);
	

	private final String statusDescription;

    private final int statusValue;

    private DemoRecipeDetailsStatusEnum(String description, int value) {
        this.statusDescription = description;
        this.statusValue = value;
    }

	public String getStatusDescription() {
		return statusDescription;
	}

	public int getStatusValue() {
		return statusValue;
	}

}
