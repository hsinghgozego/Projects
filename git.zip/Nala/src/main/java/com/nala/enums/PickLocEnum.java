package com.nala.enums;

public enum PickLocEnum {
	
	VEG(1),
	MEAT(2);

	private final int loc;

    private PickLocEnum(int loc) {
        this.loc = loc;
    }

	public int getLoc() {
		return loc;
	}

}
