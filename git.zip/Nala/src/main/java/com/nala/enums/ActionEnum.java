package com.nala.enums;

import java.util.HashMap;
import java.util.Map;

public enum ActionEnum implements Labeled {
	
	UTENSIL_PICK("UTENSIL_PICK", 1, 10),
	SPATULA_PICK("SPATULA_PICK", 2, 10),
	VEG_COLLECTION("VEG_COLLECTION", 3, 10),
	SPICE_COLLECTION("SPICE_COLLECTION", 4, 10),
	MEAT_COLLECTION("MEAT_COLLECTION", 5, 10),
	VEG_PICKUP("VEG_PICKUP", 6, 10),
	SPICE_PICKUP("SPICE_PICKUP", 7, 10),
	MEAT_PICKUP("MEAT_PICKUP", 8, 10),
	IGNITION("IGNITION", 9, 10),
	STIRR("STIRR",  10, 10),
	TOSS("TOSS", 11, 10),
	LIQUID_DISPENSING("LIQUID_DISPENSING", 12, 20),
	DELAY("DELAY", 13, 10),
	FRYER_PICKUP("FRYER_PICKUP", 14, 10),
	FRYER_ACTION("FRYER_ACTION", 15, 10),
	FRYER_SERVE("FRYER_SERVE", 16, 10),
	SERVE("SERVE", 17, 10);

    /** final variables to store the values, which can't be changed */
    public final String label;
    public final int actionId;
    public final int noOfRegisters;
    
    /** 
     * Maps cache labels and their associated ActionEnum instances.
     * Note that this only works if the values are all unique!
     */
    private static final Map<String, ActionEnum> BY_LABEL = new HashMap<>();
    private static final Map<Integer, ActionEnum> BY_ACTION_ID = new HashMap<>();
    private static final Map<Integer, ActionEnum> BY_NO_OF_REGISTERS = new HashMap<>();

    /** populate the caches */
    static {
        for (ActionEnum e : values()) {
            BY_LABEL.put(e.label, e);
            BY_ACTION_ID.put(e.actionId, e);
            BY_NO_OF_REGISTERS.put(e.noOfRegisters, e);
        }
    }

    private ActionEnum(String label, int actionId, int noOfRegisters) {
        this.label = label;
        this.actionId = actionId;
        this.noOfRegisters = noOfRegisters;
    }
    
    /**
     * Implement the Labeled interface.
     * @return the label value
     */
    @Override
    public String label() {
        return label;
    }
    
    /**
     * Look up ActionEnum instances by the label field. This implementation finds the label in the BY_LABEL cache.
     * @param label The label to look up
     * @return The ActionEnum instance with the label, or null if not found.
     */
    public static ActionEnum valueOfLabel(String label) {
        return BY_LABEL.get(label);
    }
    
    /**
     * Look up ActionEnum instances by the actionId field. This implementation finds the actionId address in the cache.
     * @param actionId the address to look up
     * @return The ActionEnum instance with the actionId, or null if not found.
     */
    public static ActionEnum valueOfActionId(int actionId) {
        return BY_ACTION_ID.get(actionId);
    }
    
    /**
     * Look up ActionEnum instances by the noOfRegisters field. This implementation finds the noOfRegisters address in the cache.
     * @param noOfRegisters the address to look up
     * @return The ActionEnum instance with the noOfRegisters, or null if not found.
     */
    public static ActionEnum valueOfNoOfRegisters(int noOfRegisters) {
        return BY_NO_OF_REGISTERS.get(noOfRegisters);
    }
    
    /**
     * Override the toString() method to return the label instead of the declared name.
     * @return 
     */
    @Override
    public String toString() {
        return this.label;
    }

}
