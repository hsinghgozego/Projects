package com.nala.enums;

public interface Labeled {
	
    String label();

}
