package com.nala.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

public class CoilAddress {

	@Id
	private ObjectId id;

	Integer coilId;

	Integer coilTypeId;

	String actionName;

	String coilType;

	String coilName;

	Integer coilAddress;

	String description;

	String burner;

	String javaPreOperations;

	String javaPostOperations;

	String plcOperations;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getCoilId() {
		return coilId;
	}

	public void setCoilId(Integer coilId) {
		this.coilId = coilId;
	}

	public Integer getCoilTypeId() {
		return coilTypeId;
	}

	public void setCoilTypeId(Integer coilTypeId) {
		this.coilTypeId = coilTypeId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getCoilType() {
		return coilType;
	}

	public void setCoilType(String coilType) {
		this.coilType = coilType;
	}

	public String getCoilName() {
		return coilName;
	}

	public void setCoilName(String coilName) {
		this.coilName = coilName;
	}

	public Integer getCoilAddress() {
		return coilAddress;
	}

	public void setCoilAddress(Integer coilAddress) {
		this.coilAddress = coilAddress;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBurner() {
		return burner;
	}

	public void setBurner(String burner) {
		this.burner = burner;
	}

	public String getJavaPreOperations() {
		return javaPreOperations;
	}

	public void setJavaPreOperations(String javaPreOperations) {
		this.javaPreOperations = javaPreOperations;
	}

	public String getJavaPostOperations() {
		return javaPostOperations;
	}

	public void setJavaPostOperations(String javaPostOperations) {
		this.javaPostOperations = javaPostOperations;
	}

	public String getPlcOperations() {
		return plcOperations;
	}

	public void setPlcOperations(String plcOperations) {
		this.plcOperations = plcOperations;
	}

	@Override
	public String toString() {
		return "CoilAddress [id=" + id + ", coilId=" + coilId + ", coilTypeId=" + coilTypeId + ", actionName="
				+ actionName + ", coilType=" + coilType + ", coilName=" + coilName + ", coilAddress=" + coilAddress
				+ ", description=" + description + ", burner=" + burner + ", javaPreOperations=" + javaPreOperations
				+ ", javaPostOperations=" + javaPostOperations + ", plcOperations=" + plcOperations + "]";
	}

}
