package com.nala.model;

public class RegisterAddressForm {

	private String robo;

	private String burner;

	private String actionName;

	private Integer bin;

	private Integer qty;

	private Integer time;

	private Integer flame;

	public String getRobo() {
		return robo;
	}

	public void setRobo(String robo) {
		this.robo = robo;
	}

	public String getBurner() {
		return burner;
	}

	public void setBurner(String burner) {
		this.burner = burner;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public Integer getBin() {
		return bin;
	}

	public void setBin(Integer bin) {
		this.bin = bin;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public Integer getFlame() {
		return flame;
	}

	public void setFlame(Integer flame) {
		this.flame = flame;
	}

	@Override
	public String toString() {
		return "RegisterAddressForm [robo=" + robo + ", burner=" + burner + ", actionName=" + actionName + ", bin="
				+ bin + ", qty=" + qty + ", time=" + time + ", flame=" + flame + "]";
	}

}
