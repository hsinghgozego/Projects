package com.nala.model.helper;

public class FryerServe {
	
	private Integer poolLoc;
	
	private Integer transOrServe;

	public Integer getPoolLoc() {
		return poolLoc;
	}

	public void setPoolLoc(Integer poolLoc) {
		this.poolLoc = poolLoc;
	}

	public Integer getTransOrServe() {
		return transOrServe;
	}

	public void setTransOrServe(Integer transOrServe) {
		this.transOrServe = transOrServe;
	}

	@Override
	public String toString() {
		return "FryerServe [poolLoc=" + poolLoc + ", transOrServe=" + transOrServe + "]";
	}

}
