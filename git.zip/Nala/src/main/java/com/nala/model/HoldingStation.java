package com.nala.model;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class HoldingStation {
	
	@Id
    private ObjectId id;
    
    private String name;
    
    private String description;
    
    private Station station;
    
    private Integer noOfUtensils;
    
    private Integer noOfSpatulas;
    
    private Integer noOfBowls;
	
	private String status;
	
	private String images;
	
	private String thumbnailImages;
	
	private List<HoldingStationToUtensilMap> holdingStationToUtensilMapList;
	
	private List<HoldingStationToSpatulaMap> holdingStationToSpatulaMapList;
	
	private List<HoldingStationToBowlMap> holdingStationToBowlMapList;
    
    private String createdBy;
    
    private String lastUpdatedBy;
	
    @DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date createdDateTime;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date lastUpdatedDateTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getNoOfUtensils() {
		return noOfUtensils;
	}

	public void setNoOfUtensils(Integer noOfUtensils) {
		this.noOfUtensils = noOfUtensils;
	}

	public Integer getNoOfSpatulas() {
		return noOfSpatulas;
	}

	public void setNoOfSpatulas(Integer noOfSpatulas) {
		this.noOfSpatulas = noOfSpatulas;
	}

	public Integer getNoOfBowls() {
		return noOfBowls;
	}

	public void setNoOfBowls(Integer noOfBowls) {
		this.noOfBowls = noOfBowls;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public String getThumbnailImages() {
		return thumbnailImages;
	}

	public void setThumbnailImages(String thumbnailImages) {
		this.thumbnailImages = thumbnailImages;
	}

	public List<HoldingStationToUtensilMap> getHoldingStationToUtensilMapList() {
		return holdingStationToUtensilMapList;
	}

	public void setHoldingStationToUtensilMapList(List<HoldingStationToUtensilMap> holdingStationToUtensilMapList) {
		this.holdingStationToUtensilMapList = holdingStationToUtensilMapList;
	}

	public List<HoldingStationToSpatulaMap> getHoldingStationToSpatulaMapList() {
		return holdingStationToSpatulaMapList;
	}

	public void setHoldingStationToSpatulaMapList(List<HoldingStationToSpatulaMap> holdingStationToSpatulaMapList) {
		this.holdingStationToSpatulaMapList = holdingStationToSpatulaMapList;
	}

	public List<HoldingStationToBowlMap> getHoldingStationToBowlMapList() {
		return holdingStationToBowlMapList;
	}

	public void setHoldingStationToBowlMapList(List<HoldingStationToBowlMap> holdingStationToBowlMapList) {
		this.holdingStationToBowlMapList = holdingStationToBowlMapList;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public Station getStation() {
		return station;
	}

	public void setStation(Station station) {
		this.station = station;
	}

	@Override
	public String toString() {
		return "HoldingStation [id=" + id + ", name=" + name + ", description=" + description + ", station=" + station
				+ ", noOfUtensils=" + noOfUtensils + ", noOfSpatulas=" + noOfSpatulas + ", noOfBowls=" + noOfBowls
				+ ", status=" + status + ", images=" + images + ", thumbnailImages=" + thumbnailImages
				+ ", holdingStationToUtensilMapList=" + holdingStationToUtensilMapList
				+ ", holdingStationToSpatulaMapList=" + holdingStationToSpatulaMapList
				+ ", holdingStationToBowlMapList=" + holdingStationToBowlMapList + ", createdBy=" + createdBy
				+ ", lastUpdatedBy=" + lastUpdatedBy + ", createdDateTime=" + createdDateTime + ", lastUpdatedDateTime="
				+ lastUpdatedDateTime + "]";
	}

}
