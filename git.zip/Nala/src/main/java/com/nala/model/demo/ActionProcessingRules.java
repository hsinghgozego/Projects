package com.nala.model.demo;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ActionProcessingRules {

	@Id
	private ObjectId id;

	private Integer uniqueNo;

	private Integer actionId;

	private String actionName;

	private Integer burnerNo;

	private Integer rackOrLiquid;

	private Integer sectionId;
	
	private List<Integer> burner1ParllelActions;
	
	private ActionsWithLimitations burner1ParllelActionsWithLimitations;
	
	private List<Integer> burner1ExcludedActions;
	
	private ActionsWithLimitations burner1ExcludedActionsWithLimitations;
	
	private List<Integer> burner2ParllelActions;
	
	private ActionsWithLimitations burner2ParllelActionsWithLimitations;
	
	private List<Integer> burner2ExcludedActions;
	
	private ActionsWithLimitations burner2ExcludedActionsWithLimitations;
	
	private List<Integer> burner3ParllelActions;
	
	private ActionsWithLimitations burner3ParllelActionsWithLimitations;
	
	private List<Integer> burner3ExcludedActions;
	
	private ActionsWithLimitations burner3ExcludedActionsWithLimitations;
	
	private List<Integer> burner4ParllelActions;
	
	private ActionsWithLimitations burner4ParllelActionsWithLimitations;
	
	private List<Integer> burner4ExcludedActions;
	
	private ActionsWithLimitations burner4ExcludedActionsWithLimitations;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(Integer uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public Integer getActionId() {
		return actionId;
	}

	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public Integer getBurnerNo() {
		return burnerNo;
	}

	public void setBurnerNo(Integer burnerNo) {
		this.burnerNo = burnerNo;
	}

	public Integer getRackOrLiquid() {
		return rackOrLiquid;
	}

	public void setRackOrLiquid(Integer rackOrLiquid) {
		this.rackOrLiquid = rackOrLiquid;
	}

	public Integer getSectionId() {
		return sectionId;
	}

	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	public List<Integer> getBurner1ParllelActions() {
		return burner1ParllelActions;
	}

	public void setBurner1ParllelActions(List<Integer> burner1ParllelActions) {
		this.burner1ParllelActions = burner1ParllelActions;
	}

	public ActionsWithLimitations getBurner1ParllelActionsWithLimitations() {
		return burner1ParllelActionsWithLimitations;
	}

	public void setBurner1ParllelActionsWithLimitations(ActionsWithLimitations burner1ParllelActionsWithLimitations) {
		this.burner1ParllelActionsWithLimitations = burner1ParllelActionsWithLimitations;
	}

	public List<Integer> getBurner1ExcludedActions() {
		return burner1ExcludedActions;
	}

	public void setBurner1ExcludedActions(List<Integer> burner1ExcludedActions) {
		this.burner1ExcludedActions = burner1ExcludedActions;
	}

	public ActionsWithLimitations getBurner1ExcludedActionsWithLimitations() {
		return burner1ExcludedActionsWithLimitations;
	}

	public void setBurner1ExcludedActionsWithLimitations(ActionsWithLimitations burner1ExcludedActionsWithLimitations) {
		this.burner1ExcludedActionsWithLimitations = burner1ExcludedActionsWithLimitations;
	}

	public List<Integer> getBurner2ParllelActions() {
		return burner2ParllelActions;
	}

	public void setBurner2ParllelActions(List<Integer> burner2ParllelActions) {
		this.burner2ParllelActions = burner2ParllelActions;
	}

	public ActionsWithLimitations getBurner2ParllelActionsWithLimitations() {
		return burner2ParllelActionsWithLimitations;
	}

	public void setBurner2ParllelActionsWithLimitations(ActionsWithLimitations burner2ParllelActionsWithLimitations) {
		this.burner2ParllelActionsWithLimitations = burner2ParllelActionsWithLimitations;
	}

	public List<Integer> getBurner2ExcludedActions() {
		return burner2ExcludedActions;
	}

	public void setBurner2ExcludedActions(List<Integer> burner2ExcludedActions) {
		this.burner2ExcludedActions = burner2ExcludedActions;
	}

	public ActionsWithLimitations getBurner2ExcludedActionsWithLimitations() {
		return burner2ExcludedActionsWithLimitations;
	}

	public void setBurner2ExcludedActionsWithLimitations(ActionsWithLimitations burner2ExcludedActionsWithLimitations) {
		this.burner2ExcludedActionsWithLimitations = burner2ExcludedActionsWithLimitations;
	}

	public List<Integer> getBurner3ParllelActions() {
		return burner3ParllelActions;
	}

	public void setBurner3ParllelActions(List<Integer> burner3ParllelActions) {
		this.burner3ParllelActions = burner3ParllelActions;
	}

	public ActionsWithLimitations getBurner3ParllelActionsWithLimitations() {
		return burner3ParllelActionsWithLimitations;
	}

	public void setBurner3ParllelActionsWithLimitations(ActionsWithLimitations burner3ParllelActionsWithLimitations) {
		this.burner3ParllelActionsWithLimitations = burner3ParllelActionsWithLimitations;
	}

	public List<Integer> getBurner3ExcludedActions() {
		return burner3ExcludedActions;
	}

	public void setBurner3ExcludedActions(List<Integer> burner3ExcludedActions) {
		this.burner3ExcludedActions = burner3ExcludedActions;
	}

	public ActionsWithLimitations getBurner3ExcludedActionsWithLimitations() {
		return burner3ExcludedActionsWithLimitations;
	}

	public void setBurner3ExcludedActionsWithLimitations(ActionsWithLimitations burner3ExcludedActionsWithLimitations) {
		this.burner3ExcludedActionsWithLimitations = burner3ExcludedActionsWithLimitations;
	}

	public List<Integer> getBurner4ParllelActions() {
		return burner4ParllelActions;
	}

	public void setBurner4ParllelActions(List<Integer> burner4ParllelActions) {
		this.burner4ParllelActions = burner4ParllelActions;
	}

	public ActionsWithLimitations getBurner4ParllelActionsWithLimitations() {
		return burner4ParllelActionsWithLimitations;
	}

	public void setBurner4ParllelActionsWithLimitations(ActionsWithLimitations burner4ParllelActionsWithLimitations) {
		this.burner4ParllelActionsWithLimitations = burner4ParllelActionsWithLimitations;
	}

	public List<Integer> getBurner4ExcludedActions() {
		return burner4ExcludedActions;
	}

	public void setBurner4ExcludedActions(List<Integer> burner4ExcludedActions) {
		this.burner4ExcludedActions = burner4ExcludedActions;
	}

	public ActionsWithLimitations getBurner4ExcludedActionsWithLimitations() {
		return burner4ExcludedActionsWithLimitations;
	}

	public void setBurner4ExcludedActionsWithLimitations(ActionsWithLimitations burner4ExcludedActionsWithLimitations) {
		this.burner4ExcludedActionsWithLimitations = burner4ExcludedActionsWithLimitations;
	}

	@Override
	public String toString() {
		return "ActionProcessingRules [id=" + id + ", uniqueNo=" + uniqueNo + ", actionId=" + actionId + ", actionName="
				+ actionName + ", burnerNo=" + burnerNo + ", rackOrLiquid=" + rackOrLiquid + ", sectionId=" + sectionId
				+ ", burner1ParllelActions=" + burner1ParllelActions + ", burner1ParllelActionsWithLimitations="
				+ burner1ParllelActionsWithLimitations + ", burner1ExcludedActions=" + burner1ExcludedActions
				+ ", burner1ExcludedActionsWithLimitations=" + burner1ExcludedActionsWithLimitations
				+ ", burner2ParllelActions=" + burner2ParllelActions + ", burner2ParllelActionsWithLimitations="
				+ burner2ParllelActionsWithLimitations + ", burner2ExcludedActions=" + burner2ExcludedActions
				+ ", burner2ExcludedActionsWithLimitations=" + burner2ExcludedActionsWithLimitations
				+ ", burner3ParllelActions=" + burner3ParllelActions + ", burner3ParllelActionsWithLimitations="
				+ burner3ParllelActionsWithLimitations + ", burner3ExcludedActions=" + burner3ExcludedActions
				+ ", burner3ExcludedActionsWithLimitations=" + burner3ExcludedActionsWithLimitations
				+ ", burner4ParllelActions=" + burner4ParllelActions + ", burner4ParllelActionsWithLimitations="
				+ burner4ParllelActionsWithLimitations + ", burner4ExcludedActions=" + burner4ExcludedActions
				+ ", burner4ExcludedActionsWithLimitations=" + burner4ExcludedActionsWithLimitations + "]";
	}

}
