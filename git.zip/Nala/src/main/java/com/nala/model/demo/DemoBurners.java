package com.nala.model.demo;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoBurners {

	@Id
	private ObjectId id;
	
	private Integer burnerNo;
	
	private String name;
	
	private String description;
	
	private Integer stationId;
	
	private Integer robotId;
	
	private Integer fryerId;
	
	private Integer rackId;
	
	private Boolean isActive;
	
	private Boolean isFree;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getBurnerNo() {
		return burnerNo;
	}

	public void setBurnerNo(Integer burnerNo) {
		this.burnerNo = burnerNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStationId() {
		return stationId;
	}

	public void setStationId(Integer stationId) {
		this.stationId = stationId;
	}

	public Integer getRobotId() {
		return robotId;
	}

	public void setRobotId(Integer robotId) {
		this.robotId = robotId;
	}

	public Integer getFryerId() {
		return fryerId;
	}

	public void setFryerId(Integer fryerId) {
		this.fryerId = fryerId;
	}

	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsFree() {
		return isFree;
	}

	public void setIsFree(Boolean isFree) {
		this.isFree = isFree;
	}

	@Override
	public String toString() {
		return "DemoBurners [id=" + id + ", burnerNo=" + burnerNo + ", name=" + name + ", description=" + description
				+ ", stationId=" + stationId + ", robotId=" + robotId + ", fryerId=" + fryerId + ", rackId=" + rackId
				+ ", isActive=" + isActive + ", isFree=" + isFree + "]";
	}
	
}
