package com.nala.model.demo;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoActions {

	@Id
	private ObjectId id;

	private int actionId;

	private String name;

	private int noOfRegistersToRead;

	private boolean isRackDependent;

	private boolean isRoboDependent;

	private boolean isBurnerDependent;

	private boolean isStationdependent;

	private boolean isHoldingStationDependent;

	private boolean isservingStationDependent;

	private boolean isFryerDependent;

	private boolean isLiquidDependent;

	private boolean isSectionDependent;

	private boolean isUtensilDependent;

	private boolean isSpatulaDependent;

	private boolean isStirDependent;

	private boolean isTossDependent;

	private boolean isVegCollectionDependent;

	private boolean isSpiceCollectionDependent;

	private boolean isMeatCollectionDependent;

	private boolean isBowlDependent;

	private boolean isActive;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public int getActionId() {
		return actionId;
	}

	public void setActionId(int actionId) {
		this.actionId = actionId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNoOfRegistersToRead() {
		return noOfRegistersToRead;
	}

	public void setNoOfRegistersToRead(int noOfRegistersToRead) {
		this.noOfRegistersToRead = noOfRegistersToRead;
	}

	public boolean isRackDependent() {
		return isRackDependent;
	}

	public void setRackDependent(boolean isRackDependent) {
		this.isRackDependent = isRackDependent;
	}

	public boolean isRoboDependent() {
		return isRoboDependent;
	}

	public void setRoboDependent(boolean isRoboDependent) {
		this.isRoboDependent = isRoboDependent;
	}

	public boolean isBurnerDependent() {
		return isBurnerDependent;
	}

	public void setBurnerDependent(boolean isBurnerDependent) {
		this.isBurnerDependent = isBurnerDependent;
	}

	public boolean isStationdependent() {
		return isStationdependent;
	}

	public void setStationdependent(boolean isStationdependent) {
		this.isStationdependent = isStationdependent;
	}

	public boolean isHoldingStationDependent() {
		return isHoldingStationDependent;
	}

	public void setHoldingStationDependent(boolean isHoldingStationDependent) {
		this.isHoldingStationDependent = isHoldingStationDependent;
	}

	public boolean isIsservingStationDependent() {
		return isservingStationDependent;
	}

	public void setIsservingStationDependent(boolean isservingStationDependent) {
		this.isservingStationDependent = isservingStationDependent;
	}

	public boolean isFryerDependent() {
		return isFryerDependent;
	}

	public void setFryerDependent(boolean isFryerDependent) {
		this.isFryerDependent = isFryerDependent;
	}

	public boolean isLiquidDependent() {
		return isLiquidDependent;
	}

	public void setLiquidDependent(boolean isLiquidDependent) {
		this.isLiquidDependent = isLiquidDependent;
	}

	public boolean isSectionDependent() {
		return isSectionDependent;
	}

	public void setSectionDependent(boolean isSectionDependent) {
		this.isSectionDependent = isSectionDependent;
	}

	public boolean isUtensilDependent() {
		return isUtensilDependent;
	}

	public void setUtensilDependent(boolean isUtensilDependent) {
		this.isUtensilDependent = isUtensilDependent;
	}

	public boolean isSpatulaDependent() {
		return isSpatulaDependent;
	}

	public void setSpatulaDependent(boolean isSpatulaDependent) {
		this.isSpatulaDependent = isSpatulaDependent;
	}

	public boolean isStirDependent() {
		return isStirDependent;
	}

	public void setStirDependent(boolean isStirDependent) {
		this.isStirDependent = isStirDependent;
	}

	public boolean isTossDependent() {
		return isTossDependent;
	}

	public void setTossDependent(boolean isTossDependent) {
		this.isTossDependent = isTossDependent;
	}

	public boolean isVegCollectionDependent() {
		return isVegCollectionDependent;
	}

	public void setVegCollectionDependent(boolean isVegCollectionDependent) {
		this.isVegCollectionDependent = isVegCollectionDependent;
	}

	public boolean isSpiceCollectionDependent() {
		return isSpiceCollectionDependent;
	}

	public void setSpiceCollectionDependent(boolean isSpiceCollectionDependent) {
		this.isSpiceCollectionDependent = isSpiceCollectionDependent;
	}

	public boolean isMeatCollectionDependent() {
		return isMeatCollectionDependent;
	}

	public void setMeatCollectionDependent(boolean isMeatCollectionDependent) {
		this.isMeatCollectionDependent = isMeatCollectionDependent;
	}

	public boolean isBowlDependent() {
		return isBowlDependent;
	}

	public void setBowlDependent(boolean isBowlDependent) {
		this.isBowlDependent = isBowlDependent;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "DemoActions [id=" + id + ", actionId=" + actionId + ", name=" + name + ", noOfRegistersToRead="
				+ noOfRegistersToRead + ", isRackDependent=" + isRackDependent + ", isRoboDependent=" + isRoboDependent
				+ ", isBurnerDependent=" + isBurnerDependent + ", isStationdependent=" + isStationdependent
				+ ", isHoldingStationDependent=" + isHoldingStationDependent + ", isservingStationDependent="
				+ isservingStationDependent + ", isFryerDependent=" + isFryerDependent + ", isLiquidDependent="
				+ isLiquidDependent + ", isSectionDependent=" + isSectionDependent + ", isUtensilDependent="
				+ isUtensilDependent + ", isSpatulaDependent=" + isSpatulaDependent + ", isStirDependent="
				+ isStirDependent + ", isTossDependent=" + isTossDependent + ", isVegCollectionDependent="
				+ isVegCollectionDependent + ", isSpiceCollectionDependent=" + isSpiceCollectionDependent
				+ ", isMeatCollectionDependent=" + isMeatCollectionDependent + ", isBowlDependent=" + isBowlDependent
				+ ", isActive=" + isActive + "]";
	}

}
