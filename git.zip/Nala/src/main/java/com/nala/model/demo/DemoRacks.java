package com.nala.model.demo;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoRacks {

	@Id
	private ObjectId id;

	private Integer rackId;

	private String rackName;

	private String description;

	private String type;

	private List<String> section;

	private List<Integer> vegBins;

	private List<Integer> meatBins;

	private List<Integer> spiceBins;

	private List<String> stations;

	private List<Integer> sharingBins;

	private List<Integer> exclusiveBins;

	private List<Integer> station1ExclusiveBins;

	private List<Integer> station2ExclusiveBins;

	private List<Integer> station1Bins;

	private List<Integer> station2Bins;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public String getRackName() {
		return rackName;
	}

	public void setRackName(String rackName) {
		this.rackName = rackName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getSection() {
		return section;
	}

	public void setSection(List<String> section) {
		this.section = section;
	}

	public List<Integer> getVegBins() {
		return vegBins;
	}

	public void setVegBins(List<Integer> vegBins) {
		this.vegBins = vegBins;
	}

	public List<Integer> getMeatBins() {
		return meatBins;
	}

	public void setMeatBins(List<Integer> meatBins) {
		this.meatBins = meatBins;
	}

	public List<Integer> getSpiceBins() {
		return spiceBins;
	}

	public void setSpiceBins(List<Integer> spiceBins) {
		this.spiceBins = spiceBins;
	}

	public List<String> getStations() {
		return stations;
	}

	public void setStations(List<String> stations) {
		this.stations = stations;
	}

	public List<Integer> getSharingBins() {
		return sharingBins;
	}

	public void setSharingBins(List<Integer> sharingBins) {
		this.sharingBins = sharingBins;
	}

	public List<Integer> getExclusiveBins() {
		return exclusiveBins;
	}

	public void setExclusiveBins(List<Integer> exclusiveBins) {
		this.exclusiveBins = exclusiveBins;
	}

	public List<Integer> getStation1ExclusiveBins() {
		return station1ExclusiveBins;
	}

	public void setStation1ExclusiveBins(List<Integer> station1ExclusiveBins) {
		this.station1ExclusiveBins = station1ExclusiveBins;
	}

	public List<Integer> getStation2ExclusiveBins() {
		return station2ExclusiveBins;
	}

	public void setStation2ExclusiveBins(List<Integer> station2ExclusiveBins) {
		this.station2ExclusiveBins = station2ExclusiveBins;
	}

	public List<Integer> getStation1Bins() {
		return station1Bins;
	}

	public void setStation1Bins(List<Integer> station1Bins) {
		this.station1Bins = station1Bins;
	}

	public List<Integer> getStation2Bins() {
		return station2Bins;
	}

	public void setStation2Bins(List<Integer> station2Bins) {
		this.station2Bins = station2Bins;
	}

	@Override
	public String toString() {
		return "DemoRacks [id=" + id + ", rackId=" + rackId + ", rackName=" + rackName + ", description=" + description
				+ ", type=" + type + ", section=" + section + ", vegBins=" + vegBins + ", meatBins=" + meatBins
				+ ", spiceBins=" + spiceBins + ", stations=" + stations + ", sharingBins=" + sharingBins
				+ ", exclusiveBins=" + exclusiveBins + ", station1ExclusiveBins=" + station1ExclusiveBins
				+ ", station2ExclusiveBins=" + station2ExclusiveBins + ", station1Bins=" + station1Bins
				+ ", station2Bins=" + station2Bins + "]";
	}

}
