package com.nala.model.helper;

public class LiquidBin {
	
	private Integer ingId;
	
	private Integer ms;

	public Integer getIngId() {
		return ingId;
	}

	public void setIngId(Integer ingId) {
		this.ingId = ingId;
	}

	public Integer getMs() {
		return ms;
	}

	public void setMs(Integer ms) {
		this.ms = ms;
	}

	@Override
	public String toString() {
		return "LiquidBin [ingId=" + ingId + ", ms=" + ms + "]";
	}

}
