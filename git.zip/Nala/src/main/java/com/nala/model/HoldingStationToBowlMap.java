package com.nala.model;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class HoldingStationToBowlMap {

	@Id
    private ObjectId id;
	
	private Integer postionId;
	
	private BowlType bowlType;
	
	private Bowl bowl;
	
    private ObjectId bowlId;
	
	private String status;
    
    private String createdBy;
    
    private String lastUpdatedBy;
	
    @DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date createdDateTime;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date lastUpdatedDateTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getPostionId() {
		return postionId;
	}

	public void setPostionId(Integer postionId) {
		this.postionId = postionId;
	}

	public BowlType getBowlType() {
		return bowlType;
	}

	public void setBowlType(BowlType bowlType) {
		this.bowlType = bowlType;
	}

	public Bowl getBowl() {
		return bowl;
	}

	public void setBowl(Bowl bowl) {
		this.bowl = bowl;
	}

	public ObjectId getBowlId() {
		return bowlId;
	}

	public void setBowlId(ObjectId bowlId) {
		this.bowlId = bowlId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	@Override
	public String toString() {
		return "HoldingStationToBowlMap [id=" + id + ", postionId=" + postionId + ", bowlType=" + bowlType + ", bowl="
				+ bowl + ", bowlId=" + bowlId + ", status=" + status + ", createdBy=" + createdBy + ", lastUpdatedBy="
				+ lastUpdatedBy + ", createdDateTime=" + createdDateTime + ", lastUpdatedDateTime="
				+ lastUpdatedDateTime + "]";
	}

}
