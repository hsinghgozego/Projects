package com.nala.model.demo;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoRecipeDetails {

	@Id
	private ObjectId id;

	private Integer recipeDetailsId;

	private Integer recipeId;

	private String recipeName;

	private Integer actionId;

	private Object sourceOrType;

	private Integer qty;

	private Integer time;

	private Integer flame;

	private Integer groupId;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getRecipeDetailsId() {
		return recipeDetailsId;
	}

	public void setRecipeDetailsId(Integer recipeDetailsId) {
		this.recipeDetailsId = recipeDetailsId;
	}

	public Integer getRecipeId() {
		return recipeId;
	}

	public void setRecipeId(Integer recipeId) {
		this.recipeId = recipeId;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public Integer getActionId() {
		return actionId;
	}

	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}

	public Object getSourceOrType() {
		return sourceOrType;
	}

	public void setSourceOrType(Object sourceOrType) {
		this.sourceOrType = sourceOrType;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public Integer getFlame() {
		return flame;
	}

	public void setFlame(Integer flame) {
		this.flame = flame;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	@Override
	public String toString() {
		return "TestRecipe [id=" + id + ", recipeDetailsId=" + recipeDetailsId + ", recipeId=" + recipeId
				+ ", recipeName=" + recipeName + ", actionId=" + actionId + ", sourceOrType=" + sourceOrType + ", qty="
				+ qty + ", time=" + time + ", flame=" + flame + ", groupId=" + groupId + "]";
	}

}
