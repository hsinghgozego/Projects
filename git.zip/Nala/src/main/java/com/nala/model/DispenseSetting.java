package com.nala.model;

public class DispenseSetting {

	private Integer min;

	private Integer max;

	private Integer cutOffPct;

	private Integer normalOpsInPct;

	private Integer normalOpsSpeed;

	private Integer inchingSpeed;

	private Integer gapBtwNormalAndInch;

	private Integer gapBtwInch;

	private Integer inchingTime;

	public Integer getMin() {
		return min;
	}

	public void setMin(Integer min) {
		this.min = min;
	}

	public Integer getMax() {
		return max;
	}

	public void setMax(Integer max) {
		this.max = max;
	}

	public Integer getCutOffPct() {
		return cutOffPct;
	}

	public void setCutOffPct(Integer cutOffPct) {
		this.cutOffPct = cutOffPct;
	}

	public Integer getNormalOpsInPct() {
		return normalOpsInPct;
	}

	public void setNormalOpsInPct(Integer normalOpsInPct) {
		this.normalOpsInPct = normalOpsInPct;
	}

	public Integer getNormalOpsSpeed() {
		return normalOpsSpeed;
	}

	public void setNormalOpsSpeed(Integer normalOpsSpeed) {
		this.normalOpsSpeed = normalOpsSpeed;
	}

	public Integer getInchingSpeed() {
		return inchingSpeed;
	}

	public void setInchingSpeed(Integer inchingSpeed) {
		this.inchingSpeed = inchingSpeed;
	}

	public Integer getGapBtwNormalAndInch() {
		return gapBtwNormalAndInch;
	}

	public void setGapBtwNormalAndInch(Integer gapBtwNormalAndInch) {
		this.gapBtwNormalAndInch = gapBtwNormalAndInch;
	}

	public Integer getGapBtwInch() {
		return gapBtwInch;
	}

	public void setGapBtwInch(Integer gapBtwInch) {
		this.gapBtwInch = gapBtwInch;
	}

	public Integer getInchingTime() {
		return inchingTime;
	}

	public void setInchingTime(Integer inchingTime) {
		this.inchingTime = inchingTime;
	}

	@Override
	public String toString() {
		return "DispenseSetting [min=" + min + ", max=" + max + ", cutOffPct=" + cutOffPct + ", normalOpsInPct="
				+ normalOpsInPct + ", normalOpsSpeed=" + normalOpsSpeed + ", inchingSpeed=" + inchingSpeed
				+ ", gapBtwNormalAndInch=" + gapBtwNormalAndInch + ", gapBtwInch=" + gapBtwInch + ", inchingTime="
				+ inchingTime + "]";
	}
	
	

}
