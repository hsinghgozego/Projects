package com.nala.model.demo;

import java.sql.Timestamp;
import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.nala.actions.Delay;
import com.nala.actions.FryerActionDB;
import com.nala.actions.FryerPickupDB;
import com.nala.actions.FryerServeDB;
import com.nala.actions.Ignition;
import com.nala.actions.LiquidDispensing;
import com.nala.actions.MeatCollection;
import com.nala.actions.MeatPickup;
import com.nala.actions.Serve;
import com.nala.actions.SpatulaPick;
import com.nala.actions.SpiceCollection;
import com.nala.actions.SpicePickup;
import com.nala.actions.Stirr;
import com.nala.actions.Toss;
import com.nala.actions.UtensilPick;
import com.nala.actions.VegCollection;
import com.nala.actions.VegPickup;

@Document
public class DemoOrderSteps {

	@Id
	private ObjectId id;

	private Integer orderId;

	private Integer recipeId;

	private Integer burnerNo;

	private String recipeName;

	private DemoOrderProcessing dop;

	private Delay delay;

	private FryerActionDB fryerActionDB;

	private FryerPickupDB fryerPickupDB;

	private FryerServeDB fryerServeDB;

	private Ignition ignition;

	private LiquidDispensing liquidDispensing;

	private MeatCollection meatCollection;

	private MeatPickup meatPickup;

	private Serve serve;

	private SpatulaPick spatulaPick;

	private SpiceCollection spiceCollection;

	private SpicePickup spicePickup;

	private Stirr stirr;

	private Toss toss;

	private UtensilPick utensilPick;

	private VegCollection vegCollection;

	private VegPickup vegPickup;

	private Integer flameWrite;

	private Integer flameRead;

	private Date updatedTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getRecipeId() {
		return recipeId;
	}

	public void setRecipeId(Integer recipeId) {
		this.recipeId = recipeId;
	}

	public Integer getBurnerNo() {
		return burnerNo;
	}

	public void setBurnerNo(Integer burnerNo) {
		this.burnerNo = burnerNo;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public DemoOrderProcessing getDop() {
		return dop;
	}

	public void setDop(DemoOrderProcessing dop) {
		this.dop = dop;
	}

	public Delay getDelay() {
		return delay;
	}

	public void setDelay(Delay delay) {
		this.delay = delay;
	}

	public FryerActionDB getFryerActionDB() {
		return fryerActionDB;
	}

	public void setFryerActionDB(FryerActionDB fryerActionDB) {
		this.fryerActionDB = fryerActionDB;
	}

	public FryerPickupDB getFryerPickupDB() {
		return fryerPickupDB;
	}

	public void setFryerPickupDB(FryerPickupDB fryerPickupDB) {
		this.fryerPickupDB = fryerPickupDB;
	}

	public FryerServeDB getFryerServeDB() {
		return fryerServeDB;
	}

	public void setFryerServeDB(FryerServeDB fryerServeDB) {
		this.fryerServeDB = fryerServeDB;
	}

	public Ignition getIgnition() {
		return ignition;
	}

	public void setIgnition(Ignition ignition) {
		this.ignition = ignition;
	}

	public LiquidDispensing getLiquidDispensing() {
		return liquidDispensing;
	}

	public void setLiquidDispensing(LiquidDispensing liquidDispensing) {
		this.liquidDispensing = liquidDispensing;
	}

	public MeatCollection getMeatCollection() {
		return meatCollection;
	}

	public void setMeatCollection(MeatCollection meatCollection) {
		this.meatCollection = meatCollection;
	}

	public MeatPickup getMeatPickup() {
		return meatPickup;
	}

	public void setMeatPickup(MeatPickup meatPickup) {
		this.meatPickup = meatPickup;
	}

	public Serve getServe() {
		return serve;
	}

	public void setServe(Serve serve) {
		this.serve = serve;
	}

	public SpatulaPick getSpatulaPick() {
		return spatulaPick;
	}

	public void setSpatulaPick(SpatulaPick spatulaPick) {
		this.spatulaPick = spatulaPick;
	}

	public SpiceCollection getSpiceCollection() {
		return spiceCollection;
	}

	public void setSpiceCollection(SpiceCollection spiceCollection) {
		this.spiceCollection = spiceCollection;
	}

	public SpicePickup getSpicePickup() {
		return spicePickup;
	}

	public void setSpicePickup(SpicePickup spicePickup) {
		this.spicePickup = spicePickup;
	}

	public Stirr getStirr() {
		return stirr;
	}

	public void setStirr(Stirr stirr) {
		this.stirr = stirr;
	}

	public Toss getToss() {
		return toss;
	}

	public void setToss(Toss toss) {
		this.toss = toss;
	}

	public UtensilPick getUtensilPick() {
		return utensilPick;
	}

	public void setUtensilPick(UtensilPick utensilPick) {
		this.utensilPick = utensilPick;
	}

	public VegCollection getVegCollection() {
		return vegCollection;
	}

	public void setVegCollection(VegCollection vegCollection) {
		this.vegCollection = vegCollection;
	}

	public VegPickup getVegPickup() {
		return vegPickup;
	}

	public void setVegPickup(VegPickup vegPickup) {
		this.vegPickup = vegPickup;
	}

	public Integer getFlameWrite() {
		return flameWrite;
	}

	public void setFlameWrite(Integer flameWrite) {
		this.flameWrite = flameWrite;
	}

	public Integer getFlameRead() {
		return flameRead;
	}

	public void setFlameRead(Integer flameRead) {
		this.flameRead = flameRead;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	@Override
	public String toString() {
		return "DemoOrderSteps [id=" + id + ", orderId=" + orderId + ", recipeId=" + recipeId + ", burnerNo=" + burnerNo
				+ ", recipeName=" + recipeName + ", dop=" + dop + ", delay=" + delay + ", fryerActionDB="
				+ fryerActionDB + ", fryerPickupDB=" + fryerPickupDB + ", fryerServeDB=" + fryerServeDB + ", ignition="
				+ ignition + ", liquidDispensing=" + liquidDispensing + ", meatCollection=" + meatCollection
				+ ", meatPickup=" + meatPickup + ", serve=" + serve + ", spatulaPick=" + spatulaPick
				+ ", spiceCollection=" + spiceCollection + ", spicePickup=" + spicePickup + ", stirr=" + stirr
				+ ", toss=" + toss + ", utensilPick=" + utensilPick + ", vegCollection=" + vegCollection
				+ ", vegPickup=" + vegPickup + ", flameWrite=" + flameWrite + ", flameRead=" + flameRead
				+ ", updatedTime=" + updatedTime + "]";
	}

}
