package com.nala.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RegisterAddress {

	@Id
	private ObjectId id;

	Integer registerId;

	Integer actionId;

	String actionName;

	String typeOfAction;

	Integer burner1Register;

	Integer burner2Register;

	Integer burner3Register;

	Integer burner4Register;

	String description;

	String javaPreOperations;

	String javaPostOperations;

	String plcOperations;
	
	Integer operationType;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getRegisterId() {
		return registerId;
	}

	public void setRegisterId(Integer registerId) {
		this.registerId = registerId;
	}

	public Integer getActionId() {
		return actionId;
	}

	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getTypeOfAction() {
		return typeOfAction;
	}

	public void setTypeOfAction(String typeOfAction) {
		this.typeOfAction = typeOfAction;
	}

	public Integer getBurner1Register() {
		return burner1Register;
	}

	public void setBurner1Register(Integer burner1Register) {
		this.burner1Register = burner1Register;
	}

	public Integer getBurner2Register() {
		return burner2Register;
	}

	public void setBurner2Register(Integer burner2Register) {
		this.burner2Register = burner2Register;
	}

	public Integer getBurner3Register() {
		return burner3Register;
	}

	public void setBurner3Register(Integer burner3Register) {
		this.burner3Register = burner3Register;
	}

	public Integer getBurner4Register() {
		return burner4Register;
	}

	public void setBurner4Register(Integer burner4Register) {
		this.burner4Register = burner4Register;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getJavaPreOperations() {
		return javaPreOperations;
	}

	public void setJavaPreOperations(String javaPreOperations) {
		this.javaPreOperations = javaPreOperations;
	}

	public String getJavaPostOperations() {
		return javaPostOperations;
	}

	public void setJavaPostOperations(String javaPostOperations) {
		this.javaPostOperations = javaPostOperations;
	}

	public String getPlcOperations() {
		return plcOperations;
	}

	public void setPlcOperations(String plcOperations) {
		this.plcOperations = plcOperations;
	}

	public Integer getOperationType() {
		return operationType;
	}

	public void setOperationType(Integer operationType) {
		this.operationType = operationType;
	}

	@Override
	public String toString() {
		return "RegisterAddress [id=" + id + ", registerId=" + registerId + ", actionId=" + actionId + ", actionName="
				+ actionName + ", typeOfAction=" + typeOfAction + ", burner1Register=" + burner1Register
				+ ", burner2Register=" + burner2Register + ", burner3Register=" + burner3Register + ", burner4Register="
				+ burner4Register + ", description=" + description + ", javaPreOperations=" + javaPreOperations
				+ ", javaPostOperations=" + javaPostOperations + ", plcOperations=" + plcOperations + ", operationType="
				+ operationType + "]";
	}

}
