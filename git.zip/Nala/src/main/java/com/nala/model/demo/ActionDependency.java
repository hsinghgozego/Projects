package com.nala.model.demo;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ActionDependency {

	@Id
	private ObjectId id;

	private int actionId;

	private String actionName;

	private boolean isRackDependent;

	private boolean isRoboDependent;

	private boolean isBurnerDependent;

	private boolean isStationDependent;

	private boolean isHoldingStationDependent;

	private boolean isServingStationDependent;

	private boolean isFryerDependent;

	private boolean isLiquidDependent;

	private boolean isSectionDependent;

	private boolean isUtensilDependent;

	private boolean isSpatulaDependent;

	private boolean isStirDependent;

	private boolean isTossDependent;

	private boolean isBowlDependent;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public int getActionId() {
		return actionId;
	}

	public void setActionId(int actionId) {
		this.actionId = actionId;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public boolean isRackDependent() {
		return isRackDependent;
	}

	public void setRackDependent(boolean isRackDependent) {
		this.isRackDependent = isRackDependent;
	}

	public boolean isRoboDependent() {
		return isRoboDependent;
	}

	public void setRoboDependent(boolean isRoboDependent) {
		this.isRoboDependent = isRoboDependent;
	}

	public boolean isBurnerDependent() {
		return isBurnerDependent;
	}

	public void setBurnerDependent(boolean isBurnerDependent) {
		this.isBurnerDependent = isBurnerDependent;
	}

	public boolean isStationDependent() {
		return isStationDependent;
	}

	public void setStationDependent(boolean isStationDependent) {
		this.isStationDependent = isStationDependent;
	}

	public boolean isHoldingStationDependent() {
		return isHoldingStationDependent;
	}

	public void setHoldingStationDependent(boolean isHoldingStationDependent) {
		this.isHoldingStationDependent = isHoldingStationDependent;
	}

	public boolean isServingStationDependent() {
		return isServingStationDependent;
	}

	public void setServingStationDependent(boolean isServingStationDependent) {
		this.isServingStationDependent = isServingStationDependent;
	}

	public boolean isFryerDependent() {
		return isFryerDependent;
	}

	public void setFryerDependent(boolean isFryerDependent) {
		this.isFryerDependent = isFryerDependent;
	}

	public boolean isLiquidDependent() {
		return isLiquidDependent;
	}

	public void setLiquidDependent(boolean isLiquidDependent) {
		this.isLiquidDependent = isLiquidDependent;
	}

	public boolean isSectionDependent() {
		return isSectionDependent;
	}

	public void setSectionDependent(boolean isSectionDependent) {
		this.isSectionDependent = isSectionDependent;
	}

	public boolean isUtensilDependent() {
		return isUtensilDependent;
	}

	public void setUtensilDependent(boolean isUtensilDependent) {
		this.isUtensilDependent = isUtensilDependent;
	}

	public boolean isSpatulaDependent() {
		return isSpatulaDependent;
	}

	public void setSpatulaDependent(boolean isSpatulaDependent) {
		this.isSpatulaDependent = isSpatulaDependent;
	}

	public boolean isStirDependent() {
		return isStirDependent;
	}

	public void setStirDependent(boolean isStirDependent) {
		this.isStirDependent = isStirDependent;
	}

	public boolean isTossDependent() {
		return isTossDependent;
	}

	public void setTossDependent(boolean isTossDependent) {
		this.isTossDependent = isTossDependent;
	}

	public boolean isBowlDependent() {
		return isBowlDependent;
	}

	public void setBowlDependent(boolean isBowlDependent) {
		this.isBowlDependent = isBowlDependent;
	}

	@Override
	public String toString() {
		return "ActionDependency [id=" + id + ", actionId=" + actionId + ", actionName=" + actionName
				+ ", isRackDependent=" + isRackDependent + ", isRoboDependent=" + isRoboDependent
				+ ", isBurnerDependent=" + isBurnerDependent + ", isStationDependent=" + isStationDependent
				+ ", isHoldingStationDependent=" + isHoldingStationDependent + ", isServingStationDependent="
				+ isServingStationDependent + ", isFryerDependent=" + isFryerDependent + ", isLiquidDependent="
				+ isLiquidDependent + ", isSectionDependent=" + isSectionDependent + ", isUtensilDependent="
				+ isUtensilDependent + ", isSpatulaDependent=" + isSpatulaDependent + ", isStirDependent="
				+ isStirDependent + ", isTossDependent=" + isTossDependent + ", isBowlDependent=" + isBowlDependent
				+ "]";
	}

}
