package com.nala.model;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class RecipeDetail {

	@Id
	private ObjectId id;

	private Recipe recipe;

	private int stepNo;

	private Action action;

	private Bin bin;

	private int valueInGmsMl;

	private int delayInMilliSeconds;

	private Utensil utensil;

	private Spatula spatula;

	private Stir stir;

	private Toss toss;

	private Flame flameLevel;

	@Transient
	private String mainItemId;

	@Transient
	private List<ItemType> mainItemList;

	private String createdBy;

	private String lastUpdatedBy;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date createdDateTime;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date lastUpdatedDateTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Recipe getRecipe() {
		return recipe;
	}

	public void setRecipe(Recipe recipe) {
		this.recipe = recipe;
	}

	public int getStepNo() {
		return stepNo;
	}

	public void setStepNo(int stepNo) {
		this.stepNo = stepNo;
	}

	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

	public Bin getBin() {
		return bin;
	}

	public void setBin(Bin bin) {
		this.bin = bin;
	}

	public int getValueInGmsMl() {
		return valueInGmsMl;
	}

	public void setValueInGmsMl(int valueInGmsMl) {
		this.valueInGmsMl = valueInGmsMl;
	}

	public int getDelayInMilliSeconds() {
		return delayInMilliSeconds;
	}

	public void setDelayInMilliSeconds(int delayInMilliSeconds) {
		this.delayInMilliSeconds = delayInMilliSeconds;
	}

	public Utensil getUtensil() {
		return utensil;
	}

	public void setUtensil(Utensil utensil) {
		this.utensil = utensil;
	}

	public Spatula getSpatula() {
		return spatula;
	}

	public void setSpatula(Spatula spatula) {
		this.spatula = spatula;
	}

	public Stir getStir() {
		return stir;
	}

	public void setStir(Stir stir) {
		this.stir = stir;
	}

	public Toss getToss() {
		return toss;
	}

	public void setToss(Toss toss) {
		this.toss = toss;
	}

	public Flame getFlameLevel() {
		return flameLevel;
	}

	public void setFlameLevel(Flame flameLevel) {
		this.flameLevel = flameLevel;
	}

	public String getMainItemId() {
		return mainItemId;
	}

	public void setMainItemId(String mainItemId) {
		this.mainItemId = mainItemId;
	}

	public List<ItemType> getMainItemList() {
		return mainItemList;
	}

	public void setMainItemList(List<ItemType> mainItemList) {
		this.mainItemList = mainItemList;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	@Override
	public String toString() {
		return "RecipeDetail [id=" + id + ", recipe=" + recipe + ", stepNo=" + stepNo + ", action=" + action + ", bin="
				+ bin + ", valueInGmsMl=" + valueInGmsMl + ", delayInMilliSeconds=" + delayInMilliSeconds + ", utensil="
				+ utensil + ", spatula=" + spatula + ", stir=" + stir + ", toss=" + toss + ", flameLevel=" + flameLevel
				+ ", mainItemId=" + mainItemId + ", mainItemList=" + mainItemList + ", createdBy=" + createdBy
				+ ", lastUpdatedBy=" + lastUpdatedBy + ", createdDateTime=" + createdDateTime + ", lastUpdatedDateTime="
				+ lastUpdatedDateTime + "]";
	}

}
