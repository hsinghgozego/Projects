package com.nala.model.demo;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoRecipes {

	@Id
	private ObjectId id;
	
	private int recipeId;
	
	private String recipeName;
	
	private int qty;
	
	private boolean isActive;
	
	@Transient
	private int totalSteps;
	
	@Transient
	private int currentStep;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public int getRecipeId() {
		return recipeId;
	}

	public void setRecipeId(int recipeId) {
		this.recipeId = recipeId;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public int getTotalSteps() {
		return totalSteps;
	}

	public void setTotalSteps(int totalSteps) {
		this.totalSteps = totalSteps;
	}

	public int getCurrentStep() {
		return currentStep;
	}

	public void setCurrentStep(int currentStep) {
		this.currentStep = currentStep;
	}

	@Override
	public String toString() {
		return "DemoRecipes [id=" + id + ", recipeId=" + recipeId + ", recipeName=" + recipeName + ", qty=" + qty
				+ ", isActive=" + isActive + ", totalSteps=" + totalSteps + ", currentStep=" + currentStep + "]";
	}
    
}
