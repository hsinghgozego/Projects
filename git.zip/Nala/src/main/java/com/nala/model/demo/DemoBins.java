package com.nala.model.demo;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoBins {

	@Id
	private ObjectId id;

	private Integer binId;

	private Integer binNo;

	private Integer ingredientId;

	private String ingredientName;

	private Integer sectionId;

	private String sectionName;

	private Integer rackId;

	private Integer classificationTypeId;

	private String classificationType;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Integer getBinNo() {
		return binNo;
	}

	public void setBinNo(Integer binNo) {
		this.binNo = binNo;
	}

	public Integer getIngredientId() {
		return ingredientId;
	}

	public void setIngredientId(Integer ingredientId) {
		this.ingredientId = ingredientId;
	}

	public String getIngredientName() {
		return ingredientName;
	}

	public void setIngredientName(String ingredientName) {
		this.ingredientName = ingredientName;
	}

	public Integer getSectionId() {
		return sectionId;
	}

	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public Integer getClassificationTypeId() {
		return classificationTypeId;
	}

	public void setClassificationTypeId(Integer classificationTypeId) {
		this.classificationTypeId = classificationTypeId;
	}

	public String getClassificationType() {
		return classificationType;
	}

	public void setClassificationType(String classificationType) {
		this.classificationType = classificationType;
	}

	@Override
	public String toString() {
		return "DemoBins [id=" + id + ", binId=" + binId + ", binNo=" + binNo + ", ingredientId=" + ingredientId
				+ ", ingredientName=" + ingredientName + ", sectionId=" + sectionId + ", sectionName=" + sectionName
				+ ", rackId=" + rackId + ", classificationTypeId=" + classificationTypeId + ", classificationType="
				+ classificationType + "]";
	}

}
