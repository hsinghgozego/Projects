package com.nala.model.demo;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

import com.nala.model.DispenseSetting;

public class DemoIngredients {

	@Id
	private ObjectId id;

	private Integer ingredientId;

	private String name;

	private String description;

	private String section;

	private String classificationType;

	private String typeOfUsage;

	private String weightToVolumeRatio;

	private List<DispenseSetting> dispenseSettings;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getIngredientId() {
		return ingredientId;
	}

	public void setIngredientId(Integer ingredientId) {
		this.ingredientId = ingredientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getClassificationType() {
		return classificationType;
	}

	public void setClassificationType(String classificationType) {
		this.classificationType = classificationType;
	}

	public String getTypeOfUsage() {
		return typeOfUsage;
	}

	public void setTypeOfUsage(String typeOfUsage) {
		this.typeOfUsage = typeOfUsage;
	}

	public String getWeightToVolumeRatio() {
		return weightToVolumeRatio;
	}

	public void setWeightToVolumeRatio(String weightToVolumeRatio) {
		this.weightToVolumeRatio = weightToVolumeRatio;
	}

	public List<DispenseSetting> getDispenseSettings() {
		return dispenseSettings;
	}

	public void setDispenseSettings(List<DispenseSetting> dispenseSettings) {
		this.dispenseSettings = dispenseSettings;
	}

	@Override
	public String toString() {
		return "DemoIngredients [id=" + id + ", ingredientId=" + ingredientId + ", name=" + name + ", description="
				+ description + ", section=" + section + ", classificationType=" + classificationType + ", typeOfUsage="
				+ typeOfUsage + ", weightToVolumeRatio=" + weightToVolumeRatio + ", dispenseSettings="
				+ dispenseSettings + "]";
	}

}
