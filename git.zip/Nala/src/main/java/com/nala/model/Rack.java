package com.nala.model;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class Rack {

		@Id
		private ObjectId id;
		
		private String name;
		
		private String rackId;
		
		private String status;
		
		private List<Section> sections;
		
		@Transient
		private String [] sectionIds;
		
		private String images;
		
		private String createdBy;

		private String lastUpdatedBy;

		@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
		private Date createdDateTime;

		@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
		private Date lastUpdatedDateTime;

		public ObjectId getId() {
			return id;
		}

		public void setId(ObjectId id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		
		public String getRackId() {
			return rackId;
		}

		public void setRackId(String rackId) {
			this.rackId = rackId;
		}


		public List<Section> getSections() {
			return sections;
		}

		public void setSections(List<Section> sections) {
			this.sections = sections;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getImages() {
			return images;
		}

		public void setImages(String images) {
			this.images = images;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getLastUpdatedBy() {
			return lastUpdatedBy;
		}

		public void setLastUpdatedBy(String lastUpdatedBy) {
			this.lastUpdatedBy = lastUpdatedBy;
		}

		public Date getCreatedDateTime() {
			return createdDateTime;
		}

		public void setCreatedDateTime(Date createdDateTime) {
			this.createdDateTime = createdDateTime;
		}

		public Date getLastUpdatedDateTime() {
			return lastUpdatedDateTime;
		}

		public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
			this.lastUpdatedDateTime = lastUpdatedDateTime;
		}

		public String[] getSectionIds() {
			return sectionIds;
		}

		public void setSectionIds(String[] sectionIds) {
			this.sectionIds = sectionIds;
		}

		
		
}
