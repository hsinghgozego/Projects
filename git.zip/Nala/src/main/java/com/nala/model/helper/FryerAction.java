package com.nala.model.helper;

public class FryerAction {

	private Integer poolLocation;

	private Integer liftDip;

	public Integer getPoolLocation() {
		return poolLocation;
	}

	public void setPoolLocation(Integer poolLocation) {
		this.poolLocation = poolLocation;
	}

	public Integer getLiftDip() {
		return liftDip;
	}

	public void setLiftDip(Integer liftDip) {
		this.liftDip = liftDip;
	}

	@Override
	public String toString() {
		return "FryerAction [poolLocation=" + poolLocation + ", liftDip=" + liftDip + "]";
	}

}
