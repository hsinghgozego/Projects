package com.nala.model;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class HoldingStationToUtensilMap {

	@Id
    private ObjectId id;
	
	private Integer postionId;
	
	private UtensilType utensilType;
	
	private Utensil utensil;
	
    private ObjectId utensilId;
	
	private String status;
    
    private String createdBy;
    
    private String lastUpdatedBy;
	
    @DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date createdDateTime;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date lastUpdatedDateTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getPostionId() {
		return postionId;
	}

	public void setPostionId(Integer postionId) {
		this.postionId = postionId;
	}

	public UtensilType getUtensilType() {
		return utensilType;
	}

	public void setUtensilType(UtensilType utensilType) {
		this.utensilType = utensilType;
	}

	public Utensil getUtensil() {
		return utensil;
	}

	public void setUtensil(Utensil utensil) {
		this.utensil = utensil;
	}

	public ObjectId getUtensilId() {
		return utensilId;
	}

	public void setUtensilId(ObjectId utensilId) {
		this.utensilId = utensilId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	@Override
	public String toString() {
		return "HoldingStationToUtensilMap [id=" + id + ", postionId=" + postionId + ", utensilType=" + utensilType
				+ ", utensil=" + utensil + ", utensilId=" + utensilId + ", status=" + status + ", createdBy="
				+ createdBy + ", lastUpdatedBy=" + lastUpdatedBy + ", createdDateTime=" + createdDateTime
				+ ", lastUpdatedDateTime=" + lastUpdatedDateTime + "]";
	}

}
