package com.nala.model.helper;

public class FryerPickup {
	
	private Integer pickLocation;
	
	private Integer dropLocation;
	
	private Integer bcWbc;

	public Integer getPickLocation() {
		return pickLocation;
	}

	public void setPickLocation(Integer pickLocation) {
		this.pickLocation = pickLocation;
	}

	public Integer getDropLocation() {
		return dropLocation;
	}

	public void setDropLocation(Integer dropLocation) {
		this.dropLocation = dropLocation;
	}

	public Integer getBcWbc() {
		return bcWbc;
	}

	public void setBcWbc(Integer bcWbc) {
		this.bcWbc = bcWbc;
	}

	@Override
	public String toString() {
		return "FryerPickup [pickLocation=" + pickLocation + ", dropLocation=" + dropLocation + ", bcWbc=" + bcWbc
				+ "]";
	}
	
}
