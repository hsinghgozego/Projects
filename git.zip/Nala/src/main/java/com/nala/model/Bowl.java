package com.nala.model;

import java.util.Date;

import org.bson.types.Binary;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document
public class Bowl {

	@Id
	private ObjectId id;

	private String name;

	private String description;

	private BowlType bowlType;

	private float maxvolume;
	
	private float minvolume;
	
	private Binary image;
	
	private String status;
	
	private String createdBy;

	private String lastUpdatedBy;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date createdDateTime;

	@DateTimeFormat(pattern = "MM/dd/yyyy'T'HH:mm:ss.SSSZ")
	private Date lastUpdatedDateTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Binary getImage() {
		return image;
	}

	public void setImage(Binary image) {
		this.image = image;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BowlType getBowlType() {
		return bowlType;
	}

	public void setBowlType(BowlType bowlType) {
		this.bowlType = bowlType;
	}

	public float getMaxvolume() {
		return maxvolume;
	}

	public void setMaxvolume(float maxvolume) {
		this.maxvolume = maxvolume;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public float getMinvolume() {
		return minvolume;
	}

	public void setMinvolume(float minvolume) {
		this.minvolume = minvolume;
	}

	@Override
	public String toString() {
		return "Bowl [id=" + id + ", name=" + name + ", description=" + description + ", bowlType=" + bowlType
				+ ", maxvolume=" + maxvolume + ", minvolume=" + minvolume + ", status=" + status + ", createdBy="
				+ createdBy + ", lastUpdatedBy=" + lastUpdatedBy + ", createdDateTime=" + createdDateTime
				+ ", lastUpdatedDateTime=" + lastUpdatedDateTime + "]";
	}

}
