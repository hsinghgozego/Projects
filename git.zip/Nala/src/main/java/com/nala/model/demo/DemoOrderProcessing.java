package com.nala.model.demo;

import java.sql.Timestamp;
import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class DemoOrderProcessing {

	@Id
	private ObjectId id;

	private Integer orderId;

	private Integer recipeId;

	private String recipeName;

	private Integer stationId;

	private Integer burnerNo;

	private Integer robotId;

	private Integer recipeDetailsId;

	private Integer actionId;

	private Integer rackId;

	private Integer sectionId;

	private Integer bcWbc;

	private Integer fryerId;

	private Integer poolId;

	private Boolean IsCommonLiquidsDispensing;

	private Boolean IsSharingLiquidsDispensing;

	private Object sourceOrType;

	private Integer qty;

	private Integer time;

	private Integer flame;

	private Integer groupId;

	private Integer addressId;

	private Integer motorAddressId;

	private Integer flameAddressId;

	private Integer noOfRegistersToRead;

	private Integer noOfMotorRegistersToRead;

	private Integer status;

	private Date createdTime;

	private Date updatedTime;

	private Date doneTime;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getRecipeId() {
		return recipeId;
	}

	public void setRecipeId(Integer recipeId) {
		this.recipeId = recipeId;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public Integer getStationId() {
		return stationId;
	}

	public void setStationId(Integer stationId) {
		this.stationId = stationId;
	}

	public Integer getBurnerNo() {
		return burnerNo;
	}

	public void setBurnerNo(Integer burnerNo) {
		this.burnerNo = burnerNo;
	}

	public Integer getRobotId() {
		return robotId;
	}

	public void setRobotId(Integer robotId) {
		this.robotId = robotId;
	}

	public Integer getRecipeDetailsId() {
		return recipeDetailsId;
	}

	public void setRecipeDetailsId(Integer recipeDetailsId) {
		this.recipeDetailsId = recipeDetailsId;
	}

	public Integer getActionId() {
		return actionId;
	}

	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}

	public Integer getRackId() {
		return rackId;
	}

	public void setRackId(Integer rackId) {
		this.rackId = rackId;
	}

	public Integer getSectionId() {
		return sectionId;
	}

	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	public Integer getBcWbc() {
		return bcWbc;
	}

	public void setBcWbc(Integer bcWbc) {
		this.bcWbc = bcWbc;
	}

	public Integer getFryerId() {
		return fryerId;
	}

	public void setFryerId(Integer fryerId) {
		this.fryerId = fryerId;
	}

	public Integer getPoolId() {
		return poolId;
	}

	public void setPoolId(Integer poolId) {
		this.poolId = poolId;
	}

	public Boolean getIsCommonLiquidsDispensing() {
		return IsCommonLiquidsDispensing;
	}

	public void setIsCommonLiquidsDispensing(Boolean isCommonLiquidsDispensing) {
		IsCommonLiquidsDispensing = isCommonLiquidsDispensing;
	}

	public Boolean getIsSharingLiquidsDispensing() {
		return IsSharingLiquidsDispensing;
	}

	public void setIsSharingLiquidsDispensing(Boolean isSharingLiquidsDispensing) {
		IsSharingLiquidsDispensing = isSharingLiquidsDispensing;
	}

	public Object getSourceOrType() {
		return sourceOrType;
	}

	public void setSourceOrType(Object sourceOrType) {
		this.sourceOrType = sourceOrType;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public Integer getFlame() {
		return flame;
	}

	public void setFlame(Integer flame) {
		this.flame = flame;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public Integer getMotorAddressId() {
		return motorAddressId;
	}

	public void setMotorAddressId(Integer motorAddressId) {
		this.motorAddressId = motorAddressId;
	}

	public Integer getFlameAddressId() {
		return flameAddressId;
	}

	public void setFlameAddressId(Integer flameAddressId) {
		this.flameAddressId = flameAddressId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getNoOfRegistersToRead() {
		return noOfRegistersToRead;
	}

	public void setNoOfRegistersToRead(Integer noOfRegistersToRead) {
		this.noOfRegistersToRead = noOfRegistersToRead;
	}

	public Integer getNoOfMotorRegistersToRead() {
		return noOfMotorRegistersToRead;
	}

	public void setNoOfMotorRegistersToRead(Integer noOfMotorRegistersToRead) {
		this.noOfMotorRegistersToRead = noOfMotorRegistersToRead;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Date getDoneTime() {
		return doneTime;
	}

	public void setDoneTime(Date doneTime) {
		this.doneTime = doneTime;
	}

	@Override
	public String toString() {
		return "DemoOrderProcessing [id=" + id + ", orderId=" + orderId + ", recipeId=" + recipeId + ", recipeName="
				+ recipeName + ", stationId=" + stationId + ", burnerNo=" + burnerNo + ", robotId=" + robotId
				+ ", recipeDetailsId=" + recipeDetailsId + ", actionId=" + actionId + ", rackId=" + rackId
				+ ", sectionId=" + sectionId + ", bcWbc=" + bcWbc + ", fryerId=" + fryerId + ", poolId=" + poolId
				+ ", IsCommonLiquidsDispensing=" + IsCommonLiquidsDispensing + ", IsSharingLiquidsDispensing="
				+ IsSharingLiquidsDispensing + ", sourceOrType=" + sourceOrType + ", qty=" + qty + ", time=" + time
				+ ", flame=" + flame + ", groupId=" + groupId + ", addressId=" + addressId + ", motorAddressId="
				+ motorAddressId + ", flameAddressId=" + flameAddressId + ", noOfRegistersToRead=" + noOfRegistersToRead
				+ ", noOfMotorRegistersToRead=" + noOfMotorRegistersToRead + ", status=" + status + ", createdTime="
				+ createdTime + ", updatedTime=" + updatedTime + ", doneTime=" + doneTime + "]";
	}

}
