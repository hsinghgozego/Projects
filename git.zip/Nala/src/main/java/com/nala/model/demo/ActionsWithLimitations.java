package com.nala.model.demo;

import java.util.List;

public class ActionsWithLimitations {

	private List<Integer> actionIds;

	private List<Integer> vegCollection;

	private List<Integer> vegPickup;

	private List<Integer> spiceCollection;

	private List<Integer> spicePickup;

	private List<Integer> meatCollection;

	private List<Integer> meatPickup;

	private List<Integer> liquidDispensing;

	public List<Integer> getActionIds() {
		return actionIds;
	}

	public void setActionIds(List<Integer> actionIds) {
		this.actionIds = actionIds;
	}

	public List<Integer> getVegCollection() {
		return vegCollection;
	}

	public void setVegCollection(List<Integer> vegCollection) {
		this.vegCollection = vegCollection;
	}

	public List<Integer> getVegPickup() {
		return vegPickup;
	}

	public void setVegPickup(List<Integer> vegPickup) {
		this.vegPickup = vegPickup;
	}

	public List<Integer> getSpiceCollection() {
		return spiceCollection;
	}

	public void setSpiceCollection(List<Integer> spiceCollection) {
		this.spiceCollection = spiceCollection;
	}

	public List<Integer> getSpicePickup() {
		return spicePickup;
	}

	public void setSpicePickup(List<Integer> spicePickup) {
		this.spicePickup = spicePickup;
	}

	public List<Integer> getMeatCollection() {
		return meatCollection;
	}

	public void setMeatCollection(List<Integer> meatCollection) {
		this.meatCollection = meatCollection;
	}

	public List<Integer> getMeatPickup() {
		return meatPickup;
	}

	public void setMeatPickup(List<Integer> meatPickup) {
		this.meatPickup = meatPickup;
	}

	public List<Integer> getLiquidDispensing() {
		return liquidDispensing;
	}

	public void setLiquidDispensing(List<Integer> liquidDispensing) {
		this.liquidDispensing = liquidDispensing;
	}

	@Override
	public String toString() {
		return "ActionsWithLimitations [actionIds=" + actionIds + ", vegCollection=" + vegCollection + ", vegPickup="
				+ vegPickup + ", spiceCollection=" + spiceCollection + ", spicePickup=" + spicePickup
				+ ", meatCollection=" + meatCollection + ", meatPickup=" + meatPickup + ", liquidDispensing="
				+ liquidDispensing + "]";
	}

}
