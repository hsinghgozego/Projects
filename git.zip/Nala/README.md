# Nala
Nala Project

Controllers to do Curd Opertions
Easy Modbus Communication with the PLC devices
